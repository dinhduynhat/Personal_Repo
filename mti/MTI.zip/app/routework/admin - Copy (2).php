
Route::get('/', 'HomeController@home');
Route::post('login', 'LoginController@Login');
Route::get('forgot', 'LoginController@ForgotPassword');
Route::post('forgotpasswordprocess', 'LoginController@ForgotPasswordProcess');

//Create User - For Temporary, It was Accessible without Authentication
Route::get('createuser', 'LoginController@CreateUserLayout');
Route::post('createuserprocess', 'LoginController@CreateUserProcess');

//Screens Inside the Array can't be Accessed without Login
Route::group(array('before' => 'auth'), function()
{
//home

Route::get('home', 'HomeController@HomeLayout');
Route::get('payments', 'HomeController@HomeLayoutBack');


//Vehicle
Route::get('vehicle', 'VehicleController@VehicleLayout');
Route::post('vehicleprocess', 'VehicleController@VehicleProcess');
Route::get('vehicleedit/{data}', 'VehicleController@VehicleEdit');
Route::post('vehicleupdateprocess/{data}', 'VehicleController@VehicleupdateProcess');
Route::get('vehicledelete/{data}', 'VehicleController@VehicleDelete');
Route::post('vehicledeleteprocess', 'VehicleController@VehicleDeleteProcess');
Route::get('vehicletype', 'VehicleController@VehicletypeLayout');
Route::post('VehicleTypeNameprocess', 'VehicleController@VehicleTypeNameprocess');
Route::get('VehicleTypeedit/{data}', 'VehicleController@VehicleTypeEdit');
Route::post('VehicleTypeNameupdateprocess/{data}', 'VehicleController@VehicleTypeNameUpdateProcess');
Route::get('VehicleTypedelete/{data}', 'VehicleController@VehicleTypeDelete');
Route::post('VehicleTypedeleteprocess', 'VehicleController@VehicleTypeDeleteProcess');

//Route
Route::get('route', 'RouteController@RouteLayout');
Route::post('routeprocess', 'RouteController@RouteProcess');
Route::get('routeedit/{data}', 'RouteController@RouteEdit');
Route::post('routeupdateprocess/{data}', 'RouteController@RouteupdateProcess');
Route::get('routedelete/{data}', 'RouteController@RouteDelete');

//Destination
Route::get('destination', 'DestinationController@DestinationLayout');
Route::post('destinationprocess', 'DestinationController@DestinationProcess');
Route::get('destinationedit/{data}', 'DestinationController@DestinationEdit');
Route::post('destinationupdateprocess/{data}', 'DestinationController@DestinationupdateProcess');
Route::get('destinationdelete/{data}', 'DestinationController@DestinationDelete');

//Driver
Route::get('driver', 'DriverController@DriverLayout');
Route::post('driverprocess', 'DriverController@DriverProcess');
Route::get('driveredit/{data}', 'DriverController@DriverEdit');
Route::post('driverupdateprocess/{data}', 'DriverController@DriverupdateProcess');
Route::get('driverdelete/{data}', 'DriverController@DriverDelete');
Route::post('driverdeleteprocess', 'DriverController@DriverDeleteProcess');
//Timing
Route::get('timing', 'TimingController@TimingLayout');
Route::post('timingprocess', 'TimingController@TimingProcess');
Route::get('timingedit/{data}', 'TimingController@TimingEdit');
Route::post('timingupdateprocess/{data}', 'TimingController@TimingupdateProcess');
Route::get('timingdelete/{data}', 'TimingController@TimingDelete');
Route::post('timingdeleteprocess', 'TimingController@TimingDeleteProcess');

//Allocation
Route::get('allocation', 'AllocationController@AllocationLayout');
Route::post('allocationprocess', 'AllocationController@AllocationProcess');

//Classes
Route::get('class', 'ClassController@ClassLayout');
Route::post('classprocess', 'ClassController@ClassProcess');
Route::get('classedit/{data}', 'ClassController@ClassEdit');
Route::post('classupdateprocess/{data}', 'ClassController@ClassupdateProcess');
Route::get('classdelete/{data}', 'ClassController@ClassDelete');
Route::post('classiportprocess', 'ClassController@Importprocess');
Route::get('gradeexport', 'ClassController@GradeExportLayout');
Route::post('classdeleteprocess', 'ClassController@ClassDeleteProcess');
//Upload CSV
Route::get('uploadcsv', 'UploadController@UploadCsvLayout');
Route::post('uploadcsvprocess', 'UploadController@UploadCsvProcess');


//Settings
Route::get('changepassword', 'SettingsController@ChangePasswordLayout');
Route::post('changepasswordprocess', 'SettingsController@ChangePasswordProcess');
Route::get('notification', 'SettingsController@Notification');
Route::post('notificationprocess', 'SettingsController@NotificationProcess');
Route::get('editnotification/{data}', 'SettingsController@NotificationEdit');
Route::post('notificationeditprocess/{data}', 'SettingsController@NotificationEditProcess');
Route::get('deletenotification/{data}', 'SettingsController@DeleteNotification');

//Notification

Route::get('notifyparent', 'NotificationController@NotifyParent');
Route::get('notifyparentinstant', 'NotificationController@NotifyParentInstant');
Route::post('notifyparentinstantprocess', 'NotificationController@NotifyParentInstantProcess');
Route::get('notifyparentschool', 'NotificationController@NotifyParentSchool');
Route::get('notifydriver', 'NotificationController@NotifyDriver');
Route::get('notifydriverinstant', 'NotificationController@NotifyDriverInstant');
Route::post('notifyparentprocess', 'NotificationController@NotifyParentProcess');



Route::get('notifyschool', 'NotificationController@NotifySchool');
Route::post('notifyschoolprocess', 'NotificationController@NotifySchoolProcess');

Route::get('notifybuscompany', 'NotificationController@NotifyBus');
Route::post('notifybusprocess', 'NotificationController@NotifyBuslProcess');




Route::post('notifydriverprocess', 'NotificationController@NotifyDriverProcess');


//Profile
Route::get('profile', 'SettingsController@ProfileLayout');
Route::post('profileupdateprocess', 'SettingsController@ProfileUpdateProcess');

//School
Route::get('general', 'GeneralSettingsController@GeneralSettingsLayout');
Route::post('generalprocess', 'GeneralSettingsController@GeneralProcess');
Route::get('schooledit/{data}', 'GeneralSettingsController@SchoolEdit');
Route::post('schoolupdateprocess/{data}', 'GeneralSettingsController@Schoolupdateprocess');
Route::get('schooldelete/{data}', 'GeneralSettingsController@SchoolDelete');
Route::get('schoolimport', 'GeneralSettingsController@SchoolImportLayout');
Route::post('schoolimportprocess', 'GeneralSettingsController@Importprocess');
Route::get('schoolexport', 'GeneralSettingsController@SchoolExportLayout');
Route::post('schooldeleteprocess', 'GeneralSettingsController@Schooldeleteprocess');
Route::get('sendmail/{data}', 'GeneralSettingsController@Sendmail');
//batch
Route::get('batch', 'BatchController@BatchLayout');
Route::post('batchprocess', 'BatchController@Batchprocess');
Route::get('batchedit/{data}', 'BatchController@BatchEdit');
Route::post('batchupdateprocess/{data}', 'BatchController@BatchupdateProcess');

Route::get('batchdelete/{data}', 'BatchController@BatchDelete');


//gmap

Route::get('driversonmap', 'DriverController@DriversOnMap');


//pdf
Route::get('pdf', 'PDFController@PDF');
Route::get('exportstudentattendance/{data}/{data1}/{data2}', 'PDFController@ExportStudentAttendance');
Route::get('exportstudentattendanceprocess/{data}/{data1}/{data2}', 'PDFController@ExportStudentAttendanceLayout');

Route::get('exportstudentattendance1/{data}/{data1}/{data2}', 'PDFController@ExportStudentAttendance1');
Route::get('exportstudentattendanceprocess1/{data}/{data1}/{data2}', 'PDFController@ExportStudentAttendanceLayout1');


//batch
Route::get('gradesection', 'SectionController@StudentCategoryLayout');
Route::post('sectionprocess', 'SectionController@StudentCategoryprocess');
Route::get('sectionedit/{data}', 'SectionController@CategoryEdit');
Route::post('sectionupdateprocess/{data}', 'SectionController@StudentCategoryupdateprocess');
Route::get('sectiondelete/{data}', 'SectionController@Categorydelete');
Route::post('gradesectionimportprocess', 'SectionController@Importprocess');
Route::get('gradesectionexport', 'SectionController@GradesectionExportLayout');

//student
Route::get('studentadmission', 'StudentAdmissionController@StudentAdmissionSettingsLayout');
Route::post('studentadmissionprocess', 'StudentAdmissionController@StudentAdmissionProcess');
Route::get('studentattendence', 'StudentAdmissionController@StudentListSettingsLayout');
Route::post('searchstudentprocess', 'StudentAdmissionController@SearchStudentProcess');
Route::get('studentadmissionedit/{data}', 'StudentAdmissionController@StudentadmissionEdit');
Route::post('studentupdateprocess/{data}', 'StudentAdmissionController@Studentupdateprocess');
Route::get('studentadmissiondelete/{data}', 'StudentAdmissionController@Studentdelete');
Route::get('studentimport', 'StudentAdmissionController@StudentAdmissionImportLayout');
Route::post('importprocess', 'StudentAdmissionController@Importprocess');
Route::get('studentexport', 'StudentAdmissionController@StudentAdmissionExportLayout');
Route::post('transportstudentprocess', 'StudentAdmissionController@Transportstudentprocess');
Route::post('searchschoolprocess', 'StudentAdmissionController@Searchschoolprocess');
Route::post('studentdeleteprocess', 'StudentAdmissionController@Studentdeleteprocess');
Route::get('studentlisting', 'StudentAdmissionController@StudentListLayout');
Route::get('exportattendence', 'StudentAdmissionController@ExportAttendenceLayout');
#Route::get('exportbusattendence', 'StudentAdmissionController@ExportBusAttendenceLayout');
Route::get('exportbusattendence', 'StudentAdmissionController@ExportBusAttendenceLayoutGovt');
Route::get('exportbusattendenceschool', 'StudentAdmissionController@ExportBusAttendenceLayoutSchool');
Route::get('exportbusattendencegovt', 'StudentAdmissionController@ExportBusAttendenceLayoutGovt');
Route::post('exportbusattendencegovtresult', 'StudentAdmissionController@ExportBusAttendenceLayoutGovtResult');
Route::post('exportbusattendenceschoolresult', 'StudentAdmissionController@ExportBusAttendenceLayoutSchoolResult');
Route::get('exportattendenceprocess/{data}', 'StudentAdmissionController@ExportAttendenceProcess');
Route::post('sessionprocess', 'StudentAdmissionController@SessionProcess');
Route::post('exportattendenceprocesslist', 'StudentAdmissionController@ExportAttendenceProcessList');
Route::post('searchloadschoolprocess', 'StudentAdmissionController@SearchLoadSchoolProcess');
Route::post('studentadmissionmoreprocess', 'StudentAdmissionController@StudentAdmissionMoreProcess');
Route::get('studentadmissionmore/{data}', 'StudentAdmissionController@StudentAdmissionMore');
Route::post('studentadmissionmoreaddingprocess', 'StudentAdmissionController@StudentAdmissionMoreaddingProcess');
Route::post('studentadmissionupdatemoreprocess/{data}', 'StudentAdmissionController@StudentAdmissionupdateMoreProcess');
Route::get('studentexportbyschoolprocesslayout', 'StudentAdmissionController@StudentExportbySchoolProcessLayout');
Route::post('exportstudentdetailprocessbyschool', 'StudentAdmissionController@ExportStudentDetailProcessBySchool');
Route::post('studentcalenderprocess', 'StudentAdmissionController@StudentCalenderProcess');
Route::get('studentgrouplisting', 'StudentAdmissionController@StudentListgroupLayout');
Route::post('searchschoolgradeprocess', 'StudentAdmissionController@SearchSchoolGradeProcess');
//TransportController
Route::get('studentallocation', 'TransportController@StudentCalender');
Route::get('transportlist', 'TransportController@TransportList');
Route::get('addstudenttobus', 'TransportController@AddStudentToBus');
Route::get('generatemaproute', 'TransportController@GenerateMapRoute');
Route::post('searchschoolsearchdetails', 'TransportController@SearchSchoolDetails');
Route::post('searchstudentaddressdetails', 'TransportController@SearchStudentAddressDetails');
Route::post('filterchild', 'TransportController@FilterChild');
Route::post('filterchildlocation', 'TransportController@FilterChildLocation');
Route::post('movechildtoorder', 'TransportController@MoveChildtoOrder');
Route::post('removechildtoorder', 'TransportController@RemoveChildtoOrder');
Route::post('generateroutemap', 'TransportController@GenerateRouteMap');
Route::post('saveroute', 'TransportController@SaveRoute');
Route::post('buslist', 'TransportController@BusList');
Route::post('searchdriverlist', 'TransportController@SearchDriverList');
Route::post('viewtriplist', 'TransportController@ViewTripList');
Route::post('addstudentdatadetails', 'TransportController@AddStudentdataDetails');
Route::get('regeneratemaproute', 'TransportController@ReGenerateMapRoute');
Route::get('removeregeneratemaproute', 'TransportController@RemoveReGenerateMapRoute');
Route::post('postaddstudentdata', 'TransportController@PostAddStudentData');
Route::post('updateroute', 'TransportController@UpdateRoute');
Route::post('removestudentdatadetails', 'TransportController@RemoveStudentDataDetails');

//languagetest
Route::get('languagesection', 'LanguageController@LanguageLayout');
Route::post('languageprocess', 'LanguageController@Languageprocess');
Route::get('languageedit/{data}', 'LanguageController@LanguageEdit');
Route::post('languageupdateprocess/{data}', 'LanguageController@Languageupdateprocess');
Route::get('languagedelete/{data}', 'LanguageController@Languagedelete');
Route::post('languageimportprocess', 'LanguageController@Importprocess');
Route::get('languageexport', 'LanguageController@LanguageExportLayout');

//Government Entity
Route::get('addgovtentity', 'GovernmentEntityController@AddGovernmentEntity');
Route::post('addgovtentityprocess', 'GovernmentEntityController@AddGovernmentEntityProcess');
Route::get('listgovtentity', 'GovernmentEntityController@ListGovernmentEntity');
Route::get('govtentityedit/{data}', 'GovernmentEntityController@EditGovernmentEntity');
Route::post('govtentityupdateprocess/{data}', 'GovernmentEntityController@EditGovernmentEntityProcess');
Route::get('govtentitydelete/{data}', 'GovernmentEntityController@DeleteGovernmentEntity');
Route::get('feepayment', 'GovernmentEntityController@FeePayment');
Route::post('feepaymentprocess', 'GovernmentEntityController@FeePaymentProcess');
Route::get('feepaymentedit', 'GovernmentEntityController@FeePaymentEdit');
Route::post('studentfeedetails', 'GovernmentEntityController@StudentFeeDetails');
Route::get('paymentlist', 'GovernmentEntityController@FeePaymentList');
Route::post('acceptpayment', 'GovernmentEntityController@AcceptPayment');

Route::get('editfeepayment', 'GovernmentEntityController@EditFeePayments');
Route::get('listfeepayment', 'GovernmentEntityController@ListFeePayment');
Route::get('listfeepaymentge', 'GovernmentEntityController@ListFeePaymentGE');
Route::post('editpaymentlisting', 'GovernmentEntityController@ListPaymentEdit');
Route::post('editpaymentlistingadmin', 'GovernmentEntityController@ListPaymentEditAdmin');
Route::get('updatepayment/{data}', 'GovernmentEntityController@UpdatePayment');
Route::post('paymentupdateprocess', 'GovernmentEntityController@UpdatePaymentProcess');




Route::get('editapproval', 'ParentController@EditApproval');
Route::get('editapprovalprocess/{data}', 'ParentController@EditApprovalLayout');
Route::get('editapprovalprocessdelete/{data}', 'ParentController@EditApprovalDelete');
Route::post('editparentapprove/{data}', 'ParentController@EditApprovalProcess');


//buscompanycontroller
Route::get('buscompanylayout', 'BusCompanyController@BuscompanyLayout');
Route::post('buscompanyprocess', 'BusCompanyController@BusCompanyProcess');
Route::get('busedit/{data}', 'BusCompanyController@BusEdit');
Route::post('busupdateprocess/{data}', 'BusCompanyController@BusUpdateProcess');
Route::get('busdelete/{data}', 'BusCompanyController@BusDelete');
Route::post('busdeleteprocess', 'BusCompanyController@BusDeleteProcess');
#editpaymentlist

//Logout Screen at Last
Route::get('logout', 'LoginController@Logout');
});

Route::get('pdf', 'PDFController@pdf');

Route::post('notifyparentprocesscron', 'NotificationController@NotifyParentProcessCron');
Route::post('notifydriverprocesscron', 'NotificationController@NotifyDriverProcessCron');


