<?php
class TimeZoneModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'timezone';  
    protected $fillable = array('tmezone');
    
    public $timestamps = false;
	
}