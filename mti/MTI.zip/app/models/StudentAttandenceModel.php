<?php

class StudentAttandenceModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'studentattandence';  

    protected $fillable = array('studentid','toschool','fromschool','comment','date','inserttime','updatetime');  

    

    public $timestamps = false;

	

}