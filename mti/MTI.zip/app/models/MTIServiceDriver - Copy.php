<?php
class MTIServiceDriver extends Eloquent
{
    protected $table = 'driver';
    protected $fillable = array('FirstName', 'LastName', 'Email', 'Mobile', 'House', 'Apartment', 'Street', 'City', 'State', 'Pincode','Generatekey');
    public $timestamps = false;
    protected $primaryKey = 'AutoID';
    

	 
        public static $updaterule = array(
        'Name'=>  array('required'),
        'Mobile'=>  array('required'),
        'GcmId'=>  array('required'),
        'DeviceId'=>  array('required')
        );

        public static $driverauthrule = array(
        'DeviceId'=>  array('required'),
        'UniqueCode'=>  array('required')
        );

        public static $driverupdaterule = array(
        'DriverName'=>  array('required'),       
        'Mobile'=>  array('required'),
        'Email'=>  array('required'),
        'Address'=>  array('required')
        );
		
        		
}