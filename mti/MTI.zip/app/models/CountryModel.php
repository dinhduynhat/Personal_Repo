<?php
class CountryModel extends Eloquent
{
    protected $primaryKey = 'idCountry';
    protected $table = 'countries';  
    protected $fillable = array('countryCode', 'countryName', 'currencyCode');
    
    public $timestamps = false;
	
}