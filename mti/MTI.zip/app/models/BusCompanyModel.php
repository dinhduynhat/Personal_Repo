<?php

class BusCompanyModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'buscompany';  

    protected $fillable = array('Companyname','Address','Phone','website','Contactpersonname','Email','Mobile','password','Status', 'lat', 'lon');

    

    public $timestamps = false;

	



	 public static $rules = array(

        'Companyname' =>   'required|unique:buscompany',
        'Address' =>  array('required'),		
		'Email' => array('email','required', 'unique:users,email','unique:buscompany'), 
		'Mobile' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
		'Phone' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
        #'Mobile' =>array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
		#'Phone' =>  array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
        'Contactpersonname' =>  array('required'),
		 'password' =>  array('required'),
		 'website' =>  array('required'),
        );

		

}