<?php
class DriverModel extends Eloquent
{
    
    protected $primaryKey = 'AutoID';
    protected $created_at = 'CreatedAt';
    protected $updated_at = 'UpdatedAt';
    protected $table = 'driver';
    protected $guarded = array('DriverName');
    protected $fillable = array('DriverName', 'Age', 'Address', 'LicenseNumber', 'DriverName', 'DateOfBirth', 'LicenseExpiry', 'DriverPhoto', 'LicensePhoto','LisenceType','Mobile','Email','Company','UniqueCode');
    
    public $timestamps = true;
	
    public function setDateOfBirthAttribute($value)
    {
        $this->attributes['DateOfBirth'] = date("Y-m-d", strtotime($value));
    }
  
    
    public function setDriverPhotoAttribute($DriverPhoto)
    {   
        if($DriverPhoto)
        {
		echo Input::file('DriverPhoto');
		
        $this->attributes['DriverPhoto'] = Input::get('Mobile') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension();
        Input::file('DriverPhoto')->move('assets/uploads/driver/', Input::get('Mobile') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension());
        }
    }
    
    public function setLicensePhotoAttribute($LicensePhoto)
    {
        if($LicensePhoto)
        {
        $this->attributes['LicensePhoto'] = Input::get('Mobile') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension();
        Input::file('LicensePhoto')->move('assets/uploads/driver/', Input::get('Mobile') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension());
        }
    }
    
    public static $rules = array(
        'DriverName' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        //'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
       // 'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000',
		//'LisenceType' => 'required',
        'Mobile'=> array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),
#		'Mobile' => array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
		'Email' => array('required','unique:driver','email'),
        );
		public static $updaterules = array(
        'DriverName' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        //'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
       // 'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000',
		///'LisenceType' => 'required',
		'Mobile' => array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),        
);
    
}