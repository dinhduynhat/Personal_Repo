<?php
class ParentModel extends Eloquent
{
    protected $table = 'parent';
    protected $fillable = array('FirstName', 'LastName', 'Email', 'Mobile', 'House', 'Apartment', 'Street', 'City', 'State', 'Pincode','Generatekey');
    public $timestamps = false;	

	 public static $parentupdaterule = array(
        'FirstName'=>  array('required'),		
		'LastName'=>  array('required'),
		'Mail'=>  array('required'),
        'Mobile'=>  array('required'),			
		'House'=>  array('required'),		
		'Apartment'=>  array('required'),
		'Street'=>  'required|numeric',			
		'City'=>  array('required'),			
		'State'=>  array('required'),		
		'Pincode'=>  array('required')
        );

	 	public static $parentregisterrule = array(
        'DeviceId'=>  array('required'),
        'GcmId'=>  array('required')
        );

        	public static $notificationrule = array(
        'EmailNotification'=>  array('required'),
        'MobileNotification'=>  array('required')
        );

		
		
}