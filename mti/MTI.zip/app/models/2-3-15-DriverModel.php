<?php
class DriverModel extends Eloquent
{
    
    protected $primaryKey = 'AutoID';
    protected $created_at = 'CreatedAt';
    protected $updated_at = 'UpdatedAt';
    protected $table = 'driver';
    protected $guarded = array('DriverName');
    protected $fillable = array('DriverName', 'Age', 'Address', 'LicenseNumber', 'DriverName', 'DateOfBirth', 'LicenseExpiry', 'DriverPhoto', 'LicensePhoto','LisenceType','Mobile');
    
    public $timestamps = true;
	
    public function setDateOfBirthAttribute($value)
    {
        $this->attributes['DateOfBirth'] = date("Y-m-d", strtotime($value));
    }
    public function setLicenseExpiryAttribute($value)
    {
        $this->attributes['LicenseExpiry'] = date("Y-m-d", strtotime($value));
    }
    
    public function setDriverPhotoAttribute($DriverPhoto)
    {   
        if($DriverPhoto)
        {
        $this->attributes['DriverPhoto'] = Input::get('LicenseNumber') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension();
        Input::file('DriverPhoto')->move('assets/uploads/driver/', Input::get('LicenseNumber') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension());
        }
    }
    
    public function setLicensePhotoAttribute($LicensePhoto)
    {
        if($LicensePhoto)
        {
        $this->attributes['LicensePhoto'] = Input::get('LicenseNumber') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension();
        Input::file('LicensePhoto')->move('assets/uploads/driver/', Input::get('LicenseNumber') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension());
        }
    }
    
    public static $rules = array(
        'DriverName' =>  array('required', 'unique:driver', 'regex:/^[\w.]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
        'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000',
		'LisenceType' => 'required',
		'Mobile' => 'required|integer',
        );
		public static $updaterules = array(
        'DriverName' =>  array('required', 'regex:/^[\w.]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
        'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000',
		'LisenceType' => 'required',
		'Mobile' => 'required|integer',
        );
    
}