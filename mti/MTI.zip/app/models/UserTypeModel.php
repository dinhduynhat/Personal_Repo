<?php
class UserTypeModel extends Eloquent
{
    
    protected $primaryKey = 'AutoID';
    protected $table = 'usertype';
    protected $fillable = array('UserTypeID','UserType',);
    
    public $timestamps = true;
    
    
    
	
    
}