<?php
class SchoolNotificationHistoryModel extends Eloquent
{
    
    protected $table = 'school_notification_history';
    
    protected $fillable = array('NotificationName', 'NotificationMessage');

    public static $rule = array(
    'NotificationName'=>  array('required', 'unique:notification'),
    'NotificationMessage'=>  array('required', 'unique:notification')
        );

    

}