<?php
class VehicleModel extends Eloquent
{
    protected $primaryKey = 'AutoID';
    protected $table = 'vehicle';
    protected $guarded = array('VehicleCode');
    protected $fillable = array('VehicleCode', 'NumberSeats', 'VehicleNumber', 'MaximumAllowed',  'Phone', 'Insurance', 'VehicleType', 'Address', 'Tax', 'InsurancePhoto', 'RcPhoto','filledpickupseats','filleddropoffseats','Company','Rate');
    
    public $timestamps = false;
    
    public function setInsurancePhotoAttribute($InsurancePhoto)
    {
        if($InsurancePhoto)
        {    
        $this->attributes['InsurancePhoto'] = Input::get('VehicleCode') . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalExtension();
        Input::file('InsurancePhoto')->move('assets/uploads/vehicle/', Input::get('VehicleCode') . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalExtension());
        }
    }
    
    public function setRCPhotoAttribute($RcPhoto)
    {
        if($RcPhoto)
        {            
        $this->attributes['RcPhoto'] = Input::get('VehicleCode') . '-RcPhoto.' . Input::file('RcPhoto')->getClientOriginalExtension();
        Input::file('RcPhoto')->move('assets/uploads/vehicle/', Input::get('VehicleCode') . '-RcPhoto.' . Input::file('RcPhoto')->getClientOriginalExtension());
        }
    }
    
    public static $rules = array(
        'VehicleNumber' =>  array('required', 'unique:vehicle','Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
        'NumberSeats' => 'required|integer', 
        'VehicleType' => 'required',         
        'VehicleCode' => 'required|unique:vehicle',
        'InsurancePhoto' => 'image|max:2000',
        'RcPhoto' => 'image|max:2000',
		'Company' => 'required',  
		
		
        );
		public static $updaterules = array(
        'VehicleNumber' =>  array('required','Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
        'NumberSeats' => 'required|integer', 
        'VehicleType' => 'required',         
        'VehicleCode' => 'required',
        'InsurancePhoto' => 'image|max:2000',
        'RcPhoto' => 'image|max:2000',
        );
}