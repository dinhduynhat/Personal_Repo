<?php
class GovernmentEntityModel extends Eloquent
{
    
    protected $primaryKey = 'id';
    protected $created_at = 'CreatedAt';
    protected $updated_at = 'UpdatedAt';
    protected $table = 'govtentityinformation';
    protected $guarded = array('DriverName');
    protected $fillable = array('GovernmentEntityName', 'GovernmentEntityAddress', 'GovernmentEntityEmail', 'GovernmentEntityPhone', 'GovernmentEntityMobile', 'GovernmentEntityContactPerson', 'Password');
    
    public $timestamps = true;


     public function setpasswordAttribute($value)
    {
        
        $this->attributes['Password'] = Hash::make($value); 
        #$this->attributes['password'] = '$2y$10$8x./aHlA7aqgU6/kEidJHeYlssNfIY6mqKoJAPzNMd1T3j5KVQazS'; 
        
        
    }


	
    public function setDateOfBirthAttribute($value)
    {
        $this->attributes['DateOfBirth'] = date("Y-m-d", strtotime($value));
    }
    public function setLicenseExpiryAttribute($value)
    {
        $this->attributes['LicenseExpiry'] = date("Y-m-d", strtotime($value));
    }
    
    public function setDriverPhotoAttribute($DriverPhoto)
    {   
        if($DriverPhoto)
        {
        $this->attributes['DriverPhoto'] = Input::get('LicenseNumber') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension();
        Input::file('DriverPhoto')->move('assets/uploads/driver/', Input::get('LicenseNumber') . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalExtension());
        }
    }
    
    public function setLicensePhotoAttribute($LicensePhoto)
    {
        if($LicensePhoto)
        {
        $this->attributes['LicensePhoto'] = Input::get('LicenseNumber') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension();
        Input::file('LicensePhoto')->move('assets/uploads/driver/', Input::get('LicenseNumber') . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalExtension());
        }
    }
    
    public static $rules = array(
        'GovernmentEntityName' =>  array('required', 'unique:govtentityinformation'),
        'GovernmentEntityAddress' => 'required', 
        'GovernmentEntityEmail' => array('required', 'unique:users,email','unique:govtentityinformation'), 
        'Password' => 'required', 
        'GovernmentEntityPhone' => 'required'
        
        );



public static $updaterule = array(
        'GovernmentEntityName' =>  array('required',  'regex:/^[\w. ]+$/'),
        'GovernmentEntityAddress' => 'required', 
        'GovernmentEntityEmail' => array('required', 'unique:users,email','unique:govtentityinformation'), 
        'Password' => 'required', 
        'GovernmentEntityPhone' => 'required'
        
        );

		public static $updaterules = array(
        'DriverName' =>  array('required', 'regex:/^[\w. ]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
        'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|mimes:jpg,png,gif|max:5000',
        'LicensePhoto' => 'image|mimes:jpg,png,gif|max:5000'
        );
    
}