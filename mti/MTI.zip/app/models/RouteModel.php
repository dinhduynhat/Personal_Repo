<?php
class RouteModel extends Eloquent
{
    protected $primaryKey = 'AutoID';
    protected $table = 'route';
    protected $guarded = array('RouteName');
    protected $fillable = array('RouteName', 'RouteDescription', 'NumberStops', 'VehicleCode');
    
    public $timestamps = false;
    
    public static $rules = array(
    	'RouteName' =>  array('required', 'unique:route','regex:/^[\w.]+$/'),
    	'NumberStops' => 'required|integer', 
    	'VehicleCode' => 'required|unique:route');
		public static $updaterules = array(
    	'RouteName' =>  array('required', 'regex:/^[\w.]+$/'),
    	'NumberStops' => 'required|integer', 
    	'VehicleCode' => 'required');
}