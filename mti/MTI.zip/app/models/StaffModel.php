<?php
class StaffModel extends Eloquent
{
    
    protected $table = 'staff';
    
    protected $fillable = array('BusCompany', 'Name', 'Email', 'Phone', 'Address',

	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'
	
	);
    
    
    
    
    
    public static $rules = array(
        'BusCompany' =>  array('required'),
		'Name' =>  array('required', 'unique:staff,Name'),
        'Email' =>  array('required', 'unique:users,email', 'email'),
        'Phone' => 'required',
        'Address' => 'required',
        );
		
		
		
}