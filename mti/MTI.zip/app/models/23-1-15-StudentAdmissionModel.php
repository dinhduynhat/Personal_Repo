<?php
class StudentAdmissionModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'studentinformation';  
    protected $fillable = array('SchoolName','StudentCourse','StudentBatch','StudentSection','StudentLanguage','PersonalFirstName','PersonalMiddleName','PersonalLastName','Age','Gender','ContactPresentAddress','ContactCity','ContactState','ContactPin','ContactCountry','ContactPhone','ContactMobile','ContactUploadLogo','GuardianFirstName','GuardianMiddleName','GuardianLastName','GuardianPresentAddress','GuardianCity','GuardianState','GuardianPin','GuardianCountry','GuardianPhone','GuardianMobile','pickupoption','importfile','DropTime','StartTime');
    
    public $timestamps = false;	
	
	 public function batchresult(){ 
        return $this->belongsTo('ClassModel', 'StudentCourse');
    }
	
	 public function schollresult(){ 
        return $this->belongsTo('GeneralSettingModel', 'SchoolName');
    }
	
	public function setContactUploadLogoAttribute($ContactUploadLogo)
    {
        if($ContactUploadLogo)
        {    
        $this->attributes['ContactUploadLogo'] = Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension();
        Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/', Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension());
        }
    }
	 public static $rules = array(
        'SchoolName'=>  array('required'),		
		'StudentCourse'=>  array('required'),
		'StudentBatch'=>  array('required'),	
        'StudentSection'=>  array('required'),	
        'StudentLanguage'=>  array('required'),			
		'PersonalFirstName'=>  array('required'),		
		'PersonalLastName'=>  array('required'),
		'Age'=>  array('required'),			
		'Gender'=>  array('required'),			
		'ContactPresentAddress'=>  array('required'),		
		'ContactCity'=>  array('required'),
		'ContactState'=>  array('required'),
		'ContactPin'=>  array('required'),
		'ContactCountry'=>  array('required'),
		'ContactPhone'=>  array('required'),
		'ContactMobile'=>  array('required'),		
		'ContactUploadLogo'=> 'image',	
		'GuardianFirstName'=>  array('required'),		
		'GuardianLastName'=>  array('required'),				
		'GuardianPresentAddress'=>  array('required'),		
		'GuardianCity'=>  array('required'),
		'GuardianState'=>  array('required'),
		'GuardianPin'=>  array('required'),
		'GuardianCountry'=>  array('required'),
		'GuardianPhone'=>  array('required'),
		'GuardianMobile'=>  array('required'),	
		'StartTime'=>  array('required'),	
		'DropTime'=>  array('required'),	
        );
		
		 public static $importrules = array(
        'importfile'=>  'required|mimes:xls,xlsx',	
			
        );
		
}