<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $primaryKey = 'id';
	protected $table = 'users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');
	protected $created_at = 'CreatedAt';
    protected $updated_at = 'UpdatedAt';

        public function setpasswordAttribute($value)
    {
        $this->attributes['password'] = Hash::make($value);
    }

   

    public static $rules = array(
        'UserName' =>  array('required', 'unique:users','regex:/^./'),
        'password' => 'required'
        );
		 public static $updaterules = array(
        'UserName' =>  array('regex:/^./'),
       
        );
      public static $loginrules = array(     
        'UserName' => 'required',         
        'password' => 'required', 
		'usertype' => 'required'
		
        );

    public static $rulespwd = array('OldPassword' => 'required|pwdvalidation',
        'NewPassword' => 'required|confirmed|alphaNum|min:5|max:10',
        'NewPassword_confirmation' => 'required',
        );
 

    protected $guarded = array('UserName');
    protected $fillable = array('UserName', 'password','FirstName', 'LastName','email','usertype','schoolid');

	

	

}
