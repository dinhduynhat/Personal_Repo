<?php

class ProfileModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'users';  

    protected $fillable = array('UserName', 'FirstName', 'LastName', 'email','password', 'Photo', 'remember_token', 'LastLogin','Hashkey', 'created_at', 'CreatedBy', 'updated_at','UpdatedBy', 'ActiveStatus', 'IsDeletable');

    

    public $timestamps = false;

	public function setPhotoAttribute($Photo)

    {

        if($Photo)

        {    

        $this->attributes['Photo'] = '-Photo.' . Input::file('Photo')->getClientOriginalExtension();

        Input::file('Photo')->move('assets/uploads/profilephoto/', '-Photo.' . Input::file('Photo')->getClientOriginalExtension());

        }

    }

	

    public static $rules = array(

    	'FirstName' => 'required',

    	'Photo' => 'image',

    	'email' => 'required',  

        );

		

}