<?php
class StaffModel extends Eloquent
{
    
    protected $table = 'staff';
    
    protected $fillable = array('BusCompany', 'Name', 'Email', 'Phone', 'Address', 'SchoolAccess','StudentAccess','TransportAccess','ReportAccess','StaffAccess', 'NotificationAccess');
    
    
    
    
    
    public static $rules = array(
        'BusCompany' =>  array('required'),
        'Name' => 'required', 
        'Email' => 'required',         
        'Phone' => 'required',
        'Address' => 'required',
        );
		
}