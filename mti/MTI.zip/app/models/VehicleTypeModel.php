<?php
class VehicleTypeModel extends Eloquent
{
    protected $primaryKey = 'AutoID';
    protected $table = 'vehicletype';
    public $timestamps = false;
	protected $fillable = array('VehicleTypeName', 'Company','triptype');
}
