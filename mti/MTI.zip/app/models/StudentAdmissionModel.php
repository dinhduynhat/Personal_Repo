<?php

class StudentAdmissionModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'studentinformation';  

    #protected $fillable = array('SchoolName','StudentCourse','StudentBatch','StudentLanguage','PersonalFirstName','PersonalMiddleName','PersonalLastName','Age','Gender','Street','ContactCity','ContactState','ContactPin','ContactPhone','ContactMobile','ContactUploadLogo','GuardianFirstName','GuardianMiddleName','GuardianLastName','importfile','transportdate','transporttake','comment','DateOfBirth','EntranceDate','ExitDate','MondayInTime','MondayoutTime','TuesdayInTime','TuesdayoutTime','WednesdayInTime','WednesdayoutTime','ThursdayInTime','ThursdayoutTime','FridayInTime','FridayoutTime','Apartment','House','timingoption','Weekdaysfrom','Weekdaysto','weekInTime','weekoutTime','Generatekey','TripType','parentid','GuardianMail','fromTripType','ContactFirstName','ContactMiddleName','ContactLastName','ContactpersonPhone','ContactpersonMobile','lat','long','tripcom','Company');
	protected $fillable = array('SchoolName','StudentCourse','Address','StudentBatch','StudentLanguage','PersonalFirstName','PersonalMiddleName','PersonalLastName','Age','Gender','ContactPin','ContactPhone','ContactMobile','ContactUploadLogo','GuardianFirstName','GuardianMiddleName','GuardianLastName','importfile','transportdate','transporttake','comment','DateOfBirth','EntranceDate','ExitDate','MondayInTime','MondayoutTime','TuesdayInTime','TuesdayoutTime','WednesdayInTime','WednesdayoutTime','ThursdayInTime','ThursdayoutTime','FridayInTime','FridayoutTime','timingoption','Weekdaysfrom','Weekdaysto','weekInTime','weekoutTime','Generatekey','TripType','parentid','GuardianMail','fromTripType','ContactFirstName','ContactMiddleName','ContactLastName','ContactpersonPhone','ContactpersonMobile','lat','long','tripcom','Company','SchoolAddress');

#'DateOfBirth','EntranceDate','ExitDate'
   

     public function setDateOfBirthAttribute($value)
    {
        $this->attributes['DateOfBirth'] = date("Y-m-d", strtotime($value) );
    }

     

    public function setEntranceDateAttribute($value)
    {
        $this->attributes['EntranceDate'] = date("Y-m-d", strtotime($value) );
    }

    public function setExitDateAttribute($value)
    {
        $this->attributes['ExitDate'] = date("Y-m-d", strtotime($value) );
    }



    public $timestamps = false;	

	

	 public function batchresult(){ 

        return $this->belongsTo('ClassModel', 'StudentCourse');

    }

	

	 public function schollresult(){ 

        return $this->belongsTo('GeneralSettingModel', 'SchoolName');

    }

	public function attendance()
    {
        // Assuming a one-to-one relationship
        return $this->hasOne('StudentAttandenceModel','studentid');
    }

	public function setContactUploadLogoAttribute($ContactUploadLogo)

    {

        if($ContactUploadLogo)

        {    

        $this->attributes['ContactUploadLogo'] = Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension();

        Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/', Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension());

        }

    }

	 public static $rules = array(

        'SchoolName'=>  array('required'),		

		'StudentCourse'=>  array('required'),

		'StudentBatch'=>  array('required'),

        'Company'=>  array('required'),		

		'PersonalFirstName'=>  array('required'),		

		'PersonalLastName'=>  array('required'),
		'Address'=>  array('required'),

		'Age'=> array('required','numeric'),			

		'Gender'=>  array('required'),			

		// 'Street'=>  array('required'),		

		// 'ContactCity'=>  array('required'),

		// 'ContactState'=>  array('required'),

		// 'ContactPin'=>  array('regex:/(^\d{5}$)|(^\d{5}-\d{4}$)/'),

		'ContactPhone'=> array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),

		'ContactUploadLogo'=> 'image',	

		'GuardianFirstName'=>  array('required'),
		
        'DateOfBirth'=>  array('required'),	

        'EntranceDate'=>  array('required'),	

        'ExitDate'=>  array('required'),		

		'ContactMobile'=> array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),
        'TripType'=>  array('required'),
          'GuardianMail' =>  array('required','email'),   
          'ContactFirstName' =>  'required', 
           'ContactpersonPhone' =>  array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'), 
              'ContactpersonMobile' =>  array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),    
        );

		

		 public static $importrules = array(

        'importfile'=>  'required|mimes:xlsx',	

			

        );

		

		

}