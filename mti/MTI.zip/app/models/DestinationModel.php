<?php
class DestinationModel extends Eloquent
{
    
    protected $primaryKey = 'AutoID';
    protected $table = 'destination';
    protected $guarded = array('RouteName');
    protected $fillable = array('RouteName', 'Destination', 'MonthlyCost');
    
    public $timestamps = false;
    
    public static $rules = array(
        'RouteName' =>  array('required', 'unique:destination','regex:/^[\w.]+$/'),
        'Destination' =>  array('required', 'regex:/^[\w.]+$/'), #Need to confirm RouteName or Destination or both, which  is Unique
    	'MonthlyCost' => 'required'
    	);
	 public static $updaterules = array(
        'RouteName' =>  array('required', 'regex:/^[\w.]+$/'),
        'Destination' =>  array('required', 'regex:/^[\w.]+$/'), #Need to confirm RouteName or Destination or both, which  is Unique
    	'MonthlyCost' => 'required'
    	);
    
}
