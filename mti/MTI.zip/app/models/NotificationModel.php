<?php
class NotificationModel extends Eloquent
{
    
    protected $table = 'notification';
    
    protected $fillable = array('NotificationName', 'NotificationMessage');

    public static $rule = array(
    'NotificationName'=>  array('required', 'unique:notification'),
    'NotificationMessage'=>  array('required', 'unique:notification')
        );

	public static $rules = array(
    'schoolid'=>  array('required'),
    'PayMonth'=>  array('required'),
    'PayYear'=>  array('required')  
        );
    

}