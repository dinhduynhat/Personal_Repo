<?php
class TariffTypeModel extends Eloquent
{
    
    protected $table = 'triptype';
    public $timestamps = false;
	protected $fillable = array('triptype', 'charge','company', 'tripway');
	
	    public static $rules = array(
        'triptype' =>  array('required', 'unique:triptype,triptype'),
		'charge' =>  array('required')
        );
		
}
