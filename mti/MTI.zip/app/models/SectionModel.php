<?php
class SectionModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'gradesection';  
    protected $fillable = array('Section','importfile');
    
    public $timestamps = false;
	
	public static $rules = array(     
        'Section' => 'required|unique:gradesection'         
     
        );
		public static $updaterules = array(
        'Section' => 'required'         
       
        );
		public static $importrules = array(
        'importfile'=>  'required|mimes:xlsx',	
			
        );
}