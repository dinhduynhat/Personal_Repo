<?php
class LanguageModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'language';  
    protected $fillable = array('language','importfile');
    
    public $timestamps = false;
	
	public static $rules = array(     
        'language' => 'required|unique:language'         
     
        );
		public static $updaterules = array(
        'language' => 'required'         
       
        );
		public static $importrules = array(
        'importfile'=>  'required|mimes:xlsx',	
			
        );	
}