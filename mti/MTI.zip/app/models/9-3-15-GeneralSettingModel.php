<?php

class GeneralSettingModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'schoolinformation';  

    protected $fillable = array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','Country','UploadLogo','Username','Password','Status','importfile','Schoolloginstatus','SchoolInTime','SchooloutTime');

    

    public $timestamps = false;

	

	public function StudentAdmissionModel(){ 

        return $this->belongsTo('StudentAdmissionModel', 'id');

    }

	

	public function udata(){ 

        return $this->belongsTo('User', 'schoolid');

    }

	

	public function setUploadLogoAttribute($UploadLogo)

    {

        if($UploadLogo)

        {    

        $this->attributes['UploadLogo'] = Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension();

        Input::file('UploadLogo')->move('assets/uploads/uploadschoollogo/', Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension());

        }

    }

	 public static $rules = array(

        'SchoolName' =>   'required|unique:schoolinformation',         

        'SchoolAddress' =>  array('required'),

		#'SchoolEmail' =>  'required|unique:schoolinformation',      
		'SchoolEmail' => array('required', 'unique:users,email','unique:schoolinformation'), 

		'SchoolPhone' =>  'required|integer',

		//'SchoolMobile' =>  array('required'),

		//'AdminContactPerson' =>  array('required'),		

		//'Country' =>  array('required'),		

	     'UploadLogo' => 'image',

		 //'UserName' =>  array('required'),		

		 'password' =>  array('required'),
		 'SchoolInTime' =>  array('required'),
		 'SchooloutTime' =>  array('required'),

        );

		public static $updaterules = array(

        'SchoolName' =>  array('required'),

        'SchoolAddress' =>  array('required'),

		//'SchoolEmail' =>  array('required'),

		'SchoolPhone' =>  'required|integer',

		//'SchoolMobile' =>  array('required'),

		//'AdminContactPerson' =>  array('required'),		

		//'Country' =>  array('required'),		

	     'UploadLogo' => 'image',

		

        );

		 public static $importrules = array(

        'importfile'=>  'required|mimes:xlsx',	

			

        );

}