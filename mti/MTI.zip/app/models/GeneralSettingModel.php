<?php

class GeneralSettingModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'schoolinformation';  

    protected $fillable = array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','UploadLogo','Username','Password','Status','importfile','Schoolloginstatus','SchoolInTime','SchooloutTime','lat','lon','GradeFrom','GradeTo');

    

    public $timestamps = false;

	

	public function StudentAdmissionModel(){ 

        return $this->belongsTo('StudentAdmissionModel', 'id');

    }

	

	public function udata(){ 

        return $this->belongsTo('User', 'schoolid');

    }

	

	public function setUploadLogoAttribute($UploadLogo)

    {

        if($UploadLogo)

        {    

        $this->attributes['UploadLogo'] = Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension();

        Input::file('UploadLogo')->move('assets/uploads/uploadschoollogo/', Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension());

        }

    }

	 public static $rules = array(

        'SchoolName' =>   'required|unique:schoolinformation',         

        'SchoolAddress' =>  array('required'),
		'GradeFrom' =>  array('required'),
		'GradeTo' =>  array('required'),

		#'SchoolEmail' =>  'required|unique:schoolinformation',      
		'SchoolEmail' => array('required', 'unique:users,email','unique:schoolinformation', 'email'), 
#		'SchoolMobile' =>array(  'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
#'SchoolMobile'=> array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),
'SchoolPhone'=> array('required', 'regex:/^(-|\s)?\d{3}?(-|\s)?\d{3}(-|\s)\d{4}$/'),
#		'SchoolPhone'  =>array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),

		

		//'AdminContactPerson' =>  array('required'),		

		//'Country' =>  array('required'),		

	     'UploadLogo' => 'image',

		 //'UserName' =>  array('required'),		

		 'password' =>  array('required'),
		 'SchoolInTime' =>  array('required'),
		 'SchooloutTime' =>  array('required'),

        );

		public static $updaterules = array(

        'SchoolName' =>  array('required'),

        'SchoolAddress' =>  array('required'),

		//'SchoolEmail' =>  array('required'),

		'SchoolPhone' =>  'required|integer',

		//'SchoolMobile' =>  array('required'),

		//'AdminContactPerson' =>  array('required'),		

		//'Country' =>  array('required'),		

	     'UploadLogo' => 'image',

		

        );

		 public static $importrules = array(

        'importfile'=>  'required|mimes:xlsx',	

			

        );

}