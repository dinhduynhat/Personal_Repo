<?php
class TimingModel extends Eloquent
{
    protected $primaryKey = 'AutoID';
    protected $table = 'timing';
    protected $guarded = array('VehicleCode');
    protected $fillable = array('VehicleCode', 'StartTime', 'EndTime', 'DriverName');
    
    public $timestamps = false;
    public static $rules = array(
    	'VehicleCode' => 'required|unique:timing',
    	'StartTime' => 'required',
    	'EndTime' => 'required|min:StartTime',
    	'DriverName' => 'required',
    #   'DriverName' => 'required|unique:timing', #If required one driver for a Vehicle
        );
		public static $updaterules = array(
    	'VehicleCode' => 'required',
    	'StartTime' => 'required',
    	'EndTime' => 'required|min:StartTime',
    	'DriverName' => 'required',
    #   'DriverName' => 'required|unique:timing', #If required one driver for a Vehicle
        );
    //public static $myRule = 'required|min:'.Input::get('StartTime');
}