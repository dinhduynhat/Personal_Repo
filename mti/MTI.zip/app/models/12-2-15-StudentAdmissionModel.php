<?php

class StudentAdmissionModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'studentinformation';  

    protected $fillable = array('SchoolName','StudentCourse','StudentBatch','StudentLanguage','PersonalFirstName','PersonalMiddleName','PersonalLastName','Age','Gender','Street','ContactCity','ContactState','ContactPin','ContactPhone','ContactMobile','ContactUploadLogo','GuardianFirstName','GuardianMiddleName','GuardianLastName','importfile','transportdate','transporttake','comment','DateOfBirth','EntranceDate','ExitDate','MondayInTime','MondayoutTime','TuesdayInTime','TuesdayoutTime','WednesdayInTime','WednesdayoutTime','ThursdayInTime','ThursdayoutTime','FridayInTime','FridayoutTime','Apartment','House','timingoption','Weekdaysfrom','Weekdaysto','weekInTime','weekoutTime','Generatekey','TripType','parentid');

    

    public $timestamps = false;	

	

	 public function batchresult(){ 

        return $this->belongsTo('ClassModel', 'StudentCourse');

    }

	

	 public function schollresult(){ 

        return $this->belongsTo('GeneralSettingModel', 'SchoolName');

    }

	public function attendance()
    {
        // Assuming a one-to-one relationship
        return $this->hasOne('StudentAttandenceModel','studentid');
    }

	public function setContactUploadLogoAttribute($ContactUploadLogo)

    {

        if($ContactUploadLogo)

        {    

        $this->attributes['ContactUploadLogo'] = Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension();

        Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/', Input::get('StudentRegisterNumber').'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalExtension());

        }

    }

	 public static $rules = array(

        'SchoolName'=>  array('required'),		

		'StudentCourse'=>  array('required'),

		'StudentBatch'=>  array('required'),

        'StudentLanguage'=>  array('required'),			

		'PersonalFirstName'=>  array('required'),		

		'PersonalLastName'=>  array('required'),

		'Age'=>  'required|numeric',			

		'Gender'=>  array('required'),			

		'Street'=>  array('required'),		

		'ContactCity'=>  array('required'),

		'ContactState'=>  array('required'),

		'ContactPin'=>  'required|integer',

		'ContactPhone'=> 'required|integer',

		'ContactUploadLogo'=> 'image',	

		'GuardianFirstName'=>  array('required'),		

		'GuardianLastName'=>  array('required'),

        'DateOfBirth'=>  array('required'),	

        'EntranceDate'=>  array('required'),	

        'ExitDate'=>  array('required'),		

		'ContactMobile'=> 'required|integer',
        'TripType'=>  array('required'),

        );

		

		 public static $importrules = array(

        'importfile'=>  'required|mimes:xlsx',	

			

        );

		

		

}