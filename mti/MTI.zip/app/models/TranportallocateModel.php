<?php
class TranportallocateModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'transportroute';  
    protected $fillable = array('studentid','triptype','busid','start','destination','route','schoolid','buscompany','sequence','time','distance','destinationtime','destinationdistance');
    
    public $timestamps = false;
	
	
	
}