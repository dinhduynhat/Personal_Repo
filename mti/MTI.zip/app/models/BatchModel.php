<?php
class BatchModel extends Eloquent
{
    protected $primaryKey = 'AutoID';
    protected $table = 'batch';  
    protected $fillable = array('Class','batch','Statedate','Enddate');
    
    public $timestamps = false;
	
	
	 public function classModel(){ 
        return $this->belongsTo('ClassModel', 'Class');
    }
	public static $rules = array(     
        'Class' => 'required',         
        'batch' => 'required', 
		'Statedate' => 'required', 
		'Enddate' => 'required', 
        );
		public static $updaterules = array(
        'Class' => 'required',         
        'batch' => 'required', 
		'Statedate' => 'required', 
		'Enddate' => 'required', 
        );
}