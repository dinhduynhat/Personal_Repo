<?php
class ParentNotificationHistoryModel extends Eloquent
{
    
    protected $table = 'parent_notification_history';
    
    protected $fillable = array('NotificationName', 'NotificationMessage');

    public static $rule = array(
    'NotificationName'=>  array('required', 'unique:notification'),
    'NotificationMessage'=>  array('required', 'unique:notification')
        );

    

}