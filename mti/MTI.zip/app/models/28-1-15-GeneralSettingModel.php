<?php

class GeneralSettingModel extends Eloquent

{

    protected $primaryKey = 'id';

    protected $table = 'schoolinformation';  

    protected $fillable = array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','Country','UploadLogo','Username','Password');

    

    public $timestamps = false;

	

	public function StudentAdmissionModel(){ 

        return $this->belongsTo('StudentAdmissionModel', 'id');

    }

	

	public function setUploadLogoAttribute($UploadLogo)

    {

        if($UploadLogo)

        {    

        $this->attributes['UploadLogo'] = Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension();

        Input::file('UploadLogo')->move('assets/uploads/uploadschoollogo/', Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalExtension());

        }

    }

	 public static $rules = array(

        'SchoolName' =>  array('required'),

        'SchoolAddress' =>  array('required'),

		'SchoolEmail' =>  array('required'),

		'SchoolPhone' =>  array('required'),

		'SchoolMobile' =>  array('required'),

		'AdminContactPerson' =>  array('required'),		

		'Country' =>  array('required'),		

	     'UploadLogo' => 'image|mimes:jpg,png,gif|max:5000',

		 //'UserName' =>  array('required'),

		// 'password' =>  array('required'),

        );

		public static $updaterules = array(

        'SchoolName' =>  array('required'),

        'SchoolAddress' =>  array('required'),

		'SchoolEmail' =>  array('required'),

		'SchoolPhone' =>  array('required'),

		'SchoolMobile' =>  array('required'),

		'AdminContactPerson' =>  array('required'),		

		'Country' =>  array('required'),		

	     'UploadLogo' => 'image',

		

        );

}