<?php

class VehicleLocation extends Eloquent


{
	protected $table = 'vehicle_location';
	protected $primaryKey = 'AutoId';
	
	protected $fillable = array('VehicleId', 'DriverId');

	public function DriverModel(){ 
        return $this->belongsTo('DriverModel', 'AutoId');

    }
    
}
