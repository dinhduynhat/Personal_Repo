<?php
class LisenceModel extends Eloquent
{
    protected $primaryKey = 'id';
    protected $table = 'licensetype';
    public $timestamps = false;
}
