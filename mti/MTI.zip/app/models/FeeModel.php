<?php
class FeeModel extends Eloquent
{
    protected $table = 'schoolfeepayment';
    protected $fillable = array('SchoolName','BusCompanyName', 'Amount','Status', 'PaidDate', 'PaidBy', 'PayMonth', 'PayYear','Cheque','Paid');

         public function setPaidDateAttribute($value)
    {
        $this->attributes['PaidDate'] = date("Y-m-d", strtotime($value) );
    }

    

	 public static $rules = array(
       'BusCompanyName'=>  array('required'),
       'Paid'=>  array('required'),
        'SchoolName'=>  array('required'),
        'SchoolName'=>  array('required'),
		'PaidDate'=>  array('required'),		
        'PayMonth'=>  array('required'),     
        'Amount'=>  array('required'),     
        'PayYear'=>  array('required'),     
		'PaidDate'=>  array('required'),
		'PaidBy'=>  'required',
        );

     public static $updaterules = array(
        'SchoolName'=>  array('required'),      
        'Paid'=>  array('required'),
        'Amount'=>  array('required'),
       # 'Cheque'=>  array('required'),  
        'PaidDate'=>  array('required'),           
        'PayMonth'=>  array('required'),     
        'PayYear'=>  array('required')
        );

	 	public static $parentregisterrule = array(
        'DeviceId'=>  array('required'),
        'GCMId'=>  array('required')
        );

        	public static $notificationrule = array(
        'EmailNotification'=>  array('required'),
        'MobileNotification'=>  array('required')
        );

		
		
}