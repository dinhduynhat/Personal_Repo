<?php

class DriverController extends BaseController
{
    
    public function DriverLayout()
    {
	        $DriverDetails = DriverModel::all()->toArray();
      
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails);
    
    }
    
    public function DriverProcess()
    {
        
        $DriverData = Input::all();
        $validation = Validator::make($DriverData, DriverModel::$rules);       
        if ($validation->passes()) 
        {
            DriverModel::create($DriverData);
            return Redirect::to('driver')->with('Message', 'Vehicle Details Saved Succesfully');
        } else 
        {
            return Redirect::to('driver')->withInput()->withErrors($validation->messages());
        }
    }
	public function DriverEdit($data=NULL)
    {
	    $editvehicle=$data;
		$DriverDetailsbyid = DriverModel::where('AutoID', $editvehicle)->get()->toArray();
         $DriverDetails = DriverModel::all()->toArray();
      
        return View::make('driver/driverupdate')->with('DriverDetails', $DriverDetails)->with('DriverDetailsbyid', $DriverDetailsbyid);
	}
	public function DriverupdateProcess($data=NULL)
    {
        $update = array(       
		'DriverName' =>array('required','Regex:/^[A-Za-z0-9\-! ,]+$/', 'unique:driver,DriverName,'.$data.',AutoID'),
        'Age' => 'required|integer', 
        'Address' => 'required', 
        'LicenseNumber' => 'required', 
        'DateOfBirth' => 'required', 
        'LicenseExpiry' => 'required',
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000'
        );
        $DriverData = array_filter(Input::except(array('_token')));
	  $validation  = Validator::make($DriverData, $update);         
        if ($validation->passes()) 
        {
		if(!empty($DriverData['DriverPhoto']))
	{
	Input::file('DriverPhoto')->move('assets/uploads/driver/', $data . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalName());
	$DriverPhoto=$data . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalName();
	unset($DriverData['DriverPhoto']);
	$DriverData['DriverPhoto']=$DriverPhoto;
	}
	if(!empty($DriverData['LicensePhoto']))
	{
	Input::file('LicensePhoto')->move('assets/uploads/driver/', $data . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalName());
	$LicensePhoto=$data . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalName();
	unset($DriverData['LicensePhoto']);
	$DriverData['LicensePhoto']=$LicensePhoto;
}
		   $affectedRows = DriverModel::where('AutoID', $data)->update($DriverData);
            //VehicleModel::create($VehicleData);
            return Redirect::to('driveredit/'.$data)->with('Message', 'Driver Details Update Succesfully');
        } else 
        {
            return Redirect::to('driveredit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function driverdelete($data=NULL)
    {
	    $editvehicle=$data;
			$vehiclebyid = DriverModel::where('AutoID', $editvehicle)->get()->toArray();
		$DriverName=$vehiclebyid[0]['DriverName'];
	 $count = TimingModel::where('DriverName', '=', $DriverName)->count();

	if($count==0)
	{
		$affectedRows = DriverModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('driver')->with('Message', 'Driver Details Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	       $DriverDetails = DriverModel::all()->toArray();
      
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails)->with('deleteerror', $deleteerror);	   
        
	   }
	}
	public function DriverDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['driverdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$vehiclebyid = DriverModel::where('AutoID', $data[$i])->get()->toArray();
		$DriverName=$vehiclebyid[0]['DriverName'];
	 $count[] = TimingModel::where('DriverName', '=', $DriverName)->count();	
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = DriverModel::where('AutoID', $data[$i])->delete();
     
	}
	  return Redirect::to('driver')->with('Message', 'Driver Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	   $DriverDetails = DriverModel::all()->toArray();
      
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails)->with('deleteerror', $deleteerror);
	}
	}
}