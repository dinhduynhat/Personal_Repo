<?php

class SectionController extends BaseController
{
    
    public function StudentCategoryLayout()
    {
	
	$StudentCategoryDetails = SectionModel::all()->toArray();
	
        return View::make('section/gradesection')->with('StudentCategoryDetails', $StudentCategoryDetails);
     
    }
	public function StudentCategoryprocess()
    {

       
        $StudentCategoryData = Input::all();
        $validation = Validator::make($StudentCategoryData, SectionModel::$rules);
        
        if ($validation->passes()) 
        {
            SectionModel::create($StudentCategoryData);
            return Redirect::to('gradesection')->with('Message', 'Section Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('gradesection')->withInput()->withErrors($validation->messages());
        }
    }
    public function CategoryEdit($data=NULL)
    {
	    $editcategory=$data;
		$batchDetailsbyid = SectionModel::where('id', $editcategory)->get()->toArray();
       $StudentCategoryDetails = SectionModel::all()->toArray();
	
        return View::make('section/gradesectionupdate')->with('StudentCategoryDetails', $StudentCategoryDetails)->with('batchDetailsbyid', $batchDetailsbyid);
	}
	public function StudentCategoryupdateprocess($data=NULL)
    {
        $categoryEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($categoryEditData, SectionModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = SectionModel::where('id', $data)->update($categoryEditData);
            
            return Redirect::to('sectionedit/'.$data)->with('Message', 'Section Details Update Succesfully');
        } else 
        {
            return Redirect::to('sectionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function Categorydelete($data=NULL)
    {
	    $editcategory=$data;
		$affectedRows = SectionModel::where('id', $editcategory)->delete();		
       return Redirect::to('gradesection')->with('Message', 'Section Details Delete Succesfully');
	}
  
public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();

        $validation  = Validator::make($StudentAdmissionData, SectionModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/section/','section' . Input::file('importfile')->getClientOriginalName());
	$importfile='section' . Input::file('importfile')->getClientOriginalName();
	
	}
$results=Excel::load('assets/uploads/section/'.$importfile, function($reader) {

})->get()->toArray();

function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

foreach($finaldata as $final)
{
$Section=$final['section'];	
 	 if(!empty($Section))
{
	 $languagecount = SectionModel::where('Section', '=', $Section)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['Section']=$Section;
	 SectionModel::create($StudentLanguageData);
	 }
	 }
	 }
 return Redirect::to('gradesection')->with('Message', 'Grade Section Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('gradesection')->withInput()->withErrors($validation->messages());
        }
}
public function GradesectionExportLayout()
    {	

Excel::create('Gradesection', function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
		$ClassDetails = SectionModel::all()->toArray();


foreach ($ClassDetails as $ClassDetailsvalue)
{
$uploaddata[$ClassDetailsvalue['id']]['section']=$ClassDetailsvalue['Section'];	

}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('class');		
       
    }
}