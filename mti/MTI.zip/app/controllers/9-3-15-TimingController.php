<?php

class TimingController extends BaseController
{
    
    public function TimingLayout()
    {
        $VehicleDetails = VehicleModel::lists('VehicleCode', 'VehicleCode');
        $DriverDetails = DriverModel::lists('DriverName', 'DriverName');
		$TimingDetails = TimingModel::all()->toArray();
        return View::make('timing/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails);
    }
    
    public function TimingProcess()
    {
        
        $TimingData = Input::all();
        $validation = Validator::make($TimingData, TimingModel::$rules);
        
        if ($validation->passes()) 
        {
            TimingModel::create($TimingData);
            return Redirect::to('timing')->with('Message', 'Timing Details Saved Succesfully');
        } else 
        {
            return Redirect::to('timing')->withInput()->withErrors($validation->messages());
        }
    }
	public function TimingEdit($data=NULL)
    {
	    $editvehicle=$data;
		$TimingDetailsbyid = TimingModel::where('AutoID', $editvehicle)->get()->toArray();
         $VehicleDetails = VehicleModel::lists('VehicleCode', 'VehicleCode');
        $DriverDetails = DriverModel::lists('DriverName', 'DriverName');
		$TimingDetails = TimingModel::all()->toArray();
        return View::make('timing/timingupdate')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails)->with('TimingDetailsbyid', $TimingDetailsbyid);
	}
	public function TimingupdateProcess($data=NULL)
    {
$update = array(
    	'VehicleCode' => 'required|unique:timing,VehicleCode,'.$data.',AutoID',     
    	'StartTime' => 'required',
    	'EndTime' => 'required|min:StartTime',
    	'DriverName' => 'required',
   
        );
        $TimingEditData = array_filter(Input::except(array('_token')));
	
	   $validation = Validator::make($TimingEditData, $update);      
        if ($validation->passes()) 
        {
		   $affectedRows = TimingModel::where('AutoID', $data)->update($TimingEditData);
            
            return Redirect::to('timingedit/'.$data)->with('Message', 'Timing Details Update Succesfully');
        } else 
        {
            return Redirect::to('timingedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function TimingDelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = TimingModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('timing')->with('Message', 'Timing Details Delete Succesfully');
	}
	public function TimingDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['timingdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = TimingModel::where('AutoID', $data[$i])->delete();
	
     
	}
	    return Redirect::to('timing')->with('Message', 'Timing Details Delete Succesfully');
	
	}
}