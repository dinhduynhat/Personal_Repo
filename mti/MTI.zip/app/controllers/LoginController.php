<?php

class LoginController extends BaseController
{   
		
		
    	public function Login()
		{
			$LoginData = Input::except(array('_token'));
			$username=Input::get('UserName');
			$password=Input::get('password');
			$URL = Input::get('urlpath');
			Session::put('urlpath', Input::get('urlpath'));
		   if (Auth::attempt(array('email' => $username, 'password' => $password)))
		   {
			if($URL =='admin')
			{
			if(Auth::user()->usertype =="1")
			{
				return Redirect::to('admin/home');
			}
			else
			{
			return Redirect::to('admin')->with('Message', 'Only Admin can be logged in here.');
			}
			}
			
			if($URL =='school')
			{

        $Block = GeneralSettingModel::where('SchoolEmail', Auth::user()->email)->pluck('Status');
        if($Block=='Block')
        {
          return Redirect::to('school')->with('Message', 'Your account is blocked');
        
        }
        else
        {

     
        
			if(Auth::user()->usertype =="2")
			{
				return Redirect::to('school/home');
			}
			else
			{
			return Redirect::to('school')->with('Message', 'Only School User can be logged in here.');
			}
    }
			}
			
			if($URL =='government')
			{
			if(Auth::user()->usertype =="3")
			{
				return Redirect::to('government/home');
			}
			else
			{
			return Redirect::to('government')->with('Message', 'Only Government Entity User can be logged in here.');
			}
			}
			
			
			if($URL =='bus')
			{

   $Block = BusCompanyModel::where('Email', Auth::user()->email)->pluck('Status');
        if($Block=='Block')
        {
          return Redirect::to('bus')->with('Message', 'Your account is blocked');
        
        }
        else
        {



			if(Auth::user()->usertype =="4")
			{
				return Redirect::to('bus/home');
			}
			else
			{
			return Redirect::to('bus')->with('Message', 'Only Bus Company User can be logged in here.');
			}

		}
			}
			
			exit();
			
			
            if(Auth::user()->usertype =="3")
           {
		   
		   
		   
           $govtentityid=Auth::user()->schoolid;
           $govtentitybyid = GovernmentEntityModel::where('id', $govtentityid)->get()->toArray();
           if($govtentitybyid[0]['Status']=="Unblock")
           {
              return Redirect::to('home');
           }
           else
           {
            Session::flush();      
           return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
           }
           } else if(Auth::user()->usertype =="4")
           {
           $govtentityid=Auth::user()->schoolid;		   
           $govtentitybyid = BusCompanyModel::where('id', $govtentityid)->get()->toArray();
		 
           if($govtentitybyid[0]['Status']=="Unblock")
           {
              return Redirect::to('home');
           }
           else
           {
            Session::flush();      
           return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
           }
           } else if(Auth::user()->usertype =="2")
		   {
		   $schoolid=Auth::user()->schoolid;
		   $schooluserDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
            #return $schooluserDetailsbyid; 

		   if($schooluserDetailsbyid[0]['Status']=="Unblock")
		   {
			  return Redirect::to('admin/home');
		   } else {	 
			Session::flush();	   
		   return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
		   }
			} else {
			  return Redirect::to('admin/home');
			}	   
		   } 
		  else
			{
				
				return Redirect::to($URL)->with('Message', 'UserName or Password Invalid');
			}
		}



public function LoginAdmin()
    {
      $LoginData = Input::except(array('_token'));
      $username=Input::get('UserName');
      $password=Input::get('password');
    
       if (Auth::attempt(array('email' => $username, 'password' => $password)))
       {

		 if(Auth::user()->usertype =="1")
           {
	   return Redirect::to('admin/home');
	   }
	   else
	   {
	   return Redirect::to('/admin')->with('Message', 'Only Admin can logged into Admin Panel');
	   }
	   
            if(Auth::user()->usertype =="3")
           {
           $govtentityid=Auth::user()->schoolid;
           $govtentitybyid = GovernmentEntityModel::where('id', $govtentityid)->get()->toArray();
           if($govtentitybyid[0]['Status']=="Unblock")
           {
              return Redirect::to('home');
           }
           else
           {
            Session::flush();      
           return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
           }
           } else if(Auth::user()->usertype =="4")
           {
           $govtentityid=Auth::user()->schoolid;       
           $govtentitybyid = BusCompanyModel::where('id', $govtentityid)->get()->toArray();
     
           if($govtentitybyid[0]['Status']=="Unblock")
           {
              return Redirect::to('home');
           }
           else
           {
            Session::flush();      
           return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
           }
           } else if(Auth::user()->usertype =="2")
       {
       $schoolid=Auth::user()->schoolid;
       $schooluserDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
            #return $schooluserDetailsbyid; 

       if($schooluserDetailsbyid[0]['Status']=="Unblock")
       {
        return Redirect::to('admin/home');
       } else {  
      Session::flush();    
       return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
       }
      } else {
        return Redirect::to('admin/home');
      }    
       } 
      else
      {
        return Redirect::to('')->with('Message', 'UserName or Password Invalid');
      }
    }



    public function Logout()
    {
        Session::flush();


if(Auth::user()->usertype==1)
{
return Redirect::to('/admin');       
}

if(Auth::user()->usertype==2)
{
return Redirect::to('/school');       
}

if(Auth::user()->usertype==3)
{
return Redirect::to('/government');       
}

if(Auth::user()->usertype==4)
{
return Redirect::to('/bus');       
}

return Redirect::to('');       


    }

    public function ForgotPassword()
    {
        
        return View::make('login/forgot');
    }
    
        public function CreateUserLayout()
    {      
        return View::make('login/createuser');
    }

    public function CreateUserProcess()
    {
        $UserData = Input::all();
		
        $validation  = Validator::make($UserData, User::$rules);
        if ($validation->passes()) 
        {
            User::create($UserData);
            return Redirect::to('createuser')->with('Message', 'User Details Saved Succesfully');
        } else 
        {
            return Redirect::to('createuser')->withInput()->withErrors($validation->messages());
        }
    }   
	public function ForgotPasswordProcess()
    {
        $UserData = Input::except(array('_token'));
		  $requestusername=$UserData['UserName'];
		 $url =  $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		 $url = explode('/', $url);
		 end($url);
		 $usertype = prev($url); 
		 if($usertype=='admin')
		 {
		 $UserDetails = User::where('email', $requestusername)->where('usertype', '1')->get()->toArray();
		 }
		 if($usertype=='bus')
		 {
		 $UserDetails = User::where('email', $requestusername)->where('usertype', '4')->get()->toArray();
		 }
		 if($usertype=='school')
		 {
		 $UserDetails = User::where('email', $requestusername)->where('usertype', '2')->get()->toArray();
		 }
		 if($usertype=='government')
		 {
		 $UserDetails = User::where('email', $requestusername)->where('usertype', '3')->get()->toArray();
		 }
		 
        #return $UserDetails;
		

        if (empty($UserDetails)) 
        {

            return Redirect::to(Session::get('forgoturl').'/forgot')->withInput()->with('Message', 'No such Mail Exists');
            #return View::make('login/forgot')->with('Message', 'No such Mail Exists');
        }

        if (!empty($requestusername))
        {
        $string = str_random(5);     
        $passworddata = User::find($UserDetails[0]['id']);
        $email=$UserDetails[0]['email'];
		$username=$UserDetails[0]['UserName'];       
        $passworddata->password = $string;
        //$passworddata->newpassword = $string;
        $passworddata->save();
        
        //Mail::send([], [], function($message)
        Mail::send([],
     array('pass' => $string,'email' => $email,'username' => $username), function($message) use ($string,$email,$username)
    {
        $user = MailTemplate::find(1);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
        $mail_body = str_replace("{password}", $string, $mail_body);
        $mail_body = str_replace("{username}", $username, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($email);
        $message->subject('Login Details - MTI');
        });

        #return Redirect::to(.'/forgot')->withInput()->with('Message', 'No such Mail Exists');
        return Redirect::to(Session::get('forgoturl').'/forgot')->withInput()->with('Message', 'New Password sent to mail Succesfully');
        }
        else
        {
        return Redirect::to(Session::get('forgoturl').'/forgot')->withInput()->withInput()->with('Message', 'UserName not Found');
        
        
        }
        



        
    }
}