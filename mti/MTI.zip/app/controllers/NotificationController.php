<?php

class NotificationController extends BaseController
{
    
	public function NotifyParent()
    {	
        
        $Type = Auth::user()->usertype;
        if ($Type=='1' || $Type=='3' || $Type=='4') 
        {
        $ParentData = ParentModel::all()->toArray();
        return View::make('notification/notifyparent')->with('ParentData', $ParentData);
        }
        if ($Type=='2') 
        {
        $ParentData = ParentModel::all()->toArray();
        return View::make('notification/notifyparentschool')->with('ParentData', $ParentData);
        }


        
    }    



    




public function NotifyParentInstant()
    {   
        $ParentData = ParentModel::all()->toArray();
        return View::make('notification/notifyparentinstant')->with('ParentData', $ParentData);
    }
    

    public function NotifyParentProcess()
    {      
        $StudentData = Input::all();
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        $data=explode(",",$studentdeletelist);
        for($i=0;$i<count($data);$i++)
        {
        $user = new ParentNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $ParentData = ParentModel::where('id', $data[$i])->firstOrFail();
        if ($ParentData['MobileNotification']=='1') 
        {
        $user->Push = '1';
        }
        if ($ParentData['EmailNotification']=='1') 
        {
        $user->Email = '1';
        }
        $user->save();        
        }
        $ParentData = ParentModel::all()->toArray();
        return Redirect::to(Session::get('urlpath').'/notifyparent')->with('ParentData', $ParentData)->with('Message', 'Notification sent Succesfully');;
    }  

    public function NotifySchool()
    {   
	
		
		
	
        $SchoolData = GeneralSettingModel::all()->toArray();
        return View::make('notification/notifyschool')->with('StudentData', $SchoolData);
    
    }    


    public function NotifySchoolProcess()
    {      
        $StudentData = Input::all();
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        $data=explode(",",$studentdeletelist);
        for($i=0;$i<count($data);$i++)
        {
        $user = new SchoolNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $user->Email = '1';
        $user->save();
        }

        $SchoolData = GeneralSettingModel::all()->toArray();
        #return View::make('notification/notifyschool')->with('StudentData', $SchoolData);

        #$ParentData = ParentModel::all()->toArray();
        return Redirect::to(Session::get('urlpath').'/notifyschool')->with('StudentData', $SchoolData)->with('Message', 'Notification sent Succesfully');;
        


        #$SParentData = ParentModel::all()->toArray();
        #return Redirect::to('notifyschool')->with('ParentData', $ParentData)->with('Message', 'Notification sent Succesfully');;
    }  



        public function NotifyBus()
    {   
        $BusData = BusCompanyModel::all()->toArray();
        return View::make('notification/notifybus')->with('StudentData', $BusData);
    
    }    




        public function NotifyBuslProcess()
    {   
        
        $StudentData = Input::all();
        #return $StudentData;
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        
        $data=explode(",",$studentdeletelist);
        
        for($i=0;$i<count($data);$i++)
        {
        $user = new BusNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $user->Email = '1';
        $user->save();
        }

        #return View::make('notification/notifybus')->with('StudentData', $BusData);

        $BusData = BusCompanyModel::all()->toArray();
        return Redirect::to(Session::get('urlpath').'/notifybuscompany')->with('StudentData', $BusData)->with('Message', 'Notifications Sent Succesfully');


    }  


    public function NotifyParentInstantProcess()
    {   
        

        $StudentData = Input::all();
        #return $StudentData;
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        
        $data=explode(",",$studentdeletelist);
        
        for($i=0;$i<count($data);$i++)
        {
        
        $user = new ParentNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $ParentData = ParentModel::where('id', $data[$i])->firstOrFail();
        if ($ParentData['MobileNotification']=='1') 
        {
        $user->Push = '1';
        }
        if ($ParentData['EmailNotification']=='1') 
        {

        $user->Email = '1';
        $email = $ParentData['Email'];


        Mail::send([],array('email' => $email), function($message) use ($email)
        {
        $user = MailTemplate::find(1);
        $mail_body = $user->MailContent;
        $message->setBody('msg', 'text/html');
        $message->to($email);
        $message->subject('title');
        });
        $user->EmailStatus = '1';
        }
        
        exit();

        }
        $user->save();        
        


        $ParentData = ParentModel::all()->toArray();

        return View::make('notification/notifyparentinstant')->with('ParentData', $ParentData)->with('Message', 'Notification Sent Succesfully');
        

    }  



    public function NotifyParentProcessCron()
    {   
        
    $EmailSendersCount = ParentNotificationHistoryModel::where('Email', '1')->where('EmailStatus', '0')->get()->count();    
    
    $trackeddata ='';
    if ($EmailSendersCount>2) 
    {
    
    $EmailSenders = ParentNotificationHistoryModel::where('Email', '1')->where('EmailStatus', '0')->get()->take(5);
    
        foreach ($EmailSenders as $key) 
        {
           $TriggerEmail = $key->id;

           #Start of Triggering Email
               Mail::send([],array('TriggerEmail' => $TriggerEmail), function($message) use ($TriggerEmail)
            {
             $CronData = ParentNotificationHistoryModel::where('id', $TriggerEmail)->first();
             $TargetMail = ParentModel::where('id', $CronData->SentTo)->pluck('Email');
             $message->setBody($CronData->Message, 'text/html');
             $message->to($TargetMail);
             $message->subject($CronData->Title);
            });
            #End of Triggering Email
           $EmailUpdate = ParentNotificationHistoryModel::where('id', $key->id)->first();
           $EmailUpdate->EmailStatus = '1';
           $EmailUpdate->save();
           $trackeddata .= $key->id.',';
        }
    
    }

    $PNSenders = ParentNotificationHistoryModel::where('Push', '1')->where('PushStatus', '0')->get()->take(5);
    
    if (isset($PNSenders)) 
    {
        foreach ($PNSenders as $key) 
        {
            $PNSendersData = ParentNotificationHistoryModel::where('id', $key->id)->first();


            #Push Notification Starts Here
           $PushMessage = '';
           $PushMessage = "{'Title' : ".$PNSendersData->Title."', 'Message' : '".$PNSendersData->Message."'}"; 
           $PNSenderGCM = ParentModel::where('id', $TriggerEmail)->pluck('GcmId');
           $Message = array("notification"=>urldecode($PushMessage));
           $this->PushNotification($PNSenderGCM, $Message);
            #Push Notification Ends Here

           $PNUpdate = ParentNotificationHistoryModel::where('id', $key->id)->first();
           $PNUpdate->PushStatus = '1';
           $PNUpdate->save();
           $trackeddata .= $key->id.',';
        }
    
    }
    return $trackeddata;
   
    }   




     public function NotifyDriverProcessCron()
    {   
        
    $EmailSendersCount = ParentNotificationHistoryModel::where('Email', '1')->where('EmailStatus', '0')->get()->count();    
    
    $trackeddata ='';
    if ($EmailSendersCount>2) 
    {
    
    $EmailSenders = ParentNotificationHistoryModel::where('Email', '1')->where('EmailStatus', '0')->get()->take(5);
    

        foreach ($EmailSenders as $key) 
        {
           $TriggerEmail = $key->id;

           #Start of Triggering Email
               Mail::send([],array('TriggerEmail' => $TriggerEmail), function($message) use ($TriggerEmail)
            {
             $CronData = ParentNotificationHistoryModel::where('id', $TriggerEmail)->first();
             $TargetMail = ParentModel::where('id', $CronData->SentTo)->pluck('Email');
             $message->setBody($CronData->Message, 'text/html');
             $message->to($TargetMail);
             $message->subject($CronData->Title);
            });
            #End of Triggering Email
           $EmailUpdate = ParentNotificationHistoryModel::where('id', $key->id)->first();
           $EmailUpdate->EmailStatus = '1';
           $EmailUpdate->save();
           $trackeddata .= $key->id.',';
        }
    
    }

    $PNSenders = ParentNotificationHistoryModel::where('Push', '1')->where('PushStatus', '0')->get()->take(5);
    
    if (isset($PNSenders)) 
    {
        foreach ($PNSenders as $key) 
        {
            $PNSendersData = ParentNotificationHistoryModel::where('id', $key->id)->first();


            #Push Notification Starts Here
           $PushMessage = '';
           $PushMessage = "{'Title' : ".$PNSendersData->Title."', 'Message' : '".$PNSendersData->Message."'}"; 
           $PNSenderGCM = ParentModel::where('id', $TriggerEmail)->pluck('GcmId');
           $Message = array("notification"=>urldecode($PushMessage));
           $this->PushNotification($PNSenderGCM, $Message);
            #Push Notification Ends Here

           $PNUpdate = ParentNotificationHistoryModel::where('id', $key->id)->first();
           $PNUpdate->PushStatus = '1';
           $PNUpdate->save();
           $trackeddata .= $key->id.',';
        }
    
    }
    return $trackeddata;
   
    }   




    public function NotifyParentSchool()
    {   
        $ParentData = ParentModel::all()->toArray();
        return View::make('notification/notifyparentschool')->with('ParentData', $ParentData);
    }    

    public function NotifyDriver()
    {	
        

        $Type = Auth::user()->usertype;
        if ($Type=='1' || $Type=='3' || $Type=='4') 
        {

        $DriverData = DriverModel::all()->toArray();
        return View::make('notification/notifydriver')->with('DriverData', $DriverData);
    }
    else
    {
        $DriverData = DriverModel::all()->toArray();
        return View::make('notification/notifydriverschool')->with('DriverData', $DriverData);

    }
    }    

public function NotifyDriverProcess()
    {   
        
        $StudentData = Input::all();
        #return $StudentData;
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        
        $data=explode(",",$studentdeletelist);
        
        for($i=0;$i<count($data);$i++)
        {
        $user = new DriverNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $DriverData = DriverModel::where('AutoId', $data[$i])->firstOrFail();
        if ($DriverData['MobileNotification']=='1') 
        {
            $user->Push = '1';
            // $PushMessage = $_POST['Title'].','.$_POST['Message']; 
            // $DeviceId = array($DriverData['GcmId']);
            // $Message = array("price"=>urldecode($PushMessage));
            // $this->PushNotification($DeviceId, $Message);
            // $user->PushStatus = '1';
        }
        if ($DriverData['EmailNotification']=='1') 
        {
        $user->Email = '1';

        }
        $user->save();
        }

        

        $DriverData = DriverModel::all()->toArray();        
        return Redirect::to(Session::get('urlpath').'/notifydriver')->with('DriverData', $DriverData)->with('Message', 'Notification Sent Succesfully');


    }  




    public function NotifyDriverProcessone()
    {   
        
        $StudentData = Input::all();
        #return $StudentData;
        $studentdeletelist = $StudentData['vehicledeleteprocess'];
        
        $data=explode(",",$studentdeletelist);
        
        for($i=0;$i<count($data);$i++)
        {
        
        $user = new DriverNotificationHistoryModel;
        $user->Title = $_POST['Title'];
        $user->Message = $_POST['Message'];
        $user->SentBy = Auth::user()->id;
        $user->SentTo = $data[$i];
        $user->save();
        # Notification
        // $PushMessage = "{'Title' : ".$_POST['Title']."', 'Message' : '".$_POST['Message']."'}"; 
        // $DeviceId = DriverModel::where('AutoId', '=', $data[$i])->pluck('GCMId');
        // $Message = array("price"=>urldecode($PushMessage));
        // $this->PushNotification($DeviceId, $Message);
        # End of Notification
        }
        $ParentData = ParentModel::all()->toArray();
        return View::make('notification/notifyparent')->with('ParentData', $ParentData)->with('Message', 'Notification Sent Succesfully');

    }



       public function PushNotification($DeviceId,$Message) 
    {
    $url = 'https://android.googleapis.com/gcm/send';
    $fields = array(
            'registration_ids' => $DeviceId,
            'data' => $Message
        );
    $headers = array(
        'Authorization: key = AIzaSyCUx1PyeAonGjbHAuVvAc74pbk9F_wVfKE',
        'Content-Type: application/json'
                      );
    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
        }
        curl_close($ch);
    
    }



    public function PushNotificationold($DeviceId,$Message) 
    {
    $url = 'https://android.googleapis.com/gcm/send';
    $fields = array(
            'registration_ids' => $DeviceId,
            'data' => $Message
        );
    $headers = array(
        'Authorization: key = AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo',
        'Content-Type: application/json'
                      );
    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
        }
        curl_close($ch);
    
    }

    
}