<?php

class DestinationController extends BaseController
{
    
    public function DestinationLayout()
    {
        $RouteDetails = RouteModel::lists('RouteName', 'RouteName');
		$DestinationDetails = DestinationModel::all()->toArray();
        return View::make('destination/destination')->with('RouteDetails', $RouteDetails)->with('DestinationDetails', $DestinationDetails);
    }
    
    public function DestinationProcess()
    {
        
        $DestinationData = Input::all();
        $validation      = Validator::make($DestinationData, DestinationModel::$rules);
        
        if ($validation->passes()) 
        {
            DestinationModel::create($DestinationData);
            return Redirect::to('destination')->withErrors('Destination Details Saved Succesfully');
        } else 
        {
            return Redirect::to('destination')->withInput()->withErrors($validation->messages());
        }
    }
	public function DestinationEdit($data=NULL)
    {
	    $editvehicle=$data;
		$DestinationDetailsbyid = DestinationModel::where('AutoID', $editvehicle)->get()->toArray();
        $RouteDetails = RouteModel::lists('RouteName', 'RouteName');
		$DestinationDetails = DestinationModel::all()->toArray();
     return View::make('destination/destinationupdate')->with('RouteDetails', $RouteDetails)->with('DestinationDetails', $DestinationDetails)->with('DestinationDetailsbyid', $DestinationDetailsbyid);
	}
	public function DestinationupdateProcess($data=NULL)
    {
        $DestinationEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($DestinationEditData, DestinationModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = DestinationModel::where('AutoID', $data)->update($DestinationEditData);
            
            return Redirect::to('destinationedit/'.$data)->with('Message', 'Destination Details Update Succesfully');
        } else 
        {
            return Redirect::to('destinationedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function DestinationDelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = DestinationModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('destination')->with('Message', 'Destination Details Delete Succesfully');
	}
}