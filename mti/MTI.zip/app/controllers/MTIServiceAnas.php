<?php

class MTIService extends BaseController
{

############# Parent App Web Service ############################
    
    public function CheckParentDevice()
    {
        #Checks if the DeviceId matches any Record in the Parent Information Table
        $ParentData = MTIServiceParent::where('DeviceId', Input::get('DeviceId'))->pluck('id');
        if ($ParentData) 
        {
        $Response   = array(
            'success' => '1',
            'parent_id' => $ParentData
        );
        return $Response;
        }
        else
        {
        $Response   = array(
            'success' => '0',
            'parent_id' => 'Parent Not Found'
        );    
        return $Response;
        }
    }
    
    public function RegisterParentDevice()
    {

    if((Input::get('Mobile') =='') || (Input::get('Name') =='')) 
    {
    $Response   = array(
            'success' => '0',
            'parent_id' => 'Insufficient Data'
        );    
        return $Response;
        exit();
    }

    $ParentData = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('Generatekey');


        if ($ParentData) 
        {   
        $ParentGCM = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('GcmId');
        $Response   = array(
            'success' => '1',
            );
            $PushMessage = "Activation Code is ".$ParentData; 
            $DeviceId = array($ParentGCM);
            $Message = array("price"=>urldecode($PushMessage));
            $this->PushNotification($DeviceId, $Message);
        return $Response;
        }
        else
        {
        $Response   = array(
            'success' => '0',
            'parent_id' => 'Parent Not Found'
        );    
        return $Response;
        }
    }


    public function AuthenticateParent()
    {
        #Updates the DeviceId, GcmId with the matching Record in the Parent Information Table
        #$ParentId = MTIServiceParent::where('Generatekey', '=', Input::get('UniqueCode'))->where('DeviceId', '=', Input::get('DeviceId'))->pluck('id');
        $ParentId = MTIServiceParent::where('Generatekey', '=', Input::get('UniqueCode'))->pluck('id');
        #$ParentId = MTIServiceParent::where('Generatekey', Input::get('UniqueCode'))->pluck('id');
        if ($ParentId) {
            #Update the DeviceId and GCMId of the Device in the Student Information Table
            $ParentData           = Input::all();
            $ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentregisterrule);
            if ($ParentDataValidation->passes()) {
                $ParentDataUpdate           = MTIServiceParent::where('id', $ParentId)->first();
                $ParentDataUpdate->DeviceId = Input::get('DeviceId');
                $ParentDataUpdate->GcmId    = Input::get('GcmId');
                $ParentDataUpdate->save();
                $Response = array(
                    'success' => '1',
                    'parent_id' => $ParentId
                );
                return json_encode($Response);
            } else {
                $Response = array(
                    'success' => '0',
                    'message' => 'Insufficient Data'
                    #'errors' => #$ParentDataValidation->messages()
                );
                return json_encode($Response);
            }
            
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'The Unique Key does not match with a Registered Parent at MTI'
            );
            return json_encode($Response);
        }
    }
    
    public function ShowParentProfile()
    {
        $IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($IsParentExist) {
            $ParentData = MTIServiceParent::find($IsParentExist);
            $Response   = array(
                'success' => '1',
                'firstname' => $ParentData->FirstName,
                'lastname' => $ParentData->LastName,
                'email' => $ParentData->Email,
                'mobile' => $ParentData->Mobile,
                'house' => $ParentData->House,
                'apartment' => $ParentData->Apartment,
                'street' => $ParentData->Street,
                'city' => $ParentData->City,
                'state' => $ParentData->State,
                'pincode' => $ParentData->Pincode
            );
            return json_encode($Response);
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }


    public function UpdateParentProfileOld()
    {
        $IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($IsParentExist) {
        $ParentData           = Input::all();
            $ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentupdaterule);
            if ($ParentDataValidation->passes()) {
                $ParentUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();
                $ParentUpdate->FirstName = Input::get('FirstName');
                $ParentUpdate->LastName = Input::get('LastName');
                $ParentUpdate->Email = Input::get('Mail');
                $ParentUpdate->Mobile = Input::get('Mobile');
                $ParentUpdate->House = Input::get('House');
                $ParentUpdate->Apartment = Input::get('Apartment');
                $ParentUpdate->Street = Input::get('Street');
                $ParentUpdate->City = Input::get('City');
                $ParentUpdate->State = Input::get('State');
                $ParentUpdate->Pincode = Input::get('Pincode');
                $ParentUpdate->save();
                $Response = array(
                                'success' => '1'
                            );
                            return json_encode($Response);
                }
                 else {
            $Response = array(
                'success' => '0',
                'errors' => $ParentDataValidation->messages()
            );
            return json_encode($Response);
        }

        

        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }


public function UpdateParentProfile()
    {
        $IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($IsParentExist) {
        $ParentData           = Input::all();
      
            $ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentupdaterule);
            if ($ParentDataValidation->passes()) {
                $ParentUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();
                $ParentUpdate->FirstName = Input::get('FirstName');
                $ParentUpdate->LastName = Input::get('LastName');
                $ParentUpdate->Email = Input::get('Mail');
                $ParentUpdate->Mobile = Input::get('Mobile');
                $ParentUpdate->House = Input::get('House');
                $ParentUpdate->Apartment = Input::get('Apartment');
                $ParentUpdate->Street = Input::get('Street');
                $ParentUpdate->City = Input::get('City');
                $ParentUpdate->State = Input::get('State');
                $ParentUpdate->Pincode = Input::get('Pincode');
                $ParentUpdate->save();
                $Response = array(
                                'success' => '1'
                            );
                            return json_encode($Response);
                }
                 else {
            $Response = array(
                'success' => '0',
                'errors' => $ParentDataValidation->messages()
            );
            return json_encode($Response);
        }

        

        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }



    public function ShowParentNotification()
    {
        $IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($IsParentExist) {
            $ParentData = MTIServiceParent::find($IsParentExist);
            $Response   = array(
                'success' => '1',
                'pushnotify' => ''.$ParentData->MobileNotification.'',
                'emailnotify' => ''.$ParentData->EmailNotification.''
            );
            return json_encode($Response);
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }

    }

    public function UpdateParentNotification()
    {
        $IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($IsParentExist) {

            $ParentData           = Input::all();
            $ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$notificationrule);
            if ($ParentDataValidation->passes()) {
                $NotificationUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();        
                $NotificationUpdate->EmailNotification = Input::get('EmailNotification');
                $NotificationUpdate->MobileNotification = Input::get('MobileNotification');
                $NotificationUpdate->save();
                $Response = array(
                                'success' => '1'
                            );
                            return json_encode($Response);
                }
                 else {
            $Response = array(
                'success' => '0',
                'message' => 'Insufficient Data'
                #'errors' => $ParentDataValidation->messages()
            );
            return json_encode($Response);
        }
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }





    public function ShowKids()
    {  
    $ParentDetails = MTIServiceParent::where('id', Input::get('ParentId'))->select('House', 'Apartment','Street','City','State','Pincode')->get()->first();
    if ($ParentDetails) 
    {
    
    $StudentDetails = MTIServiceStudent::where('parentid', Input::get('ParentId'))->select('id','PersonalFirstName as FirstName','PersonalLastName as LastName', 'StudentCourse as Course','TripType','fromTripType','ContactUploadLogo as ProfileImage')->get();

    $Response = array(
                'success' => '1',
                'address' => $ParentDetails,
                'student' => $StudentDetails
            );
            return json_encode($Response);
    }
    else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }

    public function UpdateAttendance()
    {        
        #if (Input::get('StudentId') != '' && Input::get('ToSchool') !='' && Input::get('ToHome') !='' && Input::get('Date') !='' && Input::get('Time') !='') 
        if (Input::get('StudentId') != ''  && Input::get('Date') !='' && Input::get('Time') !='') 
        {      
        #$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        $IsStudntExist = MTIServiceStudent::where('id', Input::get('StudentId'))->count();

        if ($IsStudntExist=='1') 
        {

        $UpdateAttendance = new StudentAttandenceModel;
        $UpdateAttendance->studentid = Input::get('StudentId');
        $UpdateAttendance->toschool = Input::get('ToSchool');
        $UpdateAttendance->tohome = Input::get('ToHome');
		$UpdateAttendance->date = Input::get('Date');
		$UpdateAttendance->inserttime = Input::get('Time');
        $UpdateAttendance->save();
        $Response = array(
                    'success' => '1',
                    'message' => 'Success'
                );
                return json_encode($Response);          
        }
        else
        {
            $Response = array(
                    'success' => '0',
                    'message' => 'Student Not Found'
                );
                return json_encode($Response);       
        }
        }
        else
        {
            $Response = array(
                    'success' => '0',
                    'message' => 'Insufficient Data'
                );
                return json_encode($Response);       

        }
        
    }

	public function AlertParent()
    {
	if (Input::get('StudentId') != '' && Input::get('Message') != '' ) 
        {      
        $IsStudntExist = MTIServiceStudent::where('id', Input::get('StudentId'))->count();
        if ($IsStudntExist=='1') 
        {
		$Parent = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
		$ParentGCM = MTIServiceParent::where('id', $Parent)->pluck('GcmId');
		
		#here
		$PushMessage = Input::get('Message'); 
            $DeviceId = array($ParentGCM);
            $Message = array("price"=>urldecode($PushMessage));
            $this->PushNotification($DeviceId, $Message);
		$Response = array(
                    'success' => '1',
                    'message' => 'Success'
                );
                return json_encode($Response); 	
			
		
		}
		else
		{
		    $Response = array(
                    'success' => '0',
                    'message' => 'Student Not Found'
                );
                return json_encode($Response);       

		}
		}
		else
		{
		    $Response = array(
                    'success' => '0',
                    'message' => 'Insufficient Data'
                );
                return json_encode($Response);       

		}
		
	}

    public function GetDriverLocationParent()
    {
  

    if (Input::get('ParentId') != '' && Input::get('TripType') != '' ) 
        {  
        

    $StudentData = MTIServiceStudent::where('parentid', Input::get('ParentId'))->get()->toArray();
    $Mat ='';
    $busid ='';
    $latbus ='';
     foreach ($StudentData as $key) 
        {

    $AllBus = TranportallocateModel::orderBy('id','asc')->where('triptype', Input::get('TripType'))->get();

    foreach ($AllBus as $Bus) 
    {
    
$latbus .='';
     $row = $Bus['studentid'];
     $users = DB::select("SELECT FIND_IN_SET('".$key['id']."','".$row."') as Res");
    $data = $users[0]->Res;
    $decoded = json_decode($data);

    if ($decoded!='0')
    {
        $Mat .='1';
         
        $bus = TranportallocateModel::where('id', $Bus['id'])->pluck('busid');
        $lat = VehicleLocation::where('AutoId', $Bus['busid'])->get()->first();

        $busid .= $Bus['id'].',';
        $latbus .= '{"Bus" : "'.$Bus['id'].'", "Lat" : "'.$lat['Lat'].'", "Long" : "'.$lat['Long'].'"},';
    }
    else
    {
        $Mat .='0';
    }
    #$latbus = $latbus.'},';  
    $latbus = $latbus;
    }


    }

#$latbus = $latbus.'}'



$final = '['.$latbus.']';

if ($final=='[]') 
{
     $Response   = array(
            'success' => '0',
            'message' => 'Bus Not Found'
        );    
        return $Response;
} else 
{
    



$newfinal = substr($final, 0, -2);
$newfinal = $newfinal.']';

$ar = json_decode($newfinal,true);
$unique = array_map("unserialize", array_unique(array_map("serialize", $ar)));

return '{"success":"1","busdata":' . json_encode($unique) . '}';

#return  ;

     // $Response   = array(
     //        'success' => '1',
     //        'data' => json_encode($unique)
     //    );    
     //    return $Response;


}

}
else
{
     $Response   = array(
            'success' => '0',
            'message' => 'Insufficient Data'
        );    
        return $Response;
}


return $newfinal;










return $busid.' - '.$latbus;


/*
        #Checks if the DeviceId matches any Record in the Parent Information Table
        $ParentData = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
        if ($ParentData) 
        {       
        $StudentDataCount = MTIServiceStudent::where('parentid', Input::get('ParentId'))->count();
        $StudentData = MTIServiceStudent::where('parentid', Input::get('ParentId'))->get();
        $Student = '';
        $BusId = '';       

     $arrayName = array('val' => 1,2,3 );

         foreach ($StudentData as $key) 
        {
             $Student .=$key->id.',';

               $Bus = TranportallocateModel::whereIn('id',  $arrayName)->get();
              
              $BusId .=$Bus;
        }

        
        return $BusId;



    return DB::getQueryLog();
        
       return $Student.' - '.$BusId;
       #return $Student;
    


        $Response   = array(
            'success' => '1',
            'parent_id' => $StudentParentData
        );
        return $Response;
        }
        else
        {
        $Response   = array(
            'success' => '0',
            'parent_id' => 'Parent Not Found'
        );    
        return $Response;
        }
*/

    }
    


############# Bus Operator Web Service ############################



       public function CheckBusOperatorDevice()
    {
        #Checks if the Bus OperatorId matches any Record in the Driver Information Table
        $DriverId = MTIServiceDriver::where('DeviceId', Input::get('DeviceId'))->pluck('AutoId');
        if ($DriverId) 
        {
        $Response   = array(
            'success' => '1',
            'driver_id' => $DriverId
        );
        return $Response;
        }
        else
        {
        $Response   = array(
            'success' => '0',
            'driver_id' => 'Bus Not Found'
        );    
        return $Response;
        }
    }
    
     public function AuthenticateBusOperator()
    {
        
    if(Input::get('UniqueCode')!='' && Input::get('DeviceId')!='' && Input::get('GcmId')!='') 
            {

        #Updates the DeviceId, GcmId with the matching Record in the Driver Table
        $DriverId = MTIServiceDriver::where('UniqueCode', Input::get('UniqueCode'))->pluck('AutoId');        
        if ($DriverId) {
            #Update the DeviceId and GCMId of the Device in the Driver Table
            $DriverData = Input::all();

            if(Input::get('UniqueCode')!='' || Input::get('DeviceId')!='') 
            {
                $RiderUpdate = MTIServiceDriver::where('UniqueCode', Input::get('UniqueCode'))->first();
                $RiderUpdate->DeviceId = Input::get('DeviceId');
                $RiderUpdate->GcmId = Input::get('GcmId');
                $RiderUpdate->save();
                $Response = array(
                    'success' => '1',
                    'driver_id' => $DriverId
                );
                return json_encode($Response);

            }
             else {
                $Response = array(
                    'success' => '0',
                    'message' => 'The Unique Code does not match with a Registered Driver at MTI'
                );
                return json_encode($Response);
            }
            
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'The Unique Code does not match with a Registered Driver at MTI'
            );
            return json_encode($Response);
        }
    }
    else
    {
            $Response = array(
                'success' => '0',
                'message' => 'Insufficient Data'
            );
            return json_encode($Response);

    }
    }



    public function ShowDriverNotification()
    {
        $IsParentExist = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->pluck('AutoId');
        if ($IsParentExist) {
            $ParentData = MTIServiceDriver::find($IsParentExist);
            $Response   = array(
                'success' => '1',
                'pushnotify' => ''.$ParentData->MobileNotification.'',
                'emailnotify' => ''.$ParentData->EmailNotification.''
            );
            return json_encode($Response);
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'Driver Not Found'
            );
            return json_encode($Response);
        }

    }




public function UpdateDriverNotification()
    {
        
if(Input::get('DriverId')!='' && Input::get('EmailNotification')!='' && Input::get('MobileNotification')!='') 
{

       $IsParentExist = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->pluck('AutoId');
        if ($IsParentExist) {
            $ParentData           = Input::all();
            $NotificationUpdate = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->first();        
            $NotificationUpdate->EmailNotification = Input::get('EmailNotification');
            $NotificationUpdate->MobileNotification = Input::get('MobileNotification');
            $NotificationUpdate->save();
            $Response = array(
                                'success' => '1'
                            );
                return json_encode($Response);   
        }
        else
        {
                $Response = array(
                                'success' => '0',
                                'message' => 'Parent Not Exist'
                            );
                return json_encode($Response);   
        }
 

}
else
{

$Response = array(
                                'success' => '0',
                                'message' => 'Insufficient Data'
                            );
                return json_encode($Response);   
}

        
    }


    public function UpdateDriverLocation()
    {   

    if(Input::get('driver_id') && Input::get('Lat')!='' && Input::get('Long')!='') #If all three parameters were given
    {

    $DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
    if ($DriverCount=='1') 
    {
        $DriverUpdate = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->first();
        $DriverUpdate->Lat = Input::get('Lat');
        $DriverUpdate->Long = Input::get('Long');
        $DriverUpdate->save();
    $Response = array('success' => '2','message' => 'Updated');
    return json_encode($Response);
    }
    else
    {
    $Response = array('success' => '1','message' => 'Driver Not Found');
    return json_encode($Response);
    }
    }
    else
    {
    $Response = array('success' => '0','message' => 'Insufficient Data');
    return json_encode($Response);   
    }
   }


   public function ShowDriverProfile()
    {
        $IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
        if ($IsDriverExist) {
            $DriverData = MTIServiceDriver::find($IsDriverExist);
            $Response   = array(
                'success' => '1',
                'name' => $DriverData->DriverName,
                'mobile' => $DriverData->Mobile,
                'email' => $DriverData->Email,
                'address' => $DriverData->Address,
                'age' => $DriverData->Age
                
            );
            return json_encode($Response);
        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No Driver Found'
            );
            return json_encode($Response);
        }
    }
    

    public function UpdateDriverProfile()
    {
        $IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
        if ($IsDriverExist) {
        $DriverData           = Input::all();
            $ParentDataValidation = Validator::make($DriverData, MTIServiceDriver::$driverupdaterule);
            if ($ParentDataValidation->passes()) {
                $ParentUpdate = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->first();
                $ParentUpdate->DriverName = Input::get('DriverName');
                $ParentUpdate->Email = Input::get('Email');
                $ParentUpdate->Mobile = Input::get('Mobile');
                $ParentUpdate->Address = Input::get('Address');
                $ParentUpdate->save();
                $Response = array(
                                'success' => '1'
                            );
                            return json_encode($Response);
                }
                 else {
            $Response = array(
                'success' => '0',
                #'errors' => $ParentDataValidation->messages()
                'message' => 'Insufficient Data'
            );
            return json_encode($Response);
        }

        

        } else {
            $Response = array(
                'success' => '0',
                'message' => 'No User Found'
            );
            return json_encode($Response);
        }
    }
    public function ShowKid()
    {

$id = '5';
$Match = TranportallocateModel::whereRaw(
    'find_in_set(?, `studentid`)',
    ['5']
)->first();

return $Match['id'];
    }



    public function KidsOnMap()
    {

    if (Input::get('Trip')!='' && Input::get('DriverId')!='' && Input::get('Date')!='') 
    {

    
    $BusId = TimingModel::where('DriverName', '=', Input::get('DriverId'))->pluck('VehicleCode');
    if (Input::get('Trip')=='AM') 
    {
    $VehicleCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->count();    
    $DriverData = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->where('triptype', '=', 'AM')->first();
    } elseif (Input::get('Trip')=='PM') 
    {
    $VehicleCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->count();        
    $DriverData = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->first();
    }
    else
    {
        $Response = array(
                'success' => '0',
                'message' => 'Insufficient Data'
            );
            return json_encode($Response);
    }
    if ($VehicleCount=='1') 
    {
    $Kids  = $DriverData['studentid'];
    #return $Kids;
    $array = explode(',', $Kids);
    $KidsData = '[';
    foreach ($array as $key) 
        {
        $Student = MTIServiceStudent::where('id', '=', $key)->get()->first();
    
    #New Condition Here

        $Marked = StudentAttandenceModel::where('studentid', '=', $key)->where('date', '=', Input::get('Date'))->get()->first();
        if ($Marked>='1') 
        {
        
        } else 
        {
            $KidsData .= '{ "StudentId" : "'.$key.'", "StudentName" : "'.$Student['PersonalFirstName'].' '.$Student['PersonalLastName'].'", "Lat" : "'.$Student['lat'].'", "Long" : "'.$Student['long'].'"},';                
        }
        


        }
        $KidsData = substr($KidsData, 0, -2);
        $KidsData = $KidsData.'}]';     

        return '{"success":"1","kids":' . $KidsData . '}';
    }
    else
    {
        return '{"success":"0","message":"Bus Not Found"}';
    }
    }
    else
    {
        return '{"success":"0","message":"Insufficient Data"}';
    }
    }
	

    public function DriverLatLong()
    {
    if (Input::get('DriverId')!='' && Input::get('Lat')!='' && Input::get('Long')!='')
    {
    $Driver = VehicleLocation::where('DriverId', '=', Input::get('DriverId'))->count(); 
     if ($Driver=='1') 
    {

                $DriverUpdate           = VehicleLocation::where('DriverId', Input::get('DriverId'))->first();
                $DriverUpdate->Lat = Input::get('Lat');
                $DriverUpdate->Long    = Input::get('Long');
                $DriverUpdate->save();

                $Response = array(
                'success' => '1',
                
            );
            return json_encode($Response);

    }
    else
    {
        $Response = array(
                'success' => '0',
                'message' => 'Driver Not Found'
            );
            return json_encode($Response);
    }
    }
    else
    {
        $Response = array(
                'success' => '0',
                'message' => 'Insufficient Data'
            );
            return json_encode($Response);
    }
    
    }



	public function KidsDriverOnMap()
    {
	if (Input::get('ParentId')!='')
    {
	$Parent = MTIServiceParent::where('id', '=', Input::get('ParentId'))->count(); 
	
	 if ($Parent=='1') 
    {
	$StudentCount = MTIServiceStudent::where('parentid', '=', Input::get('ParentId'))->count(); 
	$StudentData = MTIServiceStudent::where('parentid', Input::get('ParentId'))->get();
	$Mat ='';
	 foreach ($StudentData as $key) 
        {
		$Match = TranportallocateModel::whereRaw('find_in_set(?, `studentid`)',['2','3'])->first();
        $Mat .='1';
        }

		

		return DB::getQueryLog();
	
	
	
	}
	else
	{
	 $Response = array(
                'success' => '0',
                'message' => 'Parent Not Found');
            
            return json_encode($Response);
	}
	}
	else
	{
	$Response = array(
                'success' => '0',
                'message' => 'Insufficient Data');
            return json_encode($Response);
	}
	}
    public function GetStudentDetail()
    {
    

    if (Input::get('StudentId')!='' && Input::get('Trip')!='' && Input::get('DriverId'))
    {
    $StudentCount = MTIServiceStudent::where('id', '=', Input::get('StudentId'))->count();       
    if ($StudentCount=='1') 
    {

    
    $StartTime =  date('l').'InTime';
    
    $EndTime =  date('l').'outTime';    
    #return $EndTime;
    #Attendance Calculation starts
	$Attendance = '1';
	$dt_min = new DateTime("last monday");
	$dt_max = clone($dt_min);
	$dt1 = clone($dt_min);
	$dt2 = clone($dt_min);
	$dt3 = clone($dt_min);
	$dt4 = clone($dt_min);
	$dt_max->modify('+4 days');
	$dt1->modify('+1 days');
	$dt2->modify('+2 days');
	$dt3->modify('+3 days');
	$dt4->modify('+4 days');

	$Attendance = '{';
	$Monday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt_min->format('Y-m-d'))->first();
	if($Monday)
	{
	$Attendance .= '"MondayIn" : "'.$Monday['toschool'].'", "MondayOut" : "'.$Monday['tohome'].'",';
	}
	$Tuesday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt1->format('Y-m-d'))->first();
	if($Tuesday)
	{
	$Attendance .= '"TuesdayIn" : "'.$Tuesday['toschool'].'", "TuesdayOut" : "'.$Tuesday['tohome'].'",';
	}
	$Wednesday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt2->format('Y-m-d'))->first();
	if($Wednesday)
	{
	$Attendance .= '"WednesdayIn" : "'.$Wednesday['toschool'].'", "WednesdayOut" : "'.$Wednesday['tohome'].'",';
	}
	$Thursday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt3->format('Y-m-d'))->first();
	if($Thursday)
	{
	$Attendance .= '"ThursdayIn" : "'.$Thursday['toschool'].'", "ThursdayOut" : "'.$Thursday['tohome'].'",';
	}
	$Friday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt4->format('Y-m-d'))->first();
	if($Friday)
	{
	$Attendance .= '"FridayIn" : "'.$Friday['toschool'].'", "FridayOut" : "'.$Friday['tohome'].'",';
	}
	$Attendance .= '}';
	$Attendance = substr($Attendance, 0, -2);
    $Attendance = $Attendance.'}';       	
	#Attendance Calculation Ends
    $StudentData = MTIServiceStudent::where('id', '=', Input::get('StudentId'))->first();
    $ParentName = MTIServiceParent::where('id', '=', $StudentData['parentid'])->pluck('FirstName'); 
    $ParentPhone = MTIServiceParent::where('id', '=', $StudentData['parentid'])->pluck('Mobile'); 

    $Timing = TimingModel::where('DriverName', '=', Input::get('DriverId'))->first();	
	$StudentName = $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'];
	$Address = $StudentData['House'].' '.$StudentData['Apartment'].' '.$StudentData['Street'].' '.$StudentData['ContactCity'].' '.$StudentData['ContactState'];
    
    if ($Attendance=='}')
     {
    return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$StudentData[$StartTime].'", "endtime" : "'.$StudentData[$EndTime].'"}'; 
    } 
    else 
    {
        return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$StudentData[$StartTime].'", "endtime" : "'.$StudentData[$EndTime].'", "attendance": '.$Attendance.'}';    
    }
    
    #return $Attendance;



	exit();
	
   /*
    $Response = array(
                'success' => '1',
                'studentname' => $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'],
                'grade' => $StudentData['StudentCourse'],
                'parentname' => $ParentName,
                'address' => ,
                'triptype' =>  $StudentData['TripType'],
                'totriptype' =>  $StudentData['fromTripType'],
                'starttime' =>  $StudentData[$StartTime],
                'endtime' =>  $StudentData[$EndTime],
				'attendance' =>  $Attendance,
                'success' => '1'
                );
    return json_encode($Response);
   */ 
    } else 
    {
        $Response = array(
                'success' => '0',
                'message' => 'Student Not Found');
            
            return json_encode($Response);
    }
}
else
{
    $Response = array(
                'success' => '0',
                'message' => 'Insufficient Data');
            return json_encode($Response);
}
    
    }
    public function ShowTotalPickUp()
    {
    $BusId = TimingModel::where('DriverName', '=', Input::get('DriverId'))->pluck('VehicleCode');
    $VehicleAMCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->count();
    $VehiclePMCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->count();
    #$DriverCount = TranportallocateModel::where('busid', '=', Input::get('BusId'))->count();
    if ($VehicleAMCount=='1' && $VehiclePMCount=='1') 
    {
        $DriverData = TranportallocateModel::where('busid', '=', $BusId)->first();
        $DriverDataAM = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->first();
        $DriverDataPM = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->first();
        $VehicleCode = VehicleModel::where('AutoId', '=', $DriverData['busid'])->first();
        $amlist = count(array_filter( explode( ',', $DriverDataAM['studentid'] )));
        $pmlist = count(array_filter( explode( ',', $DriverDataPM['studentid'] )));

        $Timing = TimingModel::where('DriverName', '=', Input::get('DriverId'))->first();
        $PickUpTime = $Timing['StartTime'].' - '.$Timing['StartTime'];

        $Response = array(
                'success' => '1',
                'vehiclecode' => $VehicleCode['VehicleCode'],
                'vehiclenumber' => $VehicleCode['VehicleNumber'],
                'amlist' => $amlist,
                'pmlist' => $pmlist,
                'starttime' => $Timing['StartTime'],
                'endtime' => $Timing['EndTime'],

            );
            return json_encode($Response);
    }
    else
    {
        $Response = array(
                'success' => '0',
                'message' => 'Bus Not Found'
            );
            return json_encode($Response);
    }
    }
	
   

   public function GetDriverLocation()
    {   

    if(Input::get('driver_id')) #If all three parameters were given
    {
    $DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
    $DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
    if ($DriverCount=='1') 
    {
        
    $DriverData = VehicleLocation::select('Lat','Long')->where('DriverId', '=', Input::get('driver_id'))->get();
    $Response = array('success' => '1','lat' => $DriverData[0]->Lat, 'long' => $DriverData[0]->Long);

    $RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$DriverData[0]->Lat.','.$DriverData[0]->Long."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";  
    $GoogleApiResult = file_get_contents($RequestUrl);
    $GoogleApiResultDecoded = json_decode($GoogleApiResult);
    if($GoogleApiResultDecoded->status!='ZERO_RESULTS')
    {
    $Response = array('success' => '1','location' => $GoogleApiResultDecoded->results[0]->formatted_address);
    return json_encode($Response);
    }
    else
    {
    $Response = array('success' => '2','message' => 'Location Error');
    return json_encode($Response);    
    }
    }
    else
    {
    $Response = array('success' => '1','message' => 'Driver Not Found');
    return json_encode($Response);
    }
    }
    else
    {
    $Response = array('success' => '0','message' => 'Insufficient Data');
    return json_encode($Response);   
    }
   }


   public function PushNotification($DeviceId,$Message) 
    {
    $url = 'https://android.googleapis.com/gcm/send';
    $fields = array(
            'registration_ids' => $DeviceId,
            'data' => $Message
        );
    $headers = array(
        'Authorization: key = AIzaSyCUx1PyeAonGjbHAuVvAc74pbk9F_wVfKE',
        'Content-Type: application/json'
                      );
    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
        }
        curl_close($ch);
    
    }
    
    
}