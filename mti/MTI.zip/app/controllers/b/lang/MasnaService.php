<?php

class MasnaService extends BaseController {

## Web Service for Rider

	public function CheckUser()
	{
		$RiderData = RiderModel::where('DeviceID', Input::get('DeviceId'))->pluck('RiderId');
		$Response = array('success' => '1', 'rider_id' => $RiderData);
		return json_encode($Response);
	}

	public function Register()
	{
	$Mobile = RiderModel::where('Mobile', Input::get('Mobile'))->count();
	if ($Mobile =='0') #If the user is already Registered
	{
		$RegisterData = Input::all();
		$validation  = Validator::make($RegisterData, RiderModel::$rule);
	if ($validation->passes()) 
    {
		/*$Length = 10; Random:
		$RandomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $Length);*/
		
		$CharLength = 4; Randomlabel:
		$RandomCharString = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $CharLength);
		$NumLength = 2;
		$RandomNumString = substr(str_shuffle("0123456789"), 0, $NumLength);
		
		$RandomString = $RandomCharString.$RandomNumString;
		
		$RandomData = RiderModel::where('UniqueCode', $RandomString)->pluck('RiderId');
	if ($RandomData) { goto Randomlabel; }
		$riderModel = new RiderModel;
		$riderModel->t_Name = Input::get('Name');
		$riderModel->Mobile = Input::get('Mobile');
		$riderModel->t_GCMId = Input::get('GCMId');
		$riderModel->t_DeviceId = Input::get('DeviceId');
		$riderModel->UniqueCode = $RandomString;
		$riderModel->save();

		#InfoBip SMS Start
		$smsClient = new \infobip\SmsClient('spacetel', 'Nemanja123');
		$smsMessage = new \infobip\models\SMSRequest();
		$smsMessage->senderAddress = 'MasnaTaxi';
		$smsMessage->address = Input::get('Mobile');
		$smsMessage->message = 'MasnaTaxi aktivacioni kod : "'.$RandomString.'" - MashnaTaxi';
		$smsMessageSendResult = $smsClient->sendSMS($smsMessage);
		
		// You can use $clientCorrelator or $smsMessageSendResult as an method call argument here:
		// $smsMessageStatus = $smsClient->queryDeliveryStatus($smsMessageSendResult);
		// $deliveryStatus = $smsMessageStatus->deliveryInfo[0]->deliveryStatus;

		

		 //echo 'Success:', $smsMessageStatus->isSuccess(), "\n";
		 //echo 'Status:', $deliveryStatus, "\n";
		 //if( ! $smsMessageStatus->isSuccess()) 
		 //{
		   //  echo 'Message id:', $smsMessageStatus->exception->messageId, "\n";
		    // echo 'Text:', $smsMessageStatus->exception->text, "\n";
		     //echo 'Variables:', $smsMessageStatus->exception->variables, "\n";
		 //}
		#InfoBip SMS End

		$Response = array('success' => '1');
		return json_encode($Response);
    }
    else  #Validation Error
    {  
		$Response = array('success' => '0', 'message' => 'Please check the Username or Mobile Number'); #$validation->messages();
		return json_encode($Response);
    }
	}
	else 
	{
		$RiderUpdate = RiderModel::where('Mobile', Input::get('Mobile'))->first();
		/*$Length = 10; Randomlabel:
		$RandomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $Length);*/
		
		$CharLength = 4; RandomlabelOne:
		$RandomCharString = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $CharLength);
		$NumLength = 2; 
		$RandomNumString = substr(str_shuffle("0123456789"), 0, $NumLength);
		
		$RandomString = $RandomCharString.$RandomNumString;
		
		$RandomDataYes = RiderModel::where('UniqueCode', $RandomString)->pluck('RiderId');
	if ($RandomDataYes) { goto RandomlabelOne; }
		$RiderUpdate->t_Name = Input::get('Name');
		$RiderUpdate->t_GCMId = Input::get('GCMId');
		$RiderUpdate->t_DeviceId = Input::get('DeviceId');
		$RiderUpdate->UniqueCode = $RandomString;
		$RiderUpdate->save();	

		#InfoBip SMS Start
	    $smsClient = new \infobip\SmsClient('spacetel', 'Nemanja123');
		$smsMessage = new \infobip\models\SMSRequest();
		$smsMessage->senderAddress = 'MasnaTaxi';
		$smsMessage->address = Input::get('Mobile');
		$smsMessage->message = 'MasnaTaxi aktivacioni kod : "'.$RandomString.'" - MashnaTaxi';
		$smsMessageSendResult = $smsClient->sendSMS($smsMessage);
		
		// You can use $clientCorrelator or $smsMessageSendResult as an method call argument here:
		// $smsMessageStatus = $smsClient->queryDeliveryStatus($smsMessageSendResult);
		// $deliveryStatus = $smsMessageStatus->deliveryInfo[0]->deliveryStatus;

		 //echo 'Success:', $smsMessageStatus->isSuccess(), "\n";
		 //echo 'Status:', $deliveryStatus, "\n";
		 //if( ! $smsMessageStatus->isSuccess()) 
		 //{
		   //  echo 'Message id:', $smsMessageStatus->exception->messageId, "\n";
		    // echo 'Text:', $smsMessageStatus->exception->text, "\n";
		     //echo 'Variables:', $smsMessageStatus->exception->variables, "\n";
		 //}
		#InfoBip SMS End



		$Response = array('success' => '1', 'message' => 'Updated Data'); #, 'rider_id' => $LastId
		return json_encode($Response);
	}	
	}

	public function Authentication()
	{	
	$AuthCheck = RiderModel::where('UniqueCode', '=', Input::get('UniqueCode'))->where('t_DeviceId', '=', Input::get('DeviceId'))->pluck('RiderId');
	if ($AuthCheck) 
	{
		$RiderData = RiderModel::where('RiderId', '=', $AuthCheck)->get();	
	foreach ($RiderData as $Data)
	{
		$NewName = $Data->t_Name;
		$DeviceId = $Data->t_DeviceId;
		$GCMId = $Data->t_GCMId;
		$RiderId = $Data->RiderId;
	}
		$RiderUpdate = RiderModel::where('RiderId', $RiderId)->first();
		$RiderUpdate->Name = $NewName;
		$RiderUpdate->DeviceId = $DeviceId;
		$RiderUpdate->GCMId = $GCMId;
		$RiderUpdate->t_Name = '';
		$RiderUpdate->t_DeviceId = '';
		$RiderUpdate->t_GCMId = '';
		$RiderUpdate->save();
		$Response = array('success' => '1', 'rider_id' => $RiderId);
		return json_encode($Response);
		exit();
	}
	else
	{
		$Response = array('success' => '0', 'message' => 'Invalid Activation Code');
		return json_encode($Response);
	}
	}
	
	public function Booking()
	{

	#Checking if the Rider IsActive
	$IsRiderActive = RiderModel::where('RiderId', '=', Input::get('RiderId'))->where('IsActive', '=', '1')->where('DeviceId', '=', Input::get('DeviceId'))->count(); //pluck('RiderId');  //->count();
	
	if ($IsRiderActive =='0') 
	{
		$Response = array('success' => '2', 'message_title' => 'Alert', 'message' => ' We have detected misuse of application, your account is temporarily suspended. To unblock your account please send us a mail with an explanation of what exactly happened');
		return json_encode($Response);
	}

	else #If the Rider has IsActive '1'
	{
	

	#Initial Step to Set Tarrif
	#Setting Time
		$CurrentDay = date("N");
		$CurrentDate = date("Y-m-d");
		$CurrentTime = date("H:i:s");
		$CurrentHour = date("H");
	#	$CurrentDay = '7';
	#	$CurrentDate = '2015-03-29';
	#	$CurrentHour = '22';
	#Holiday Checking
	$IsHoliday = HolidayModel::where('holiday_date', '=', $CurrentDate)->count();		
	if ($CurrentDay =='7' || $IsHoliday =='1') #Today is Holiday or Sunday
	{
		$TarrifID = '2';
	}
	//elseif($CurrentHour > '20' ||  $CurrentHour < '6')
	elseif($CurrentHour > '21' ||  $CurrentHour < '6')  #The Current Time is between 10pm and 6am --> Late Night or Regular Day
	{
		$TarrifID = '2';
	}
	else # It was no holiday or Sunday and the Time is on Regular Time
	{
		$TarrifID = '1';	
	}
	#Tariffid was set while exiting from the loop
	#If the Booking Type was Fast Booking
	if((Input::get('BookingType') =='F') && (Input::get('Lat') !='') && (Input::get('Long') !=''))	  #Fast Booking
	{	
	$AllocatedDriver = DB::select('call GetDriver(?,?,?,?)',array(Input::get('Lat'),Input::get('Long'),'0',date('Y-m-d H:i:s')));	
//	return $AllocatedDriver;
	if(isset($AllocatedDriver[0]->DriverId))
	{
		
	$DriverUpdate = DriverModel::where('DriverId', '=', $AllocatedDriver[0]->DriverId)->first();
	$DriverUpdate->IsOnline = '2';
	$DriverUpdate->save();
		
		
		$FreshTripEntry = new TripModel;
		$FreshTripEntry->BookingType = 'F';
		$FreshTripEntry->TarrifID = $TarrifID;
		$FreshTripEntry->Start_tariffId	 = $TarrifID;
		$FreshTripEntry->RequestDate = $CurrentDate;
		$FreshTripEntry->RequestTime = $CurrentTime;
		$FreshTripEntry->RiderId = Input::get('RiderId');
		$FreshTripEntry->DriverId = $AllocatedDriver[0]->DriverId;
		$FreshTripEntry->DriverResponse = '0';
		$FreshTripEntry->save();
		$SavedTripId = $FreshTripEntry->AutoId;
	#Push Notification Service
	$DriverGCMId = DriverModel::where('DriverId', '=', $AllocatedDriver[0]->DriverId)->pluck('GCMId');
	#return $DriverGCMId;
	#$PushMessage = "{ 'Trip Request' : 'Fast Booking', 'Trip Id ' : ".$SavedTripId.", Rider Lat : ".Input::get('Lat').", Rider Long : ".Input::get('Long').", Rider Time ";
	#anas
	#return '1';
	$TaxiLocation = DriverLatLongModel::where('DriverId', '=', $AllocatedDriver[0]->DriverId)->get();




	#$DriverData = DriverModel::where('DriverId', '=', $AllocatedDriver[0]->DriverId)->get();
	$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$TaxiLocation[0]->Lat.','.$TaxiLocation[0]->Long;
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult);
	$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."', 'ArrivalTime' : '".$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text."'}"; #$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text
	$DeviceId = array($DriverGCMId);
	$Message = array("price"=>urldecode($PushMessage));
	$this->PushNotification($DeviceId, $Message);
	$Response = array('success' => '1', 'trip_id' => $SavedTripId);
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'No Taxi available close to your location. Please try after some time');
	return json_encode($Response);
	}
		
	}
	elseif((Input::get('BookingType') =='M')  && (Input::get('DriverId') !=''))  #Manual Booking
	{

	$IsDriverAvailable = DriverModel::where('DriverId', '=', Input::get('DriverId'))->pluck('IsOnline');
	if ($IsDriverAvailable =='1') 
	{
	#changehere
	
	$DriverUpdate = DriverModel::where('DriverId', '=', Input::get('DriverId'))->first();
	$DriverUpdate->IsOnline = '2';
	$DriverUpdate->save();
	
	#Checking if the TripId is Created Already
	$IsTripIdActive = TripModel::where('AutoId', '=', Input::get('TripId'))->pluck('AutoId');
	if($IsTripIdActive) # Having Trip Already so updating with new New DriverId and Date, Time
	{
		
		$UpdateTripDetails = TripModel::where('AutoId', $IsTripIdActive)->first();
		$UpdateTripDetails->TarrifID = $TarrifID;
		$UpdateTripDetails->Start_tariffId = $TarrifID;
		$UpdateTripDetails->DriverId = Input::get('DriverId');
		$UpdateTripDetails->RequestDate = $CurrentDate;
		$UpdateTripDetails->RequestTime = $CurrentTime;
		$UpdateTripDetails->save();
		$SavedTripId = $UpdateTripDetails->AutoId;
		#manual
		$TaxiLocation = DriverLatLongModel::where('DriverId', '=', Input::get('DriverId'))->get();
		#return '1';
		$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$TaxiLocation[0]->Lat.','.$TaxiLocation[0]->Long;
		$GoogleApiResult = file_get_contents($RequestUrl);
		$GoogleApiResultDecoded = json_decode($GoogleApiResult);
		$DriverGCMId = DriverModel::where('DriverId', '=', Input::get('DriverId'))->pluck('GCMId');
		$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."', 'ArrivalTime' : '".$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text."'}"; #$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text
#		$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."'}";
		$DeviceId = array($DriverGCMId);
		$Message = array("price"=>urldecode($PushMessage));
		$this->PushNotification($DeviceId, $Message);
#		return $DriverGCMId;

		$Response = array('success' => '1', 'trip_id' => $IsTripIdActive, 'message_title' => 'Updated', 'message' => 'Updated the Trip Details');
		return json_encode($Response);
	}
	else # Create fresh Trip
	{
		$FreshTripEntry = new TripModel;
		$FreshTripEntry->BookingType = 'M';
		$FreshTripEntry->TarrifID = $TarrifID;
		$FreshTripEntry->RequestDate = $CurrentDate;
		$FreshTripEntry->Start_tariffId	 = $TarrifID;
		$FreshTripEntry->RequestTime = $CurrentTime;
		$FreshTripEntry->RiderId = Input::get('RiderId');
		$FreshTripEntry->DriverId = Input::get('DriverId');
		$FreshTripEntry->DriverResponse = '0';
		$FreshTripEntry->save();
		$SavedTripId = $FreshTripEntry->AutoId; #LastInsertedTripId
		
		$TaxiLocation = DriverLatLongModel::where('DriverId', '=', Input::get('DriverId'))->get();

		$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$TaxiLocation[0]->Lat.','.$TaxiLocation[0]->Long;
		$GoogleApiResult = file_get_contents($RequestUrl);
		$GoogleApiResultDecoded = json_decode($GoogleApiResult);

		$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."', 'ArrivalTime' : '".$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text."'}"; #$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text
		$DriverGCMId = DriverModel::where('DriverId', '=', Input::get('DriverId'))->pluck('GCMId');
		#$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."'}";
		$DeviceId = array($DriverGCMId);
		$Message = array("price"=>urldecode($PushMessage));
		$this->PushNotification($DeviceId, $Message);
		$Response = array('success' => '1', 'trip_id' => $SavedTripId, 'message_title' => 'Saved', 'message' => 'Trip Details Saved');
		return json_encode($Response);
	}
	}
	else
	{	
	$Response = array('success' => '0', 'message_title' => 'Driver Already Booked','message' => 'The selected driver was booked already. Please choose another driver');
	return json_encode($Response);
	}
	}
	else #Invalid Booking
	{
	return 'Invalid Booking';
	exit();
	}
	#return 'Tarrif is '.$TarrifID.' Day is '.$CurrentDay.' Time is '.$CurrentHour.'Current Date is '.date("Y-m-d").' - Count : '.$IsHoliday;	
	}
	}

	public function DriverResponse()
	{
	
#	Change ignore id status here
#	Driver Details
	



	$IsTripAllocated = TripModel::where('AutoId', '=', Input::get('TripId'))->get();		#$reqtime = $IsTripAllocated[0]->RequestTime;		return $IsTripAllocated;
	$TaxiLocation = DriverLatLongModel::where('DriverId', '=', $IsTripAllocated[0]->DriverId)->get();
	$TimeDifference = strtotime(date("Y-m-d H:i:s")) - strtotime($IsTripAllocated[0]->RequestDate.' '.$IsTripAllocated[0]->RequestTime);
	#return date("Y-m-d H:i:s").' - '.$IsTripAllocated[0]->RequestDate.' '.$IsTripAllocated[0]->RequestTime;
	#return strtotime(date("Y-m-d H:i:s")).' - '.strtotime($IsTripAllocated[0]->RequestDate.' '.$IsTripAllocated[0]->RequestTime);
	#return $TimeDifference;

	$DriverUpdate = DriverModel::where('DriverId', '=', $IsTripAllocated[0]->DriverId)->first();
	$DriverUpdate->IsOnline = '2';
	$DriverUpdate->save();

	if($IsTripAllocated[0]->DriverResponse=='1' && Input::get('Lat')!='' && Input::get('Long')!='') #DriverResponse is Allocated
	{

	$DriverLatLong = DriverLatLongModel::where('DriverId', '=', $IsTripAllocated[0]->DriverId)->get();	
	#return $DriverLatLong;
	foreach ($DriverLatLong as $DriverData)
	{
		$DriverLat = $DriverData->Lat;
		$DriverLong = $DriverData->Long;
	}
	$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$DriverLat.','.$DriverLong;
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult); //Decoding Google Sent 
	$DriverDetails = DriverModel::where('DriverId', '=', $IsTripAllocated[0]->DriverId)->get();
	$Response = array('success' => '1', 'status' => '1', 'message_title' => 'Driver Allocated', 'message' => 'Trip Details Saved',
					  'trip_id' => $IsTripAllocated[0]->AutoId, 'driver_id' => $IsTripAllocated[0]->DriverId,
					  'driver_name' => $DriverDetails[0]->Firstname, 'driver_photo' => $DriverDetails[0]->DriverPhoto,
					  'taxi_plate' => $DriverDetails[0]->TaxiPlateNo, 'taxi_model' => $DriverDetails[0]->TaxiModel,
					  'taxi_lat' => $TaxiLocation[0]->Lat, 'taxi_long' => $TaxiLocation[0]->Long, 
					  'mobile_number' => $DriverDetails[0]->Mobile, 'distance' => $GoogleApiResultDecoded->rows[0]->elements[0]->distance->text,
					  'arrival_time' => $GoogleApiResultDecoded->rows[0]->elements[0]->duration->text);
	return json_encode($Response);
	}
	elseif($TimeDifference <= 10) #10 Seconds not completed
	{
	$Response = array('success' => '1', 'status' => '2');
	return json_encode($Response);
	}
	elseif($TimeDifference > 10 && Input::get('BookingType')=='M' ) #10 Seconds completed for Manual Booking, driver not responded
	{
	$Response = array('success' => '1', 'status' => '0', 'message' => 'The selected vehicle has not been able to pick you up. Sorry for the inconvenience. Please select another cab');
	return json_encode($Response);
	}
	elseif($TimeDifference  > 10 && Input::get('BookingType')=='F' && Input::get('Lat')!='' && Input::get('Long')!='' ) #10 Seconds completed for Fast Booking Driver not responded, sending request to next driver
	{	
	if((Input::get('Exclude')=='')) 
	{ 
	$Exclude = $IsTripAllocated[0]->DriverId;	
	}
	else
	{
	$Exclude = Input::get('Exclude').','.$IsTripAllocated[0]->DriverId;
	}	
	$NextAllocatedDriver = DB::select('call GetDriver(?,?,?,?)',array(Input::get('Lat'),Input::get('Long'),$Exclude,date('Y-m-d H:i:s')));
	if($NextAllocatedDriver)
	{
	$UpdateTripDetails = TripModel::where('AutoId', Input::get('TripId'))->first();
	$UpdateTripDetails->DriverId = $NextAllocatedDriver[0]->DriverId;
	$UpdateTripDetails->RequestDate = date("Y-m-d");
	$UpdateTripDetails->RequestTime = date("H:i:s");
	$UpdateTripDetails->save();
	#herepush notification 

	$DriverGCMId = DriverModel::where('DriverId', '=', $NextAllocatedDriver[0]->DriverId)->pluck('GCMId');
	
	$TaxiLocation = DriverLatLongModel::where('DriverId', '=', $NextAllocatedDriver[0]->DriverId)->get();

	$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$TaxiLocation[0]->Lat.','.$TaxiLocation[0]->Long;
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult);
	$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".Input::get('TripId')."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."', 'ArrivalTime' : '".$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text."'}"; #$GoogleApiResultDecoded->rows[0]->elements[0]->duration->text
	$DeviceId = array($DriverGCMId);
	$Message = array("price"=>urldecode($PushMessage));
	$this->PushNotification($DeviceId, $Message);


	$Response = array('success' => '1', 'status' => '0', 'message' => 'No response from driver. Sending request to next driver', 'ignore_driver_id' => $IsTripAllocated[0]->DriverId);
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0','message' => 'No Taxi available close to your location. Please try after some time');
	return json_encode($Response);
	}
	}
	else
	{
	$Response = array('success' => '0','message' => 'Invalid Booking');
	return json_encode($Response);
	}
	
	
	
	
	}




	public function ListTaxi()
	{	
	$ListTaxi = DB::select('call ListTaxi(?,?,?)',array(Input::get('Lat'),Input::get('Long'),date('Y-m-d H:i:s')));
	if(empty($ListTaxi))
	{
	$Response = array('success' => '0','message' => 'No Taxi available close to your location. Please try after some time');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '1', 'taxi_list' => $ListTaxi);
	return json_encode($Response);
	}	
	}



	public function DriverLocation()
	{	

	if(Input::get('driver_id') && Input::get('Lat')!='' && Input::get('Long')!='') #If all three parameters were given
	{
	$DriverLatLong = DriverLatLongModel::where('DriverId', '=', Input::get('driver_id'))->get();	
	foreach ($DriverLatLong as $DriverData)
	{
		$DriverLat = $DriverData->Lat;
		$DriverLong = $DriverData->Long;
	}

	$RequestUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".Input::get('Lat').",".Input::get('Long')."&destinations=".$DriverLat.','.$DriverLong;
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult);
	if($GoogleApiResultDecoded->rows[0]->elements[0]->status!='ZERO_RESULTS')
	{
	$Response = array('success' => '1',
					  'driver_lat' => $DriverLat,
					  'driver_long' => $DriverLong,	
					  'arrival_time' => $GoogleApiResultDecoded->rows[0]->elements[0]->duration->text,
					  'distance' => $GoogleApiResultDecoded->rows[0]->elements[0]->distance->text);
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0','message' => 'Location Error');
	return json_encode($Response);
	}
	}
	else
	{
	$Response = array('success' => '0','message' => 'Insufficient Data');
	return json_encode($Response);
	}
	}	
	
	public function TripCancel()
	{	
	if(Input::get('trip_id') && Input::get('cancel_by')!='' && Input::get('message')!='') #If all three parameters were given
	{
	$TripCancelDetails = TripModel::where('AutoId', Input::get('trip_id'))->first();
	$TripCancelDetails->IsCancel = '1';
	$TripCancelDetails->CanceledBy = Input::get('cancel_by');
	$TripCancelDetails->CancelReason = Input::get('message');
	$TripCancelDetails->save();	
	
	//Driver Details
	$DriverId = TripModel::where('AutoId', '=', Input::get('trip_id'))->pluck('DriverId');
	$DriverUpdate = DriverModel::where('DriverId', '=', $DriverId)->first();
	$DriverUpdate->IsOnline = '1';
	$DriverUpdate->save();

	if(Input::get('cancel_by')=='rider') #Push Notification for Rider
	{
	#Push Notification Service
	$DriverId = TripModel::where('AutoId', '=', Input::get('trip_id'))->pluck('DriverId');
	$DriverGCMId = DriverModel::where('DriverId', '=', $DriverId)->pluck('GCMId');
	#here
	$PushMessage = "{'message' : 'Rider cancelled the ride. Sorry for harassment', 'message_title' : 'Alert', 'Type' : 'TripCancel'}";
	#	$PushMessage = "Rider cancelled the ride. Sorry for harassment";
	$DeviceId = array($DriverGCMId);
	$Message = array("price"=>urldecode($PushMessage)); 
	$this->PushNotification($DeviceId, $Message);
	#End of Push Notification Service
	}
	elseif(Input::get('cancel_by')=='driver')  #Push Notification for Driver
	{
	#Push Notification Service
	$RiderId = TripModel::where('AutoId', '=', Input::get('trip_id'))->pluck('RiderId');
	$RiderGCMId = RiderModel::where('RiderId', '=', $RiderId)->pluck('GCMId');
	$PushMessage = "{'message' : 'The selected vehicle has not been able to pick you up. Sorry for the inconvenience. Please select another cab', 'message_title' : 'Alert', 'Type' : 'TripCancel'}";
	#$PushMessage = "The selected vehicle has not been able to pick you up. Sorry for the inconvenience. Please select another cab";
	$DeviceId = array($RiderGCMId);
	$Message = array("price"=>urldecode($PushMessage)); 
	$this->PushNotification($DeviceId, $Message);
	#End of Push Notification Service
	}
	else
	{
	$Response = array('success' => '0','message' => 'Only Driver or Rider can Cancel the Trip');
	return json_encode($Response);	
	}
	$Response = array('success' => '1','message' => 'Cancelled Succesfully');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0','message' => 'Insufficient Data');
	return json_encode($Response);
	}
	}

	public function TripCost()
	{	
	if (Input::get('trip_id')) 
	{
	$TripData = TripModel::find(Input::get('trip_id')); 	#Fetching Trip Data
	if ($TripData) 
	{
	$DriverData = DriverModel::find($TripData->DriverId); 	#Fetching Driver Data
	$Amount = TariffModel::find($TripData->TarrifID); 		#Fetching Amount
	$DistanceLocal = TripModel::where('AutoId', Input::get('trip_id'))->pluck('TripDistance');
	$OutDistance = OutSideCity::where('TripId', Input::get('trip_id'))->sum('TotalDistance');
	$TotalDistance = $DistanceLocal + $OutDistance;
	$Response = array('success' => '1','driver_photo' => $DriverData->DriverPhoto, 'taxi_photo' => $DriverData->TaxiImage, 'trip_cost' => $TripData->TotalFare, 'distance' => $TotalDistance);
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0','message' => 'Trip Not Found');
	return json_encode($Response);
	}
	}
	else
	{
	$Response = array('success' => '0','message' => 'Insufficient Data');
	return json_encode($Response);	
	}	
	}

	public function Rating()
	{	
	if (Input::get('trip_id') && Input::get('rating') >= '0' && Input::get('rating') <= '5') #If both TripId and Rating was given and Rating should between 0-5
	{
	$RiderUpdate = TripModel::where('AutoId', Input::get('trip_id'))->first();
	if ($RiderUpdate) 
	{
	$RiderUpdate->RideRating = Input::get('rating');
	$RiderUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);	
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Invalid Trip Id');
	return json_encode($Response);		
	}
	}
	else
	{
	$Response = array('success' => '0');
	return json_encode($Response);	
	}	
	}


	public function FareReview()
	{	
	if (Input::get('trip_id') && Input::get('review_by') && Input::get('message')) #If both TripId and Rating was given and Rating should between 0-5
	{
	$RiderUpdate = TripModel::where('AutoId', Input::get('trip_id'))->first();
	if($RiderUpdate && Input::get('review_by')=='rider') #Push Notification for Rider
	{
	$RiderUpdate->FairReviewByRider = Input::get('message');
	$RiderUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	elseif($RiderUpdate && Input::get('review_by')=='driver')
	{
	$RiderUpdate->FairReviewByDriver = Input::get('message');
	$RiderUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Insufficient Data');
	return json_encode($Response);		
	}
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Insufficient Data');
	return json_encode($Response);			
	}
	}



	public function RiderProfile()
	{	
	if (Input::get('rider_id')) #If both TripId and Rating was given and Rating should between 0-5
	{
	$RiderData = RiderModel::find(Input::get('rider_id')); 	#Fetching Rider Data
	if ($RiderData) 
	{
	$Response = array('success' => '1', 'rider_name' => $RiderData->Name, 'rider_mobile' => $RiderData->Mobile, 'rider_email' => $RiderData->Email, 'rider_firstname' => $RiderData->Firstname, 'rider_lastname' => $RiderData->Lastname);
	return json_encode($Response);		
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Invalid Rider Id');
	return json_encode($Response);		
	}
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Enter Rider Id');
	return json_encode($Response);	
	}	
	}

	public function RiderProfileSave()
	{	
	#
	$RiderData = Input::all();
	$data = Input::get('RiderId');
	


	#$RiderCount = RiderModel::where('RiderId', Input::get('RiderId'))->count(); 
	$RiderCount = RiderModel::where('RiderId', Input::get('RiderId'))->where('DeviceId', '=', Input::get('DeviceId'))->count(); 
	$validation  = Validator::make($RiderData, RiderModel::$updaterules);
	if ($RiderCount=='1') 
	{

	if ($validation->passes()) 
    {
    $TriggerUpdate = RiderModel::where('RiderId', $data)->update($RiderData);
	$Response = array('success' => '1', 'message' => 'Updated Succesfully');
	return json_encode($Response);	
    }
    else
    {
    $Response = array('success' => '0', 'message' => 'Insufficient Data');  #, 'validationerrorfortesting' => $validation->messages()
	return json_encode($Response);
    }	
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Rider Not Exist');
	return json_encode($Response);

	}
	
	}

	public function RiderEmail()
	{	
	if (Input::get('rider_id')) 
	{
	$RiderEmail = RiderModel::where('RiderId', Input::get('rider_id'))->pluck('Email');
	if ($RiderEmail) 
	{
	$Response = array('success' => '1', 'email' => $RiderEmail);
    return $Response;
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Email Not Found');
    return $Response;
	}
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Email Not Found');
    return $Response;	
	}
	}

	public function ContactUs()
	{	
	if (Input::get('rider_id') && Input::get('rider_email') && Input::get('message')) 
	{
	$RiderName = RiderModel::where('RiderId', Input::get('rider_id'))->pluck('Name');
	if ($RiderName) 
	{
	$Email = Input::get('rider_email');
	$Msg = Input::get('message');
	#Triggering Email to the one Configured in the Web Panel
	 Mail::send([],array('foo' => $RiderName, 'name' => $Email, 'email' => $Msg), function($message) use ($RiderName, $Email, $Msg)
    {   
        $message->setBody("From : ".$Email."<br>Subject : ".$Msg."<br><br>Sincerely,</p><p>Masna Taxi. <br/><br/> This is an automatically generated email. Please do not reply. © Masna Taxi</p>", "text/html");
        $message->to(User::where('id','1')->pluck('Email'));
        $message->subject('Contact Us From Ma$na Taxi');
        });
	$Response = array('success' => '1', 'message' => 'Mail Sent Succesfully');
    return $Response;		
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Rider Not Found');
    return $Response;
	}
	
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Insufficient Data');
    return $Response;		
	}

	}

## Web Service for Driver

		public function CheckDriver()
	{
		$DriverData = DriverModel::where('DeviceID', Input::get('device_id'))->where('IsActive', '1')->pluck('DriverId');
		if($DriverData)
		{
		$AuthDriverUpdate = DriverModel::where('DriverId', $DriverData)->first();
		$AuthDriverUpdate->IsOnline = '1';
		$AuthDriverUpdate->save();
		}
		$Response = array('success' => '1', 'driver_id' => $DriverData);
		return json_encode($Response);
	}

		public function DriverActivation()
	{
		$AuthorizedDriver = DriverModel::where('UniqueCode', '=', Input::get('activation_code'))->where('IsActive', '1')->pluck('DriverId');
		if ($AuthorizedDriver) 
		{
		$AuthDriverUpdate = DriverModel::where('DriverId', $AuthorizedDriver)->first();
		$AuthDriverUpdate->GCMId = Input::get('gcm_id');
		$AuthDriverUpdate->DeviceId = Input::get('device_id');
		$AuthDriverUpdate->IsOnline = '1';
		$AuthDriverUpdate->save();

		// $SMSSubject = 'Dear user, Your Ma$na Taxi Verification code is '.$RandomString.', More information contact info@masnataxi.com';
		// $Url = "http://projects.bizarresoftware.in/infobip/json.php?Sender=".Input::get('Mobile')."&Subject=".$SMSSubject;	
		// $Result = file_get_contents($Url);
		// $ResultValue = json_decode($Result);
		$Response = array('success' => '1', 'driver_id' => $AuthorizedDriver);
		return json_encode($Response);
		}
		else
		{
		
		$Response = array('success' => '0', 'message' => 'Your Account is blocked, Please contact Administrator');
		return json_encode($Response);
		}
	}

	public function DriverInfo()
	{	
		$DriverData = DriverModel::find(Input::get('driver_id')); 	#Fetching Driver DAta
		if ($DriverData) 
		{
		$RideRating = TripModel::where('DriverId', '=', Input::get('driver_id'))->avg('RideRating');
		$Response = array('success' => '1', 'driver_name' => $DriverData->Firstname.' '.$DriverData->Lastname, 'driver_photo' => $DriverData->DriverPhoto, 'taxi_model' => $DriverData->TaxiModel, 'taxi_plateno' => $DriverData->TaxiPlateNo, 'rating' => "".round($RideRating,1)."");
		return json_encode($Response);
		}
		else
		{
		$Response = array('success' => '0', 'message' => 'Driver Not Found');
		return json_encode($Response);		
		}
	}


	public function AcceptTrip()
	{	
		




		if (Input::get('trip_id') && Input::get('driver_id')) 
		{
		$TripCount = TripModel::where('AutoId', Input::get('trip_id'))->count(); # Not checking whether the trip is previously allocated or not
		$RiderCount = DriverModel::where('DriverId', Input::get('driver_id'))->where('IsActive', '=', '1')->where('IsOnline', '=', '2')->count();
		if ($TripCount =='1' && $RiderCount=='1') 
		{

		$TripTime = TripModel::where('AutoId', Input::get('trip_id'))->pluck('updated_at');
		
		$CurrentDateTime = date("Y-m-d H:i:s");

		#$TimeDifference = $TripTime - $CurrentDateTime;
		
		$TimeDifference = strtotime(date($CurrentDateTime)) - strtotime(date($TripTime));
		#return $TripTime.' | '.$CurrentDateTime.' | '.$TimeDifference;
#		return $CurrentDateTime;

		
		if ($TimeDifference >'30') 
		{
		$Response = array('success' => '3', 'message' => 'Timeout');
		return json_encode($Response);
		}
		else
		{
		$TripData = TripModel::find(Input::get('trip_id'));
		$TimeDifference = strtotime(date("Y-m-d H:i:s")) - strtotime($TripData->RequestDate.' '.$TripData->RequestTime);
		$TripUpdate = TripModel::where('AutoId', Input::get('trip_id'))->first();
		$TripUpdate->DriverResponse = '1';
		$TripUpdate->ResponseTime = $TimeDifference;;
		$TripUpdate->save();

		//Driver Details
		$DriverUpdate = DriverModel::where('DriverId', Input::get('driver_id'))->first();
		$DriverUpdate->IsOnline = '2';
		$DriverUpdate->save();

		$Rider = TripModel::where('AutoId', Input::get('trip_id'))->pluck('RiderId');
		$RiderData = RiderModel::find($Rider);
		$PushMessage = "{'Type' : 'DriverAccepted'}";
		$DeviceId = array($RiderData->GCMId);
		$Message = array("price"=>urldecode($PushMessage)); 
		$this->PushNotification($DeviceId, $Message);

		$Response = array('success' => '1');
		return json_encode($Response);
		}
		
		

/*

		$PushMessage = "{'Type' : 'TripRequest', 'TripId' : '".$SavedTripId."', 'RiderLat' : '".Input::get('Lat')."', 'RiderLong' : '".Input::get('Long')."'}";
		#return $PushMessage;
		$DeviceId = array($DriverGCMId);
		$Message = array("price"=>urldecode($PushMessage));
		$this->PushNotification($DeviceId, $Message);
*/

		}
		else
		{
		$Response = array('success' => '2', 'message' => 'Invalid Booking');
		return json_encode($Response);			
		}
		}
		else
		{
		$Response = array('success' => '0', 'message' => 'Insufficient Data');
		return json_encode($Response);			
		}
	}

	public function BeginTrip()
	{

	$TripCount = TripModel::where('AutoId', Input::get('TripId'))->count();
	if ($TripCount =='1' && Input::get('pickup_lat') !='' && Input::get('pickup_long') !='') 
	{
	$Driver = TripModel::where('AutoId', Input::get('TripId'))->pluck('DriverId');
	$DriverDetailUpdate = DriverModel::find($Driver);
	$DriverDetailUpdate->IsOnline = '2';
	$DriverDetailUpdate->save();
	#Reverse Geocode
	$RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".Input::get('pickup_lat').','.Input::get('pickup_long')."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";	
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult);
	$TaxiDetailUpdate = TripModel::find(Input::get('TripId'));
	$TaxiDetailUpdate->PickupTime = date("Y-m-d H:i:s");
	$TaxiDetailUpdate->PickupLAT = Input::get('pickup_lat');
	$TaxiDetailUpdate->PickupLONG = Input::get('pickup_long');
	$TaxiDetailUpdate->PickupAddress = $GoogleApiResultDecoded->results[0]->formatted_address;
	$TaxiDetailUpdate->save();
	$Rider = TripModel::where('AutoId', Input::get('TripId'))->pluck('RiderId');
	$RiderData = RiderModel::find($Rider);
	$PushMessage = "{'Type' : 'BeginTrip'}";
	$DeviceId = array($RiderData->GCMId);
	$Message = array("price"=>urldecode($PushMessage)); 
	$this->PushNotification($DeviceId, $Message);
	#anas
	#return $RiderData->GCMId;

	$Response = array('success' => '1', 'message' => 'Succesfully Updated');
	return json_encode($Response);			
	}
	else
	{
		$Response = array('success' => '0', 'message' => 'Insufficient Data');
		return json_encode($Response);			
	}
	}

	public function UpdateTrip()
	{
	
	$TripUpdate = TripModel::where('AutoId', Input::get('trip_id'))->first();
	if($TripUpdate && Input::get('tot_waittime') !='' && Input::get('trip_distance') !='')
	{
	$TripUpdate->TotWaitingTime = Input::get('tot_waittime');
	$TripUpdate->TripDistance = Input::get('trip_distance');
	$TripUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Insufficient Data');
	return json_encode($Response);
	}
	
	}

	public function Tariff3Start()
	{
	$TripCount = TripModel::where('AutoId', Input::get('TripId'))->count();
	if ($TripCount=='1')
	{
	$Tariff3Data = Input::all();
	$validation  = Validator::make($Tariff3Data, OutSideCity::$rule);
		if ($validation->passes()) 
	    {
	    $Tariff3Id = OutSideCity::create($Tariff3Data);
		$LastTariff3Id = $Tariff3Id->Id;
	    $Response = array('success' => '1', 'tariff3' => $LastTariff3Id);
		return json_encode($Response);	
	    }
	    else
	    {
	    $Response = array('success' => '0', 'message' => 'Validaton Error');
		return json_encode($Response);	
	    }
	}
	else
	{
	$Response = array('success' => '0', 'message' => 'Trip Not Found');
	return json_encode($Response);
	}	
	}

	public function Tariff3Stop()
	{
	$Tariff3Count = OutSideCity::where('Id', Input::get('tariff3_id'))->count();
	if ($Tariff3Count=='1' && Input::get('lat') !='' && Input::get('long') !='' && Input::get('distance') !='' && Input::get('waittime') !='')
	{
	$Trip3Update = OutSideCity::where('Id', Input::get('tariff3_id'))->first();
	$Trip3Update->EndLat = Input::get('lat');
	$Trip3Update->EndLong = Input::get('long');
	$Trip3Update->TotalDistance = Input::get('distance');
	$Trip3Update->TotWaitingTime = Input::get('waittime');
	$Trip3Update->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0');
	return json_encode($Response);
	}	
	}

	public function EndTrip()
	{

	$TripUpdate = TripModel::where('AutoId', Input::get('trip_id'))->first();	
	#If TripId exists Update the Trip Detais and Proceed into function
	if($TripUpdate && Input::get('lat')!='' && Input::get('long')!='')
	{

	$TariffId = TripModel::where('AutoId', Input::get('trip_id'))->pluck('Start_tariffId');

	if ($TariffId==1) 
	{
		$DistanceTravelled = Input::get('tot_distance');
		$Increment = $DistanceTravelled*16/100;
		$DistanceTravelledRounded = round(($DistanceTravelled + $Increment),2);
	
	}
	elseif($TariffId==2)
	{
		$DistanceTravelled = Input::get('tot_distance');
		$Increment = $DistanceTravelled*6/100;
		$DistanceTravelledRounded = round(($DistanceTravelled + $Increment),2);
		
	}
	else
	{
		$DistanceTravelled = Input::get('tot_distance');
		$Increment = $DistanceTravelled*6/100;
		$DistanceTravelledRounded = round(($DistanceTravelled + $Increment),2);
		
	}

	

	$TripData = TripModel::where('AutoId', Input::get('trip_id'))->firstOrFail();
	$TripUpdate->DropLAT = Input::get('lat');
	$TripUpdate->DropLONG = Input::get('long');
	#Reverse Geocode to store address
	$RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".Input::get('lat').','.Input::get('long')."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";	
	$GoogleApiResult = file_get_contents($RequestUrl);
	$GoogleApiResultDecoded = json_decode($GoogleApiResult);

		if($GoogleApiResultDecoded->status!='ZERO_RESULTS')
	{
		$TripUpdate->DropAddress = $GoogleApiResultDecoded->results[0]->formatted_address;	
		#return $GoogleApiResultDecoded->results[0]->formatted_address;	
	}
	else
	{
#	return '';
	$Response = array('success' => '0', 'message' => 'Invalid Lat Long');
	return json_encode($Response);

	$TripUpdate->DropAddress = '';	

	}
	
	$TripUpdate->DropAddress = $GoogleApiResultDecoded->results[0]->formatted_address;		
	$TripUpdate->TotWaitingTime = Input::get('tot_waittime');
	$TripUpdate->TripDistance = $DistanceTravelledRounded;
	
	
	$TripUpdate->DropTime = date("Y-m-d H:i:s");
	$TripUpdate->save();

	$Trip3Update = OutSideCity::where('Id', Input::get('tariff3_id'))->first();
	#If trip3 details exist

	if ($Trip3Update)
	{
		$OutsideTravelled = Input::get('t3_distance');
		$OutsideIncrement = $OutsideTravelled*6/100;
		$OutsideDistanceTravelledRounded = round(($OutsideTravelled + $OutsideIncrement),2);

		$Trip3Update->TotWaitingTime = Input::get('t3_waittime');
		$Trip3Update->TotalDistance = $OutsideDistanceTravelledRounded;
		$Trip3Update->EndLat = Input::get('lat');
		$Trip3Update->EndLong = Input::get('long');
		$Trip3Update->save();
	}
	
	#Cost Calculation
	#Fetching Tariff Details
	

	$TripAmount = TariffModel::find($TariffId); 		#Fetching Amount

	$TotalWaitTime = Input::get('tot_waittime');
	
	$TCost = ($DistanceTravelledRounded * $TripAmount->PerKm) + (strtotime("1970-01-01 $TotalWaitTime UTC") * $TripAmount->WaitingPH/3600);
	#$TFinal = $TCost + $TripAmount->Start;

	$TFinal = $TCost;
	
	$Tariff3Count = OutSideCity::where('TripId', Input::get('trip_id'))->count();

	$T3Final = '';
	$T3StartTime = '';
	$TimeDifference = '';
	$OutDistance = '';
	$Trip3Amount = TariffModel::find('3'); 	
	if ($Tariff3Count!='0') 
	{	
		$OutDistance = OutSideCity::where('TripId', Input::get('trip_id'))->sum('TotalDistance');

		$T3Data = OutSideCity::where('TripId', Input::get('trip_id'))->firstOrFail();
		$Trip3Amount = TariffModel::find('3'); 		#Fetching Tariff 3 Amount
		// $Trip3TotalWaitingTime = OutSideCity::where('TripId', '=', Input::get('trip_id'))->sum('TotWaitingTime');
		// $Trip3TotalDistance = OutSideCity::where('TripId', '=', Input::get('trip_id'))->sum('TotalDistance');
		// $Trip3WaitingTotalTime =  implode(':',str_split(str_pad($Trip3TotalWaitingTime, 6, '0', STR_PAD_LEFT),2));
		// $T3Cost =  ($Trip3TotalDistance * $Trip3Amount->PerKm) + (strtotime("1970-01-01 $Trip3WaitingTotalTime UTC") * $Trip3Amount->WaitingPH/3600);
		#return strtotime("1970-01-01 $Trip3WaitingTotalTime UTC")*1.0;
		$CallProc = DB::select('call OutsideTripCost(?)',array(Input::get('trip_id')));
		$T3Cost =  ($CallProc[0]->TotalDistance * $Trip3Amount->PerKm) + ($CallProc[0]->TotalWaitingTime * $Trip3Amount->WaitingPH);
		#return $Trip3TotalDistance;
		#$T3Final = $Trip3Amount->Start + $T3Cost;
		$T3Final = $T3Cost;
		#Calculating Time Difference
		#$T3StartTime = date('H:i:s',strtotime($T3Data->created_at));
		$T3StartTime = strtotime($T3Data->created_at);

// New Change

		$TStartTime = strtotime($TripData->PickupTime);

		$TimeDifference = $T3StartTime - $TStartTime;
		
		if ($TimeDifference < 30) 
		{
		$UpdateNewTariff = TripModel::find(Input::get('trip_id'));
		$UpdateNewTariff->Start_tariffId = '3';
		$UpdateNewTariff->save();
		}
		
	}
		#$TStartTime = date('H:i:s',strtotime($TripData->created_at));

#return $TStartTime." ".$T3StartTime." ".$TimeDifference;
		//$TripMinCharge = $TripAmount->Start;
	$TripData = TripModel::where('AutoId', Input::get('trip_id'))->firstOrFail();

		if ($TripData->Start_tariffId=='3') 
		{
			$TripMinCharge = $Trip3Amount->Start;
		}
		else
		{
			$TripMinCharge = $TripAmount->Start;
		}
		#return $TripMinCharge;

		$TotalCost = $TripMinCharge + $TFinal + $T3Final;

		// $FirstTime = OutSideCity::where('TripId', Input::get('trip_id'))->firstOrFail();
		// $T3StartTime = date('H:i:s',strtotime($FirstTime->created_at));
	#Calculating Total Cost

	#Start Push Notification
	$RiderId = TripModel::where('AutoId', Input::get('trip_id'))->pluck('RiderId');
	$RiderGCMId = RiderModel::where('RiderId', $RiderId)->pluck('GCMId');
	$PushMessage = "{'Type' : 'EndTrip'}";
	$DeviceId = array($RiderGCMId);
	$Message = array("price"=>urldecode($PushMessage)); 
	$this->PushNotification($DeviceId, $Message);
	#End Push Notification
	#To check Rider GCMID
	#return $RiderGCMId;

	#Adding 2 % Tax 
	#Changed to 6 % Tax 
	#Removing the 6 % Tax
	#$Tax = $TotalCost*6/100;
	#$TotalCost = round($TotalCost + $Tax);
	
	#Fetching and Updating Charge Information

	$TariffId = TripModel::where('AutoId', Input::get('trip_id'))->pluck('Start_tariffId');
	$MainTripAmount = TariffModel::find($TariffId); 
	$StartTariff = $MainTripAmount->Start;
	$InDistanceCost = $MainTripAmount->PerKm;
	$InDistanceWaitingTime = $MainTripAmount->WaitingPH;
	$OutDistanceCost = $Trip3Amount->PerKm;
	$OutDistanceWaitingTime = $Trip3Amount->WaitingPH;


	$TripDriverUpdate = TripModel::find(Input::get('trip_id'));
	$TripDriverUpdate->StartTariff = $StartTariff;
	$TripDriverUpdate->InDistanceCost = $InDistanceCost;
	$TripDriverUpdate->InDistanceWaitingTime = $InDistanceWaitingTime;
	$TripDriverUpdate->OutDistanceCost = $OutDistanceCost;
	$TripDriverUpdate->OutDistanceWaitingTime = $OutDistanceWaitingTime;
	$TripDriverUpdate->TotalFare = $TotalCost;
	$TripDriverUpdate->save();

	#Sending Response
	#proc here
	
	#return 'Dist->'.$CallProc[0]->TotalDistance.' :Time->'.$CallProc[0]->TotalWaitingTime;
	
	$DistanceLocal = TripModel::where('AutoId', Input::get('trip_id'))->pluck('TripDistance');
	$TotalDistance = $DistanceLocal + $OutDistance;
	

	$Response = array('success' => '1', 'distance' => "".$TotalDistance."",'cost' => "".$TotalCost."");
	return json_encode($Response);	

	}
	else
	{
		$Response = array('success' => '0', 'message' => 'Insufficient Data');
		return json_encode($Response);
	}

	}




	public function GoOnLine()
	{
	$DriverCount = DriverModel::where('DriverId', Input::get('driver_id'))->count();
	if ($DriverCount=='1') 
	{
	$DriverStatusUpdate = DriverModel::find(Input::get('driver_id'));
	$DriverStatusUpdate->IsOnline = '1';
	$DriverStatusUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0');
	return json_encode($Response);	
	}
	}

	public function DriverLatLongUpdate()
	{
	$DriverCount = DriverModel::where('DriverId', Input::get('driver_id'))->where('IsOnline', '1')->where('IsActive', '1')->count();	
	if ($DriverCount=='1') 
	{
		
		$DriverStatusUpdate = DriverLatLongModel::where('DriverId', Input::get('driver_id'))->firstOrFail();
		$DriverStatusUpdate->Lat = Input::get('lat');
		$DriverStatusUpdate->Long = Input::get('long');
		$DriverStatusUpdate->save();
		$Response = array('success' => '1');
		return json_encode($Response);

	}
	else
	{
		$Response = array('success' => '0');
		return json_encode($Response);		
	}
	}


public function GoOffLine()
	{
	$DriverCount = DriverModel::where('DriverId', Input::get('driver_id'))->count();
	if ($DriverCount=='1') 
	{
	$DriverStatusUpdate = DriverModel::find(Input::get('driver_id'));
	$DriverStatusUpdate->IsOnline = '0';
	$DriverStatusUpdate->save();
	$Response = array('success' => '1');
	return json_encode($Response);
	}
	else
	{
	$Response = array('success' => '0');
	return json_encode($Response);	
	}
	}





	public function DriverGetAccountInfo()
	{	
		$DriverData = DriverModel::find(Input::get('driver_id')); 	#Fetching Driver DAta
		if ($DriverData) 
		{
		$RideRating = TripModel::where('DriverId', '=', Input::get('driver_id'))->avg('RideRating');
		$Response = array('success' => '1', 'driver_name' => $DriverData->Firstname.' '.$DriverData->Lastname, 'mobie' => $DriverData->Mobile, 'driver_photo' => $DriverData->DriverPhoto,  'taxi_model' => $DriverData->TaxiModel, 'taxi_plateno' => $DriverData->TaxiPlateNo, 'rating' => "".round($RideRating,1)."");
		return json_encode($Response);
		}
		else
		{
		$Response = array('success' => '0', 'message' => 'Driver Not Found');
		return json_encode($Response);		
		}
	}


	public function Push()
	{

	$PushMessage = "{'Type' : 'DriverAccepted'}";
	$Message = array("price"=>$PushMessage);  
	$DeviceId = array("APA91bHXw6hDr0ZblCfklksQ1sNfAx4B_RKpWpfDLW29S74nqOUmT2SmZZP8ehC0lN2DOJaB2yFsVloQQkIEfyH_4fKR8v7fBM__rv3bz62ojxHBifw7c4ldElJwB9Deo8SlFV9r9bZY3U8AWde1517TEALbylrGguvhmPJwp-iRIkRbTH-rqbg");
	#$DeviceId = array("APA91bEpqv3BFaQ4QStwo98OJ2C2HPk28g0N1EI5870yE5Q6gbFX2pAXYXC0BhNrExDyeJXozu4xcgGwSGv-1YLFbHYGYnIeGsY8O5tKM9JwPncPCIJ77ZaC8r_VlyiPWT3VFcAVa1UX-J1m-UgBDyWy2PkaNKgrkg");
	$this->PushNotification($DeviceId, $Message);	
	}




	public function PushNotification($DeviceId,$Message) 
	{
    $url = 'https://android.googleapis.com/gcm/send';
    $fields = array(
            'registration_ids' => $DeviceId,
            'data' => $Message
        );
    $headers = array(
        'Authorization: key = AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo',
        'Content-Type: application/json'
                      );
    $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    $result = json_decode($result, true);
	$canonical_ids_count = $result['canonical_ids'];
	if($canonical_ids_count)
	{
		$NewGCMIdList = end($result['results']);
		$NewGCMId =  $NewGCMIdList['registration_id'];
    	$RiderId = RiderModel::where('GCMId', $DeviceId)->pluck('RiderId');
    	if ($RiderId) 
    	{
    	$RiderUpdate = RiderModel::where('RiderId', $RiderId)->first();
		$RiderUpdate->GCMId = $NewGCMId;
		$RiderUpdate->GCMId_updated_at = date('Y-m-d H:i:s');
		$RiderUpdate->save();	
    	}
    	$DriverId = DriverModel::where('GCMId', $DeviceId)->pluck('DriverId');
    	if ($DriverId) 
    	{
    	$RiderUpdate = DriverModel::where('DriverId', $DriverId)->first();
		$RiderUpdate->GCMId = $NewGCMId;
		$RiderUpdate->GCMId_updated_at = date('Y-m-d H:i:s');
		$RiderUpdate->save();	
    	}
	}

    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
        }
        curl_close($ch);
    
	}





	




















# Advance Codes


	public function GetDriversList()
	{	
	$RiderList = RiderModel::all();
	$Response = array('driverlist' => $RiderList);
    return json_encode($Response);
	exit();
	}

	public function GetDriversListData()
	{	
	$RiderList = RiderModel::select('Name','Mobile')->get()->toArray();
	$Response = array('driverlist' => $RiderList);
    return json_encode($Response);
	exit();
	}


	public function DistanceCalculation()
	{	
	$RiderData = RiderModel::where('UniqueCode', '=', Input::get('UniqueCode'))->where('DeviceId', '=', Input::get('DeviceId'))->pluck('RiderId');
	$Response = array('success' => '1', 'rider_id' => $RiderData);
    return json_encode($Response);
	exit();
	}
	

	


# Ends Here





























	public function GetAllRiders()
	{
	$RiderDetails = RiderModel::where('DeviceID', Input::get('device_id'))->get()->toArray();
	//$RiderDetails = RiderModel::where('DeviceID', Input::get('device_id'))->select('RiderId','Firstname')->get();
	
	return $RiderDetails;
	exit();

	}

	public function GetAllRiderss()

	{
	$RiderDetails = RiderModel::where('DeviceID', Input::get('device_id'))->get()->toArray();
	//$RiderDetails = RiderModel::where('DeviceID', Input::get('device_id'))->select('RiderId','Firstname')->get();
	
	return $RiderDetails;
	exit();

	}

public function CheckUserOld()
	{
	$RiderDetails[0]['Success'] = "1";
	$RiderData = RiderModel::where('DeviceID', Input::get('device_id'))->select('RiderId')->get()->toArray();
	if (!empty($RiderData)) 
	{
	$RiderDetails[0]['RiderId']  = $RiderData[0]['RiderId'];
	}
	else
	{
	$RiderDetails[0]['RiderId']  = '';
	}
	return $RiderDetails[0];	
	}

	
}
