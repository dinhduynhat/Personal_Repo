<?php

class SettingsController extends BaseController {

    public function ChangePasswordLayout() {
        return View::make('settings/changepassword/changepassword');
    }
    
    public function ChangePasswordProcess() {
        $PasswordData = Input::all();

        Validator::extend('pwdvalidation', function($field, $value, $parameters) {
            return Hash::check($value, Auth::user()->password);
        });

        $messages = array('pwdvalidation' => 'The Old Password is Incorrect');

        $validator = Validator::make($PasswordData, User::$rulespwd, $messages);
        if ($validator->passes()) {
            $user = User::find(Auth::user()->id);
            $user->password = Input::get('NewPassword');
            $user->save();
            return Redirect::to(Session::get('urlpath') . '/changepassword')->withInput()->with('Messages', 'The Password Information was Updated');
        } else {
            return Redirect::to(Session::get('urlpath') . '/changepassword')->withInput()->withErrors($validator);
        }
    }

    public function ProfileLayout() {
        $user = Auth::user()->id;
        $ProfileDetailsbyid = ProfileModel::where('id', $user)->get()->toArray();
        return View::make('settings/profile/profile')->with('ProfileDetailsbyid', $ProfileDetailsbyid);
    }

    public function ProfileUpdateProcess($data = NULL) {

        $user = Auth::user()->id;
        $ProfileDetailsbyid = ProfileModel::where('id', $user)->get()->toArray();

        $ProfileData = array_filter(Input::except(array('_token')));

        $validation = Validator::make($ProfileData, ProfileModel::$rules);
        if ($validation->passes()) {



            if (!empty($ProfileData['Photo'])) {
                Input::file('Photo')->move('assets/uploads/profilephoto/', $user . '-Photo.' . Input::file('Photo')->getClientOriginalName());
                $Photo = $user . '-Photo.' . Input::file('Photo')->getClientOriginalName();
                unset($ProfileData['Photo']);
                $ProfileData['Photo'] = $Photo;
            }

            $affectedRows = ProfileModel::where('id', $user)->update($ProfileData);
            if (Auth::user()->usertype == 3) {

                $GovtUpdate = GovernmentEntityModel::where('id', $user = Auth::user()->schoolid)->first();
                $GovtUpdate->GovernmentEntityName = Input::get('FirstName');
                $GovtUpdate->GovernmentEntityEmail = Input::get('email');
                $GovtUpdate->save();
            }

             if (Auth::user()->usertype == 4) {

                $GovtUpdate = BusCompanyModel::where('id', $user = Auth::user()->schoolid)->first();
                $GovtUpdate->Contactpersonname = Input::get('FirstName');
                
                $GovtUpdate->save();
            }

             if (Auth::user()->usertype == 2) {

                $GovtUpdate = GeneralSettingModel::where('id', $user = Auth::user()->schoolid)->first();
                $GovtUpdate->AdminContactPerson = Input::get('FirstName');
                
                $GovtUpdate->save();
            }

            //VehicleModel::create($VehicleData);
            return Redirect::to(Session::get('urlpath') . '/profile')->with('Message', 'Profile Details Update Succesfully')->with('ProfileDetailsbyid', $ProfileDetailsbyid);
        } else {

            return Redirect::to(Session::get('urlpath') . '/profile')->withInput()->withErrors($validation->messages())->with('ProfileDetailsbyid', $ProfileDetailsbyid);
        }
    }

    public function Notification() {
        $NotificationDetails = NotificationModel::all()->toArray();
        return View::make('settings/notification/notification')->with('NotificationDetails', $NotificationDetails);
    }

    public function NotificationProcess() {
        $NotificationData = Input::except(array('_token'));
        $validator = Validator::make($NotificationData, NotificationModel::$rule);
        if ($validator->passes()) {
            NotificationModel::create($NotificationData);
            return Redirect::to(Session::get('urlpath') . '/notification')->withInput()->with('Message', 'The Notification was Created Succesfully');
        } else {
            return Redirect::to(Session::get('urlpath') . '/notification')->withInput()->withErrors($validator);
        }
    }

    public function NotificationEdit($data = NULL) {
        $NotificationData = NotificationModel::where('id', $data)->get()->toArray();
        return View::make('settings/notification/editnotification')->with('NotificationData', $NotificationData);
    }

    public function NotificationEditProcess($data = NULL) {

        $NotificationData = array_filter(Input::except(array('_token')));

        $updaterules = array(
            'NotificationName' => 'required|unique:notification,NotificationName,' . $data . ',id',
            'NotificationMessage' => 'required|unique:notification,NotificationMessage,' . $data . ',id'
        );
        $validation = Validator::make($NotificationData, $updaterules);
        if ($validation->passes()) {
            $NotificationUpdate = NotificationModel::where('id', $data)->first();
            $NotificationUpdate->NotificationName = Input::get('NotificationName');
            $NotificationUpdate->NotificationMessage = Input::get('NotificationMessage');
            $NotificationUpdate->save();
            return Redirect::to(Session::get('urlpath') . '/notification')->with('Message', 'Notification Details Updated Succesfully');
        } else {
            return Redirect::to(Session::get('urlpath') . '/editnotification/' . $data)->withInput()->withErrors($validation->messages());
        }
    }

    public function DeleteNotification($data = NULL) {
        NotificationModel::where('id', $data)->delete();
        return Redirect::to(Session::get('urlpath') . '/notification')->with('Message', 'Notification Deleted Succesfully');
    }

}
