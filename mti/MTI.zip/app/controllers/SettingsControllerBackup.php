<?php

class SettingsController extends BaseController
{
    
    public function ChangePasswordLayout()
    {
        return View::make('settings/changepassword/changepassword');
    }
    
    public function ChangePasswordProcess()
    {
        $PasswordData = Input::all();
        $validation  = Validator::make($PasswordData, User::$rulespwd);
        if ($validation->fails()) 
        {
                return Redirect::to('changepassword')->withInput()->withErrors($validation->messages());            
        }
        else
        {
            if(Hash::check(Input::get('OldPassword'), Auth::user()->password))
            {
                $user = User::find(Auth::user()->id);
                $user->password = Hash::make(Input::get('NewPassword'));
                $user->save();       
            }
            else
            {
                return Redirect::to('changepassword')->withInput()->with('Messages', 'The Old Password is not valid.');                
            }
        }




    }
}