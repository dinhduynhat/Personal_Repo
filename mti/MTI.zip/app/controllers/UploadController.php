<?php

class UploadController extends BaseController
{
    
    public function UploadCsvLayout()
    {
        return View::make('uploadcsv/uploadcsv');
    }
    
    public function UploadCsvProcess()
    {
    
    /*        
        $VehicleData = Input::all();
        $validation  = Validator::make($VehicleData, VehicleModel::$rules);
        
        if ($validation->passes()) 
        {
            VehicleModel::create($VehicleData);
            return Redirect::to('uploadcsv')->withErrors('Vehicle Details Saved Succesfully');
        } else 
        {
            return Redirect::to('uploadcsv')->withInput()->withErrors($validation->messages());
        }
    */
    }
}