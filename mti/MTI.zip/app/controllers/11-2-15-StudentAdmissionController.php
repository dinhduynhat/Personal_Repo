<?php

class StudentAdmissionController extends BaseController
{
    
    public function StudentAdmissionSettingsLayout()
    {
	
	    $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$gender= array("Male"=>"Male", "Female"=>"Female");
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('gender', $gender)->with('weekdays', $weekdays);
    }
    public function StudentAdmissionProcess()
    {	
        $StudentAdmissionData = Input::all();	
			$schoolid = $StudentAdmissionData['SchoolName'];
			$StudentCourse = $StudentAdmissionData['StudentCourse'];
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {	
$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
        $StudentAdmissionData['Generatekey']= str_random(5);
		   $student = StudentAdmissionModel::create($StudentAdmissionData);
		  
            return Redirect::to('studentlisting')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
       return Redirect::to('studentadmission')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentListSettingsLayout()
    {
	
	 $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
    if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentDetails = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentDetails = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	
    return View::make('studentadmission/studentlist')->with('ClassDetails', $ClassDetails)->with('years', $years)->with('StudentDetails', $StudentDetails)->with('SchoolDetails', $SchoolDetails);
    }
	
public function SearchStudentProcess()
	{
	$StudentAdmissionData= Array();
	$StudentData = array_filter(Input::except(array('_token')));	
	if(!empty($StudentData['Searchdata']))
{
	$Searchdata=$StudentData['Searchdata'];
	$resultdata=explode("/",$Searchdata);
	$studentname=explode(" ",$resultdata[0]);
$StudentAdmissionData['PersonalFirstName']=$studentname[0];
$StudentAdmissionData['PersonalLastName']=$studentname[1];
$StudentAdmissionData['Age']=$resultdata[1];
$StudentAdmissionData['Gender']=$resultdata[2];
}
if(!empty($StudentData['SchoolName']))
{
$StudentAdmissionData['SchoolName']=$StudentData['SchoolName'];
}
	if(!empty($StudentAdmissionData))
	{
	
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->with('batchresult')->with('schollresult')->get()->toArray();	
		}
if(Auth::user()->usertype==2)
		{
$style="unwant";
$titlename="Change Student Transport Status";

}else{
$style="";
$titlename="Student Transport Status";
}
		
		//print_r($StudentAdmissionDetailsbyid);
		echo "<script>
$(document).ready(function(){ $('#student-listing-table').dataTable();
});
</script>";
echo '<div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Student List</h5>
        </div>
     
        <div class="panel-tab-row"><table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
		<th class="'.$style.'">School</th>
        <th>Name</th>
        <th>Grade</th>
		<th>Age</th>
		<th>Gender</th>
		<th>Parent Name</th>
		<th>Parent Mobile</th>        
        </tr>
        </thead>
        <tbody>';
		$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);

		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
		
		//$checkdata=$StudentAdmissionDetailvalue['transporttake'];
		
				$studentid=$StudentAdmissionDetailvalue['id'];
				$checksdata['studentid']=$studentid;
	$checksdata['date']=date('Y-m-d');
		$StudentAttandencebyid = StudentAttandenceModel::where($checksdata)->get()->toArray();
      if(!empty($StudentAttandencebyid))	
{	  
       $checkdata=$StudentAttandencebyid[0]['toschool'];
		if($checkdata==1)
		{
		 $yescheck="checked";
		 //$nocheck="";
		} else {
		  $yescheck="";
		// $nocheck="selected";
		}
	 } else {
	 $yescheck="checked";
	 $StudentAttandencebyid[0]['comment']="";
	 }
		
		if(!empty($StudentAdmissionDetailvalue['House'])) { $address=$StudentAdmissionDetailvalue['House'].'</br>'.$StudentAdmissionDetailvalue['Street'].',</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; } else { $address= $StudentAdmissionDetailvalue['Apartment'].'</br>'.$StudentAdmissionDetailvalue['Street'].',</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; }
		
       echo '<tr>
	   <td  class="'.$style.'">'.$StudentAdmissionDetailvalue['schollresult']['SchoolName'].'</td>   
        <td><span class="tab-check"></span><a class="fancybox attandencelink" href="#inline'.$StudentAdmissionDetailvalue['id'].'" id="'.$StudentAdmissionDetailvalue['id'].'">'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</a>
		<div id="attandence'.$StudentAdmissionDetailvalue["id"].'" title="Basic dialog" style="display: none;">
		<div class="work-sch-contain">
        <div class="panel-heading">
        <h4 class="panel-title">Weekly Work Schedule</h4>
        </div>
        <div class="work-row work-row-head">
              <div class="work-right">
                 <ul>
                     <li>'.date("m-d-Y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-Y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-Y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-Y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-Y", strtotime($dates[4])).'</br>Fri</li>
                 </ul>
              </div>
        </div>
        <div class="work-row work-row-present">
             <div class="work-left">
                 <p>To Home</p>
             </div>
             <div class="work-right">
                 <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		if($StudentAttandence[0]['tohome']==1)
		{
                  echo'<li><span class="icon-work icon-work-present"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
        <div class="work-row work-row-absent">
             <div class="work-left">
                 <p>To School</p>
             </div>
             <div class="work-right">
                  <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
                  echo'<li><span class="icon-work icon-work-present"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
    </div>
		</div>
		</td>
        <td>'.$StudentAdmissionDetailvalue['StudentCourse'].'</td>
		<td>'.$StudentAdmissionDetailvalue['Age'].'</td>
        <td>'.$StudentAdmissionDetailvalue['Gender'].'</td>   
          <td>'.$StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName'].'</td>
        <td>'.$StudentAdmissionDetailvalue['ContactMobile'].'</td>
        </tr><div id="inline'.$StudentAdmissionDetailvalue['id'].'" class="pop-des" style="display: none;">
		
		<div class="panel-heading">
                <h2 class="">'.$titlename.'</h2>
              </div>
		<div class="coln_box">
		<div class="coln coln_1">
		
		<div class="panel-heading">
                <h4 class="panel-title">Student Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Gender: </span>'.$StudentAdmissionDetailvalue['Gender'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Age:</span> '.$StudentAdmissionDetailvalue['Age'].'</label>
        </div>       
        </li>
          <li>
        <div class="label-control">
        <label for="r_no"><span>Grade:</span> '.$StudentAdmissionDetailvalue['StudentCourse'].'</label>
        </div>       
        </li>         		
        </ul>        
		</div>
		<div class="coln coln_2">
		
		<div class="panel-heading">
                <h4 class="panel-title">Parent Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Mobile:</span> '.$StudentAdmissionDetailvalue['ContactMobile'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Address: </span><p>'.trim($address).'</p></label>
        </div>       
        </li>         		
        </ul> 
		
		</div>
		<div class="coln coln_3">';
if(Auth::user()->usertype ==2)
{
		echo '<div class="panel-heading">
                <h4 class="panel-title">Update Student Transport Detail</h4>
              </div>
			  <div class="error stransport"></div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-controlcheckbox">
		<label for="r_no">Taking Transport Today</label><em>*</em></br>	
		yes<input type="radio" name="check'.$StudentAdmissionDetailvalue['id'].'" id="yes'.$StudentAdmissionDetailvalue['id'].'" value="1" />
		No<input type="radio" name="check'.$StudentAdmissionDetailvalue['id'].'" id="No'.$StudentAdmissionDetailvalue['id'].'" value="0" />
       <input id="updatedate'.$StudentAdmissionDetailvalue['id'].'" name="updatedate" type="hidden" value="">
		        
		<input id="studentid" name="studentid" type="hidden" value="'.$StudentAdmissionDetailvalue['id'].'">
        </div>        
         
        </li>  	
         <li>
        <div class="label-control">
        <label for="r_no">Comments</label><em>*</em>
        </div>
        <div class="input-control">       
       <textarea class="Comments" name="Comments" id="textcomment'.$StudentAdmissionDetailvalue['id'].'" cols="30" rows="30" style="height: 34px;width: 266px;" required onkeyup="transpotalert(this.value)" >'.$StudentAttandencebyid[0]['comment'].'</textarea>
	   <input id="CommentsData" class="CommentsData'.$StudentAdmissionDetailvalue['id'].'" name="CommentsData" type="hidden" value="">
        </div>
         
        </li>
         		
        </ul> 
<div class="btn-group  transportcommentbutton">
        <input class="submit-btn transportcomment" type="submit" value="Save" id="'.$StudentAdmissionDetailvalue['id'].'" >    
       
        </div>';
}
    echo '<div class="">
        <div class="panel-heading">
        <h4 class="panel-title">Weekly Work Schedule</h4>
        </div>
        <div class="work-row work-row-head">
              <div class="work-right">
                 <ul>
                     <li>'.date("m-d-Y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-Y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-Y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-Y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-Y", strtotime($dates[4])).'</br>Fri</li>
                 </ul>
              </div>
        </div>
        <div class="work-row work-row-present">
             <div class="work-left">
                 <p>From Home</p>
             </div>
             <div class="work-right">
                 <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		if($StudentAttandence[0]['tohome']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		} else {
		$message="";
		}
                  echo'<li><span class="icon-work icon-work-present masterTooltip" title="No Entry"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent masterTooltip" title="No Entry"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence masterTooltip" title="No Entry"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
        <div class="work-row work-row-absent">
             <div class="work-left">
                 <p>From School</p>
             </div>
             <div class="work-right">
                  <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		} else {
		$message="";
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		}
		
                  echo'<li><span class="icon-work icon-work-present masterTooltip '.$dates[$i].'" title="'.$message.'" style="cursor:pointer" id="'.$commentdata.'"></span></li>';
				  } else {
				  if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		} else {
		$message="";
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		}
				   echo'<li><span class="icon-work icon-work-absent masterTooltip getabsent '.$dates[$i].'" style="cursor:pointer" title="'.$message.'" id="'.$commentdata.'"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence masterTooltip  '.$dates[$i].'" title="No Entry"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
    </div></div>
		</div>
		
	</div>';
		
        } 
		echo '</tbody>
        </table>
		<div class="updatesearch"></div>
		</div>
        </div>';
		}
		echo '<script>
		function transpotalert(commentval){
			$("#CommentsData").val(commentval);
			}
			
		$(".transportcomment").click(function(){	
       var studentid = $(this).attr("id");
	   if(document.getElementById("yes"+studentid).checked == true) {
	   var pickupoption=1;
	   } else {
	    var pickupoption=0;
	   }		
		 var CommentsData = $("#textcomment"+studentid).val();
       // var CommentsData = $(".CommentsData"+studentid).val();		 
		 var updatedate = $("#updatedate"+studentid).val();
var dataString = "pickupoption="+pickupoption + "&Comments="+CommentsData + "&studentid="+studentid + "&updatedate="+updatedate; 
                $.ajax({
                    type: "POST",
                    url : "transportstudentprocess",
                    data : { pickupoption: pickupoption, Comments: CommentsData , studentid: studentid  , updatedate: updatedate },
                    success : function(data){					
					$(".stransport").html(data);
					
					//$(".comment"+studentid).val(Comment);
					$("#yes"+studentid).removeAttr("disabled", "disable");
					$("#No"+studentid).removeAttr("disabled", "disable");
					if(pickupoption==1)
					{
					if(updatedate=="")
					{
					var updatedate="'.date('Y-m-d').'";
					$("."+updatedate).removeClass("icon-work-absent");
					 $("."+updatedate).addClass("icon-work-present");
					} else {
					$("."+updatedate).removeClass("icon-work-absent");
					$("."+updatedate).addClass("icon-work-present");
					
					}
					$("#yes"+studentid).prop("checked", false);
					} else {
					if(updatedate=="")
					{
					var updatedate="'.date('Y-m-d').'";
					$("."+updatedate).addClass("icon-work-absent");
					 $("."+updatedate).removeClass("icon-work-present");
					} else {
					$("."+updatedate).addClass("icon-work-absent");
					$("."+updatedate).removeClass("icon-work-present");
					
					}
					$("#No"+studentid).prop("checked", false);					
					}
					$("#textcomment"+studentid).val("");
					$("#updatedate"+studentid).val("");
					$(".CommentsData"+studentid).val("");
					$(".stransport").html("");
					$(".fancybox-close").trigger( "click" );
					$(".Search").trigger("click");
					
					
                    }
                });
});
	$(".attandencelink").mouseover(function (e) {
                 var id=$(this).attr("id");
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-120});
				   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
   
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				
				 });
				$(".paginate_button").click(function(){

$(".attandencelink").mouseover(function (e) {
                 var id=$(this).attr("id");
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-120});
				   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
   
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				
				 });
}); 

				 $(document).ready(function() {
       
        $(".masterTooltip").hover(function(){
               var tooltip="tooltip";
                var title = $(this).attr("title");
                $(this).data("tipText", title).removeAttr("title");
                $("<p class="+tooltip+"	></p>").text(title).appendTo("body").fadeIn("slow");
        }, function() {
                
                $(this).attr("title", $(this).data("tipText"));
                $(".tooltip").remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $(".tooltip").css({ top: mousey, left: mousex })
        });
		$(".getabsent").click(function(){
		var valuecomment=$(this).attr("id");
		var res = valuecomment.split("/");
		$("#yes"+res[2]).attr("disabled", "disable");
		$("#No"+res[2]).attr("disabled", "disable");
		if(res[0]==1)
		{
		$("#yes"+res[2]).val(res[0]).prop("checked", true);
		} else {
		$("#No"+res[2]).val(res[0]).prop("checked", true);
		
		}
		$("#textcomment"+res[2]).val(res[1]);
		$(".CommentsData"+res[2]).val(res[1]);
		$("#updatedate"+res[2]).val(res[3]);
		});
});
		</script>';
	
	
	}
	public function StudentadmissionEdit($data=NULL)
    {
	    $editvehicle=$data;
		$StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $editvehicle)->get()->toArray();
		$gender= array("Male"=>"Male", "Female"=>"Female");
          $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		}else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('StudentAdmissioneditbyid', $StudentAdmissioneditbyid)->with('gender', $gender)->with('weekdays', $weekdays);
	}
	public function Studentupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token')));
$schoolid = $GeneralData['SchoolName'];
			$StudentCourse = $GeneralData['StudentCourse'];
        $validation  = Validator::make($GeneralData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {
$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
			
		   if(!empty($GeneralData['ContactUploadLogo']))
	{
	Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/',$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName());
	$ContactUploadLogo=$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName();
	unset($GeneralData['ContactUploadLogo']);
	$GeneralData['ContactUploadLogo']=$ContactUploadLogo;
	}
	  $updatedata=array_filter($GeneralData);
	   $affectedRows = StudentAdmissionModel::where('id', $data)->update($updatedata);
		   
            return Redirect::to('studentadmissionedit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
            return Redirect::to('studentadmissionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function Studentdelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = StudentAdmissionModel::where('id', $editvehicle)->delete();		
       return Redirect::to('studentlisting')->with('Message', 'Student Delete Succesfully');
	}
	 public function StudentAdmissionImportLayout()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentimport')->with('SchoolDetails', $SchoolDetails);
    }

    public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();
	
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/studentdata/','importfile' . Input::file('importfile')->getClientOriginalName());
	$importfile='importfile' . Input::file('importfile')->getClientOriginalName();
	
	}
	
		
$uploaddata['SchoolName']=$StudentAdmissionData['SchoolName'];	
$uploaddata['StudentBatch']=$StudentAdmissionData['StudentBatch'];
 //$uploaddata['SchoolAddress']=$StudentAdmissionData['SchoolAddress'];

$results=Excel::load('assets/uploads/studentdata/'.$importfile, function($reader) {

})->get()->toArray();



function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

$test=array_filter($finaldata);
foreach($finaldata as $uniquevalue)
{
$arrayvalcount[]=$uniquevalue['studentfirstname'];
}
$count=count($arrayvalcount);

if($count <= 50)
{
foreach($finaldata as $uniqueval)
{
$arrayval[]=$uniqueval['studentfirstname'];
}
if(count($arrayval)==count(array_filter($arrayval)))
{
foreach($finaldata as $final)
{

$uploaddata['StudentCourse']=$final['grade'];
$uploaddata['EntranceDate']=$final['schoolentrancedate'];
$uploaddata['ExitDate']=$final['schoolexitdate'];
$uploaddata['PersonalFirstName']=$final['studentfirstname'];
$uploaddata['PersonalMiddleName']=$final['studentmiddlename'];	
$uploaddata['PersonalLastName']=$final['studentlastname'];
$uploaddata['Age']=$final['age'];	
$uploaddata['Gender']=$final['gender'];
$uploaddata['DateOfBirth']=$final['dateofbirth'];
$uploaddata['StudentLanguage']=$final['language'];
$uploaddata['GuardianFirstName']=$final['parentfirstname'];	
$uploaddata['GuardianMiddleName']=$final['parentmiddlename'];
$uploaddata['GuardianLastName']=$final['parentlastname'];
$uploaddata['ContactPhone']=$final['phone'];	
$uploaddata['ContactMobile']=$final['mobile'];
$uploaddata['House']=$final['house'];
$uploaddata['Apartment']=$final['apartment'];
$uploaddata['Street']=$final['street'];	
$uploaddata['ContactCity']=$final['city'];
$uploaddata['ContactState']=$final['state'];	
$uploaddata['ContactPin']=$final['zipcode'];
$uploaddata['Weekdaysfrom']=$final['weekdayfrom'];
$uploaddata['Weekdaysto']=$final['weekdayto'];	
$uploaddata['weekInTime']=$final['intime'];	
$uploaddata['weekoutTime']=$final['outtime'];
$uploaddata['MondayInTime']=$final['mondayintime'];	
$uploaddata['MondayoutTime']=$final['mondayouttime'];
$uploaddata['TuesdayInTime']=$final['tuesdayintime'];	
$uploaddata['TuesdayoutTime']=$final['tuesdayouttime'];
$uploaddata['WednesdayInTime']=$final['wednesdayintime'];
$uploaddata['WednesdayoutTime']=$final['wednesdayouttime'];
$uploaddata['ThursdayInTime']=$final['thursdayintime'];	
$uploaddata['ThursdayoutTime']=$final['thursdayouttime'];
$uploaddata['FridayInTime']=$final['fridayintime'];
$uploaddata['FridayoutTime']=$final['fridayouttime'];
$uploaddata['Note']=$final['note'];
if($final['oneway']==1)
 {
 $uploaddata['TripType']=1;
 } else {
  $uploaddata['TripType']=2;
 }
 $uploaddata['Generatekey']= str_random(5);
if(!empty($final['weekdayfrom']) && !empty($final['weekdayto']))
{
$uploaddata['timingoption']=1;
} else {
$uploaddata['timingoption']=0;
}
$GradeName=$final['grade'];	
$language=$final['language'];

if(!empty($GradeName))
{
   $count = ClassModel::where('GradeName', '=', $GradeName)->count();
     if($count==0)
	 {
	 
	 $ClassData['GradeName']=$GradeName;
	 ClassModel::create($ClassData);
	 }
	 }

	 	 if(!empty($language))
{
	 $languagecount = LanguageModel::where('language', '=', $language)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['language']=$language;
	 LanguageModel::create($StudentLanguageData);
	 }
	 }

	 if(!empty($final['studentfirstname']))
	 {
	 	
	$student = StudentAdmissionModel::create($uploaddata);
	}
	
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Student firstname missing in your record.');
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Maximum 50 record only allowed to import');
}
 return Redirect::to('studentlisting')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentimport')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentAdmissionExportLayout()
    {	


if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentdetails";
		}

Excel::create($mtidetail, function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolEntranceDate']=$StudentAdmissionDetailvalue['EntranceDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolExitdate']=$StudentAdmissionDetailvalue['ExitDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Language']=$StudentAdmissionDetailvalue['StudentLanguage'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentFirstName']=$StudentAdmissionDetailvalue['GuardianFirstName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentMiddleName']=$StudentAdmissionDetailvalue['GuardianMiddleName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentLastName']=$StudentAdmissionDetailvalue['GuardianLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Phone']=$StudentAdmissionDetailvalue['ContactPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Mobile']=$StudentAdmissionDetailvalue['ContactMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['House']=$StudentAdmissionDetailvalue['House'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Apartment']=$StudentAdmissionDetailvalue['Apartment'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Street']=$StudentAdmissionDetailvalue['Street'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['City']=$StudentAdmissionDetailvalue['ContactCity'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['State']=$StudentAdmissionDetailvalue['ContactState'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ZipCode']=$StudentAdmissionDetailvalue['ContactPin'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayfrom']=$StudentAdmissionDetailvalue['Weekdaysfrom'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayto']=$StudentAdmissionDetailvalue['Weekdaysto'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['InTime']=$StudentAdmissionDetailvalue['weekInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Outtime']=$StudentAdmissionDetailvalue['weekoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayInTime']=$StudentAdmissionDetailvalue['MondayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayoutTime']=$StudentAdmissionDetailvalue['MondayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayInTime']=$StudentAdmissionDetailvalue['TuesdayInTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayoutTime']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayInTime']=$StudentAdmissionDetailvalue['WednesdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayoutTime']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayInTime']=$StudentAdmissionDetailvalue['ThursdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayoutTime']=$StudentAdmissionDetailvalue['ThursdayoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayInTime']=$StudentAdmissionDetailvalue['FridayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayoutTime']=$StudentAdmissionDetailvalue['FridayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Note']=$StudentAdmissionDetailvalue['Note'];
if($StudentAdmissionDetailvalue['TripType']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']=1;
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']="";
} else {
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']=2;
}
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('studentadmission');		
       
    }
	public function Transportstudentprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();
	
	$pickoption=$StudentData['pickupoption'];
	$Comments=$StudentData['Comments'];
	$studentid=$StudentData['studentid'];
    $updatedate=$StudentData['updatedate'];
	$updatedata['date']=date('Y-m-d');
	$updatedata['tohome']=1;
	$updatedata['toschool']=$pickoption;
	$updatedata['comment']=$Comments;
	$updatedata['studentid']=$studentid;
	$checkdata['studentid']=$studentid;
	$checkdata['date']=date('Y-m-d');
	$count = StudentAttandenceModel::where($checkdata)->count();
	if(empty($updatedate))
	{
	if($count==0)
	{
	 StudentAttandenceModel::create($updatedata);
	// $affectedRows = StudentAttandenceModel::where('id', $studentid)->update($updatedata);
	} else {
	
	$affectedRows = StudentAttandenceModel::where($checkdata)->update($updatedata);
	}
	} else {	
	$update['tohome']=1;
	$update['toschool']=$pickoption;
	$update['comment']=$Comments;
	$checkupdatedata['studentid']=$studentid;
	$checkupdatedata['date']=$updatedate;
	$affectedRows = StudentAttandenceModel::where($checkupdatedata)->update($updatedata);
	}
	 echo "Details Updated successfully";
	
	}
	public function Searchschoolprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();	
	$SchoolName=$StudentData['SchoolName'];
	$schooluserDetailsbyid = GeneralSettingModel::where('id', $SchoolName)->get()->toArray();
	echo $schooluserDetailsbyid[0]['SchoolAddress'];
	
	}
	public function Studentdeleteprocess()
	{
	$StudentData = Input::all();
	$studentdeletelist=$StudentData['studentdeletelist'];
	$data=explode(",",$studentdeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = StudentAdmissionModel::where('id', $data[$i])->delete();	
	}
	return Redirect::to('studentlisting')->with('Message', 'Students Deleted Succesfully');
	}
	 public function StudentListLayout()
    {
	$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);
		$weekdays= array("0"=>"Monday", "1"=>"Tuesday","2"=>"Wednesday","3"=>"Thursday","4"=>"Friday");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentlisting')->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('weekdays', $weekdays)->with('dates', $dates);
    }
	public function ExportAttendenceLayout()
    {	   $age=array();
	$grade=array();	
	$studentname=array();
	$parentname=array();
			if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		} else {	
		if(Session::get('selectschool')=="")
		{		
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
		} else {
		$selectschool=Session::get('selectschool');
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();	
		}			
		}
		
		foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
		{
		  $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
		  $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
		   $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
		   $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
		}
		$gender= array("Male"=>"Male", "Female"=>"Female");
		$AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
		$fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$checkresult=array();
        return View::make('studentadmission/exportattendence')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult);
    }
	public function ExportAttendenceProcess($data=NULL)
    {	 
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentattendence";
		}
$string = $data;
Excel::create($mtidetail, function($excel) use($string){

 $excel->sheet('Sheetname', function($sheet) use($string){

$checkarray=array();
$checkarray=array();
 $studentcheckarray = array();
$dataarray=explode("&",$string);

$StudentAdmissionData['schoolid']=$dataarray[0];
$StudentAdmissionData['studentname']=$dataarray[1];
$StudentAdmissionData['Startdate']=$dataarray[2];
$StudentAdmissionData['Enddate']=$dataarray[3];
$StudentAdmissionData['Gender']=$dataarray[4];
$StudentAdmissionData['Age']=$dataarray[5];
$StudentAdmissionData['Grade']=$dataarray[6];
$StudentAdmissionData['ParentName']=$dataarray[7];
$StudentAdmissionData['AttendenceStatus']=$dataarray[8];
$StudentAdmissionData['AttendenceFrom']=$dataarray[9];
$StudentAdmissionData['TripType']=$dataarray[10];
 if(!empty($StudentAdmissionData['TripType']))
 {
 $TripType=$StudentAdmissionData['TripType'];
 $studentcheckarray['TripType']=$TripType;
 } else {
  $TripType="";
 }
 if(!empty($StudentAdmissionData['schoolid']))
 {
 $schoolid=$StudentAdmissionData['schoolid'];
$studentcheckarray['SchoolName']=$schoolid;
 } else {
 $schoolid="";
 }

 if(!empty($StudentAdmissionData['Startdate']))
 {
 $Startdate=$StudentAdmissionData['Startdate'];
 } else {
  $Startdate="";
 }
 if(!empty($StudentAdmissionData['Enddate']))
 {
 $Enddate=$StudentAdmissionData['Enddate'];
 } else {
 $Enddate="";
 }
 if(!empty($StudentAdmissionData['Gender']))
 {
 $Gender=$StudentAdmissionData['Gender'];
 $studentcheckarray['gender']=$Gender;
 } else {
 $Gender="";
 }
 if(!empty($StudentAdmissionData['Age']))
 {
 $Age=$StudentAdmissionData['Age'];
   $studentcheckarray['Age']=$Age;
 } else {
 $Age="";
 }
 if(!empty($StudentAdmissionData['Grade']))
 {
 $Grade=$StudentAdmissionData['Grade'];
$studentcheckarray['StudentCourse']=$Grade;
 } else {
 $Grade="";
 }
  if(!empty($StudentAdmissionData['AttendenceStatus']))
 {
 $status=$StudentAdmissionData['AttendenceStatus'];
 
 } else {
 $status="";
 }
 if(!empty($StudentAdmissionData['studentname']))
 {
 $sname=$StudentAdmissionData['studentname'];
 $snamearray=explode(" ",$sname);
 $studentfirstname=$snamearray[0];
 $studentlastname=$snamearray[1];
 $studentcheckarray['PersonalFirstName']=$studentfirstname;
$studentcheckarray['PersonalLastName']=$studentlastname;
 } else {
 $sname="";
 $studentfirstname="";
  $studentlastname="";
 }
  if(!empty($StudentAdmissionData['ParentName']))
 {
 $pname=$StudentAdmissionData['ParentName'];
 $pnamearray=explode(" ",$pname);
 $parentfirstname=$pnamearray[0];
 $parentlastname=$pnamearray[1];
$studentcheckarray['GuardianFirstName']=$parentfirstname;
$studentcheckarray['GuardianLastName']=$parentlastname;
 } else {
 $pname="";
 $parentfirstname="";
 $parentlastname="";
 }
if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 $AttendenceFrom=$StudentAdmissionData['AttendenceFrom'];

 } else {
 $AttendenceFrom="";
 }
 // if(Auth::user()->usertype==2)
		// {
		// $schoolid=Auth::user()->schoolid;
		// $studentcheckarray['id']=$schoolid;
		// }
$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($studentcheckarray)
->whereHas('attendance',function($q)
{
if(!empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->whereBetween('date', array($Startdate,$Enddate));
	
	}
	if(!empty($StudentAdmissionData['Startdate']) && empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '>', $Startdate);
	}
	if(empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '<', $Enddate);
	}
	if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 if($AttendenceFrom=="all") 
 {
 if($status==0)
 {
 $q->where('toschool', '=', '0')->where('tohome', '=', '0');	
 }
 if($status==1)
 {
 $q->where('toschool', '=', '1')->where('tohome', '=', '1');	
 }
 }
 if($AttendenceFrom=="fromschool") 
 {
  if($status==0)
 {
 $q->where('toschool', '=', '0');	
 } 
   if($status==1)
 {
 $q->where('toschool', '=', '1');	
 } 
 }
 if($AttendenceFrom=="fromhome") 
 {
  if($status==1)
 {
 $q->where('tohome', '=', '1');	
 } 
  if($status==0)
 {
 $q->where('tohome', '=', '0');	
 } 
 }
 
 }
	
})
->with('attendance') // Optional eager loading, but recommended
->with('schollresult')->with('batchresult')->get()->toArray();



	$uploaddata=Array();

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Date']=$StudentAdmissionDetailvalue['attendance']['date'];	
if($StudentAdmissionDetailvalue['attendance']['tohome']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Fromhome']="Present";	
}else{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Fromhome']="Absent";	
}
if($StudentAdmissionDetailvalue['attendance']['toschool']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Toschool']="Present";	
}else{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Toschool']="Absent";	
}

}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('exportattendence');		
       
    }
	public function SessionProcess()
    {	
	  $schoolData = Input::all();
	  $schoolid=$schoolData['schoolid'];
	 Session::put('selectschool', $schoolid);
	}
	public function ExportAttendenceProcessList()
    {	
	  $StudentAdmissionData = Input::all();
$checkarray=array();

 $studentcheckarray = array();
  if(!empty($StudentAdmissionData['TripType']))
 {
 $TripType=$StudentAdmissionData['TripType'];
 $studentcheckarray['TripType']=$TripType;
 } else {
  $TripType="";
 }
 if(!empty($StudentAdmissionData['Startdate']))
 {
 $Startdate=$StudentAdmissionData['Startdate'];
 } else {
  $Startdate="";
 }
 if(!empty($StudentAdmissionData['Enddate']))
 {
 $Enddate=$StudentAdmissionData['Enddate'];
 } else {
 $Enddate="";
 }
 if(!empty($StudentAdmissionData['Gender']))
 {
 $Gender=$StudentAdmissionData['Gender'];
 $studentcheckarray['Gender']=$Gender;
 } else {
 $Gender="";
 }
 if(!empty($StudentAdmissionData['Age']))
 {
 $Age=$StudentAdmissionData['Age'];
   $studentcheckarray['Age']=$Age;
 } else {
 $Age="";
 }
 if(!empty($StudentAdmissionData['Grade']))
 {
 $Grade=$StudentAdmissionData['Grade'];
$studentcheckarray['StudentCourse']=$Grade;
 } else {
 $Grade="";
 }
  if(!empty($StudentAdmissionData['AttendenceStatus']))
 {
 $status=$StudentAdmissionData['AttendenceStatus'];
 
 } else {
 $status="";
 }
 if(!empty($StudentAdmissionData['studentname']))
 {
 $sname=$StudentAdmissionData['studentname'];
 $snamearray=explode(" ",$sname);
 $studentfirstname=$snamearray[0];
 $studentlastname=$snamearray[1];
 $studentcheckarray['PersonalFirstName']=$studentfirstname;
$studentcheckarray['PersonalLastName']=$studentlastname;
 } else {
 $sname="";
 $studentfirstname="";
  $studentlastname="";
 }
  if(!empty($StudentAdmissionData['ParentName']))
 {
 $pname=$StudentAdmissionData['ParentName'];
 $pnamearray=explode(" ",$pname);
 $parentfirstname=$pnamearray[0];
 $parentlastname=$pnamearray[1];
$studentcheckarray['GuardianFirstName']=$parentfirstname;
$studentcheckarray['GuardianLastName']=$parentlastname;
 } else {
 $pname="";
 $parentfirstname="";
 $parentlastname="";
 }
if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 $AttendenceFrom=$StudentAdmissionData['AttendenceFrom'];

 } else {
 $AttendenceFrom="";
 }
 if(!empty($StudentAdmissionData['schoolid']))
 {
$schoolid=$StudentAdmissionData['schoolid'];
$studentcheckarray['SchoolName']=$schoolid;
 } else {
 $schoolid="";
 }
// if(Auth::user()->usertype==2)
		// {
		// $schoolid=Auth::user()->schoolid;
		// $studentcheckarray['id']=$schoolid;
		// }
		
$checkresult = StudentAdmissionModel::where($studentcheckarray)

->whereHas('attendance',function($q)
{
if(!empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->whereBetween('date', array($Startdate,$Enddate));
	
	}
	if(!empty($StudentAdmissionData['Startdate']) && empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '>', $Startdate);
	}
	if(empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '<', $Enddate);
	}
	if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 if($AttendenceFrom=="all") 
 {
 if($status==0)
 {
 $q->where('toschool', '=', '0')->where('tohome', '=', '0');	
 }
 if($status==1)
 {
 $q->where('toschool', '=', '1')->where('tohome', '=', '1');	
 }
 }
 if($AttendenceFrom=="fromschool") 
 {
  if($status==0)
 {
 $q->where('toschool', '=', '0');	
 } 
   if($status==1)
 {
 $q->where('toschool', '=', '1');	
 } 
 }
 if($AttendenceFrom=="fromhome") 
 {
  if($status==1)
 {
 $q->where('tohome', '=', '1');	
 } 
  if($status==0)
 {
 $q->where('tohome', '=', '0');	
 } 
 }
 
 }
	
})
->with('attendance') // Optional eager loading, but recommended
->with('schollresult')->with('batchresult')->get()->toArray();
if(Auth::user()->usertype ==2)

		{
		$class="unwant";		
		} else {
		$class="";
		}
 echo '<script>
$(document).ready(function(){

$("#student-listing-table").dataTable();
});
</script>

        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">';
		if(!empty($checkresult))
		{
		echo '<a href="'.url().'/exportattendenceprocess/'.$StudentAdmissionData['schoolid'].'&'.$StudentAdmissionData['studentname'].'&'.$StudentAdmissionData['Startdate'].'&'.$StudentAdmissionData['Enddate'].'&'.$StudentAdmissionData['Gender'].'&'.$StudentAdmissionData['Age'].'&'.$StudentAdmissionData['Grade'].'&'.$StudentAdmissionData['ParentName'].'&'.$StudentAdmissionData['AttendenceStatus'].'&'.$AttendenceFrom.'&'.$StudentAdmissionData['TripType'].'" class="btn-sb pass-btn">Export Student Attendence</a>';
		}
        echo '<h5>Student Attendence Report</h5>
        </div>
       
        <div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th class="'.$class.'">SchoolName</th>
        <th>Student Name</th>
        <th>Gender</th>
        <th>Age</th>
		<th>Grade</th>
		<th>Attendence Status (From School)</th>
		<th>Attendence Status (From Home)</th>
        </tr>
        </thead>
        <tbody>';

		foreach ($checkresult as $checkresultvalue)
{
		
       echo' <tr>        
        <td class="'.$class.'">'.$checkresultvalue['schollresult']['SchoolName'].'</td>
        <td>'.$checkresultvalue['PersonalFirstName']." ".$checkresultvalue['PersonalLastName'].'</td>
        <td>'.$checkresultvalue['Gender'].'</td>
        <td>'.$checkresultvalue['Age'].'</td>
		<td>'.$checkresultvalue['StudentCourse'].'</td>
		<td>';
		if($checkresultvalue['attendance']['toschool']==1)
{
echo "Present";	
}else{
echo "Absent";	
} echo'</td>
		<td>';
		if($checkresultvalue['attendance']['tohome']==1)
{
echo "Present";	
}else{
echo "Absent";	
} 
echo '</td>
        </tr>';
       } 
        echo '</tbody>
        </table>
        </div>
        </div>
		';

}
}
