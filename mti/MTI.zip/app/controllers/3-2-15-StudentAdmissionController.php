<?php

class StudentAdmissionController extends BaseController
{
    
    public function StudentAdmissionSettingsLayout()
    {
	
	    $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$gender= array("Male"=>"Male", "Female"=>"Female");
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('gender', $gender)->with('weekdays', $weekdays);
    }
    public function StudentAdmissionProcess()
    {	
        $StudentAdmissionData = Input::all();	
			
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {		
		   $student = StudentAdmissionModel::create($StudentAdmissionData);
		  
            return Redirect::to('studentadmission')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentadmission')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentListSettingsLayout()
    {
	
	 $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
    if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentDetails = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentDetails = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	
    return View::make('studentadmission/studentlist')->with('ClassDetails', $ClassDetails)->with('years', $years)->with('StudentDetails', $StudentDetails);
    }
	public function SearchStudentProcess()
	{
	$StudentAdmissionData= Array();
	$StudentData = array_filter(Input::except(array('_token')));	
	$Searchdata=$StudentData['Searchdata'];
	$resultdata=explode("/",$Searchdata);
	$studentname=explode(" ",$resultdata[0]);
$StudentAdmissionData['PersonalFirstName']=$studentname[0];
$StudentAdmissionData['PersonalLastName']=$studentname[1];
$StudentAdmissionData['Age']=$resultdata[1];
$StudentAdmissionData['Gender']=$resultdata[2];
	if(!empty($StudentAdmissionData))
	{
	
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->with('batchresult')->with('schollresult')->get()->toArray();	
		}
		
		//print_r($StudentAdmissionDetailsbyid);
		echo "<script>
$(document).ready(function(){ $('#student-listing-table').dataTable();
});
</script>";
echo '<div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Student List</h5>
        </div>
     
        <div class="panel-tab-row"><table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Name</th>
        <th>Grade</th>
		<th>Age</th>
		<th>Gender</th>
		<th>Parent Name</th>
		<th>Parent Mobile</th>        
        </tr>
        </thead>
        <tbody>';
		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
		
		$checkdata=$StudentAdmissionDetailvalue['transporttake'];
		if($checkdata==1)
		{
		 $yescheck="selected";
		 $nocheck="";
		} else {
		  $yescheck="";
		 $nocheck="selected";
		}
		
       echo '<tr>
        <td><span class="tab-check"></span><a class="fancybox" href="#inline'.$StudentAdmissionDetailvalue['id'].'">'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</a></td>
        <td>'.$StudentAdmissionDetailvalue['StudentCourse'].'</td>
		<td>'.$StudentAdmissionDetailvalue['Age'].'</td>
        <td>'.$StudentAdmissionDetailvalue['Gender'].'</td>   
          <td>'.$StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName'].'</td>
        <td>'.$StudentAdmissionDetailvalue['GuardianMobile'].'</td>
        </tr><div id="inline'.$StudentAdmissionDetailvalue['id'].'" class="pop-des" style="display: none;">
		
		<div class="panel-heading">
                <h2 class="">Change Student Transport Status</h2>
              </div>
		<div class="coln_box">
		<div class="coln coln_1">
		
		<div class="panel-heading">
                <h4 class="panel-title">Student Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Gender: </span>'.$StudentAdmissionDetailvalue['Gender'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Age:</span> '.$StudentAdmissionDetailvalue['Age'].'</label>
        </div>       
        </li>
          <li>
        <div class="label-control">
        <label for="r_no"><span>Grade:</span> '.$StudentAdmissionDetailvalue['StudentCourse'].'</label>
        </div>       
        </li>         		
        </ul>        
		</div>
		<div class="coln coln_2">
		
		<div class="panel-heading">
                <h4 class="panel-title">Parent Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Mobile:</span> '.$StudentAdmissionDetailvalue['GuardianMobile'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Address: </span><p>'.$StudentAdmissionDetailvalue['GuardianPresentAddress'].',</br>'.$StudentAdmissionDetailvalue['GuardianCity'].',</br>'.$StudentAdmissionDetailvalue['GuardianState'].',</br>'.$StudentAdmissionDetailvalue['GuardianCountry'].'</p></label>
        </div>       
        </li> 
          <li>
        <div class="label-control">
        <label for="r_no"><span>Pickup Time: </span>'.$StudentAdmissionDetailvalue['StartTime'].'</label>
        </div>       
        </li>
         <li>
        <div class="label-control">
        <label for="r_no"><span>Drop Time:</span> '.$StudentAdmissionDetailvalue['DropTime'].'</label>
        </div>       
        </li>		
        </ul> 
		
		</div>
		<div class="coln coln_3">
		<div class="panel-heading">
                <h4 class="panel-title">Update Student Transport Detail</h4>
              </div>
			  <div class="error stransport"></div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-controlcheckbox">
		<label for="r_no">Taking Transport Today</label><em>*</em></br>		
		<select class="pickupoption" id="pick'.$StudentAdmissionDetailvalue['id'].'" >
		<option value="1" '.$yescheck.'>Yes</option>
		<option value="0"'.$nocheck.'>No</option>
		</select>        
		<input id="studentid" name="studentid" type="hidden" value="'.$StudentAdmissionDetailvalue['id'].'">
        </div>        
         
        </li>  	
         <li>
        <div class="label-control">
        <label for="r_no">Comments</label><em>*</em>
        </div>
        <div class="input-control">       
       <textarea class="Comments" name="Comments" id="comment'.$StudentAdmissionDetailvalue['id'].'" cols="30" rows="30" style="height: 34px;width: 266px;" required onkeyup="transpotalert(this.value)" >'.$StudentAdmissionDetailvalue['comment'].'</textarea>
	   <input id="CommentsData" name="CommentsData" type="hidden" value="">
        </div>
         
        </li>
         		
        </ul> 
<div class="btn-group  transportcommentbutton">
        <input class="submit-btn transportcomment" type="submit" value="Save" >    
       
        </div>	
		
		</div>
		</div>
		
	</div>';
		
        } 
		echo '</tbody>
        </table>
		<div class="updatesearch"></div>
		</div>
        </div>
		<script>
		function transpotalert(commentval){
			$("#CommentsData").val(commentval);
			}
		$(".transportcomment").click(function(){		
         var pickupoption = $(".pickupoption").val();
		
		 var Comment = $(".Comments").val();
        var CommentsData = $("#CommentsData").val();		 
		 var studentid = $("#studentid").val();
		 var dataString = "pickupoption="+pickupoption + "&Comments="+CommentsData + "&studentid="+studentid; 
                $.ajax({
                    type: "POST",
                    url : "transportstudentprocess",
                    data : { pickupoption: pickupoption, Comments: CommentsData , studentid: studentid },
                    success : function(data){					
					$(".stransport").html(data);
					$(".pick"+studentid).val(pickupoption);
					$(".comment"+studentid).val(Comment);
					$(".stransport").html("");
					$(".fancybox-close").trigger( "click" );
                    }
                });
});

		</script>
		';
	} 
	
	}
	public function StudentadmissionEdit($data=NULL)
    {
	    $editvehicle=$data;
		$StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $editvehicle)->get()->toArray();
		$gender= array("Male"=>"Male", "Female"=>"Female");
          $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		}else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('StudentAdmissioneditbyid', $StudentAdmissioneditbyid)->with('gender', $gender)->with('weekdays', $weekdays);
	}
	public function Studentupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token')));

        $validation  = Validator::make($GeneralData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {
			
		   if(!empty($GeneralData['ContactUploadLogo']))
	{
	Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/',$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName());
	$ContactUploadLogo=$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName();
	unset($GeneralData['ContactUploadLogo']);
	$GeneralData['ContactUploadLogo']=$ContactUploadLogo;
	}
	  $updatedata=array_filter($GeneralData);
	   $affectedRows = StudentAdmissionModel::where('id', $data)->update($updatedata);
		   
            return Redirect::to('studentadmissionedit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
            return Redirect::to('studentadmissionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function Studentdelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = StudentAdmissionModel::where('id', $editvehicle)->delete();		
       return Redirect::to('studentadmission')->with('Message', 'Student Delete Succesfully');
	}
	 public function StudentAdmissionImportLayout()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentimport')->with('SchoolDetails', $SchoolDetails);
    }

    public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();
	
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/studentdata/','importfile' . Input::file('importfile')->getClientOriginalName());
	$importfile='importfile' . Input::file('importfile')->getClientOriginalName();
	
	}
	
		
$uploaddata['SchoolName']=$StudentAdmissionData['SchoolName'];	
$uploaddata['StudentBatch']=$StudentAdmissionData['StudentBatch'];
$uploaddata['SchoolAddress']=$StudentAdmissionData['SchoolAddress'];
$results=Excel::load('assets/uploads/studentdata/'.$importfile, function($reader) {

})->get()->toArray();



function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

$test=array_filter($finaldata);
$count=count($finaldata);

if($count <= 50)
{
foreach($finaldata as $uniqueval)
{
$arrayval[]=$uniqueval['studentfirstname'];
}
if(count($arrayval)==count(array_filter($arrayval)))
{
foreach($finaldata as $final)
{

$uploaddata['StudentCourse']=$final['grade'];
$uploaddata['EntranceDate']=$final['schoolentrancedate'];
$uploaddata['ExitDate']=$final['schoolexitdate'];
$uploaddata['PersonalFirstName']=$final['studentfirstname'];
$uploaddata['PersonalMiddleName']=$final['studentmiddlename'];	
$uploaddata['PersonalLastName']=$final['studentlastname'];
$uploaddata['Age']=$final['age'];	
$uploaddata['Gender']=$final['gender'];
$uploaddata['DateOfBirth']=$final['dateofbirth'];
$uploaddata['StudentLanguage']=$final['language'];
$uploaddata['GuardianFirstName']=$final['parentfirstname'];	
$uploaddata['GuardianMiddleName']=$final['parentmiddlename'];
$uploaddata['GuardianLastName']=$final['parentlastname'];
$uploaddata['ContactPhone']=$final['phone'];	
$uploaddata['ContactMobile']=$final['mobile'];
$uploaddata['House']=$final['house'];
$uploaddata['Apartment']=$final['apartment'];
$uploaddata['Street']=$final['street'];	
$uploaddata['ContactCity']=$final['city'];
$uploaddata['ContactState']=$final['state'];	
$uploaddata['ContactPin']=$final['zipcode'];
$uploaddata['Weekdaysfrom']=$final['weekdayfrom'];
$uploaddata['Weekdaysto']=$final['weekdayto'];	
$uploaddata['weekInTime']=$final['intime'];	
$uploaddata['weekoutTime']=$final['outtime'];
$uploaddata['MondayInTime']=$final['mondayintime'];	
$uploaddata['MondayoutTime']=$final['mondayouttime'];
$uploaddata['TuesdayInTime']=$final['tuesdayintime'];	
$uploaddata['TuesdayoutTime']=$final['tuesdayouttime'];
$uploaddata['WednesdayInTime']=$final['wednesdayintime'];
$uploaddata['WednesdayoutTime']=$final['wednesdayouttime'];
$uploaddata['ThursdayInTime']=$final['thursdayintime'];	
$uploaddata['ThursdayoutTime']=$final['thursdayouttime'];
$uploaddata['FridayInTime']=$final['fridayintime'];
$uploaddata['FridayoutTime']=$final['fridayouttime'];
$uploaddata['Note']=$final['note'];
if(!empty($final['weekdayfrom']) && !empty($final['weekdayto']))
{
$uploaddata['timingoption']=1;
} else {
$uploaddata['timingoption']=0;
}
$GradeName=$final['grade'];	
$language=$final['language'];

if(!empty($GradeName))
{
   $count = ClassModel::where('GradeName', '=', $GradeName)->count();
     if($count==0)
	 {
	 
	 $ClassData['GradeName']=$GradeName;
	 ClassModel::create($ClassData);
	 }
	 }

	 	 if(!empty($language))
{
	 $languagecount = LanguageModel::where('language', '=', $language)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['language']=$language;
	 LanguageModel::create($StudentLanguageData);
	 }
	 }

	 if(!empty($final['studentfirstname']))
	 {
	 	
	$student = StudentAdmissionModel::create($uploaddata);
	}
	
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Student firstname missing in your record.');
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Maximum 50 record only allowed to import');
}
 return Redirect::to('studentadmission')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentimport')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentAdmissionExportLayout()
    {	


if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentdetails";
		}

Excel::create($mtidetail, function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolEntranceDate']=$StudentAdmissionDetailvalue['EntranceDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolExitdate']=$StudentAdmissionDetailvalue['ExitDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Language']=$StudentAdmissionDetailvalue['StudentLanguage'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentFirstName']=$StudentAdmissionDetailvalue['GuardianFirstName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentMiddleName']=$StudentAdmissionDetailvalue['GuardianMiddleName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentLastName']=$StudentAdmissionDetailvalue['GuardianLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Phone']=$StudentAdmissionDetailvalue['ContactPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Mobile']=$StudentAdmissionDetailvalue['ContactMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['House']=$StudentAdmissionDetailvalue['House'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Apartment']=$StudentAdmissionDetailvalue['Apartment'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Street']=$StudentAdmissionDetailvalue['Street'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['City']=$StudentAdmissionDetailvalue['ContactCity'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['State']=$StudentAdmissionDetailvalue['ContactState'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ZipCode']=$StudentAdmissionDetailvalue['ContactPin'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayfrom']=$StudentAdmissionDetailvalue['Weekdaysfrom'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayto']=$StudentAdmissionDetailvalue['Weekdaysto'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['InTime']=$StudentAdmissionDetailvalue['weekInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Outtime']=$StudentAdmissionDetailvalue['weekoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayInTime']=$StudentAdmissionDetailvalue['MondayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayoutTime']=$StudentAdmissionDetailvalue['MondayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayInTime']=$StudentAdmissionDetailvalue['TuesdayInTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayoutTime']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayInTime']=$StudentAdmissionDetailvalue['WednesdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayoutTime']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayInTime']=$StudentAdmissionDetailvalue['ThursdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayoutTime']=$StudentAdmissionDetailvalue['ThursdayoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayInTime']=$StudentAdmissionDetailvalue['FridayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayoutTime']=$StudentAdmissionDetailvalue['FridayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Note']=$StudentAdmissionDetailvalue['Note'];
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('studentadmission');		
       
    }
	public function Transportstudentprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();
	
	$pickoption=$StudentData['pickupoption'];
	$Comments=$StudentData['Comments'];
	$studentid=$StudentData['studentid'];
	if($pickoption=="" || $Comments=="")
	{
	 echo "Please fill transport taking and comment";
	} else {
	$updatedata['transportdate']=date('Y-m-d');
	$updatedata['transporttake']=$pickoption;
	$updatedata['comment']=$Comments;
	 $affectedRows = StudentAdmissionModel::where('id', $studentid)->update($updatedata);
	 echo "Details Updated successfully";
	}
	}
	public function Searchschoolprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();	
	$SchoolName=$StudentData['SchoolName'];
	$schooluserDetailsbyid = GeneralSettingModel::where('id', $SchoolName)->get()->toArray();
	echo $schooluserDetailsbyid[0]['SchoolAddress'];
	
	}
}
