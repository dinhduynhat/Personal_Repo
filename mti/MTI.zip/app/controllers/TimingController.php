<?php

class TimingController extends BaseController
{
    
    public function TimingLayout()
    {
        $TimingDetails = TimingModel::lists('VehicleCode');

        if (empty($TimingDetails)) 
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode','AutoID');    
        }
        else
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $TimingDetails)->lists('VehicleCode','AutoID');    
        }

        
        

        #return $VehicleDetails;
        
        
        #return $VehicleDetails;
        $DriverDetailss = TimingModel::lists('DriverName');

        if(empty($DriverDetailss))
        {
            $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');    
        }
        else
        {
        $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $DriverDetailss)->lists('DriverName', 'AutoID');
        }
        

        
		$TimingDetails = TimingModel::all()->toArray();
        return View::make('timing/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails);
    }
    
    public function TimingProcess()
    {
        
        $TimingData = Input::all();
        $validation = Validator::make($TimingData, TimingModel::$rules);

        $TimingData['VehicleId'] = Input::get('VehicleCode');
        $TimingData['DriverId'] = Input::get('DriverName');
        

        #return $TimingData;
        
        

        if ($validation->passes()) 
        {
            TimingModel::create($TimingData);
            VehicleLocation::create($TimingData);
            return Redirect::to(Session::get('urlpath').'/timing')->with('Message', 'Timing Details Saved Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/timing')->withInput()->withErrors($validation->messages());
        }
    }
	public function TimingEdit($data=NULL)
    {
	    
        $editvehicle=$data;
		$TimingDetailsbyid = TimingModel::where('AutoID', $editvehicle)->get()->toArray();

        if(empty($TimingDetailsbyid))
        {
            $TimingDetails = TimingModel::lists('VehicleCode');
        if (empty($TimingDetails)) 
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode','AutoID');    
        }
        else
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $TimingDetails)->lists('VehicleCode','AutoID');    
        }
        $DriverDetailss = TimingModel::lists('DriverName');
        if(empty($DriverDetailss))
        {
            $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');    
        }
        else
        {
        $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $DriverDetailss)->lists('DriverName', 'AutoID');
        }
        $TimingDetails = TimingModel::all()->toArray();

        return Redirect::to(Session::get('urlpath').'/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails);

#        return View::make('timing/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails);

        }
        else
        {

        #$TimingDetailsbyid;
  //       $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode', 'AutoID');
  //       $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');
		// $TimingDetails = TimingModel::all()->toArray();

        $TimingDetailss = TimingModel::lists('VehicleCode');
        $Self = TimingModel::where('AutoID', $data)->pluck('VehicleCode');
        $dat = [$Self];        
        $TimingDetails = array_diff($TimingDetailss, $dat);

        if (empty($TimingDetails)) 
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode','AutoID');    

        }
        else
        {
            $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $TimingDetails)->lists('VehicleCode','AutoID');
        }

        

        $DriverDetailss = TimingModel::lists('DriverName');
        $Selfs = TimingModel::where('AutoID', $data)->pluck('DriverName');
        $dats = [$Selfs];        
        $DriverDetailss = array_diff($DriverDetailss, $dats);
        

        if(empty($DriverDetailss))
        {
            $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');    
        }
        else
        {
        $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->whereNotIn('AutoID', $DriverDetailss)->lists('DriverName', 'AutoID');
        }
        $TimingDetails = TimingModel::all()->toArray();

        return View::make('timing/timingupdate')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails)->with('TimingDetailsbyid', $TimingDetailsbyid);

        }
	}
	public function TimingupdateProcess($data=NULL)
    {
	#return 1;
	$update = array(
    	'VehicleCode' => 'required|unique:timing,VehicleCode,'.$data.',AutoID',     
    	'StartTime' => 'required',
    	'EndTime' => 'required|min:StartTime',
    	'DriverName' => 'required',
    #   'DriverName' => 'required|unique:timing', #If required one driver for a Vehicle
        );
        $TimingEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($TimingEditData, $update);        
        if ($validation->passes()) 
        {
		
		$TimingEditDataJi['VehicleId'] = Input::get('VehicleCode');
		
        $TimingEditDataJi['DriverId'] = Input::get('DriverName');
        #return $data;

		   $VehicleNo = TimingModel::where('AutoID', $data)->pluck('VehicleCode');
		   #return $VehicleNo;
		   $affectedRows = TimingModel::where('AutoID', $data)->update($TimingEditData);
		   
			#$VehicleNo = VehicleLocation::where('VehicleCode', $data)->pluck('VehicleCode');
			#return $VehicleNo;
		   #$VehicleNo = VehicleLocation::where('VehicleId', $VehicleNo)->delete();
		   #VehicleLocation::create($TimingEditDataJi);
		   
		   $affectedRowsji = VehicleLocation::where('VehicleId', $VehicleNo)->update($TimingEditDataJi);
            
            return Redirect::to(Session::get('urlpath').'/timingedit/'.$data)->with('Message', 'Timing Details Update Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/timingedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function TimingDelete($data=NULL)
    {
	    $editvehicle=$data;
		$TimingDetailsbyid = TimingModel::where('AutoID', $editvehicle)->get()->toArray();
		$busid=$TimingDetailsbyid[0]['VehicleCode'];		
		$count = TranportallocateModel::where('busid', '=', $busid)->count();

	if($count==0)
	{
		$VehicleNo = TimingModel::where('AutoID', $editvehicle)->pluck('VehicleCode');
		$affectedRows = TimingModel::where('AutoID', $editvehicle)->delete();		
		$VehicleNo = VehicleLocation::where('VehicleId', $VehicleNo)->delete();
		#$affectedRows = VehicleLocation::where('AutoID', $data)->delete();		
		
		
       return Redirect::to(Session::get('urlpath').'/timing')->with('Message', 'Timing Details Delete Succesfully');
	   } else {
	    $deleteerror['error']="error";
	    $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode', 'AutoID');
        $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');
		$TimingDetails = TimingModel::all()->toArray();
        return View::make('timing/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails)->with('deleteerror', $deleteerror);
	   }
	}
	public function TimingDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['timingdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$TimingDetailsbyid = TimingModel::where('AutoID', $data[$i])->get()->toArray();
		$busid=$TimingDetailsbyid[0]['VehicleCode'];		
		$count[] = TranportallocateModel::where('busid', '=', $busid)->count();
      }
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = TimingModel::where('AutoID', $data[$i])->delete();
	
     
	}
	    return Redirect::to(Session::get('urlpath').'/timing')->with('Message', 'Timing Details Delete Succesfully');
	} else {
	    $deleteerror['error']="error";
	    $VehicleDetails = VehicleModel::where('Company', Auth::user()->schoolid)->lists('VehicleCode', 'AutoID');
        $DriverDetails = DriverModel::where('Company', Auth::user()->schoolid)->lists('DriverName', 'AutoID');
		$TimingDetails = TimingModel::all()->toArray();
        return View::make('timing/timing')->with('VehicleDetails', $VehicleDetails)->with('DriverDetails', $DriverDetails)->with('TimingDetails', $TimingDetails)->with('deleteerror', $deleteerror);
	   }
	}
}