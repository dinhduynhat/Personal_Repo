<?php

class ParentController extends BaseController
{
    
        public function EditApproval()
    {
        
        $ParentEditData = ParentEditModel::all()->toArray();
        $GeneralSettingDetails = GovernmentEntityModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('settings/editapproval')->with('ParentEditData', $ParentEditData)->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails);
    }

         public function EditApprovalLayout($data=NULL)
    {
        
		
		$Exist = ParentEditModel::where('id', $data)->count();

		if($Exist!=0)
		{
    	$ParentEditData = ParentEditModel::where('id', '=', $data)->firstOrFail();
        $ParentId = ParentEditModel::where('id', $data)->pluck('ParentId');

        $ParentData = ParentModel::where('id', '=', $ParentId)->firstOrFail();
        
		return View::make('settings/editapprovalprocess')->with('ParentEditData', $ParentEditData)->with('ParentData', $ParentData);       
		}
		else
		{
		return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', '');
		}
		
    }
    public function DriversOnMap()
    {
        return View::make('settings/mapdriver');
    }
    public function EditApprovalProcess($data=NULL,$data1=NULL)
    {	
    	$RealData = $data1;
    	$GotData = $data;
    	
    	$NewParentData = ParentEditModel::where('id', '=', $GotData)->firstOrFail();
    	


    	

		#$ParentId = $_POST['vals'];
		$ParentId = $RealData;
		$GeneralData['FirstName'] = $NewParentData->FirstName;
        $GeneralData['Phone'] = $NewParentData->Phone;
        $GeneralData['Mobile'] = $NewParentData->Mobile;
        $GeneralData['Email'] = $NewParentData->Email;
        $GeneralData['Address'] = $NewParentData->Address;
        $GeneralData['Pincode'] = $NewParentData->Pincode;
		$GeneralparentData['GuardianFirstName'] = $NewParentData->FirstName;
        $GeneralparentData['ContactPhone'] = $NewParentData->Phone;
        $GeneralparentData['ContactMobile'] = $NewParentData->Mobile;
        $GeneralparentData['GuardianMail'] = $NewParentData->Email;
        $GeneralparentData['Address'] = $NewParentData->Address;
        $GeneralparentData['ContactPin'] = $NewParentData->Pincode;
		$Address=$NewParentData->Address;
		$Address = urlencode($Address);
		$request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
		$xml = simplexml_load_file($request_url) or die("url not loading");
		$status = $xml->status;
		$Lon="";
		$Lat="";
		if ($status=="OK") 
		{
		$Lat = $xml->result->geometry->location->lat;
		$Lon = $xml->result->geometry->location->lng;
		$LatLng = "$Lat,$Lon";
		}
		$GeneralparentData['lat'] = $Lat;
        $GeneralparentData['long'] = $Lon;
		
		
		
		#return $ParentId;
		$OldEmail = ParentModel::where('id', $ParentId)->pluck('Email');
		$NewEmail = ParentEditModel::where('id', $data)->pluck('Email');
		
		#return $NewEmail;
		
		if($OldEmail!=$NewEmail)
		{
		
		#Checking if email already exist
			
			$Exist = MTIServiceParent::where('Email', $NewEmail)->count();
			
			if($Exist!=0)
			{
			#Replace with old details
			#Existing old person
			$OldPerson = ParentModel::where('Email', $NewEmail)->pluck('id');
			$VOldPerson = ParentModel::where('Email', $OldEmail)->pluck('id');
			$affectedRows = ParentModel::where('id', $OldPerson)->update($GeneralData); # Updating old person
			$affectedRows = StudentAdmissionModel::where('GuardianMail', $NewEmail)->update($GeneralparentData); # Updating old person
			$affectedRows = StudentAdmissionModel::where('GuardianMail', $OldEmail)->update($GeneralparentData); # Updating old person
			#$OldStudent = StudentAdmissionModel::where('GuardianMail', $NewEmail)->pluck('id');
			
			#return $VOldPerson;
			#Deleting old person 
			#Code for deleting old person
			 $user = ParentEditModel::find($data);
			 $user->delete();
			 $user = ParentModel::find($VOldPerson);
			 $user->delete();
			#Change the Student appropriately 
			return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Approved Parent Profile');
			return '3';
			exit();
			#Deleted the old person
			}
			else
			{

			#New Email Change, So 
			$affectedRows = ParentModel::where('id', $ParentId)->update($GeneralData);
			$affectedRows = StudentAdmissionModel::where('parentid', $ParentId)->update($GeneralparentData);
			$user = ParentEditModel::find($data);
			 $user->delete();
			return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Approved Parent Profile');
			return '2';
			exit();
			}
		}
		else # Regular Operation
		{
			
			
			
			$affectedRows = ParentModel::where('id', $ParentId)->update($GeneralData);
			$affectedRows = StudentAdmissionModel::where('parentid', $ParentId)->update($GeneralparentData);
			$user = ParentEditModel::find($data);
			$user->delete();
			return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Approved Parent Profile');
			return '1';
		}
		
		return Redirect::to(Session::get('urlpath').'/editapproval');
		return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Approved Parent Profile');
		return 'done';
		
		#$ckeckcount=MTIServiceParent::where('Email', $GeneralparentData['GuardianMail'])->count();
		
		
		
		
		#$affectedRows = StudentAdmissionModel::where('ContactPin', '6')->update($GeneralparentData);
		
		return $GeneralparentData;
		exit();
  
  
		
		
        $user = ParentEditModel::find($data);
        $user->delete();

			
        

        return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Approved Parent Profile');
    	
    }
    public function EditApprovalDelete($data=NULL)
    {
        $user = ParentEditModel::find($data);
        $user->delete();
        return Redirect::to(Session::get('urlpath').'/editapproval')->with('Message', 'Succesfully Rejected Profile Edit Request');
    }
    

    
}