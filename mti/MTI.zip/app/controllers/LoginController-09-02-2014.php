<?php

class LoginController extends BaseController
{   
   public function Login()
    {
        $LoginData = Input::except(array('_token'));
	$username=Input::get('UserName');
	$password=Input::get('password');
		
	if (Auth::attempt(array('email' => $username, 'password' => $password)))
		   {   
         	 	 
	   if(Auth::user()->usertype !="1")
	   {
	   $schoolid=Auth::user()->schoolid;
	   $schooluserDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
	   
	   if($schooluserDetailsbyid[0]['Status']=="Unblock")
	   {
	     return Redirect::intended('home');
	   } else {	 
        Session::flush();	   
	   return Redirect::to('')->with('Message', 'Your Account had been blocked.Please contact to administrator');
	   }
        } else {
		 return Redirect::intended('home');
		}	   
       } 
	  else
        {
            return Redirect::to('')->with('Message', 'UserName or Password Invalid');
        }
	}

    public function Logout()
    {
        Session::flush();
        return Redirect::to('');
    }

    public function ForgotPassword()
    {
        
        return View::make('login/forgot');
    }
    
        public function CreateUserLayout()
    {      
        return View::make('login/createuser');
    }

    public function CreateUserProcess()
    {
        $UserData = Input::all();
		
        $validation  = Validator::make($UserData, User::$rules);
        if ($validation->passes()) 
        {
            User::create($UserData);
            return Redirect::to('createuser')->with('Message', 'User Details Saved Succesfully');
        } else 
        {
            return Redirect::to('createuser')->withInput()->withErrors($validation->messages());
        }
    }   
	public function ForgotPasswordProcess()
    {
        $UserData = Input::except(array('_token'));
		$requestusername=$UserData['UserName'];
        $UserDetails = User::where('email', $requestusername)->get()->toArray();
        if (!empty($requestusername)) 
        {
        $string = str_random(5);     
        $passworddata = User::find($UserDetails[0]['id']);
        $email=$UserDetails[0]['email'];
		$username=$UserDetails[0]['UserName'];       
        $passworddata->password = $string;
        //$passworddata->newpassword = $string;
        $passworddata->save();
        
        //Mail::send([], [], function($message)
        Mail::send([],
     array('pass' => $string,'email' => $email,'username' => $username), function($message) use ($string,$email,$username)
    {
        
        

        $user = MailTemplate::find(1);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
        $mail_body = str_replace("{password}", $string, $mail_body);
        $mail_body = str_replace("{username}", $username, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($email);
        $message->subject('Password Details - Ma$na Taxi');
        });


        return Redirect::to('forgot')->withInput()->with('Message', 'New Password sent to mail Succesfully');
        }
        else
        {
        return Redirect::to('forgot')->withInput()->withInput()->with('Message', 'UserName not Found');
        
        
        }
        



        
    }
}