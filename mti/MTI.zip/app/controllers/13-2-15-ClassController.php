<?php

class ClassController extends BaseController
{
    
    public function ClassLayout()
    {
	$schoolid=Auth::user()->schoolid;
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->get()->toArray();
      
        return View::make('class/class')->with('ClassDetails', $ClassDetails);
     
    }
    
    public function ClassProcess()
    {

       
        $ClassData = Input::all();
        $validation = Validator::make($ClassData, ClassModel::$rules);
        $ClassData['schoolid']=Auth::user()->schoolid;
	$GradeName = $ClassData['GradeName'];
		$schoolid = Auth::user()->schoolid;
        if ($validation->passes()) 
        {

           $count = ClassModel::where('GradeName', '=', $GradeName)->where('schoolid', '=', $schoolid)->count();
     if($count==0)
	 {
            ClassModel::create($ClassData);
			} else {
			
			return Redirect::to('class')->with('Message', 'Grade Name Already taken');
			
			}
            return Redirect::to('class')->with('Message', 'Grade Saved Succesfully');
        } else 
        {
            
            return Redirect::to('class')->withInput()->withErrors($validation->messages());
        }
    }
	public function ClassEdit($data=NULL)
    {
	    $editvehicle=$data;
		$ClassDetailsbyid = ClassModel::where('AutoID', $editvehicle)->get()->toArray();
        $schoolid=Auth::user()->schoolid;
	    $ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->get()->toArray();
      
        return View::make('class/classupdate')->with('ClassDetails', $ClassDetails)->with('ClassDetailsbyid', $ClassDetailsbyid);
	}
	public function ClassupdateProcess($data=NULL)
    {
        $ClassEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($ClassEditData, ClassModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = ClassModel::where('AutoID', $data)->update($ClassEditData);
            
            return Redirect::to('classedit/'.$data)->with('Message', 'Grade Update Succesfully');
        } else 
        {
            return Redirect::to('classedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function ClassDelete($data=NULL)
    {
	$editvehicle=$data;
$schoolid=Auth::user()->schoolid;
		$ClassDetailsbyid = ClassModel::where('AutoID', $editvehicle)->get()->toArray();
		$grade=$ClassDetailsbyid[0]['GradeName'];
	  $count = StudentAdmissionModel::where('StudentCourse', '=', $grade)->where('SchoolName', '=', $schoolid)->count();

	if($count==0)
	{
	    $editvehicle=$data;
		$affectedRows = ClassModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('class')->with('Message', 'Grade Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	  	$schoolid=Auth::user()->schoolid;
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->get()->toArray();      
        return View::make('class/class')->with('ClassDetails', $ClassDetails)->with('deleteerror', $deleteerror);
	   }
	}
	 public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();

        $validation  = Validator::make($StudentAdmissionData, ClassModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/grade/','grade' . Input::file('importfile')->getClientOriginalName());
	$importfile='grade' . Input::file('importfile')->getClientOriginalName();
	
	}
$results=Excel::load('assets/uploads/grade/'.$importfile, function($reader) {

})->get()->toArray();
function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}
$importarr=array("grade");
$keyarray=array_keys($finaldata[0]);
$checkwantedarray=array_intersect($importarr,$keyarray);

if(count($importarr)==count(array_filter($checkwantedarray)))
{
foreach($finaldata as $uniquevalue)
{
$arrayvalcount[]=$uniquevalue['grade'];
}
$count=count(array_filter($arrayvalcount));

if($count <= 50)
{
if(count($arrayvalcount)==count(array_filter($arrayvalcount)))
{
foreach($finaldata as $final)
{
$GradeName=$final['grade'];	
$schoolid=Auth::user()->schoolid;
if(!empty($GradeName))
{
   $count = ClassModel::where('GradeName', '=', $GradeName)->where('schoolid', '=', $schoolid)->count();
     if($count==0)
	 {
	 
	 $ClassData['GradeName']=$GradeName;
	 $ClassData['schoolid']=Auth::user()->schoolid;
	 ClassModel::create($ClassData);
	 }
	 }
}
} else {
 return Redirect::to('class')->with('Message', 'Grade missing in your record.');
}
} else {
 return Redirect::to('class')->with('Message', 'Maximum 50 record only allowed to import');
}
} else {
 return Redirect::to('class')->with('Message', 'Required fields are missing');
}
 return Redirect::to('class')->with('Message', 'Grade Saved Succesfully');
        } else 
        {
            
            return Redirect::to('class')->withInput()->withErrors($validation->messages());
        }
}
public function GradeExportLayout()
    {	

Excel::create('Grade', function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
		$ClassDetails = ClassModel::all()->toArray();


foreach ($ClassDetails as $ClassDetailsvalue)
{
$uploaddata[]['Grade']=$ClassDetailsvalue['GradeName'];	

}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('class');		
       
    }
}