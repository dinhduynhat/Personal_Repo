<?php

class BatchController extends BaseController
{
    
    public function BatchLayout()
    {
	$startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	//$batchDetails = BatchModel::all()->toArray();
	//$batchDetails=BatchModel::join('class', 'batch.Class', '=', 'class.AutoID')->get()->toArray();
   $batchDetails = BatchModel::with('classModel')->get()->toArray();
      $ClassDetails = ClassModel::lists('ClassName', 'AutoID');
        return View::make('batch/batch')->with('batchDetails', $batchDetails)->with('ClassDetails', $ClassDetails)->with('years', $years);
     
    }
	public function Batchprocess()
    {

       
        $BatchData = Input::all();
        $validation = Validator::make($BatchData, BatchModel::$rules);
        
        if ($validation->passes()) 
        {
            BatchModel::create($BatchData);
            return Redirect::to('batch')->with('Message', 'Batch Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('batch')->withInput()->withErrors($validation->messages());
        }
    }
    public function BatchEdit($data=NULL)
    {
	    $editbatch=$data;
		$batchDetailsbyid = BatchModel::where('AutoID', $editbatch)->get()->toArray();
        $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	
	$batchDetails = BatchModel::all()->toArray();
      $ClassDetails = ClassModel::lists('ClassName', 'AutoID');      
     return View::make('batch/batchupdate')->with('batchDetails', $batchDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('batchDetailsbyid', $batchDetailsbyid);
	}
	public function BatchupdateProcess($data=NULL)
    {
        $BatcEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($BatcEditData, BatchModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = BatchModel::where('AutoID', $data)->update($BatcEditData);
            
            return Redirect::to('batchedit/'.$data)->with('Message', 'Batch Details Update Succesfully');
        } else 
        {
            return Redirect::to('batchedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function BatchDelete($data=NULL)
    {
	    $editbatch=$data;
		$affectedRows = BatchModel::where('AutoID', $editbatch)->delete();		
       return Redirect::to('batch')->with('Message', 'Batch Details Delete Succesfully');
	}
   
}