<?php

class StudentAdmissionController extends BaseController
{
    
    public function StudentAdmissionSettingsLayout()
    {
	
	    $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$gender= array("Male"=>"Male", "Female"=>"Female");
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('gender', $gender)->with('weekdays', $weekdays);
    }
    public function StudentAdmissionProcess()
    {	
        $StudentAdmissionData = Input::all();	
			
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {	
		$TripType = $StudentAdmissionData['TripType'];
		if($TripType==2)
		{
		unset($StudentAdmissionData['fromTripType']);
		}
		$schoolid = $StudentAdmissionData['SchoolName'];
		$StudentCourse = $StudentAdmissionData['StudentCourse'];
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
			 $key=str_random(5);
		    $StudentAdmissionData['Generatekey']= $key;
		    $ParentData['FirstName']=$StudentAdmissionData['GuardianFirstName'];
			$ParentData['LastName']=$StudentAdmissionData['GuardianLastName'];
			$ParentData['Mobile']=$StudentAdmissionData['ContactMobile'];
			$ParentData['House']=$StudentAdmissionData['House'];
			$ParentData['Apartment']=$StudentAdmissionData['Apartment'];
			$ParentData['Street']=$StudentAdmissionData['Street'];
			$ParentData['City']=$StudentAdmissionData['ContactCity'];
			$ParentData['State']=$StudentAdmissionData['ContactState'];
			$ParentData['Pincode']=$StudentAdmissionData['ContactPin'];
			$ParentData['Email']=$StudentAdmissionData['GuardianMail'];
			$ParentData['Generatekey']= $key;
			$count = MTIServiceParent::where('Email', '=', $StudentAdmissionData['GuardianMail'])->count();
	 if($count==0)
	 {
	 	$parent = MTIServiceParent::create($ParentData);
		$StudentAdmissionData['parentid'] = $parent->id;
		} else {
		$schoolDetailsbyid = MTIServiceParent::where('Email', '=', $StudentAdmissionData['GuardianMail'])->get()->toArray();
		$StudentAdmissionData['parentid'] = $schoolDetailsbyid[0]['id'];
		$StudentAdmissionData['GuardianFirstName'] = $schoolDetailsbyid[0]['FirstName'];		
		$StudentAdmissionData['ContactMobile'] = $schoolDetailsbyid[0]['Mobile'];
		$StudentAdmissionData['House'] = $schoolDetailsbyid[0]['House'];
		$StudentAdmissionData['Apartment'] = $schoolDetailsbyid[0]['Apartment'];
		$StudentAdmissionData['Street'] = $schoolDetailsbyid[0]['Street'];
		$StudentAdmissionData['ContactCity'] = $schoolDetailsbyid[0]['City'];
		$StudentAdmissionData['ContactState'] = $schoolDetailsbyid[0]['State'];
		$StudentAdmissionData['ContactPin'] = $schoolDetailsbyid[0]['Pincode'];
		}	
		$Address=$StudentAdmissionData['Street'].",".$StudentAdmissionData['ContactCity'].",".$StudentAdmissionData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $StudentAdmissionData['lat']=$Lat;
  $StudentAdmissionData['long']=$Lon;
		   $student = StudentAdmissionModel::create($StudentAdmissionData);
		 
		  
            return Redirect::to('studentlisting')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
       return Redirect::to('studentadmission')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentListSettingsLayout()
    {
	
	 $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
    if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentDetails = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentDetails = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	
    return View::make('studentadmission/studentlist')->with('ClassDetails', $ClassDetails)->with('years', $years)->with('StudentDetails', $StudentDetails)->with('SchoolDetails', $SchoolDetails);
    }
	
public function SearchStudentProcess()
	{
	$StudentAdmissionData= Array();
	$StudentData = array_filter(Input::except(array('_token')));	
	if(!empty($StudentData['Searchdata']))
{
	$Searchdata=$StudentData['Searchdata'];
	$resultdata=explode("/",$Searchdata);
	$studentname=explode("_",$resultdata[0]);
$StudentAdmissionData['PersonalFirstName']=$studentname[0];
$StudentAdmissionData['PersonalLastName']=$studentname[1];
$StudentAdmissionData['Age']=$resultdata[1];
$StudentAdmissionData['Gender']=$resultdata[2];
}
if(!empty($StudentData['SchoolName']))
{
$StudentAdmissionData['SchoolName']=$StudentData['SchoolName'];
}
	if(!empty($StudentAdmissionData))
	{
	
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->with('batchresult')->with('schollresult')->get()->toArray();	
		}
if(Auth::user()->usertype==2)
		{
$style="unwant";
$titlename="Change Student Transport Attendence Status";

}else{
$style="";
$titlename="Student Transport Attendence Status";
}
		
		//print_r($StudentAdmissionDetailsbyid);
		echo "<script>
$(document).ready(function(){ $('#student-listing-table').dataTable();
});
</script>";
echo '<div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
		
        <h5>Student List</h5>
		<div class="errorsetting" style="float: right;color: red;margin-top:14px;"><em>*</em> Click Student Name And View Student Information.</div>
        </div>
     
        <div class="panel-tab-row"><table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
		<th class="'.$style.'">School</th>
        <th>Name</th>
        <th>Grade</th>
		<th>Age</th>
		<th>Gender</th>
		<th>Parent Name</th>
		<th>Parent Mobile</th> 
       		
        </tr>
        </thead>
        <tbody>';
		$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);

		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
		
		//$checkdata=$StudentAdmissionDetailvalue['transporttake'];
		
				$studentid=$StudentAdmissionDetailvalue['id'];
				$checksdata['studentid']=$studentid;
	$checksdata['date']=date('Y-m-d');
		$StudentAttandencebyid = StudentAttandenceModel::where($checksdata)->get()->toArray();
      if(!empty($StudentAttandencebyid))	
{	  
       $checkdata=$StudentAttandencebyid[0]['toschool'];
		if($checkdata==1)
		{
		 $yescheck="checked";
		 //$nocheck="";
		} else {
		  $yescheck="";
		// $nocheck="selected";
		}
	 } else {
	 $yescheck="checked";
	 $StudentAttandencebyid[0]['comment']="";
	 }
		
		if(!empty($StudentAdmissionDetailvalue['House'])) { $address=$StudentAdmissionDetailvalue['House'].',</br>'.$StudentAdmissionDetailvalue['Street'].'</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; } else { $address= $StudentAdmissionDetailvalue['Apartment'].'</br>'.$StudentAdmissionDetailvalue['Street'].',</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; }
		
       echo '<tr>
	   <td  class="'.$style.'">'.$StudentAdmissionDetailvalue['schollresult']['SchoolName'].'</td>   
        <td><span class="tab-check"></span><a class="fancybox attandencelink" href="#inline'.$StudentAdmissionDetailvalue['id'].'" id="'.$StudentAdmissionDetailvalue['id'].'">'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</a>
		<div id="attandence'.$StudentAdmissionDetailvalue["id"].'" title="Basic dialog" style="display: none;">
		<div class="work-sch-contain">
        <div class="panel-heading">
        <h4 class="panel-title">Weekly Attendence Schedule</h4>
        </div>
        <div class="work-row work-row-head">
              <div class="work-right">
                 <ul>
                     <li>'.date("m-d-y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-y", strtotime($dates[4])).'</br>Fri</li>
                 </ul>
              </div>
        </div>
        <div class="work-row work-row-present">
             <div class="work-left">
                 <p>To Home</p>
             </div>
             <div class="work-right">
                 <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		if($StudentAttandence[0]['tohome']==1)
		{
                  echo'<li><span class="icon-work icon-work-present"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
        <div class="work-row work-row-absent">
             <div class="work-left">
                 <p>To School</p>
             </div>
             <div class="work-right">
                  <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
                  echo'<li><span class="icon-work icon-work-present"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
    </div>
		</div>
		</td>
        <td>'.$StudentAdmissionDetailvalue['StudentCourse'].'</td>
		<td>'.$StudentAdmissionDetailvalue['Age'].'</td>
        <td>'.$StudentAdmissionDetailvalue['Gender'].'</td>   
          <td>'.$StudentAdmissionDetailvalue['GuardianFirstName'].'</td>
        <td>'.$StudentAdmissionDetailvalue['ContactMobile'].'</td>
		
        </tr><div id="inline'.$StudentAdmissionDetailvalue['id'].'" class="pop-des" style="display: none;">
		
		<div class="panel-heading">
                <h2 class="">'.$titlename.'</h2>
              </div>
		<div class="coln_box">
		<div class="coln coln_1">
		
		<div class="panel-heading">
                <h4 class="panel-title">Student Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Gender: </span>'.$StudentAdmissionDetailvalue['Gender'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Age:</span> '.$StudentAdmissionDetailvalue['Age'].'</label>
        </div>       
        </li>
          <li>
        <div class="label-control">
        <label for="r_no"><span>Grade:</span> '.$StudentAdmissionDetailvalue['StudentCourse'].'</label>
        </div>       
        </li>         		
        </ul>        
		</div>
		<div class="coln coln_2">
		
		<div class="panel-heading">
                <h4 class="panel-title">Parent Details</h4>
              </div>
        <ul class="dash-form-listerpopup"> 		
		 <li>
        <div class="label-control">
        <label for="r_no"><span>Name: </span>'.$StudentAdmissionDetailvalue['GuardianFirstName'].'</label>
        </div>       
        </li>	
         <li>
        <div class="label-control">
        <label for="r_no"><span>Mobile:</span> '.$StudentAdmissionDetailvalue['ContactMobile'].'</label>
        </div>       
        </li>
        <li>
        <div class="label-control">
        <label for="r_no"><span>Address: </span><p>'.$address.'</p></label>
        </div>       
        </li>         		
        </ul> 
		
		</div>
		<div class="coln coln_3">';
		if($dates[4] >=date("Y-m-d"))
		{
		 $dateclass="";
		}else {
		$dateclass="unwant";
		}
if(Auth::user()->usertype ==2)
{
		echo '<div class="panel-heading">
                <h4 class="panel-title">Update Student Transport Attendence Detail</h4>
              </div>
			  <div class="error stransport"></div>
        <ul class="dash-form-listerpopup '.$dateclass.'">		
		 <li>
        <div class="label-controlcheckbox">
		<label for="r_no">Taking Transport Today</label><em>*</em></br>	
		yes<input type="radio" name="check'.$StudentAdmissionDetailvalue['id'].'" id="yes'.$StudentAdmissionDetailvalue['id'].'" value="1"  />
		No<input type="radio" name="check'.$StudentAdmissionDetailvalue['id'].'" id="No'.$StudentAdmissionDetailvalue['id'].'" value="0" />
       <input id="updatedate'.$StudentAdmissionDetailvalue['id'].'" name="updatedate" type="hidden" value="">
		        
		<input id="studentid" name="studentid" type="hidden" value="'.$StudentAdmissionDetailvalue['id'].'">
        </div>        
         
        </li>  	
         <li>
        <div class="label-control">
        <label for="r_no">Comments</label>
        </div>
        <div class="input-control">       
       <textarea class="Comments" name="Comments" id="textcomment'.$StudentAdmissionDetailvalue['id'].'" cols="30" rows="30" style="height: 34px;width: 266px;" required onkeyup="transpotalert(this.value)" >'.$StudentAttandencebyid[0]['comment'].'</textarea>
	   <input id="CommentsData" class="CommentsData'.$StudentAdmissionDetailvalue['id'].'" name="CommentsData" type="hidden" value="">
        </div>
         
        </li>
         		
        </ul> 
<div class="btn-group  transportcommentbutton '.$dateclass.'">
        <input class="submit-btn transportcomment" type="submit" value="Save" id="'.$StudentAdmissionDetailvalue['id'].'" >    
       
        </div>';
}
    echo '
        <div class="panel-heading">
        <h4 class="panel-title">Weekly Attendence Schedule</h4>
        </div>
        <div class="work-row work-row-head">
              <div class="work-right">
                 <ul>
                     <li>'.date("m-d-y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-y", strtotime($dates[4])).'</br>Fri</li>
                 </ul>
              </div>
        </div>
        <div class="work-row work-row-present">
             <div class="work-left">
                 <p>From Home</p>
             </div>
             <div class="work-right">
                 <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		if($StudentAttandence[0]['tohome']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		} else {
		$message="";
		}
                  echo'<li><span class="icon-work icon-work-present studentmasterTooltip" title="No Entry"></span></li>';
				  } else {
				   echo'<li><span class="icon-work icon-work-absent studentmasterTooltip" title="No Entry"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence studentmasterTooltip" title="No Entry"></span></li>';
				   }}
                echo '</ul>
             </div>
        </div>
        <div class="work-row work-row-absent">
             <div class="work-left">
                 <p>From School</p>
             </div>
             <div class="work-right">
                  <ul>';
				 for($i=0;$i<count($dates);$i++)
				 {
				 $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
	if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		} else {
		$message="";
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		}
		
                  echo'<li><span class="icon-work icon-work-present studentmasterTooltip '.$dates[$i].'" title="'.$message.'"></span></li>';
				  } else {
				  if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		} else {
		$message="";
		$message=$StudentAttandence[0]['comment'];
		$commentdata=$StudentAttandence[0]['toschool']."/".$message."/".$studentid."/".$StudentAttandence[0]['date'];
		}
				   echo'<li><span class="icon-work icon-work-absent studentmasterTooltip getabsent '.$dates[$i].'" style="cursor:pointer" title="'.$message.'" id="'.$commentdata.'"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence studentmasterTooltip  '.$dates[$i].'" title="No Entry"></span></li>';
				   }}

                echo '</ul>
             </div>
        </div>   
		
		 </div>';
		
        } 
		echo '</tbody>
        </table>
		<div class="updatesearch"></div>
		</div>
        </div>';
		}
		echo '<script>
		function transpotalert(commentval){
			$("#CommentsData").val(commentval);
			}
			
		$(".transportcomment").click(function(){	
       var studentid = $(this).attr("id");
	   if(document.getElementById("yes"+studentid).checked == true) {
	   var pickupoption=1;
	   } else {
	    var pickupoption=0;
	   }		
		 var CommentsData = $("#textcomment"+studentid).val();
       // var CommentsData = $(".CommentsData"+studentid).val();		 
		 var updatedate = $("#updatedate"+studentid).val();
var dataString = "pickupoption="+pickupoption + "&Comments="+CommentsData + "&studentid="+studentid + "&updatedate="+updatedate; 
                $.ajax({
                    type: "POST",
                    url : "transportstudentprocess",
                    data : { pickupoption: pickupoption, Comments: CommentsData , studentid: studentid  , updatedate: updatedate },
                    success : function(data){					
					$(".stransport").html(data);
					
					//$(".comment"+studentid).val(Comment);
					$("#yes"+studentid).removeAttr("disabled", "disable");
					$("#No"+studentid).removeAttr("disabled", "disable");
					if(pickupoption==1)
					{
					if(updatedate=="")
					{
					var updatedate="'.date('Y-m-d').'";
					$("."+updatedate).removeClass("icon-work-absent");
					 $("."+updatedate).addClass("icon-work-present");
					} else {
					$("."+updatedate).removeClass("icon-work-absent");
					$("."+updatedate).addClass("icon-work-present");
					
					}
					$("#yes"+studentid).prop("checked", false);
					} else {
					if(updatedate=="")
					{
					var updatedate="'.date('Y-m-d').'";
					$("."+updatedate).addClass("icon-work-absent");
					 $("."+updatedate).removeClass("icon-work-present");
					} else {
					$("."+updatedate).addClass("icon-work-absent");
					$("."+updatedate).removeClass("icon-work-present");
					
					}
					$("#No"+studentid).prop("checked", false);					
					}
					$("#textcomment"+studentid).val("");
					$("#updatedate"+studentid).val("");
					$(".CommentsData"+studentid).val("");
					$(".stransport").html("");
					$(".fancybox-close").trigger( "click" );
					$(".Search").trigger("click");
					
					
                    }
                });
});
	$(".attandencelink").mouseover(function (e) {
                 var id=$(this).attr("id");
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-120});
				   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
   
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				
				 });
				$(".paginate_button").click(function(){

$(".attandencelink").mouseover(function (e) {
                 var id=$(this).attr("id");
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-120});
				   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
   
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				
				 });
}); 

				 $(document).ready(function() {
       
        $(".studentmasterTooltip").hover(function(){
               var tooltip="tooltip";
                var title = $(this).attr("title");
                $(this).data("tipText", title).removeAttr("title");
                $("<p class="+tooltip+"	></p>").text(title).appendTo("body").fadeIn("slow");
        }, function() {
                
                $(this).attr("title", $(this).data("tipText"));
                $(".tooltip").remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $(".tooltip").css({ top: mousey, left: mousex })
        });
		$(".getabsent").click(function(){
		var valuecomment=$(this).attr("id");
		var res = valuecomment.split("/");
		$("#yes"+res[2]).attr("disabled", "disable");
		$("#No"+res[2]).attr("disabled", "disable");
		if(res[0]==1)
		{
		$("#yes"+res[2]).val(res[0]).prop("checked", true);
		} else {
		$("#No"+res[2]).val(res[0]).prop("checked", true);
		
		}
		$("#textcomment"+res[2]).val(res[1]);
		$(".CommentsData"+res[2]).val(res[1]);
		$("#updatedate"+res[2]).val(res[3]);
		});
		
});

		</script>';
	
	
	}
	public function StudentadmissionEdit($data=NULL)
    {
	    $editvehicle=$data;
		$StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $editvehicle)->get()->toArray();
		$gender= array("Male"=>"Male", "Female"=>"Female");
          $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		}else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('StudentAdmissioneditbyid', $StudentAdmissioneditbyid)->with('gender', $gender)->with('weekdays', $weekdays);
	}
	public function Studentupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token')));
		$GeneralparentData = Input::except(array('_token'));

		
        $validation  = Validator::make($GeneralData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {
		
		
		$schoolid = $GeneralData['SchoolName'];
			$StudentCourse = $GeneralData['StudentCourse'];
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
			
		   if(!empty($GeneralData['ContactUploadLogo']))
	{
	Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/',$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName());
	$ContactUploadLogo=$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName();
	unset($GeneralData['ContactUploadLogo']);
	$GeneralData['ContactUploadLogo']=$ContactUploadLogo;
	}
	   $ParentData['FirstName']=$GeneralparentData['GuardianFirstName'];
			$ParentData['LastName']=$GeneralparentData['GuardianLastName'];
			$ParentData['Mobile']=$GeneralparentData['ContactMobile'];
			$ParentData['House']=$GeneralparentData['House'];
			$ParentData['Apartment']=$GeneralparentData['Apartment'];
			$ParentData['Street']=$GeneralparentData['Street'];
			$ParentData['City']=$GeneralparentData['ContactCity'];
			$ParentData['State']=$GeneralparentData['ContactState'];
			$ParentData['Pincode']=$GeneralparentData['ContactPin'];
			$ParentData['Email']=$GeneralparentData['GuardianMail'];
	  $updatedata=array_filter($GeneralData);
	  $TripType = $GeneralData['TripType'];
		if($TripType==2)
		{
		unset($updatedata['fromTripType']);
		$updatedata['fromTripType']=0;
		}
		if(empty($GeneralData['timingoption']))
		{
		$updatedata['timingoption']=0;
		}
		
		$Address=$GeneralparentData['Street'].",".$GeneralparentData['ContactCity'].",".$GeneralparentData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $updatedata['lat']=$Lat;
  $updatedata['long']=$Lon;
  $related['GuardianFirstName']=$GeneralparentData['GuardianFirstName'];
			$related['GuardianLastName']=$GeneralparentData['GuardianLastName'];
			$related['ContactMobile']=$GeneralparentData['ContactMobile'];
			$related['House']=$GeneralparentData['House'];
			$related['Apartment']=$GeneralparentData['Apartment'];
			$related['Street']=$GeneralparentData['Street'];
			$related['ContactCity']=$GeneralparentData['ContactCity'];
			$related['ContactState']=$GeneralparentData['ContactState'];
			$related['ContactPin']=$GeneralparentData['ContactPin'];
			$related['GuardianMail']=$GeneralparentData['GuardianMail'];
	   $affectedRows = StudentAdmissionModel::where('id', $data)->update($updatedata);
	   $StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $data)->get()->toArray();
	   $parentid=$StudentAdmissioneditbyid[0]['parentid'];
	     
		    $affectedRows = MTIServiceParent::where('id', $parentid)->update($ParentData);
			$affectedRows = StudentAdmissionModel::where('parentid', $parentid)->update($related);
            return Redirect::to('studentadmissionedit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
            return Redirect::to('studentadmissionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function Studentdelete($data=NULL)
    {
	    $editvehicle=$data;	
$getdd	=array();	
		$studentdetails = TranportallocateModel::where('studentid','LIKE', '%'.$data.'%')->get()->toArray();
		foreach($studentdetails as $student)
		{
		 $change = TranportallocateModel::where('id', $student['id'])->get()->toArray();
		 $dataval=explode(",",$change[0]['studentid']);
         $getkey=array_search($data, $dataval);
		 unset($dataval[$getkey]);
		$getdd['studentid']=implode(",",$dataval);
		
		 $finaldataid=TranportallocateModel::where('id', $student['id'])->update($getdd);
		 
		 $count = count($dataval);
		 if($count==0)
		 {
		 $finaldataid=TranportallocateModel::where('id', $student['id'])->delete();		
		 }		 
		}	
		$affectedRows = StudentAdmissionModel::where('id', $editvehicle)->delete();		
		$affectedRows = StudentAttandenceModel::where('studentid', $editvehicle)->delete();	
		
       return Redirect::to('studentlisting')->with('Message', 'Student Delete Succesfully');
	}
	 public function StudentAdmissionImportLayout()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentimport')->with('SchoolDetails', $SchoolDetails);
    }

     public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();
	
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/studentdata/','importfile' . Input::file('importfile')->getClientOriginalName());
	$importfile='importfile' . Input::file('importfile')->getClientOriginalName();
	
	}
	
		
$uploaddata['SchoolName']=$StudentAdmissionData['SchoolName'];	
$uploaddata['StudentBatch']=$StudentAdmissionData['StudentBatch'];
 //$uploaddata['SchoolAddress']=$StudentAdmissionData['SchoolAddress'];

$results=Excel::load('assets/uploads/studentdata/'.$importfile, function($reader) {

})->get()->toArray();



function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));

if($dimension == 3)
{

$finaldata=$results[0];


} else {

$data=array_filter($results);

for($i=0;$i<count($data);$i++)
{
$countstring=count(array_filter($data[$i]));
if($countstring==0)
{
unset($data[$i]);
} else {
$finaldata[] =$data[$i];
}
}

}

$test=array_filter($finaldata);
$importarr=array("grade","schoolentrancedate","schoolexitdate","studentfirstname","studentmiddlename","studentlastname","age","gender","dateofbirth","language","parentfullname","phone","mobile","parentemail","house","apartment","street","city","state","zipcode","weekdayfrom","weekdayto","intime","outtime","mondayintime","mondayouttime","tuesdayintime","tuesdayouttime","wednesdayintime","wednesdayouttime","thursdayintime","thursdayouttime","fridayintime","fridayouttime","note","oneway","twoway","fromschool","fromhome","emergencypersonfullname","emergencypersonmobile","emergencypersonphone");$keyarray=array_keys($finaldata[0]);

$checkwantedarray=array_intersect($importarr,$keyarray);

if(count($importarr)==count(array_filter($checkwantedarray)))
{
foreach($finaldata as $uniquevalue)
{
$arrayvalcount[]=$uniquevalue['studentfirstname'];
}
$count=count(array_filter($arrayvalcount));

if($count <= 50)
{
foreach($finaldata as $uniqueval)
{
$arrayval[]=$uniqueval['studentfirstname'];
$arrayemailval[]=$uniqueval['parentemail'];
$arrayageval[]=$uniqueval['age'];
$arraystreetval[]=$uniqueval['street'];
$arraycityval[]=$uniqueval['city'];
$arraystateval[]=$uniqueval['state'];
}

if(count($arrayval)==count(array_filter($arrayval)) && count($arrayemailval)==count(array_filter($arrayemailval)) && 
count($arrayageval)==count(array_filter($arrayageval))&& count($arraystreetval)==count(array_filter($arraystreetval))&& count($arraycityval)==count(array_filter($arraycityval))&& count($arraystateval)==count(array_filter($arraystateval)))
{
foreach($finaldata as $final)
{

$uploaddata['StudentCourse']=$final['grade'];
$uploaddata['EntranceDate']=$final['schoolentrancedate'];
$uploaddata['ExitDate']=$final['schoolexitdate'];
$uploaddata['PersonalFirstName']=$final['studentfirstname'];
$uploaddata['PersonalMiddleName']=$final['studentmiddlename'];	
$uploaddata['PersonalLastName']=$final['studentlastname'];
$uploaddata['Age']=$final['age'];	
$uploaddata['Gender']=$final['gender'];
$uploaddata['DateOfBirth']=$final['dateofbirth'];
$uploaddata['StudentLanguage']=$final['language'];
$uploaddata['GuardianFirstName']=$final['parentfullname'];	
//$uploaddata['GuardianMiddleName']=$final['parentmiddlename'];
//$uploaddata['GuardianLastName']=$final['parentlastname'];
$uploaddata['ContactPhone']=$final['phone'];	
$uploaddata['ContactMobile']=$final['mobile'];
$uploaddata['House']=$final['house'];
$uploaddata['Apartment']=$final['apartment'];
$uploaddata['Street']=$final['street'];	
$uploaddata['ContactCity']=$final['city'];
$uploaddata['ContactState']=$final['state'];	
$uploaddata['ContactPin']=$final['zipcode'];
$uploaddata['Weekdaysfrom']=$final['weekdayfrom'];
$uploaddata['Weekdaysto']=$final['weekdayto'];	
$uploaddata['weekInTime']=$final['intime'];	
$uploaddata['weekoutTime']=$final['outtime'];
$uploaddata['MondayInTime']=$final['mondayintime'];	
$uploaddata['MondayoutTime']=$final['mondayouttime'];
$uploaddata['TuesdayInTime']=$final['tuesdayintime'];	
$uploaddata['TuesdayoutTime']=$final['tuesdayouttime'];
$uploaddata['WednesdayInTime']=$final['wednesdayintime'];
$uploaddata['WednesdayoutTime']=$final['wednesdayouttime'];
$uploaddata['ThursdayInTime']=$final['thursdayintime'];	
$uploaddata['ThursdayoutTime']=$final['thursdayouttime'];
$uploaddata['FridayInTime']=$final['fridayintime'];
$uploaddata['FridayoutTime']=$final['fridayouttime'];
$uploaddata['Note']=$final['note'];
$uploaddata['GuardianMail']=$final['parentemail'];
$uploaddata['ContactFirstName']=$final['emergencypersonfullname'];
//$uploaddata['ContactMiddleName']=$final['emergencypersonmiddlename'];
//$uploaddata['ContactLastName']=$final['emergencypersonlastname'];
$uploaddata['ContactpersonPhone']=$final['emergencypersonphone'];
$uploaddata['ContactpersonMobile']=$final['emergencypersonmobile'];
 $key=str_random(5);		   
		    $ParentData['FirstName']=$final['parentfullname'];
			//$ParentData['LastName']=$final['parentlastname'];
			$ParentData['Mobile']=$final['mobile'];
			$ParentData['House']=$final['house'];
			$ParentData['Apartment']=$final['apartment'];
			$ParentData['Street']=$final['street'];
			$ParentData['City']=$final['city'];
			$ParentData['State']=$final['state'];
			$ParentData['Pincode']=$final['zipcode'];
			$ParentData['Email']=$final['parentemail'];
			$ParentData['Generatekey']= $key;
			$Address=$final['street'].",".$final['city'].",".$final['state'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $uploaddata['lat']=$Lat;
  $uploaddata['long']=$Lon;
if($final['oneway']==1)
 {
 $uploaddata['TripType']=1;
 if($final['fromschool']==1)
 {
  $uploaddata['fromTripType']=1;
 } else {
 $uploaddata['fromTripType']=2;
 } 
 } else {
  $uploaddata['TripType']=2;
   $uploaddata['fromTripType']=0;
 }
 $uploaddata['Generatekey']= str_random(5);
if(!empty($final['weekdayfrom']) && !empty($final['weekdayto']))
{
$uploaddata['timingoption']=1;
} else {
$uploaddata['timingoption']=0;
}
$GradeName=$final['grade'];	
$language=$final['language'];

if(!empty($GradeName))
{
   $count = ClassModel::where('GradeName', '=', $GradeName)->where('schoolid', '=', $uploaddata['SchoolName'])->count();
     if($count==0)
	 {
	 
	 $ClassData['GradeName']=$GradeName;
	 $ClassData['schoolid']=$uploaddata['SchoolName'];
	 ClassModel::create($ClassData);
	 }
	 }

	 	 if(!empty($language))
{
	 $languagecount = LanguageModel::where('language', '=', $language)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['language']=$language;
	 LanguageModel::create($StudentLanguageData);
	 }
	 }

	 if(!empty($final['studentfirstname']))
	 {
	 $count = MTIServiceParent::where('Email', '=', $final['parentemail'])->count();
	 if($count==0)
	 {
	 	$parent = MTIServiceParent::create($ParentData);
		$uploaddata['parentid'] = $parent->id;
		} else {
		$schoolDetailsbyid = MTIServiceParent::where('Email', '=', $final['parentemail'])->get()->toArray();
		$uploaddata['parentid'] = $schoolDetailsbyid[0]['id'];
		$uploaddata['GuardianFirstName'] = $schoolDetailsbyid[0]['FirstName'];		
		$uploaddata['ContactMobile'] = $schoolDetailsbyid[0]['Mobile'];
		$uploaddata['House'] = $schoolDetailsbyid[0]['House'];
		$uploaddata['Apartment'] = $schoolDetailsbyid[0]['Apartment'];
		$uploaddata['Street'] = $schoolDetailsbyid[0]['Street'];
		$uploaddata['ContactCity'] = $schoolDetailsbyid[0]['City'];
		$uploaddata['ContactState'] = $schoolDetailsbyid[0]['State'];
		$uploaddata['ContactPin'] = $schoolDetailsbyid[0]['Pincode'];
		$uploaddata['GuardianMail'] = $schoolDetailsbyid[0]['Email'];
		}
		$trimmed_array=array_map('trim',$uploaddata);
	$student = StudentAdmissionModel::create($trimmed_array);
	}
	
}
} else {
 return Redirect::to('studentimport')->with('Message', 'The Following fields should be required in your file,</br>Student Firstname </br> Parent Email </br> Student Age </br> Street </br> City </br> State .');
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Maximum 50 record only allowed to import');
}
} else {
 return Redirect::to('studentimport')->with('Message', 'Required fields are missing');
}
 return Redirect::to('studentlisting')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentimport')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentAdmissionExportLayout()
    {	


if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentdetails";
		}

Excel::create($mtidetail, function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolEntranceDate']=$StudentAdmissionDetailvalue['EntranceDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolExitdate']=$StudentAdmissionDetailvalue['ExitDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Language']=$StudentAdmissionDetailvalue['StudentLanguage'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentFullName']=$StudentAdmissionDetailvalue['GuardianFirstName'];	

$uploaddata[$StudentAdmissionDetailvalue['id']]['Phone']=$StudentAdmissionDetailvalue['ContactPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Mobile']=$StudentAdmissionDetailvalue['ContactMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentEmail']=$StudentAdmissionDetailvalue['GuardianMail'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonFullName']=$StudentAdmissionDetailvalue['ContactFirstName'];

$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonPhone']=$StudentAdmissionDetailvalue['ContactpersonPhone'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonMobile']=$StudentAdmissionDetailvalue['ContactpersonMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['House']=$StudentAdmissionDetailvalue['House'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Apartment']=$StudentAdmissionDetailvalue['Apartment'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Street']=$StudentAdmissionDetailvalue['Street'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['City']=$StudentAdmissionDetailvalue['ContactCity'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['State']=$StudentAdmissionDetailvalue['ContactState'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ZipCode']=$StudentAdmissionDetailvalue['ContactPin'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayfrom']=$StudentAdmissionDetailvalue['Weekdaysfrom'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayto']=$StudentAdmissionDetailvalue['Weekdaysto'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['InTime']=$StudentAdmissionDetailvalue['weekInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Outtime']=$StudentAdmissionDetailvalue['weekoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayInTime']=$StudentAdmissionDetailvalue['MondayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayoutTime']=$StudentAdmissionDetailvalue['MondayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayInTime']=$StudentAdmissionDetailvalue['TuesdayInTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayoutTime']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayInTime']=$StudentAdmissionDetailvalue['WednesdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayoutTime']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayInTime']=$StudentAdmissionDetailvalue['ThursdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayoutTime']=$StudentAdmissionDetailvalue['ThursdayoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayInTime']=$StudentAdmissionDetailvalue['FridayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayoutTime']=$StudentAdmissionDetailvalue['FridayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Note']=$StudentAdmissionDetailvalue['Note'];
if($StudentAdmissionDetailvalue['TripType']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']=1;
 if($StudentAdmissionDetailvalue['fromTripType']==1)
 {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']=1;
} else {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']=2;
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']="";
}
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']="";
} else {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']=2;
}
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('studentadmission');		
       
    }
	public function Transportstudentprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();
	if(!empty($StudentData['pickupoption']))
	{
	$pickoption=$StudentData['pickupoption'];
	$Comments=$StudentData['Comments'];
	$studentid=$StudentData['studentid'];
    $updatedate=$StudentData['updatedate'];
	$updatedata['date']=date('Y-m-d');
	$updatedata['tohome']=1;
	$updatedata['toschool']=$pickoption;
	$updatedata['comment']=$Comments;
	$updatedata['studentid']=$studentid;
	$checkdata['studentid']=$studentid;
	$checkdata['date']=date('Y-m-d');
	$count = StudentAttandenceModel::where($checkdata)->count();
	if(empty($updatedate))
	{
	if($count==0)
	{
         $updatedata['inserttime']=date('H:i:s');
	 StudentAttandenceModel::create($updatedata);
      
	// $affectedRows = StudentAttandenceModel::where('id', $studentid)->update($updatedata);
	} else {
	$updatedata['updatetime']=date('H:i:s');
	$affectedRows = StudentAttandenceModel::where($checkdata)->update($updatedata);
	}
	} else {	
	$update['tohome']=1;
	$update['toschool']=$pickoption;
	$update['comment']=$Comments;
	$checkupdatedata['studentid']=$studentid;
	$checkupdatedata['date']=$updatedate;

	$affectedRows = StudentAttandenceModel::where($checkupdatedata)->update($updatedata);
	}
	 echo "Details Updated successfully";
	}
	}
	public function Searchschoolprocess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();	
	$SchoolName=$StudentData['SchoolName'];
	$schooluserDetailsbyid = GeneralSettingModel::where('id', $SchoolName)->get()->toArray();
	echo $schooluserDetailsbyid[0]['SchoolAddress'];
	
	}
	public function SearchLoadSchoolProcess()
	{
	$StudentAdmissionData= Array();
	$StudentData = Input::all();	
	$SchoolName=$StudentData['SchoolName'];
	$schooluserDetailsbyid = GeneralSettingModel::where('id', $SchoolName)->get()->toArray();
	Session::put('SchoolAddress', $schooluserDetailsbyid[0]['SchoolAddress']);
	Session::put('schoolid', $SchoolName);
	echo $schooluserDetailsbyid[0]['SchoolAddress'];
	
	}
	public function Studentdeleteprocess()
	{
	$StudentData = Input::all();
	$studentdeletelist=$StudentData['studentdeletelist'];
	$data=explode(",",$studentdeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$getiddata=$data[$i];
	$studentdetails = TranportallocateModel::where('studentid','LIKE', '%'.$getiddata.'%')->get()->toArray();
		foreach($studentdetails as $student)
		{
		 $change = TranportallocateModel::where('id', $student['id'])->get()->toArray();
		 $dataval=explode(",",$change[0]['studentid']);
         $getkey=array_search($getiddata, $dataval);
		 unset($dataval[$getkey]);
		 $getdd['studentid']=implode(",",$dataval);
		 $finaldataid=TranportallocateModel::where('id', $student['id'])->update($getdd);
		 $count = count($dataval);
		 if($count==0)
		 {
		 $finaldataid=TranportallocateModel::where('id', $student['id'])->delete();		
		 }		 
		}	
	$affectedRows = StudentAdmissionModel::where('id', $data[$i])->delete();	
	$affectedRows = StudentAttandenceModel::where('studentid', $data[$i])->delete();
	}
	return Redirect::to('studentlisting')->with('Message', 'Students Deleted Succesfully');
	}
	 public function StudentListLayout()
    {

$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);

		$weekdays= array("0"=>"Monday", "1"=>"Tuesday","2"=>"Wednesday","3"=>"Thursday","4"=>"Friday");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentlisting')->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('weekdays', $weekdays)->with('dates', $dates);

    }
	public function ExportAttendenceLayout()
    {	   $age=array();
	$grade=array();	
	$studentname=array();
	$parentname=array();
			if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		} else {	
		echo Session::get('selectschool');
		if(Session::get('selectschool')=="")
		{	

		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
		} else {
		$selectschool=Session::get('selectschool');
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();	
		}			
		}
		
		foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
		{
		  $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
		  $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
		   $studentname[]=$StudentAdmissionDetails['PersonalFirstName']."_".$StudentAdmissionDetails['PersonalLastName'];
		   $parentname[]=$StudentAdmissionDetails['GuardianFirstName'];
		}
		$gender= array("Male"=>"Male", "Female"=>"Female");
		$AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
		$fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$checkresult=array();
        return View::make('studentadmission/exportattendence')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult);
    }
	public function ExportAttendenceProcess($data=NULL)
    {	 
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentattendence";
		}
$string = $data;
Excel::create($mtidetail, function($excel) use($string){

 $excel->sheet('Sheetname', function($sheet) use($string){

$checkarray=array();
$checkarray=array();
 $studentcheckarray = array();
$dataarray=explode("&",$string);
if($dataarray[2] !="")
                   {

                    $sdate=date("Y-m-d", strtotime($dataarray[2]));
                   } else {

                    $sdate="";
                    }
 if($dataarray[3] !="")
                   {

                    $edate=date("Y-m-d", strtotime($dataarray[3]));
                   } else {

                    $edate="";
                    }
$StudentAdmissionData['schoolid']=$dataarray[0];
$StudentAdmissionData['studentname']=$dataarray[1];
$StudentAdmissionData['Startdate']=$sdate;
$StudentAdmissionData['Enddate']=$edate;
$StudentAdmissionData['Gender']=$dataarray[4];
$StudentAdmissionData['Age']=$dataarray[5];
$StudentAdmissionData['Grade']=$dataarray[6];
$StudentAdmissionData['ParentName']=$dataarray[7];
$StudentAdmissionData['AttendenceStatus']=$dataarray[8];
$StudentAdmissionData['AttendenceFrom']=$dataarray[9];
$StudentAdmissionData['TripType']=$dataarray[10];

 if(!empty($StudentAdmissionData['TripType']))
 {
 $TripType=$StudentAdmissionData['TripType'];
 $studentcheckarray['TripType']=$TripType;
 } else {
  $TripType="";
 }
 if(!empty($StudentAdmissionData['schoolid']))
 {
 $schoolid=$StudentAdmissionData['schoolid'];
$studentcheckarray['SchoolName']=$schoolid;
 } else {
 $schoolid="";
 }

 if(!empty($StudentAdmissionData['Startdate']))
 {
 $Startdate=$StudentAdmissionData['Startdate'];
 } else {
  $Startdate="";
 }
 if(!empty($StudentAdmissionData['Enddate']))
 {
 $Enddate=$StudentAdmissionData['Enddate'];
 } else {
 $Enddate="";
 }
 if(!empty($StudentAdmissionData['Gender']))
 {
 $Gender=$StudentAdmissionData['Gender'];
 $studentcheckarray['gender']=$Gender;
 } else {
 $Gender="";
 }
 if(!empty($StudentAdmissionData['Age']))
 {
 $Age=$StudentAdmissionData['Age'];
   $studentcheckarray['Age']=$Age;
 } else {
 $Age="";
 }
 if(!empty($StudentAdmissionData['Grade']))
 {
 $Grade=$StudentAdmissionData['Grade'];
$studentcheckarray['StudentCourse']=$Grade;
 } else {
 $Grade="";
 }
  if(!empty($StudentAdmissionData['AttendenceStatus']))
 {
 $status=$StudentAdmissionData['AttendenceStatus'];
 
 } else {
 $status="";
 }
 if(!empty($StudentAdmissionData['studentname']))
 {
 $sname=$StudentAdmissionData['studentname'];
 $snamearray=explode("_",$sname);
 $studentfirstname=$snamearray[0];
 $studentlastname=$snamearray[1];
 $studentcheckarray['PersonalFirstName']=$studentfirstname;
$studentcheckarray['PersonalLastName']=$studentlastname;
 } else {
 $sname="";
 $studentfirstname="";
  $studentlastname="";
 }
  if(!empty($StudentAdmissionData['ParentName']))
 {
 $pname=$StudentAdmissionData['ParentName'];
$studentcheckarray['GuardianFirstName']=$pname;
//$studentcheckarray['GuardianLastName']=$parentlastname;
 } else {
 $pname="";
 $parentfirstname="";
 $parentlastname="";
 }
if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 $AttendenceFrom=$StudentAdmissionData['AttendenceFrom'];

 } else {
 $AttendenceFrom="";
 }
 // if(Auth::user()->usertype==2)
		// {
		// $schoolid=Auth::user()->schoolid;
		// $studentcheckarray['id']=$schoolid;
		// }
$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($studentcheckarray)
->whereHas('attendance',function($q)
{
if(!empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->whereBetween('date', array($Startdate,$Enddate));
	
	}
	if(!empty($StudentAdmissionData['Startdate']) && empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '>', $Startdate);
	}
	if(empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '<', $Enddate);
	}
	if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 if($AttendenceFrom=="all") 
 {
 if($status==0)
 {
 $q->where('toschool', '=', '0')->where('tohome', '=', '0');	
 }
 if($status==1)
 {
 $q->where('toschool', '=', '1')->where('tohome', '=', '1');	
 }
 }
 if($AttendenceFrom=="fromschool") 
 {
  if($status==0)
 {
 $q->where('toschool', '=', '0');	
 } 
   if($status==1)
 {
 $q->where('toschool', '=', '1');	
 } 
 }
 if($AttendenceFrom=="fromhome") 
 {
  if($status==1)
 {
 $q->where('tohome', '=', '1');	
 } 
  if($status==0)
 {
 $q->where('tohome', '=', '0');	
 } 
 }
 
 }
	
})
->with('attendance') // Optional eager loading, but recommended
->with('schollresult')->with('batchresult')->get()->toArray();

	$uploaddata=Array();

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Date']=$StudentAdmissionDetailvalue['attendance']['date'];	
if($StudentAdmissionDetailvalue['attendance']['tohome']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Fromhome']="Present";	
}else{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Fromhome']="Absent";	
}
if($StudentAdmissionDetailvalue['attendance']['toschool']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Toschool']="Present";	
}else{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Toschool']="Absent";	
}

}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('exportattendence');		
       
    }
	public function SessionProcess()
    {	
	  $schoolData = Input::all();
	  $schoolid=$schoolData['schoolid'];
	 Session::put('selectschool', $schoolid);
	}
	public function ExportAttendenceProcessList()
    {	
	  $StudentAdmissionData = Input::all();
$checkarray=array();

 $studentcheckarray = array();
  if(!empty($StudentAdmissionData['TripType']))
 {
 $TripType=$StudentAdmissionData['TripType'];
 $studentcheckarray['TripType']=$TripType;
 } else {
  $TripType="";
 }
 if(!empty($StudentAdmissionData['Startdate']))
 {
 $Startdate=$StudentAdmissionData['Startdate'];
 } else {
  $Startdate="";
 }
 if(!empty($StudentAdmissionData['Enddate']))
 {
 $Enddate=$StudentAdmissionData['Enddate'];
 } else {
 $Enddate="";
 }
 if(!empty($StudentAdmissionData['Gender']))
 {
 $Gender=$StudentAdmissionData['Gender'];
 $studentcheckarray['Gender']=$Gender;
 } else {
 $Gender="";
 }
 if(!empty($StudentAdmissionData['Age']))
 {
 $Age=$StudentAdmissionData['Age'];
   $studentcheckarray['Age']=$Age;
 } else {
 $Age="";
 }
 if(!empty($StudentAdmissionData['Grade']))
 {
 $Grade=$StudentAdmissionData['Grade'];
$studentcheckarray['StudentCourse']=$Grade;
 } else {
 $Grade="";
 }
  if(!empty($StudentAdmissionData['AttendenceStatus']))
 {
 $status=$StudentAdmissionData['AttendenceStatus'];
 
 } else {
 $status="";
 }
 if(!empty($StudentAdmissionData['studentname']))
 {
 $sname=$StudentAdmissionData['studentname'];
 $snamearray=explode("_",$sname);
 $studentfirstname=$snamearray[0];
 $studentlastname=$snamearray[1];
 $studentcheckarray['PersonalFirstName']=$studentfirstname;
$studentcheckarray['PersonalLastName']=$studentlastname;
 } else {
 $sname="";
 $studentfirstname="";
  $studentlastname="";
 }
  if(!empty($StudentAdmissionData['ParentName']))
 {
 $pname=$StudentAdmissionData['ParentName'];

$studentcheckarray['GuardianFirstName']=$pname;
//$studentcheckarray['GuardianLastName']=$parentlastname;
 } else {
 $pname="";
 $parentfirstname="";
 $parentlastname="";
 }
if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 $AttendenceFrom=$StudentAdmissionData['AttendenceFrom'];

 } else {
 $AttendenceFrom="";
 }
 if(!empty($StudentAdmissionData['schoolid']))
 {
$schoolid=$StudentAdmissionData['schoolid'];
$studentcheckarray['SchoolName']=$schoolid;
 } else {
 $schoolid="";
 }
// if(Auth::user()->usertype==2)
		// {
		// $schoolid=Auth::user()->schoolid;
		// $studentcheckarray['id']=$schoolid;
		// }
		
$checkresult = StudentAdmissionModel::where($studentcheckarray)

->whereHas('attendance',function($q)
{
if(!empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->whereBetween('date', array($Startdate,$Enddate));
	
	}
	if(!empty($StudentAdmissionData['Startdate']) && empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '>', $Startdate);
	}
	if(empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '<', $Enddate);
	}
	if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 if($AttendenceFrom=="all") 
 {
 if($status==0)
 {
 $q->where('toschool', '=', '0')->where('tohome', '=', '0');	
 }
 if($status==1)
 {
 $q->where('toschool', '=', '1')->where('tohome', '=', '1');	
 }
 }
 if($AttendenceFrom=="fromschool") 
 {
  if($status==0)
 {
 $q->where('toschool', '=', '0');	
 } 
   if($status==1)
 {
 $q->where('toschool', '=', '1');	
 } 
 }
 if($AttendenceFrom=="fromhome") 
 {
  if($status==1)
 {
 $q->where('tohome', '=', '1');	
 } 
  if($status==0)
 {
 $q->where('tohome', '=', '0');	
 } 
 }
 
 }
	
})
->with('attendance') // Optional eager loading, but recommended
->with('schollresult')->with('batchresult')->get()->toArray();
if(Auth::user()->usertype ==2)

		{
		$class="unwant";		
		} else {
		$class="";
		}
 echo '<script>
$(document).ready(function(){

$("#student-listing-table").dataTable();
});
</script>

        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">';
		
		if(!empty($checkresult))
		{
               if($StudentAdmissionData['Startdate'] !="")
                   {

                    $sdate=date("Y-m-d", strtotime($StudentAdmissionData['Startdate']));
                   } else {

                    $sdate="";
                    }
 if($StudentAdmissionData['Enddate'] !="")
                   {

                    $edate=date("Y-m-d", strtotime($StudentAdmissionData['Enddate']));
                   } else {

                    $edate="";
                    }
		echo '<a href="'.url().'/exportattendenceprocess/'.$StudentAdmissionData['schoolid'].'&'.$StudentAdmissionData['studentname'].'&'.$sdate.'&'.$edate.'&'.$StudentAdmissionData['Gender'].'&'.$StudentAdmissionData['Age'].'&'.$StudentAdmissionData['Grade'].'&'.$StudentAdmissionData['ParentName'].'&'.$StudentAdmissionData['AttendenceStatus'].'&'.$AttendenceFrom.'&'.$StudentAdmissionData['TripType'].'" class="btn-sb pass-btn">Export Student Attendence</a>';
		}
        echo '<h5>Student Attendence Report</h5>
        </div>
       
        <div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th class="'.$class.'">SchoolName</th>
        <th>Student Name</th>
        <th>Gender</th>
        <th>Age</th>
		<th>Grade</th>
		<th>View Monthly Attendence</th>
        </tr>
        </thead>
        <tbody>';

		foreach ($checkresult as $checkresultvalue)
{
		
       echo' <tr>        
        <td class="'.$class.'">'.$checkresultvalue['schollresult']['SchoolName'].'</td>
        <td>'.$checkresultvalue['PersonalFirstName']." ".$checkresultvalue['PersonalLastName'].'</td>
        <td>'.$checkresultvalue['Gender'].'</td>
        <td>'.$checkresultvalue['Age'].'</td>
		<td>'.$checkresultvalue['StudentCourse'].'</td>
		<td><a class="fancybox monthattendence" href="#attendence'.$checkresultvalue['id'].'" id="'.$checkresultvalue['id'].'">View Attendence</a></td>
        </tr><div id="attendence'.$checkresultvalue['id'].'" class="pop-des" style="display: none;">
		
		<div class="panel-heading" >
                <h2 class="">Student Monthly And Weekly Attendence Calender</h2>
              </div>
		<div class="coln_box">
		<div class="col_right" style="display:none;">
           <ul>
              <li class="dash-content-head"><a href="javascript:;" id="'.$checkresultvalue['id'].'" class="monthcalender pass-btn">Show Month calender</a></li>
                      
           </ul>
         </div>
		 <div class="searchfield" style="display:none">
		 <input type="button" class="go savemore" style="float: right;margin-right: 645px;" value="View Attendence" id="'.$checkresultvalue['id'].'" />
		 <label>Month:</label>
		  <select class="searchmonth" value="" style="width: auto;">
<option value="">Select Month</option>		 
<option value="1">January</option>
<option value="2">February</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
<label>Year:</label>
<select class="ddlSelectYear" style="width: auto;"><option value="">Select Year</option>';

            for ($x=date("Y"); $x>1900; $x--)
              {
                 echo '<option value="'.$x.'">'.$x.'</option>'; 
              } 
             
         echo '</select> <input type="hidden" class="optionyear" value=""/><input type="hidden" class="optionmonth" value=""/>
		 </div>
		 <div class="calender"></div>
		
		</div></div>';
       } 
        echo '</tbody>
        </table>
        </div>
        </div><script>
		$(document).ready(function(){
$(".searchmonth").change(function(){
$(".optionmonth").val($(this).val());
});
$(".ddlSelectYear").change(function(){
$(".optionyear").val($(this).val());
});
	$(".go").click(function(){
		var year=$(".optionyear").val();
		var month=$(".optionmonth").val();
		var studentid = $(this).attr("id");
		$.ajax({
                    type: "POST",
                    url : "studentcalenderprocess",
                    data : { month: month, year: year, studentid: studentid},
                    success : function(data){					
					$(".calender").html(data);
					$(".masterTooltip").hover(function(){
               var tooltip="tooltip";
                var title = $(this).attr("title");
                $(this).data("tipText", title).removeAttr("title");
                $("<p class="+tooltip+"	></p>").text(title).appendTo("body").fadeIn("slow");
        }, function() {
                
                $(this).attr("title", $(this).data("tipText"));
                $(".tooltip").remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $(".tooltip").css({ top: mousey, left: mousex })
        });
					
		}});
		});
	$(".monthattendence").click(function(){
	$(".month").hide();
	$(".week").hide();
	$(".searchfield").hide();
	//$(".monthcalender").show();
	//$(".monthcalender").trigger("click");
	var year="'.date('Y').'";
		var month="'.date('m').'";
		var studentid = $(this).attr("id");
		$.ajax({
                    type: "POST",
                    url : "studentcalenderprocess",
                    data : { month: month, year: year, studentid: studentid},
                    success : function(data){					
					$(".calender").html(data);
					$(".searchfield").show();
					$(".monthcalender").hide();
					$(".masterTooltip").hover(function(){
               var tooltip="tooltip";
                var title = $(this).attr("title");
                $(this).data("tipText", title).removeAttr("title");
                $("<p class="+tooltip+"	></p>").text(title).appendTo("body").fadeIn("slow");
        }, function() {
                
                $(this).attr("title", $(this).data("tipText"));
                $(".tooltip").remove();
        }).mousemove(function(e) {
                var mousex = e.pageX + 20; //Get X coordinates
                var mousey = e.pageY + 10; //Get Y coordinates
                $(".tooltip").css({ top: mousey, left: mousex })
        });
					
		}});
	
	});
		});
		</script>
		';

}
public function StudentAdmissionMoreProcess()
    {	
        $StudentAdmissionData = Input::all();		
			$schoolid = $StudentAdmissionData['SchoolName'];
			$StudentCourse = $StudentAdmissionData['StudentCourse'];
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {	
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
			 $key=str_random(5);
		    $StudentAdmissionData['Generatekey']= $key;
		    $ParentData['FirstName']=$StudentAdmissionData['GuardianFirstName'];
			$ParentData['LastName']=$StudentAdmissionData['GuardianLastName'];
			$ParentData['Mobile']=$StudentAdmissionData['ContactMobile'];
			$ParentData['House']=$StudentAdmissionData['House'];
			$ParentData['Apartment']=$StudentAdmissionData['Apartment'];
			$ParentData['Street']=$StudentAdmissionData['Street'];
			$ParentData['City']=$StudentAdmissionData['ContactCity'];
			$ParentData['State']=$StudentAdmissionData['ContactState'];
			$ParentData['Pincode']=$StudentAdmissionData['ContactPin'];
				$ParentData['Email']=$StudentAdmissionData['GuardianMail'];
			$ParentData['Generatekey']= $key;
			$count = MTIServiceParent::where('Email', '=', $StudentAdmissionData['GuardianMail'])->count();
	 if($count==0)
	 {
	 	$parent = MTIServiceParent::create($ParentData);
		$StudentAdmissionData['parentid'] = $parent->id;
		$parentid = $parent->id;
		} else {
		$schoolDetailsbyid = MTIServiceParent::where('Email', '=', $StudentAdmissionData['GuardianMail'])->get()->toArray();
		$StudentAdmissionData['parentid'] = $schoolDetailsbyid[0]['id'];
		$StudentAdmissionData['GuardianFirstName'] = $schoolDetailsbyid[0]['FirstName'];		
		$StudentAdmissionData['ContactMobile'] = $schoolDetailsbyid[0]['Mobile'];
		$StudentAdmissionData['House'] = $schoolDetailsbyid[0]['House'];
		$StudentAdmissionData['Apartment'] = $schoolDetailsbyid[0]['Apartment'];
		$StudentAdmissionData['Street'] = $schoolDetailsbyid[0]['Street'];
		$StudentAdmissionData['ContactCity'] = $schoolDetailsbyid[0]['City'];
		$StudentAdmissionData['ContactState'] = $schoolDetailsbyid[0]['State'];
		$StudentAdmissionData['ContactPin'] = $schoolDetailsbyid[0]['Pincode'];
		$parentid = $schoolDetailsbyid[0]['id'];
		}		
$TripType = $StudentAdmissionData['TripType'];
		if($TripType==2)
		{
		unset($StudentAdmissionData['fromTripType']);
		}		
		$Address=$StudentAdmissionData['Street'].",".$StudentAdmissionData['ContactCity'].",".$StudentAdmissionData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $StudentAdmissionData['lat']=$Lat;
  $StudentAdmissionData['long']=$Lon;
		   $student = StudentAdmissionModel::create($StudentAdmissionData);

		  
            return Redirect::to('studentadmissionmore/'.$parentid)->with('Message', 'StudentAdmission Details Saved Succesfully and add More students');
        } else 
        {
       return Redirect::to('studentadmission')->withInput()->withErrors($validation->messages());
        }
    }
	public function studentadmissionmore($data=NULL)
    {
	    $editvehicle=$data;
		$StudentAdmissioneditbyid= StudentAdmissionModel::where('parentid', $editvehicle)->get()->toArray();
		$gender= array("Male"=>"Male", "Female"=>"Female");
          $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;		
	$ClassDetails = ClassModel::where('schoolid', '=', $schoolid)->lists('GradeName', 'GradeName');
	} else {
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
	}
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		}else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
		$weekdays= array("Monday"=>"Monday", "Tuesday"=>"Tuesday","Wednesday"=>"Wednesday","Thursday"=>"Thursday","Friday"=>"Friday");
        return View::make('studentadmission/studentadmissionmore')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('StudentAdmissioneditbyid', $StudentAdmissioneditbyid)->with('gender', $gender)->with('weekdays', $weekdays);
	}
	public function StudentAdmissionMoreaddingProcess()
    {	
        $StudentAdmissionData = Input::all();	
          
			$schoolid = $StudentAdmissionData['SchoolName'];
			$parentid = $StudentAdmissionData['parentid'];
			$StudentCourse = $StudentAdmissionData['StudentCourse'];
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);     
   if($StudentAdmissionData['savemore']=="")	
       {		
        if ($validation->passes()) 
        {	
		$TripType = $StudentAdmissionData['TripType'];
		if($TripType==2)
		{
		unset($StudentAdmissionData['fromTripType']);
		}
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }		
			 $Address=$StudentAdmissionData['Street'].",".$StudentAdmissionData['ContactCity'].",".$StudentAdmissionData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $StudentAdmissionData['lat']=$Lat;
  $StudentAdmissionData['long']=$Lon;
		   $student = StudentAdmissionModel::create($StudentAdmissionData);	
		  		   
            return Redirect::to('studentlisting')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
       return Redirect::to('studentadmissionmore/'.$parentid)->withInput()->withErrors($validation->messages());
        }
		} else {
		if ($validation->passes()) 
        {	
		$TripType = $StudentAdmissionData['TripType'];
		if($TripType==2)
		{
		unset($StudentAdmissionData['fromTripType']);
		}
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }	
$Address=$StudentAdmissionData['Street'].",".$StudentAdmissionData['ContactCity'].",".$StudentAdmissionData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $StudentAdmissionData['lat']=$Lat;
  $StudentAdmissionData['long']=$Lon;			 
		   $student = StudentAdmissionModel::create($StudentAdmissionData);	
		  		   
            return Redirect::to('studentadmissionmore/'.$parentid)->with('Message', 'StudentAdmission Details Saved Succesfully and add More students');
        } else 
        {
       return Redirect::to('studentadmissionmore/'.$parentid)->withInput()->withErrors($validation->messages());
        }
		}
    }
	public function StudentAdmissionupdateMoreProcess($data=NULL)
    {
	
        $GeneralData = array_filter(Input::except(array('_token')));
		$GeneralparentData = Input::except(array('_token'));
$schoolid = $GeneralData['SchoolName'];
			$StudentCourse = $GeneralData['StudentCourse'];
        $validation  = Validator::make($GeneralData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {
		$count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();		
		  if($count==0)
		  {
		  $ClassData['GradeName']=$StudentCourse;
		  $ClassData['schoolid']=$schoolid;
	       ClassModel::create($ClassData);
	         }
			
		   if(!empty($GeneralData['ContactUploadLogo']))
	{
	Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/',$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName());
	$ContactUploadLogo=$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName();
	unset($GeneralData['ContactUploadLogo']);
	$GeneralData['ContactUploadLogo']=$ContactUploadLogo;
	}
	   $ParentData['FirstName']=$GeneralparentData['GuardianFirstName'];
			$ParentData['LastName']=$GeneralparentData['GuardianLastName'];
			$ParentData['Mobile']=$GeneralparentData['ContactMobile'];
			$ParentData['House']=$GeneralparentData['House'];
			$ParentData['Apartment']=$GeneralparentData['Apartment'];
			$ParentData['Street']=$GeneralparentData['Street'];
			$ParentData['City']=$GeneralparentData['ContactCity'];
			$ParentData['State']=$GeneralparentData['ContactState'];
			$ParentData['Pincode']=$GeneralparentData['ContactPin'];
			$ParentData['Email']=$GeneralparentData['GuardianMail'];
			
	  $updatedata=array_filter($GeneralData);
	  $TripType = $GeneralData['TripType'];
	  if($TripType==2)
		{
		unset($updatedata['fromTripType']);
		$updatedata['fromTripType']=0;
		}
		if(empty($GeneralData['timingoption']))
		{
		$updatedata['timingoption']=0;
		}
		$Address=$GeneralparentData['Street'].",".$GeneralparentData['ContactCity'].",".$GeneralparentData['ContactState'];
  $Address = urlencode($Address);
  $request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";
  $xml = simplexml_load_file($request_url) or die("url not loading");
  $status = $xml->status;
  $Lon="";
   $Lat="";
  if ($status=="OK") {
      $Lat = $xml->result->geometry->location->lat;
      $Lon = $xml->result->geometry->location->lng;
      $LatLng = "$Lat,$Lon";
  }
 $updatedata['lat']=$Lat;
  $updatedata['long']=$Lon;
            $related['GuardianFirstName']=$GeneralparentData['GuardianFirstName'];
			$related['GuardianLastName']=$GeneralparentData['GuardianLastName'];
			$related['ContactMobile']=$GeneralparentData['ContactMobile'];
			$related['House']=$GeneralparentData['House'];
			$related['Apartment']=$GeneralparentData['Apartment'];
			$related['Street']=$GeneralparentData['Street'];
			$related['ContactCity']=$GeneralparentData['ContactCity'];
			$related['ContactState']=$GeneralparentData['ContactState'];
			$related['ContactPin']=$GeneralparentData['ContactPin'];
			$related['GuardianMail']=$GeneralparentData['GuardianMail'];
	   $affectedRows = StudentAdmissionModel::where('id', $data)->update($updatedata);
	   $StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $data)->get()->toArray();
	   $parentid=$StudentAdmissioneditbyid[0]['parentid'];
	     
		    $affectedRows = MTIServiceParent::where('id', $parentid)->update($ParentData);
			
			$affectedRows23 = StudentAdmissionModel::where('parentid', $parentid)->update($related);
             return Redirect::to('studentadmissionmore/'.$parentid)->with('Message', 'StudentAdmission Details Saved Succesfully and add More students');
        } else 
        {
            return Redirect::to('studentadmissionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentExportbySchoolProcessLayout()
    {	   
			
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
				
        return View::make('studentadmission/studentexport')->with('SchoolDetails', $SchoolDetails);
    }
	public function ExportStudentDetailProcessBySchool()
    {	

$GeneralData = array_filter(Input::except(array('_token')));

$schoolid=$GeneralData['SchoolName'];
 $count= StudentAdmissionModel::where('SchoolName', $schoolid)->count();
 if($count !=0)
 {
	$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		

Excel::create($mtidetail, function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
$GeneralData = array_filter(Input::except(array('_token')));

$schoolid=$GeneralData['SchoolName'];
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
			

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolEntranceDate']=$StudentAdmissionDetailvalue['EntranceDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['SchoolExitdate']=$StudentAdmissionDetailvalue['ExitDate'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentFirstName']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentMiddleName']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['StudentLastName']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dateofbirth']=$StudentAdmissionDetailvalue['DateOfBirth'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Language']=$StudentAdmissionDetailvalue['StudentLanguage'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentFullName']=$StudentAdmissionDetailvalue['GuardianFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Phone']=$StudentAdmissionDetailvalue['ContactPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Mobile']=$StudentAdmissionDetailvalue['ContactMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ParentEmail']=$StudentAdmissionDetailvalue['GuardianMail'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonFullName']=$StudentAdmissionDetailvalue['ContactFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonPhone']=$StudentAdmissionDetailvalue['ContactpersonPhone'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['EmergencyPersonMobile']=$StudentAdmissionDetailvalue['ContactpersonMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['House']=$StudentAdmissionDetailvalue['House'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Apartment']=$StudentAdmissionDetailvalue['Apartment'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Street']=$StudentAdmissionDetailvalue['Street'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['City']=$StudentAdmissionDetailvalue['ContactCity'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['State']=$StudentAdmissionDetailvalue['ContactState'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['ZipCode']=$StudentAdmissionDetailvalue['ContactPin'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayfrom']=$StudentAdmissionDetailvalue['Weekdaysfrom'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Weekdayto']=$StudentAdmissionDetailvalue['Weekdaysto'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['InTime']=$StudentAdmissionDetailvalue['weekInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Outtime']=$StudentAdmissionDetailvalue['weekoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayInTime']=$StudentAdmissionDetailvalue['MondayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['MondayoutTime']=$StudentAdmissionDetailvalue['MondayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayInTime']=$StudentAdmissionDetailvalue['TuesdayInTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['TuesdayoutTime']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayInTime']=$StudentAdmissionDetailvalue['WednesdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['WednesdayoutTime']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayInTime']=$StudentAdmissionDetailvalue['ThursdayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['ThursdayoutTime']=$StudentAdmissionDetailvalue['ThursdayoutTime'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayInTime']=$StudentAdmissionDetailvalue['FridayInTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['FridayoutTime']=$StudentAdmissionDetailvalue['FridayoutTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Note']=$StudentAdmissionDetailvalue['Note'];
if($StudentAdmissionDetailvalue['TripType']==1)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']=1;
 if($StudentAdmissionDetailvalue['fromTripType']==1)
 {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']=1;
} else {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']=2;
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']="";
}
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']="";
} else {
 unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']);
  unset($uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']);
$uploaddata[$StudentAdmissionDetailvalue['id']]['Oneway']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromSchool']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['FromHome']="";
$uploaddata[$StudentAdmissionDetailvalue['id']]['Twoway']=2;
}
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('studentadmission');		
       
    
	} else {	
	return Redirect::to('studentexportbyschoolprocesslayout')->with('Message', 'Student Details are not found for this school');
	}
	}
	public function StudentListgroupLayout()
    {
	$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);
		$weekdays= array("0"=>"Monday", "1"=>"Tuesday","2"=>"Wednesday","3"=>"Thursday","4"=>"Friday");
		 $parentdetails = MTIServiceParent::get()->toArray();	
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::orderBy('parentid','asc')->where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::orderBy('parentid','asc')->with('batchresult')->with('schollresult')->get()->toArray();	
		}        
		return View::make('studentadmission/studentgrouplisting')->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('weekdays', $weekdays)->with('dates', $dates)->with('parentdetails', $parentdetails);
    }
	public function StudentCalenderProcess()
	{
	$calendar ="";
	
	$StudentData = Input::all();

$studentid= $StudentData['studentid'];			
if(!empty($StudentData['year']) && !empty($StudentData['month']))
{
$year = $StudentData['year'];
$month = $StudentData['month'];
} else {
$StudentData['year'] = date('Y');
$StudentData['month'] = date('m');
$year = $StudentData['year'];
$month = $StudentData['month'];
}
if($year==date('Y') && $month==date('m'))
{
$yrdata= strtotime(date("Y/m/d"));
$datavalue=date("F Y", $yrdata);

}else{
$monthName = date('F', mktime(0, 0, 0, $month, 10));
$datavalue=$monthName." ".$year;
}
	

   $calendar .= '<div class="calendarr-block month">
         <div class="header-block"><h5>'.$datavalue.'</h5>
         <div class="col_right">
           <ul>
              <li><a href="#" class="cur showmonth">Month</a></li>';
			  if($year==date('Y') && $month==date('m'))
{
             $calendar .=' <li><a href="#" class="showweek">Week</a></li>';
}			 
           $calendar .='</ul>
         </div>
         </div>';
if(!empty($StudentData['year']) && !empty($StudentData['month']))
{
$year = $StudentData['year'];
$month = $StudentData['month'];
} else {
$year = date('Y');
$month = date('m');
}

	/* draw table */
	$calendar .= '<div class="calender-content ">';

	/* table headings */
	$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
	
				 $calendar.= '<div class="weekdays_head"><div class="days_week"><span>'.implode('</span>
                 </div><div class="days_week"><span>',$headings).'</span>
                 </div></div>';

	/* days and weeks vars now ... */
	$running_day = date('w',mktime(0,0,0,$month,1,$year));
	$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
	$days_in_this_week = 1;
	$day_counter = 0;
	$dates_array = array();

	/* row for week one */
	$calendar.= '<div class="weekdays_content">';


	for($x = 0; $x < $running_day; $x++):
		$calendar.= '<div class="day_mo"> </div>';
		$days_in_this_week++;
	endfor;
			 

	for($list_day = 1; $list_day <= $days_in_month; $list_day++){
	$attandsdata=array();	
    $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$year."-0".$month."-0".$list_day;
	$count = StudentAttandenceModel::where($attandsdata)->count();
			$calendar.= '<div class="day_mo" id="'.$list_day.'">'.$list_day;
			if($count !=0)
	{
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['tohome']==1)
		{
		 $message="No Comment";
			$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';
			} else {
			$message="No Comment";
			$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';
			}
			 } else {
			 $message="No Comment";
			  $calendar.= '<span class="stu-nor masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';					
				}
         if($count !=0)
	{
	 $message="";
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		} else {
		$message="No Comment";
		$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		}		
			
			} else {
			if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		} else {
		$message="No Comment";
		$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		}
			
			}
			 } else {
			$message="No Comment";
			  $calendar.= '<span class="stu-nor masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';					
				}				
					$calendar.= '</div>';
			
		
		if($running_day == 6):
			$calendar.= '</div>';
			if(($day_counter+1) != $days_in_month):
				$calendar.= '<div class="weekdays_content">';
			endif;
			$running_day = -1;
			$days_in_this_week = 0;
		endif;
		$days_in_this_week++; $running_day++; $day_counter++;
	}

	/* finish the rest of the days in the week */
	if($days_in_this_week < 8):
		for($x = 1; $x <= (8 - $days_in_this_week); $x++):
			$calendar.= '<div class="day_mo"> </div>';
		endfor;
	endif;


	$calendar.= '</div>';


	$calendar .= '</div></div>';
	$calendar .= '<div class="calendarr-block week" style="display:none;">
         <div class="header-block"><h5>'.$datavalue.'</h5>
         <div class="col_right">
           <ul>
              <li><a href="#" class="cur showmonth">Month</a></li>';
			  if($year==date('Y') && $month==date('m'))
{
             $calendar .=' <li><a href="#" class="showweek">Week</a></li>';
}			 
           $calendar .='</ul>
         </div>
         </div>';
	$calendar .= '<div class="calender-content weeklycalendar" >
             <div class="weekdays_head">
                 
                 <div class="days_week">
                    <span>Mon</span>
                 </div>
                 <div class="days_week">
                    <span>Tue</span>
                 </div>
                 <div class="days_week">
                    <span>Wed</span>
                 </div>
                 <div class="days_week">
                    <span>Thu</span>
                 </div>
                 <div class="days_week">
                    <span>Fri</span>
                 </div>
                
             </div>
             <div class="weekdays_content">';
				$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
$startDate = date("Y-m-d",$monday);
$endDate = date("Y-m-d",$friday);
$tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);
$dates=$outArray;
			 for($i=0;$i<count($dates);$i++)
			 {
			 $timestamp = strtotime($dates[$i]);

$day = date('d', $timestamp);
			$attandsdata=array();	
    $attandsdata['studentid']=$studentid;
	$attandsdata['date']=$dates[$i];
	$count = StudentAttandenceModel::where($attandsdata)->count();
			$calendar.= '<div class="day_mo" id="'.$day.'">'.$day;
			if($count !=0)
	{
$message="";
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['tohome']==1)
		{
		$message="No Comment";
			$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';
			
			} else {
			$message="No Comment";
			$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';
			}
			 } else {
			$message="No Comment";
			  $calendar.= '<span class="stu-nor masterTooltip" title="'.$message.'" style="border-bottom: 1px solid #ddd;border-left: 1px solid #ddd;cursor:pointer;">From Home</span>';					
				}
         if($count !=0)
	{
$message="";
		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();
		
		if($StudentAttandence[0]['toschool']==1)
		{
		if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		} else {
		$message="No Comment";
		$calendar.= '<span class="stu-present masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		}
			
			} else {
			if(!empty($StudentAttandence[0]['comment']))
		{
		$message=$StudentAttandence[0]['comment'];
		$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		} else {
		$message="No Comment";
		$calendar.= '<span class="stu-obs masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';
		}			
			}
			 } else {
			$message="No Comment";
			  $calendar.= '<span class="stu-nor masterTooltip" title="'.$message.'" style="border-left: 1px solid #ddd;cursor:pointer;">From School</span>';					
				}				
					$calendar.= '</div>';
                  } 
             $calendar .= '</div>
         </div></div><script>
		 $(".showweek").click(function(){
		$(".showmonth").removeClass("cur");
		$(".week").show();
		$(".month").hide();
		$(".showweek").addClass("cur");
		});
		$(".showmonth").click(function(){
		$(".showweek").removeClass("cur");
		$(".week").hide();
		$(".month").show();
		$(".showmonth").addClass("cur");
		});
		 </script>';
	echo $calendar;
	
	}
public function StudentCalender()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentallocation')->with('SchoolDetails', $SchoolDetails);
    }
	 public function TransportList()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/transportallocation')->with('SchoolDetails', $SchoolDetails);
    }
	 public function AddStudentToBus()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/addstudenttobus')->with('SchoolDetails', $SchoolDetails);
    }
	public function GenerateMapRoute()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/generatemaproute')->with('SchoolDetails', $SchoolDetails);
    }
	public function ExportBusAttendenceLayout()
    {
        return View::make('studentadmission/exportbusattendence');
    }
    public function ExportBusAttendenceLayoutGovt()
    {
        
        $SchoolData = GeneralSettingModel::lists('SchoolName', 'id');
        return View::make('studentadmission/exportbusattendencegovt')->with('SchoolDetails', $SchoolData);
    }
public function ExportBusAttendenceLayoutSchool()
    {
        $SchoolData = GeneralSettingModel::lists('SchoolName', 'id');
        return View::make('studentadmission/exportbusattendenceschool')->with('SchoolDetails', $SchoolData);
    }
    

    public function ExportBusAttendenceLayoutGovtResult()
    {


    $WorkingDays = $this->WeekDayCounter($_POST['PayYear'], $_POST['PayMonth'], array(0, 6));


    $RequestedData = Input::all();
    
    $validation  = Validator::make($RequestedData, NotificationModel::$rules);
	
	
    if ($validation->passes()) 
        {
    $dateObj   = DateTime::createFromFormat('!m', $_POST['PayMonth']);
	$monthName = $dateObj->format('F'); // March
		
	 $GeneralSettingDetails = GovernmentEntityModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');

$count = cal_days_in_month(CAL_GREGORIAN, $_POST['PayMonth'], $_POST['PayYear']); 



$headcol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	$headcol .= '<th>'.$i.'</th>';
}

$SchoolDetails = StudentAdmissionModel::where('SchoolName', $_POST['schoolid'])->get();
$SchoolDetailsCount = StudentAdmissionModel::where('SchoolName', $_POST['schoolid'])->count();

$name = '';
foreach ($SchoolDetails as $key ) 
{
$totalabsent='';
$totalpresent='';
$bodycol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	#$bodycol .= '<td><span class="fr_ho"></span><span class="fr_sc"></span></td>';
	$today = $_POST['PayYear'].'-'.$_POST['PayMonth'].'-'.$i;


	$StudDataVal = StudentAttandenceModel::where('studentid', $key->id)->where('date', $today)->first();


if ($StudDataVal) 
{
	if ($StudDataVal->tohome=='1')
{
	$toh = '<span class="hgr"></span>';
	$totalpresent .= 0.5.'+';

}
else
{
if ($StudDataVal->comment=='') 
{
$toh = '
	<span class="hr">
<a href="#" class="tooltip"><span><strong>No Comments</strong></span></a>  
	</span>';
} else 
{
$toh = '
	<span class="hr">
<a href="#" class="tooltip"><span><strong>'.$StudDataVal->comment.'</strong></span></a>  
	</span>';
}


	
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$toh = '<span class="hg"></span>';
	
}


if ($StudDataVal) 
{
	if ($StudDataVal->toschool=='1')
{
	$tos = '<span class="sgr"></span>';
	$totalpresent .= 0.5.'+';
	
}
else
{
	
if ($StudDataVal->comment=='') 
{
$tos = '
	<span class="sr">
<a href="#" class="tooltip"><span><strong>No Comments</strong></span></a>  
	</span>';
} else 
{
$tos = '
	<span class="sr">
<a href="#" class="tooltip"><span><strong>'.$StudDataVal->comment.'</strong></span></a>  
	</span>';
}

	#$tos = '<span class="sr"></span>';
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$tos = '<span class="sg"></span>';	
}
	#$totalabsent = 1;
	$bodycol .= '<td>'.$toh.$tos.'</td>';
	$totalattendance = '';
	
}


$sum = array_sum( explode( '+', $totalabsent ) );
$sumji = array_sum( explode( '+', $totalpresent ) );

$TA = $WorkingDays-$sum;
	
$name.=	'<tr>
		<td>'.$key->PersonalFirstName.' '.$key->PersonalLastName.'</td>
    	<td>'.$key->StudentCourse.'</td>
        '.$bodycol.'
        <td>'.$WorkingDays.'</td>
        <td>'.$sum.'</td>
        <td>'.$sumji.'</td>
        
		
        </tr>';

	
}


$hidecount = "";
for ($i=0; $i < $count + 5	; $i++) 
{ 
	$hidecount .= $i.',';
}

$recordcount = '5';

$result = '



<script>



$(document).ready(function() {
$("#example").dataTable( {"aoColumnDefs": [{ "bSortable": false, 
	"aTargets": [ '.$hidecount.']
	 }] } );
} );



</script>

<a href="#" class="tooltip">.<span><strong>Most Light-weight Tooltip</strong></span></a>  
<p align="right">
<div class="dash-content-head tabContaier">


<a href="exportstudentattendance/'.$_POST['schoolid'].'/'.$_POST['PayMonth'].'/'.$_POST['PayYear'].'" target="_new" class="btn-sb pass-btn" >Export Student Attendance</a>
</div>
</p>
        <table class="example tab atrtendTable" id="example">
        <thead>
        <tr>
		<th>Student Name</th>
        <th>Grade</th>
        '.$headcol.'
        <th>Total Working Days</th>
        <th>Total Absent</th>
        <th>Total Present</th>
        


        </tr>
        </thead>
        <tbody>
        '.$name.'
        </tbody>
        </table>

        ';

return $result;
        }
        else
        {
        return '';
        return 'Please Choose School, Month and Year';
        }
    


        
    }



public function WeekDayCounter($Year, $Month, $Ignore) 
{
$count = 0;
$counter = mktime(0, 0, 0, $Month, 1, $Year);
while (date("n", $counter) == $Month) {
    if (in_array(date("w", $counter), $Ignore) == false) {
        $count++;
    }
    $counter = strtotime("+1 day", $counter);
}
return $count;  
}

    public function ExportBusAttendenceLayoutSchoolResult()
    #public function ExportBusAttendenceLayoutGovtResult()
    {

	$WorkingDays = $this->WeekDayCounter($_POST['PayYear'], $_POST['PayMonth'], array(0, 6));


    #countDays(2015, 3, array(0, 6))
    $RequestedData = Input::all();
    
    $validation  = Validator::make($RequestedData, NotificationModel::$rules);
	
	
    if ($validation->passes()) 
        {
    $dateObj   = DateTime::createFromFormat('!m', $_POST['PayMonth']);
	$monthName = $dateObj->format('F'); // March
		
	 $GeneralSettingDetails = GovernmentEntityModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');

$count = cal_days_in_month(CAL_GREGORIAN, $_POST['PayMonth'], $_POST['PayYear']); 



$headcol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	$headcol .= '<th>'.$i.'</th>';
}

$ownschool = Auth::user()->schoolid;

$SchoolDetails = StudentAdmissionModel::where('SchoolName', $ownschool)->get();
$SchoolDetailsCount = StudentAdmissionModel::where('SchoolName', $ownschool)->count();

$name = '';
foreach ($SchoolDetails as $key ) 
{
$totalabsent='';
$totalpresent='';
$bodycol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	#$bodycol .= '<td><span class="fr_ho"></span><span class="fr_sc"></span></td>';
	$today = $_POST['PayYear'].'-'.$_POST['PayMonth'].'-'.$i;


	$StudDataVal = StudentAttandenceModel::where('studentid', $key->id)->where('date', $today)->first();


if ($StudDataVal) 
{
	if ($StudDataVal->tohome=='1')
{
	$toh = '<span class="hgr"></span>';
	$totalpresent .= 0.5.'+';
}
else
{


if ($StudDataVal->comment=='') 
{
$toh = '
	<span class="hr">
<a href="#" class="tooltip"><span><strong>No Comments</strong></span></a>  
	</span>';
} else 
{
$toh = '
	<span class="hr">
<a href="#" class="tooltip"><span><strong>'.$StudDataVal->comment.'</strong></span></a>  
	</span>';
}



#	$toh = '<span class="hr"></span>';
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$toh = '<span class="hg"></span>';
	
}


if ($StudDataVal) 
{
	if ($StudDataVal->toschool=='1')
{
	$tos = '<span class="sgr"></span>';
	$totalpresent .= 0.5.'+';
}
else
{

if ($StudDataVal->comment=='') 
{
$tos = '
	<span class="sg">
<a href="#" class="tooltip"><span><strong>No Comments</strong></span></a>  
	</span>';
} else 
{
$tos = '
	<span class="sg">
<a href="#" class="tooltip"><span><strong>'.$StudDataVal->comment.'</strong></span></a>  
	</span>';
}

	#$tos = '<span class="sr"></span>';
	
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$tos = '<span class="sg"></span>';
	
}

	#$totalabsent = 1;


	$bodycol .= '<td>'.$toh.$tos.'</td>';
	$totalattendance = '';
	
}


$sum = array_sum( explode( '+', $totalabsent ) );
$sumji = array_sum( explode( '+', $totalpresent ) );


$TA = $WorkingDays-$sum;
	
$name.=	'<tr>
		<td>'.$key->PersonalFirstName.' '.$key->PersonalLastName.'</td>
    	<td>'.$key->StudentCourse.'</td>
        '.$bodycol.'
        <td>'.$WorkingDays.'</td>
        <td>'.$sum.'</td>
        <td>'.$sumji.'</td>
        
		
        </tr>';

	
}


$hidecount = "";
for ($i=0; $i < $count + 5	; $i++) 
{ 
	$hidecount .= $i.',';
}

$recordcount = '5';

$result = '<script>



$(document).ready(function() {
$("#example").dataTable( {"aoColumnDefs": [{ "bSortable": false, 
	"aTargets": [ '.$hidecount.']
	 }] } );
} );



</script>

<p align="right">
<div class="dash-content-head tabContaier">
<a href="exportstudentattendance/'.$ownschool.'/'.$_POST['PayMonth'].'/'.$_POST['PayYear'].'" target="_new" class="btn-sb pass-btn" >Export Student Attendance</a>
</div>
</p>

        <table class="example tab atrtendTable" id="example">
        <thead>
        <tr>
		<th>Student Name</th>
        <th>Grade</th>
        '.$headcol.'
        <th>No. of Working Days</th>
        <th>Total Absent</th>
        <th>Total Present</th>
        

        </tr>
        </thead>
        <tbody>
        '.$name.'
        </tbody>
        </table>

        ';

return $result;
        }
        else
        {
        return '';
        return 'Please Choose School, Month and Year';
        }
    


        
    }
    
}
