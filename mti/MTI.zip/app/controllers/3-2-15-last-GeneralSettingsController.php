<?php

class GeneralSettingsController extends BaseController
{
    
    public function GeneralSettingsLayout()
    {	
        
	    $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails);
    }
    public function GeneralProcess($data=NULL)
    {
	     $GeneralData = array_filter(Input::all());
		 $loginuserdata = Input::except(array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','Country','UploadLogo'));
		 
		$loginarray=array();
        $validation  = Validator::make($GeneralData, GeneralSettingModel::$rules);        
        if ($validation->passes()) 
        {	
		$UserName=$loginuserdata['UserName'];
		$password=$loginuserdata['password'];	
        $SchoolName=$GeneralData['SchoolName'];		
		if(!empty($GeneralData['AdminContactPerson']))
		{
	$AdminContactPerson=$GeneralData['AdminContactPerson'];
	$loginarray['FirstName']=$AdminContactPerson;
	$loginarray['LastName']=$AdminContactPerson;
	}
		if(!empty($GeneralData['SchoolEmail']))
		{
	$SchoolEmail=$GeneralData['SchoolEmail'];
	$loginarray['email']=$SchoolEmail;	
	}
	$loginarray['usertype']=2;
	unset($GeneralData['UserName']);
	unset($GeneralData['password']);
            
			$validate  = Validator::make($loginuserdata, User::$rules);        
        if ($validate->passes()) 
        {	
		    $school=GeneralSettingModel::create($GeneralData);
			$insertedId = $school->id;
			$userdata=User::create($loginuserdata);
			$inserteduserdataId = $userdata->id;
			$loginarray['schoolid']=$insertedId;
			
			$affectedRows = User::where('id', $inserteduserdataId)->update($loginarray);
			if(!empty($SchoolEmail))
	  {
	   Mail::send([],
     array('pass' => $password,'email' => $SchoolEmail,'username' => $UserName,'SchoolName' => $SchoolName), function($message) use ($password,$SchoolEmail,$UserName,$SchoolName)
    {
        $user = MailTemplate::find(4);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
		$mail_body = str_replace("{user}", $SchoolName, $mail_body);
        $mail_body = str_replace("{password}", $password, $mail_body);
        $mail_body = str_replace("{username}", $UserName, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($SchoolEmail);
        $message->subject('Password Details - MTI');
        });
		}
		} else {
		  return Redirect::to('general')->withInput()->withErrors($validate->messages());
		}
            return Redirect::to('general')->with('Message', 'General Details Saved Succesfully');
        } else 
        {
            return Redirect::to('general')->withInput()->withErrors($validation->messages());
        }
		
    }
	public function Schoolupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token','Username','Password')));
         $loginuserdata = Input::except(array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','Country','UploadLogo','_token','Status'));
		 
		 $loginarray=array();

        $validation  = Validator::make($GeneralData, GeneralSettingModel::$updaterules);   

        if ($validation->passes()) 
        {	
		$UserName=$loginuserdata['UserName'];
		$password=$loginuserdata['password'];
		$SchoolName=$GeneralData['SchoolName'];
		
			if(!empty($GeneralData['AdminContactPerson']))
		{
	$AdminContactPerson=$GeneralData['AdminContactPerson'];
	$loginarray['FirstName']=$AdminContactPerson;
	$loginarray['LastName']=$AdminContactPerson;
	} else {
	$loginarray['FirstName']="";
	$loginarray['LastName']="";
	}
		if(!empty($GeneralData['SchoolEmail']))
		{
	$SchoolEmail=$GeneralData['SchoolEmail'];
	$loginarray['email']=$SchoolEmail;	
	} else {
	$loginarray['email']="";
	
	}	
	
	$loginarray['usertype']=2;
	unset($GeneralData['UserName']);
	unset($GeneralData['password']);
		   if(!empty($GeneralData['UploadLogo']))
	{
	Input::file('UploadLogo')->move('assets/uploads/uploadschoollogo/',Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalName());
	$UploadLogo=Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalName();
	unset($GeneralData['UploadLogo']);
	$GeneralData['UploadLogo']=$UploadLogo;
	}
	if(!empty($UserName) && !empty($password))
	{
	$validate  = Validator::make($loginuserdata, User::$updaterules);        
        if ($validate->passes()) 
        {
	  $updatedata=array_filter($GeneralData);
	  $affectedRows = GeneralSettingModel::where('id', $data)->update($updatedata);
	  //$affectedRows1 = User::where('id', $data)->update($loginuserdata);
	  $schooluserDetailsbyid = User::where('schoolid', $data)->get()->toArray();
	  $userid=$schooluserDetailsbyid[0]['id'];
	   $passworddata = User::find($userid);      
         $passworddata->UserName = $UserName; 		
        $passworddata->password = $password;       
        $passworddata->save();
	  $affectedRows2 = User::where('id', $userid)->update($loginarray);
	  if(!empty($SchoolEmail))
	  {
	   Mail::send([],
     array('pass' => $password,'email' => $SchoolEmail,'username' => $UserName,'SchoolName' => $SchoolName), function($message) use ($password,$SchoolEmail,$UserName,$SchoolName)
    {
        $user = MailTemplate::find(4);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
		$mail_body = str_replace("{user}", $SchoolName, $mail_body);
        $mail_body = str_replace("{password}", $password, $mail_body);
        $mail_body = str_replace("{username}", $UserName, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($SchoolEmail);
        $message->subject('Password Details - MTI');
        });
		}
		   } else {
		  return Redirect::to('schooledit/'.$data)->withInput()->withErrors($validate->messages());
		}
		} else {
	   $updatedata=array_filter($GeneralData);
	  $affectedRows = GeneralSettingModel::where('id', $data)->update($updatedata);	 
	  $affectedRows2 = User::where('id', $data)->update($loginarray);		
		}
            return Redirect::to('schooledit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
	
            return Redirect::to('schooledit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function SchoolEdit($data=NULL)
    {
	    $editvehicle=$data;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $editvehicle)->get()->toArray();
		$schooluserDetailsbyid = User::where('schoolid', $editvehicle)->get()->toArray();
         $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$status= array("Unblock"=>"Unblock","Block"=>"Block");
		
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails)->with('schoolDetailsbyid', $schoolDetailsbyid)->with('schooluserDetailsbyid', $schooluserDetailsbyid)->with('status', $status);
	}
	public function SchoolDelete($data=NULL)
    {
	$count = StudentAdmissionModel::where('SchoolName', '=', $data)->count();
	
	if($count==0)
	{
	    $editvehicle=$data;
		$affectedRows = GeneralSettingModel::where('id', $editvehicle)->delete();
		$affectedRows1 = User::where('schoolid', $editvehicle)->delete();
       return Redirect::to('general')->with('Message', 'School Delete Succesfully');
	   } else {	   
	   $deleteerror['error']="error";	  
	   $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails)->with('deleteerror', $deleteerror);
	   }
	}
     public function SchoolImportLayout()
    {	   
			
        return View::make('general/schoolimport');
    }
	public function Importprocess()
    {	
	   $loginuserdata=Array();
        $StudentAdmissionData = Input::all();
$loginarray=array();
        $validation  = Validator::make($StudentAdmissionData, GeneralSettingModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/school/','school' . Input::file('importfile')->getClientOriginalName());
	$importfile='school' . Input::file('importfile')->getClientOriginalName();
	
	}
$results=Excel::load('assets/uploads/school/'.$importfile, function($reader) {

})->get()->toArray();
function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

$count=count($finaldata);

if($count <= 50)
{
foreach($finaldata as $uniqueval)
{
$arrayval[]=$uniqueval['schoolname'];
}
if(count($arrayval)==count(array_unique($arrayval)))
{
$GeneralSettingDetails = GeneralSettingModel::all()->toArray();
foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)
{
$exitingarray[]=$GeneralSettingDetailsvalue['SchoolName'];
}
$result = array_intersect($arrayval, $exitingarray);

if(count($result)==0)
{
foreach($finaldata as $final)
{
$SchoolName=$final['schoolname'];	
$SchoolAddress=$final['schooladdress'];
$SchoolEmail=$final['schoolemail'];
$ContactPersion=$final['contactpersion'];
$SchoolPhone=$final['schoolphone'];
$Mobile=$final['mobile'];
$Fax=$final['fax'];

if(!empty($SchoolName))
{
   $count = GeneralSettingModel::where('SchoolName', '=', $SchoolName)->count();
     if($count==0)
	 {	 
	 $ClassData['SchoolName']=$SchoolName;
	 $ClassData['SchoolAddress']=$SchoolAddress;
	 $ClassData['SchoolEmail']=$SchoolEmail;
	 $ClassData['SchoolPhone']=$SchoolPhone;
	 $ClassData['SchoolMobile']=$Mobile;
	 $ClassData['SchoolFax']=$Fax;		 
	 $ClassData['AdminContactPerson']=$ContactPersion;
	 $ClassData['Status']="Unblock";
	  $loginuserdata['UserName']=$SchoolName;
	 $loginuserdata['password']=$Fax;
      $loginarray['FirstName']=$ContactPersion;
	$loginarray['LastName']=$ContactPersion;
	$loginarray['email']=$SchoolEmail;	
	$loginarray['usertype']=2;
	 $school=GeneralSettingModel::create($ClassData);
	 $insertedId = $school->id;
	 $loginarray['schoolid']=$insertedId;
			$userdata=User::create($loginarray);
			$inserteduserdataId = $userdata->id;
						
			 $password = str_random(5);     
        $passworddata = User::find($inserteduserdataId);
        $email=$SchoolEmail;
		$UserName=$SchoolName; 
         $passworddata->UserName = $SchoolName; 		
        $passworddata->password = $password;       
        $passworddata->save();
		if(!empty($email))
	  {
	   Mail::send([],
     array('pass' => $password,'email' => $SchoolEmail,'username' => $UserName,'SchoolName' => $SchoolName), function($message) use ($password,$SchoolEmail,$UserName,$SchoolName)
    {
        $user = MailTemplate::find(4);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
		$mail_body = str_replace("{user}", $SchoolName, $mail_body);
        $mail_body = str_replace("{password}", $password, $mail_body);
        $mail_body = str_replace("{username}", $UserName, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($SchoolEmail);
        $message->subject('Password Details - MTI');
        });
		}
	 }
	 } 
}
} else {
 return Redirect::to('schoolimport')->with('Message', 'Already register school details present in your excel.');
}
} else {
 return Redirect::to('schoolimport')->with('Message', 'Duplicate school name present in your excel.');
}
} else {
 return Redirect::to('schoolimport')->with('Message', 'Maximum 50 record only allowed to import');
}
 return Redirect::to('general')->with('Message', 'School Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('schoolimport')->withInput()->withErrors($validation->messages());
        }
}
public function SchoolExportLayout()
    {	

Excel::create('School', function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
		$GeneralSettingDetails = GeneralSettingModel::all()->toArray();


foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)
{
$uploaddata[$GeneralSettingDetailsvalue['id']]['SchoolName']=$GeneralSettingDetailsvalue['SchoolName'];	
$uploaddata[$GeneralSettingDetailsvalue['id']]['SchoolAddress']=$GeneralSettingDetailsvalue['SchoolAddress'];
$uploaddata[$GeneralSettingDetailsvalue['id']]['SchoolEmail']=$GeneralSettingDetailsvalue['SchoolEmail'];
$uploaddata[$GeneralSettingDetailsvalue['id']]['ContactPersion']=$GeneralSettingDetailsvalue['AdminContactPerson'];
$uploaddata[$GeneralSettingDetailsvalue['id']]['SchoolPhone']=$GeneralSettingDetailsvalue['SchoolPhone'];
$uploaddata[$GeneralSettingDetailsvalue['id']]['Mobile']=$GeneralSettingDetailsvalue['SchoolMobile'];
$uploaddata[$GeneralSettingDetailsvalue['id']]['Fax']=$GeneralSettingDetailsvalue['SchoolFax'];
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('general');		
       
    }
	public function Schooldeleteprocess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['schooldeletelist'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$count[] = StudentAdmissionModel::where('SchoolName', '=', $data[$i])->count();
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = GeneralSettingModel::where('id', $data[$i])->delete();
		$affectedRows1 = User::where('schoolid', $data[$i])->delete();
	}
	return Redirect::to('general')->with('Message', 'School Deleted Succesfully');
	} else {
	 $deleteerror['error']="error";	
	 $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails)->with('deleteerror', $deleteerror);
	}
	}
}