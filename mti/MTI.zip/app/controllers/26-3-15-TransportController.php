<?php

class TransportController extends BaseController
{
    
    public function StudentCalender()
    {	   
		if(Auth::user()->usertype==4)
		{
		$schoolid=Auth::user()->schoolid;
		$bus=array();
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->with('schollresult')->with('batchresult')->get()->toArray();
        foreach($StudentAdmissionDetailsbyid as $company)
{
$bus[]=$company['SchoolName'];
}	
$relat=array_filter(array_unique($bus));	
if(!empty($relat))
{
		$SchoolDetails = GeneralSettingModel::whereIn('id', $relat)->lists('SchoolName', 'id');
		} else {
		
		 $SchoolDetails =array();
		}
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentallocation')->with('SchoolDetails', $SchoolDetails);
    }
	 public function TransportList()
    {	
$getdata=array();	
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {
		if(Auth::user()->usertype==4)
		{
		$schoolid=Auth::user()->schoolid;
        $getSchoolDetails = TranportallocateModel::where('buscompany', $schoolid)->get()->toArray();
		if(!empty($getSchoolDetails))
		{
           foreach($getSchoolDetails as $getSchool)
{
$getdata[]=$getSchool['schoolid'];
}		   
		$SchoolDetails = GeneralSettingModel::whereIn('id', $getdata)->lists('SchoolName', 'id');
		} else {
		
		$SchoolDetails=array();
		}
		} else {
		
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		}		
        return View::make('studentadmission/transportallocation')->with('SchoolDetails', $SchoolDetails);
    }
	 public function AddStudentToBus()
    {	   
	$age=array();
	$grade=array();	
	$grade=array();	
$updateid = Session::get('updateid');
$selectedpicktype = Session::get('triptypedata');
$selectedbusid = Session::get('busiddata');
$selectschoolid = Session::get('schooliddata');
if($selectedpicktype=="pickup")
		{
		$dataval="AM";
		
		} else {
		$dataval="PM";
		
		}
		$getstudentid=array();
		$transportdetails = TranportallocateModel::where('triptype', $dataval)->get()->toArray();
		foreach($transportdetails as $transport)
		{
		 $getstudentid[]=$transport['studentid'];			 
          }	


		
$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->whereNotIn('id',$getstudentid)->where('SchoolName', $selectschoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
		{
		  $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
		  $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
		   $studentname[$StudentAdmissionDetails['id']]=$StudentAdmissionDetails['PersonalFirstName']."_".$StudentAdmissionDetails['PersonalLastName'];
		 
		}				
        return View::make('studentadmission/addstudenttobus')->with('updateid', $updateid)->with('selectedpicktype', $selectedpicktype)->with('selectedbusid', $selectedbusid)->with('selectschoolid', $selectschoolid)->with('age', $age)->with('grade', $grade)->with('studentname', $studentname);
    }
	public function GenerateMapRoute()
    {	   
		$allocatestudentid = Session::get('allocatestudentid');
$selectedpicktype = Session::get('selectedpicktype');
$selectedbusid = Session::get('selectedbusid');
$startaddress = Session::get('startaddress');
$destinationaddress = Session::get('destinationaddress');
$selectschoolid = Session::get('selectschoolid');
$getstudent=explode(",",$allocatestudentid);
$studentdetails = StudentAdmissionModel::whereIn('id', $getstudent)->get()->toArray();	
foreach($studentdetails as $studentdatavalue)
{
$locationdataarray[]=$studentdatavalue['lat'].",".$studentdatavalue['long'];
$locationaddress[]=$studentdatavalue['Street'].",".$studentdatavalue['ContactCity'].",".$studentdatavalue['ContactState'];
$locationdatastudentarray[]=$studentdatavalue['id'];
$locationstudentnameaddress[]=$studentdatavalue['PersonalFirstName'].",".$studentdatavalue['PersonalLastName'];
}
        return View::make('studentadmission/generatemaproute')->with('allocatestudentid', $allocatestudentid)->with('selectedpicktype', $selectedpicktype)->with('startaddress', $startaddress)->with('destinationaddress', $destinationaddress)->with('selectedbusid', $selectedbusid)->with('locationdataarray', $locationdataarray)->with('selectschoolid', $selectschoolid)->with('locationaddress', $locationaddress)->with('locationdatastudentarray', $locationdatastudentarray)->with('locationstudentnameaddress', $locationstudentnameaddress);
    }
	public function SearchSchoolDetails()
    {	   
		$StudentData = Input::all();

$SchoolName= $StudentData['SchoolName'];	
$SchoolDetails = GeneralSettingModel::where('id', $SchoolName)->get()->toArray();
$Agedetails = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->where('SchoolName', $SchoolName)->groupBy('Age')->get()->toArray();	
$time=$SchoolDetails[0]['SchoolInTime']."-".$SchoolDetails[0]['SchooloutTime'];
$Schooladdress=$SchoolDetails[0]['SchoolAddress'];
echo '<script>				  function Ageachange(){
			
				  var str="";
for (i=0;i<Age.length;i++) { 
if(Age[i].selected){
str +=Age[i].value + ","; 
	
}
} 
 var SchoolName = $("#SchoolName").val();

var dataString = "str="+str; 
                $.ajax({
                    type: "POST",
                    url : "searchstudentaddressdetails",
                    data : { str: str, SchoolName: SchoolName},
                    success : function(data){
					$(".result2").html(data);
                       
                    }
                });
				  }</script><li>
                <div class="label-control">
				 <input type="hidden" class="SchoolAddress" value="'.$Schooladdress.'" />
                  <label for="r_no">Timing</label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select name="timing" id="timing">
                    <option value="'.$time.'">'.$time.'</option>
                   
                  </select>                </div>
              </li>
              <li>
                <div class="label-control">
                  <label for="r_no">Age </label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select name="Age[]" id="Age" multiple onChange="Ageachange()">';
                    foreach($Agedetails as $Agevalue)
{
    echo '<option value="'.$Agevalue['Age'].'">'.$Agevalue['Age'].'</option>';
}					
                  '</select>
				 
                </div>
              </li>';

    }
	public function SearchStudentAddressDetails()
    {	
$str="";	
		$StudentData = Input::all();

$str= $StudentData['str'];
$SchoolName= $StudentData['SchoolName'];
$age=explode(",",$str);
$Agedetails = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->whereIn('Age', $age)->where('SchoolName', $SchoolName)->get()->toArray();
foreach($Agedetails as $details)
{
$arrayvalue[]=$details['Street']."/".$details['ContactCity']."/".$details['ContactState'];
}
$address=array_values(array_unique(array_filter($arrayvalue)));
$address2=array_count_values(array_values(array_filter($arrayvalue)));
$loadoptiondata="value=''";
echo '<li>
                <div class="label-control">
                  <label for="r_no">Street/City/State</label>
                </div>
                <div class="input-control">
                  <select id="location" name="location[]" multiple>';
                    foreach($address as $address)
{
    echo '<option value="'.$address.'">'.$address.'('.$address2[$address].')</option>';
}					

               echo     '</select>
                </div>
              </li>
			  <script>
			  $(".filter").click(function(){
			  var Age = $("#Age").val();
			   var location = $("#location").val();
			   var SchoolName = $("#SchoolName").val();
               var movestudentid = $(".movestudentid").val();
                $.ajax({
                    type: "POST",
                    url : "filterchild",
                   data : { Age: Age, location: location, SchoolName: SchoolName, movestudentid: movestudentid},
                    success : function(data){
					
				$(".resultunassigned").html(data);
				
				if($(".triptypevalue").val()=="dropoff")
				{
				 $("input[name=pd_time][value=dropoff]").attr("checked","checked");
				} else {
				 $("input[name=pd_time][value=pickup]").attr("checked","checked");
				
				}
$(document).ready(function() {
var classname="lab-abs";

                       $("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.display").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false,
		 initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $("<select><option '.$loadoptiondata.'>Sort By Allocate Trip Type</option></select>").appendTo($(column.footer()).empty()).on( "change", function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );
                        column.search( val ? "^"+val+"$" : "", true, false ).draw();

                    } );
                column.data().unique().sort().each( function ( d, j ) {

                    select.append( "<option value="+d+">"+d+"</option>" )

                } );

            } );

        }
		
    });
	
	    $("<span ></span>").appendTo("#acavails");

	});
	$("thead th:first-child").addClass("lastth");
                    }
                });
              
			  });
			  </script>
			  ';					
}
public function FilterChild()
    {	
	$street=array();
	$state=array();
	$city=array();
		$StudentData = Input::all();

 $Age= $StudentData['Age'];
  $location= $StudentData['location'];
  for($i=0;$i<count($location);$i++)
  {
  $laca=explode("/",$location[$i]);
   $street[]=$laca[0];
    $city[]=$laca[1];
	 $state[]=$laca[2];
  }
$SchoolName= $StudentData['SchoolName'];
$movestudentid= $StudentData['movestudentid'];

if(!empty($movestudentid))
{

$dataid=explode(",",$movestudentid);
$studentdetails = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->whereNotIn('id',$dataid)->whereIn('Age', $Age)->whereIn('Street', $street)->whereIn('ContactCity', $city)->whereIn('ContactState', $state)->where('SchoolName', $SchoolName)->get()->toArray();
} else {
$studentdetails = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->whereIn('Age', $Age)->whereIn('Street', $street)->whereIn('ContactCity', $city)->whereIn('ContactState', $state)->where('SchoolName', $SchoolName)->get()->toArray();
}

$loadoptiondata="value=''";
echo '<div class="panel-row list-row">
             <div class="dash-content-head tabContaier">
             <h5>Un-Assigned Children</h5>
             <a href="javascript:;" class="btn-sb pass-btn showunassignmap"><span class="icon_btn icon_btn_map "></span>Show in Map</a>
             </div>
             <div class="panel-tab-row"> 
				<table id="example" class="display example tab" cellspacing="0" width="100%">
                 <tfoot class="tabl tab-abs"><tr>

	   <th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		 <th  id="acavails"> 

        </th>

        </tr></tfoot>
				<thead>
                  <tr>
                    <th> <input type="checkbox" id="selecctall"  style="background: none !important;">
                    </th>
                    <th> Age </th>
                    <th> Student Name </th>
                    <th> Pick up Address </th>                   
                    <th> Contact Person </th>
                    <th> Contact Number </th>
                    <th> Grade </th>
					<th> Pick up Type </th>
                    <th> Special Care(Note) </th>
                    <th> Allocate Trip </th>
                  </tr>
                </thead>
                <tbody>';
				
				foreach($studentdetails as $student){
				$Studentname=$student['PersonalFirstName']." ".$student["PersonalLastName"];
				if(!empty($student['House'])) { $address=$student['House'].','.$student['Street'].''.$student['ContactCity'].','.$student['ContactState']; } else { $address= $student['Apartment'].','.$student['Street'].','.$student['ContactCity'].','.$student['ContactState']; }
				$parentname=$student["GuardianFirstName"];
				if($student["TripType"]==2)
				{
				$trip="Two way";
				}else {
				if($student["TripType"]==1)
				{
				$trip="From Home";
				} else {
				$trip="From School";
				}				
				}
				if($student["Note"] !="")
				{
				$string=substr($student["Note"], 0, 50);
				$class="attandencelink";
				}else {
				$string="";
				$class="unwant";
				}
				$tripcom=$student["tripcom"];				
				if(!empty($tripcom))
				{				
				 $finaltripdata=$tripcom;
				
				} else {
				$finaltripdata="None";
				}
				
                      echo '<tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="'.$student["id"].'"></td> 
						<td>'.$student["Age"].'</td>
                        <td>'.$Studentname.'</td>
                        <td>'.$address.'</td>                        
                        <td>'.$parentname.'</td>
                        <td>'.$student["ContactMobile"].'</td>
                        <td>'.$student["StudentCourse"].'</td>
                        <td>'.$trip.'</td>
                        <td>'.$string.'</br><a style="color: #AE1828;" href="javascript:;" class="'.$class.'" id="'.$student["id"].'"  >Viewmore</a>
						<div id="attandence'.$student["id"].'" title="Basic dialog" style="display: none;">

	

  <div class="work-sch-contain">

        <div class="panel-heading">

        <h4 class="panel-title">Special Care(Note)</h4>

        </div>

        <div class="work-row work-row-head">

              <div class="work-right">
			  <p>'.$student["Note"].'</p>
			  </div></div></div></div>
						</td><td>'.$finaltripdata.'</td>
                      </tr>';
                      }
                    echo '</tbody>
                  </table>
             </div>                     
             <div class="bottom-tab-row">
                <div class="col-left">
                   <ul class="list-inline">
                       <li><input type="radio" class="p_up" name="pd_time" value="pickup" checked="checked"/><label for="p_up">Pick Up</label></li>
                       <li><input type="radio" class="p_up" name="pd_time" value="dropoff"  /><label for="d_off">Drop Off</label></li>
                   </ul>
				   <p class="checkdup" style="color:red;"></p>
                </div>
                <div class="col-right">
				
                    <button class="btn-mti movestudent">Move to Transport Allocation</button>
                </div>
             </div>
             </div>';
			 $Amstdeuntid=array();
			 $Pmstdeuntid=array();
			$getstudentAMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%AM%')->get()->toArray();
			
             foreach($getstudentAMexit as $AMstudent)
{
$Amstdeuntid[]=$AMstudent['id'];
}	
			$getstudentPMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%PM%')->get()->toArray();
			
             foreach($getstudentPMexit as $PMstudent)
{
$Pmstdeuntid[]=$PMstudent['id'];
}	
$combineAM=implode(",",$Amstdeuntid);	
$combinePM=implode(",",$Pmstdeuntid); 
if($combineAM=="")
{
$combineAM=0;
}
if($combinePM=="")
{
$combinePM=0;
}

			echo '<script>$(document).ready(function() {
    $("#selecctall").click(function(event) {  
        if(this.checked) { 
            $(".deletelist").each(function() { 
                this.checked = true;         
            });
        }else{
            $(".deletelist").each(function() { 
                this.checked = false;         
            });         
        }
    });
    $(".attandencelink").mouseover(function (e) {

                 var id=$(this).attr("id");

				 $("#attandence"+id).show();				

				  $("#attandence"+id).dialog();

				  $(".ui-draggable-handle").hide();

				   $(".ui-icon-closethick").hide();

				   $(".ui-dialog").addClass("poplink");

				   var parentOffset = $(this).parent().offset(); 

				   $(".poplink").css({"top": parentOffset.top-55});



				 }) .mouseout(function() {

				 $(".poplink").css({"top": "0px"});

				  $(".ui-dialog").removeClass("poplink");

				    $(".ui-dialog").removeClass("poplink2");

				$(".ui-icon-closethick").trigger("click");

				 });
				  $(".p_up").change(function(){
var value = $(this).val();
$(".triptypevalue").val(value);
$.ajax({
                    type: "POST",
                    url : "buslist",
                   data : { tripvalue: value},
                    success : function(data){
					//$(".busdata").hide();
					//$(".alterbusdata").show();
					$(".busdata").html(data);
			
				}
				});
if(value=="pickup")
{
$(".button_name").html("View Pick Up Route And Save");
$(".destination").val($(".SchoolAddress").val());
$(".start").val("");

}else {
$(".button_name").html("View Drop Off Route And Save");
$(".start").val($(".SchoolAddress").val());
$(".destination").val("");
}
}); 
});
$(".showunassignmap").click(function(){
var docnumbers = new Array();
$(".deletelist:checked").each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
var studentid=docnumbers.join();
$.ajax({
                    type: "POST",
                    url : "filterchildlocation",
                   data : { studentid: studentid},
                    success : function(data){
					$(".defaultmap").hide();
					$(".searchmap").show();
					$(".searchmap").html(data);
			
				}
				});
});
$(".movestudent").click(function(){
var docnumbers = new Array();
var docnotnumbers = new Array();
var savedata = new Array();
$(".deletelist:checked").each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".deletelist:not(:checked)").each(function() {
   var selectdoc=this.value;

   docnotnumbers.push(selectdoc);
});

var exitingdata=$(".movestudentid").val();
if(exitingdata!="")
{
var rescom = exitingdata.split(",");
docnumbers.push(rescom);
}
var studentid=docnumbers.join();
var otherstudentid=docnotnumbers.join();

var selectedtrip=$(".triptypevalue").val();
console.log(selectedtrip);
var checkdup="";
if(selectedtrip=="pickup")
{
var getstudentidexit="'.$combineAM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
}
console.log(getstudentidexit);
}
if(selectedtrip=="dropoff")
{
var getstudentidexit="'.$combinePM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
}
console.log(getstudentidexit);
}
if (checkdup =="") {
$(".movestudentid").val(studentid);
if (typeof docnumbers !== "undefined" && docnumbers.length > 0) {
$.ajax({
                    type: "POST",
                    url : "movechildtoorder",
                   data : { studentid: studentid,selectedtrip: selectedtrip},
                    success : function(data){
					$(".movestudentdatalist").html(data);
					if($(".triptypevalue").val()=="dropoff")
				{
				$(".start").val($(".SchoolAddress").val());
				$(".destination").val("");
				} else {				
				$(".start").val("");
				$(".destination").val($(".SchoolAddress").val());
				}
					
					if($("input[name=pd_time]:checked").val()=="pickup")
					{
                 $("input[name=pd_time][value=pickup]").attr("checked","checked");
					$(".button_name").html("View Pick Up Route And Save");
                     } else {
					 $("input[name=pd_time][value=dropoff]").attr("checked","checked");
                     $(".button_name").html("View Drop Off Route And Save");

                         }
			$("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.displaystudent").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false
    } );
	$("thead th:first-child").addClass("lastth");
				}
				});
				}
				
$.ajax({
                    type: "POST",
                    url : "removechildtoorder",
                   data : { otherstudentid: otherstudentid},
                    success : function(data){
					$(".resultunassigned").html(data);
					if($(".triptypevalue").val()=="dropoff")
				{
				 $("input[name=pd_time][value=dropoff]").attr("checked","checked");
				} else {
				 $("input[name=pd_time][value=pickup]").attr("checked","checked");
				
				}
		$(document).ready(function() {
var classname="lab-abs";

                       $("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.display").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false,
		 initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $("<select><option '.$loadoptiondata.'>Sort By Allocate Trip Type</option></select>").appendTo($(column.footer()).empty()).on( "change", function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );
                        column.search( val ? "^"+val+"$" : "", true, false ).draw();

                    } );
                column.data().unique().sort().each( function ( d, j ) {

                    select.append( "<option value="+d+">"+d+"</option>" )

                } );

            } );

        }
		
    });
	
	    $("<span ></span>").appendTo("#acavails");

	});
	$("thead th:first-child").addClass("lastth");
				}
				});
				
			} else {	
var ctrip=$(".triptypevalue").val();

if(ctrip=="pickup")
{				
				 $(".checkdup").html("Already added student have present in your Pickup List selection");
				 } else {
				 
				  $(".checkdup").html("Already added student have present in your Dropoff List selection");
				 }
				}	
});
</script>';
}
public function FilterChildLocation()
    {	
	
		$StudentData = Input::all();

  $studentid= $StudentData['studentid'];
$getstudent=explode(",",$studentid);
$studentdetails = StudentAdmissionModel::whereIn('id', $getstudent)->get()->toArray();
echo '<div class="col-one-two-margin"><script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
		    <div id="map" style="min-height: 235px;border: 1px solid #dddddd;
box-sizing: border-box;
padding: 1%;width: 100%;"></div>
			<script type="text/javascript">
    var locations = [';
	$msg="";
	$lastlat="";
	$lastlong="";
	foreach($studentdetails as $student)
	{
	
	$Studentname=$student['PersonalFirstName']." ".$student["PersonalLastName"];
				if(!empty($student['House'])) { $address=$student['House'].','.$student['Street'].''.$student['ContactCity'].','.$student['ContactState']; } else { $address= $student['Apartment'].','.$student['Street'].','.$student['ContactCity'].','.$student['ContactState']; }
				$parentname=$student["GuardianFirstName"]." ".$student["GuardianLastName"];
				if($lastlat==$student["lat"] &&$lastlong==$student["long"])
				{
				$msg.="<p>Student Name:".$Studentname."</p></br>";
				}else {
				$msg ="<p>Student Name:".$Studentname."</p>";
				}
				
	echo '["'.$msg.'", '.$student["lat"].', '.$student["long"].', '.$student["id"].'],';
	$lastlat=$student["lat"];
	$lastlong=$student["long"];
      }      
    echo'];

    var map = new google.maps.Map(document.getElementById("map"), {
      zoom: 3,      
	   center: new google.maps.LatLng(39.125658, -88.542495),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
	
    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, "click", (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
  </script></div>';
  }
  public function MoveChildtoOrder()
    {		
	$StudentData = Input::all();
  $studentid= $StudentData['studentid'];
    $selectedtrip= $StudentData['selectedtrip'];
$getstudent=explode(",",$studentid);
$studentdetails = StudentAdmissionModel::whereIn('id', $getstudent)->get()->toArray();
echo '<div class="panel-row list-row list-row-btn">   <!----- allote transport section start ------->
              <div class="dash-content-head tabContaier">
                <h5>Allocate to Transport</h5>
                <a href="#" class="btn-sb pass-btn viewmovedata"><span class="icon_btn icon_btn_map "></span>Show in Map</a> </div>
              <div class="panel-tab-row tabwith_scroll"> <!---------------- unassigned listing table start ---->
                  <table id="example" class="displaystudent" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th> <input type="checkbox" id="selecctmovedaatall" onchange="javascript:CheckedAll();">
                      </th>
                      <th> Remove </th>
                      <th> Age </th>
                      <th> Student Name </th>
                      <th> Address</th>
                      <th> Contact Person </th>
                      <th> Contact Number </th>
                      <th> Grade </th>
					  <th> Pick up Type </th>
                      <th> Special Care(Note) </th>
                    </tr>
                  </thead>
                  <tbody>';
                    foreach($studentdetails as $student){
				$Studentname=$student['PersonalFirstName']." ".$student["PersonalLastName"];
				if(!empty($student['House'])) { $address=$student['House'].','.$student['Street'].''.$student['ContactCity'].','.$student['ContactState']; } else { $address= $student['Apartment'].','.$student['Street'].','.$student['ContactCity'].','.$student['ContactState']; }
				$parentname=$student["GuardianFirstName"];
				if($student["TripType"]==2)
				{
				$trip="Two way";
				}else {
				if($student["TripType"]==1)
				{
				$trip="From Home";
				} else {
				$trip="From School";
				}				
				}
				if($student["Note"] !="")
				{
				$string=substr($student["Note"], 0, 50);
				$class="attandencelink";
				}else {
				$string="";
				$class="unwant";
				}
                      echo '<tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="movelist" value="'.$student["id"].'"></td>
                         <td> <a href="javascript:;" id="'.$student["id"].'" class="icon-link icon-link-remove removedata">Remove</a> </td>						
						<td>'.$student["Age"].'</td>
                        <td>'.$Studentname.'</td>
                        <td>'.$address.'</td>                        
                        <td>'.$parentname.'</td>
                        <td>'.$student["ContactMobile"].'</td>
                        <td>'.$student["StudentCourse"].'</td>
                        <td>'.$trip.'</td>
                        <td>'.$string.'</br><a style="color: #AE1828;" href="javascript:;" class="'.$class.'" id="'.$student["id"].'"  >Viewmore</a>
						<div id="attandence'.$student["id"].'" title="Basic dialog" style="display: none;">

	

  <div class="work-sch-contain">

        <div class="panel-heading">

        <h4 class="panel-title">Special Care(Note)</h4>

        </div>

        <div class="work-row work-row-head">

              <div class="work-right">
			  <p>'.$student["Note"].'</p>
			  </div></div></div></div>
						</td>
                      </tr>';
                      }
                  echo '</tbody>
                </table>
              </div>
              <!---------------- unassigned listing table end ------>
              <div class="bottom-tab-row">
                <div class="col-left">
				<div style="color:red;" class="errormsg"></div>
                  <ul class="list-inline buslist">
				  <div class="alterbusdata" style="display:none;"></div>
                    <li class="busdata">
                      <label for="p_up">Bus</label>';
					  $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
                      echo '<select class="bus" name="bus"><option value="">Select Bus</option>';
					  foreach($VehicleDetails as $Vehicle)
					  {		
$totalseats=0;
                      if($selectedtrip=="pickup")
{					  
$totalseats=$Vehicle["filledpickupseats"];
} else {
$totalseats=$Vehicle["filleddropoffseats"];
}
				if($totalseats < $Vehicle["NumberSeats"])
{						  
                         echo '<option value="'.$Vehicle["AutoID"].'">'.$Vehicle["VehicleCode"].'-('.$totalseats.'/'.$Vehicle["NumberSeats"].')</option>';
                        }}
                      echo '</select>
                    </li>
                    <li>
                      <label for="d_off">Start</label>
                      <input type="text" class="start" value=""/>
                    </li>
                    <li>
                      <label for="d_off">Destination</label>
                      <input type="text" class="destination" value=""/>
                    </li>
                  </ul>
                </div>
                <div class="col-right">
                  <a class="fancybox attandencelink" href="javascript:;"><button class="btn-mti btn-generate button_name">View And Save Route</button></a>
                </div>
              </div>
            </div>';
$Amstdeuntid=array();
			 $Pmstdeuntid=array();
			$getstudentAMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%AM%')->get()->toArray();
			
             foreach($getstudentAMexit as $AMstudent)
{
$Amstdeuntid[]=$AMstudent['id'];
}	
			$getstudentPMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%PM%')->get()->toArray();
			
             foreach($getstudentPMexit as $PMstudent)
{
$Pmstdeuntid[]=$PMstudent['id'];
}	
$combineAM=implode(",",$Amstdeuntid);	
$combinePM=implode(",",$Pmstdeuntid); 
if($combineAM=="")
{
$combineAM=0;
}
if($combinePM=="")
{
$combinePM=0;
}
			echo '<script>
			$(document).ready(function() {
			
			 $(".attandencelink").mouseover(function (e) {

                 var id=$(this).attr("id");

				 $("#attandence"+id).show();				

				  $("#attandence"+id).dialog();

				  $(".ui-draggable-handle").hide();

				   $(".ui-icon-closethick").hide();

				   $(".ui-dialog").addClass("poplink");

				   var parentOffset = $(this).parent().offset(); 

				   $(".poplink").css({"top": parentOffset.top-55});



				 }) .mouseout(function() {

				 $(".poplink").css({"top": "0px"});

				  $(".ui-dialog").removeClass("poplink");

				    $(".ui-dialog").removeClass("poplink2");

				$(".ui-icon-closethick").trigger("click");

				 });
    $("#selecctmovedaatall").click(function(event) {  
        if(this.checked) { 
            $(".movelist").each(function() { 
                this.checked = true;         
            });
        }else{
            $(".movelist").each(function() { 
                this.checked = false;         
            });         
        }
    });
    $(".button_name").click(function(){
	var selectedtrip=$(".triptypevalue").val();
console.log(selectedtrip);
var checkdup="";
var validerror="";
if(selectedtrip=="pickup")
{
var movestudent=$(".movestudentid").val();
var docnumbers = movestudent.split(",");
var getstudentidexit="'.$combineAM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
 validerror="Already added student have present in your Pickup List selection</br></br>";
}
console.log(getstudentidexit);
}
if(selectedtrip=="dropoff")
{
var movestudent=$(".movestudentid").val();
var docnumbers = movestudent.split(",");
var getstudentidexit="'.$combinePM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
validerror="Already added student have present in your Dropoff List selection</br></br>";
}
console.log(docnumbers);
console.log(getstudentidexit);
}
	var errormsg="";
	console.log(checkdup);
	if(checkdup !="")
	{
	var ctrip=$(".triptypevalue").val();

if(ctrip=="pickup")
{				
				 errormsg +="Already added student have present in your Pickup List selection</br></br>";
				 
				 } else {
				 
				  errormsg +="Already added student have present in your Dropoff List selection</br></br>";
				 }
	}
	if($(".movestudentid").val()=="")
	{
	errormsg +="your Allocate to Transport grid is empty</br></br>";
	}
	if($(".triptypevalue").val()=="")
	{
	errormsg +="Triptype is empty</br></br>";
	}
	if($(".bus").val()=="")
	{
	errormsg +="Please select any bus</br></br>";
	} else {
	var selectbusdata=$(".bus").find(":selected").text();
	var res = selectbusdata.split("-");	
	console.log(res);
	str = res[res.length - 1].replace(/[()]/g, "");
	console.log(str);
	var resdata = str.split("/");	
	console.log(resdata);
	console.log(resdata[0]);
	console.log(resdata[1]);
	var mstudentid=$(".movestudentid").val();
	var restudata = mstudentid.split(",");
	var lendata=restudata.length;
	console.log(lendata);
	var fres=parseInt(resdata[1])-parseInt(resdata[0]);
	if(fres < lendata)
	{
	errormsg +="This bus have less than seats compare with your needs</br></br>";
	}
	}
	if($(".start").val()=="")
	{
	errormsg +="Your start address is empty</br></br>";
	}
	if($(".destination").val()=="")
	{
	errormsg +="Your destination address is empty</br></br>";
	}
	if(errormsg=="")
	{
	$(".errormsg").html(errormsg);
$(".allocatestudentid").val($(".movestudentid").val());
$(".selectedpicktype").val($(".triptypevalue").val());
$(".selectedbusid").val($(".bus").val());
$(".startaddress").val($(".start").val());
$(".destinationaddress").val($(".destination").val());
$(".selectschoolid").val($("#SchoolName").val());
$(".generateroutemap").submit();
} else {
$(".errormsg").html(errormsg);
}
});
});
$(".viewmovedata").click(function(){
var docnumbers = new Array();
$(".movelist:checked").each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
var studentid=docnumbers.join();
$.ajax({
                    type: "POST",
                    url : "filterchildlocation",
                   data : { studentid: studentid},
                    success : function(data){
					$(".defaultmap").hide();
					$(".searchmap").show();
					$(".searchmap").html(data);
			
				}
				});
});
$(".removedata").click(function(){
var getid=$(this).attr("id");
var exitingdata=$(".movestudentid").val();
var arrdelete = exitingdata.split(",");
position = arrdelete.indexOf(getid);
arrdelete.splice(position, 1);
var studentid=arrdelete.join(",");
$(".movestudentid").val(studentid);
var selectedtrip=$(".triptypevalue").val();
if (typeof arrdelete !== "undefined" && arrdelete.length > 0) {

$.ajax({
                    type: "POST",
                    url : "movechildtoorder",
                   data : { studentid: studentid,selectedtrip: selectedtrip},
                    success : function(data){
					$(".movestudentdatalist").html(data);
					if($(".triptypevalue").val()=="dropoff")
				{
				$(".start").val($(".SchoolAddress").val());
				$(".destination").val("");
				} else {				
				$(".start").val("");
				$(".destination").val($(".SchoolAddress").val());
				}
			$("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.displaystudent").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false
    } );
	$("thead th:first-child").addClass("lastth");
				}
				});
				}else {
				$.ajax({
                    type: "POST",
                    url : "movechildtoorder",
                   data : { studentid: studentid,selectedtrip: selectedtrip},
                    success : function(data){
					$(".movestudentdatalist").html(data);
		if($(".triptypevalue").val()=="dropoff")
				{
				$(".start").val($(".SchoolAddress").val());
				$(".destination").val("");
				} else {				
				$(".start").val("");
				$(".destination").val($(".SchoolAddress").val());
				}
				}
				});
				
				}
				$(".filter").trigger("click");
});
			</script>';
}
public function RemoveChildtoOrder()
    {	
	
		$StudentData = Input::all();

  $studentid= $StudentData['otherstudentid'];
$getstudent=explode(",",$studentid);
$studentdetails = StudentAdmissionModel::whereIn('id', $getstudent)->get()->toArray();
$loadoptiondata="value=''";
echo '<div class="panel-row list-row">
             <div class="dash-content-head tabContaier">
             <h5>Un-Assigned Children</h5>
             <a href="javascript:;" class="btn-sb pass-btn showunassignmap"><span class="icon_btn icon_btn_map "></span>Show in Map</a>
             </div>
             <div class="panel-tab-row"> 
				<table id="example" class="display example tab" cellspacing="0" width="100%">
				 <tfoot class="tabl tab-abs"><tr>

	   <th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		 <th  id="acavails"> 

        </th>

        </tr></tfoot>
                <thead>
                  <tr>
                    <th> <input type="checkbox" id="selecctall"  style="background: none !important;">
                    </th>
                    <th> Age </th>
                    <th> Student Name </th>
                    <th> Pick up Address </th>                   
                    <th> Contact Person </th>
                    <th> Contact Number </th>
                    <th> Grade </th>
					<th> Pick up Type </th>
                    <th> Special Care(Note) </th>
                    <th> Allocate Trip </th>
                  </tr>
                </thead>
                <tbody>';
				
				foreach($studentdetails as $student){
				$Studentname=$student['PersonalFirstName']." ".$student["PersonalLastName"];
				if(!empty($student['House'])) { $address=$student['House'].','.$student['Street'].''.$student['ContactCity'].','.$student['ContactState']; } else { $address= $student['Apartment'].','.$student['Street'].','.$student['ContactCity'].','.$student['ContactState']; }
				$parentname=$student["GuardianFirstName"];
				if($student["TripType"]==2)
				{
				$trip="Two way";
				}else {
				if($student["TripType"]==1)
				{
				$trip="From Home";
				} else {
				$trip="From School";
				}				
				}
				if($student["Note"] !="")
				{
				$string=substr($student["Note"], 0, 50);
				$class="attandencelink";
				}else {
				$string="";
				$class="unwant";
				}
				$tripcom=$student["tripcom"];				
				if(!empty($tripcom))
				{				
				 $finaltripdata=$tripcom;				
				} else {
				$finaltripdata="None";
				}
                      echo '<tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="'.$student["id"].'"></td> 
						<td>'.$student["Age"].'</td>
                        <td>'.$Studentname.'</td>
                        <td>'.$address.'</td>                        
                        <td>'.$parentname.'</td>
                        <td>'.$student["ContactMobile"].'</td>
                        <td>'.$student["StudentCourse"].'</td>
                        <td>'.$trip.'</td>
                        <td>'.$string.'</br><a style="color: #AE1828;" href="javascript:;" class="'.$class.'" id="'.$student["id"].'"  >Viewmore</a>
						<div id="attandence'.$student["id"].'" title="Basic dialog" style="display: none;">

	

  <div class="work-sch-contain">

        <div class="panel-heading">

        <h4 class="panel-title">Special Care(Note)</h4>

        </div>

        <div class="work-row work-row-head">

              <div class="work-right">
			  <p>'.$student["Note"].'</p>
			  </div></div></div></div>
						</td> <td>'.$finaltripdata.'</td>
                      </tr>';
                      }
                    echo '</tbody>
                  </table>
             </div>                     
             <div class="bottom-tab-row">
                <div class="col-left">
                   <ul class="list-inline">
                       <li><input type="radio" class="p_up" name="pd_time" value="pickup" checked="checked"/><label for="p_up">Pick Up</label></li>
                       <li><input type="radio" class="p_up" name="pd_time" value="dropoff"  /><label for="d_off">Drop Off</label></li>
                   </ul>
				    <p class="checkdup" style="color:red;"></p>
                </div>
                <div class="col-right">
                    <button class="btn-mti movestudent">Move to Transport Allocation</button>
                </div>
             </div>
             </div>';
			 $Amstdeuntid=array();
			 $Pmstdeuntid=array();
			$getstudentAMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%AM%')->get()->toArray();
			
             foreach($getstudentAMexit as $AMstudent)
{
$Amstdeuntid[]=$AMstudent['id'];
}	
			$getstudentPMexit=StudentAdmissionModel::where('tripcom', 'LIKE', '%PM%')->get()->toArray();
			
             foreach($getstudentPMexit as $PMstudent)
{
$Pmstdeuntid[]=$PMstudent['id'];
}	
$combineAM=implode(",",$Amstdeuntid);	
$combinePM=implode(",",$Pmstdeuntid); 
if($combineAM=="")
{
$combineAM=0;
}
if($combinePM=="")
{
$combinePM=0;
}
			 echo '<script>$(document).ready(function() {
			  $(".attandencelink").mouseover(function (e) {

                 var id=$(this).attr("id");

				 $("#attandence"+id).show();				

				  $("#attandence"+id).dialog();

				  $(".ui-draggable-handle").hide();

				   $(".ui-icon-closethick").hide();

				   $(".ui-dialog").addClass("poplink");

				   var parentOffset = $(this).parent().offset(); 

				   $(".poplink").css({"top": parentOffset.top-55});



				 }) .mouseout(function() {

				 $(".poplink").css({"top": "0px"});

				  $(".ui-dialog").removeClass("poplink");

				    $(".ui-dialog").removeClass("poplink2");

				$(".ui-icon-closethick").trigger("click");

				 });
    $("#selecctall").click(function(event) {  
        if(this.checked) { 
            $(".deletelist").each(function() { 
                this.checked = true;         
            });
        }else{
            $(".deletelist").each(function() { 
                this.checked = false;         
            });         
        }
    });
 $(".p_up").change(function(){
var value = $(this).val();
$(".triptypevalue").val(value);
$.ajax({
                    type: "POST",
                    url : "buslist",
                   data : { tripvalue: value},
                    success : function(data){
					//$(".busdata").hide();
					//$(".alterbusdata").show();
					$(".busdata").html(data);
			
				}
				});
if(value=="pickup")
{
$(".button_name").html("View Pick Up Route And Save");
$(".destination").val($(".SchoolAddress").val());
$(".start").val("");
}else {
$(".button_name").html("View Drop Off Route And Save");
$(".start").val($(".SchoolAddress").val());
$(".destination").val("");
}
});
});
$(".showunassignmap").click(function(){
var docnumbers = new Array();
$(".deletelist:checked").each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
var studentid=docnumbers.join();
$.ajax({
                    type: "POST",
                    url : "filterchildlocation",
                   data : { studentid: studentid},
                    success : function(data){
					$(".defaultmap").hide();
					$(".searchmap").show();
					$(".searchmap").html(data);
			
				}
				});
});
$(".movestudent").click(function(){
var docnumbers = new Array();
var docnotnumbers = new Array();
$(".deletelist:checked").each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".deletelist:not(:checked)").each(function() {
   var selectdoc=this.value;

   docnotnumbers.push(selectdoc);
});
var exitingdata=$(".movestudentid").val();
if(exitingdata!="")
{
var rescom = exitingdata.split(",");
docnumbers.push(rescom);
}
var studentid=docnumbers.join();

var otherstudentid=docnotnumbers.join();

var selectedtrip=$(".triptypevalue").val();
var checkdup="";
if(selectedtrip=="pickup")
{
var getstudentidexit="'.$combineAM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
}
console.log(getstudentidexit);
}
if(selectedtrip=="dropoff")
{
var getstudentidexit="'.$combinePM.'";
var res = getstudentidexit.split(",");
var common = $.grep(docnumbers, function(element) {
    return $.inArray(element, res ) !== -1;
});
if(common.length !=0)
{
checkdup="duplicate";
}
console.log(getstudentidexit);
}
if(checkdup =="")
{
$(".movestudentid").val(studentid);
if (typeof docnumbers !== "undefined" && docnumbers.length > 0) {

$.ajax({
                    type: "POST",
                    url : "movechildtoorder",
                   data : { studentid: studentid,selectedtrip: selectedtrip},
                    success : function(data){
					$(".movestudentdatalist").html(data);
					if($(".triptypevalue").val()=="dropoff")
				{
				$(".start").val($(".SchoolAddress").val());
				$(".destination").val("");
				} else {				
				$(".start").val("");
				$(".destination").val($(".SchoolAddress").val());
				}
					if($("input[name=pd_time]:checked").val()=="pickup")
					{
                 $("input[name=pd_time][value=pickup]").attr("checked","checked");
					$(".button_name").html("View Pick Up Route And Save");
                     } else {
					 $("input[name=pd_time][value=dropoff]").attr("checked","checked");
                     $(".button_name").html("View Drop Off Route And Save");

                         }
			$("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.displaystudent").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false
    } );
	$("thead th:first-child").addClass("lastth");
				}
				});
				}
				$.ajax({
                    type: "POST",
                    url : "removechildtoorder",
                   data : { otherstudentid: otherstudentid},
                    success : function(data){
					$(".resultunassigned").html(data);
					if($(".triptypevalue").val()=="dropoff")
				{
				 $("input[name=pd_time][value=dropoff]").attr("checked","checked");
				} else {
				 $("input[name=pd_time][value=pickup]").attr("checked","checked");
				
				}
		$(document).ready(function() {
var classname="lab-abs";

                       $("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
    $("table.display").dataTable( {
        "scrollY": "190px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": false,
		 initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $("<select><option '.$loadoptiondata.'>Sort By Allocate Trip Type</option></select>").appendTo($(column.footer()).empty()).on( "change", function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );
                        column.search( val ? "^"+val+"$" : "", true, false ).draw();

                    } );
                column.data().unique().sort().each( function ( d, j ) {

                    select.append( "<option value="+d+">"+d+"</option>" )

                } );

            } );

        }
		
    });
	
	    $("<span ></span>").appendTo("#acavails");

	});
	$("thead th:first-child").addClass("lastth");
				}
				});
				} else {	
var ctrip=$(".triptypevalue").val();

if(ctrip=="pickup")
{				
				 $(".checkdup").html("Already added student have present in your Pickup List selection");
				 } else {
				 
				  $(".checkdup").html("Already added student have present in your Dropoff List selection");
				 }
				}

});
</script>';
}
public function GenerateRouteMap()
    {	   
		$Routedata = Input::all();
		
	Session::put('allocatestudentid', $Routedata['allocatestudentid']);
	Session::put('selectedpicktype', $Routedata['selectedpicktype']);
	Session::put('selectedbusid', $Routedata['selectedbusid']);
	Session::put('startaddress', $Routedata['startaddress']);
	Session::put('destinationaddress', $Routedata['destinationaddress']);
	Session::put('selectschoolid', $Routedata['schoolid']);
	return Redirect::to('generatemaproute');

		}
		public function SaveRoute()
    {	   
		$Routedata = Input::all();
		
		$studentid=$Routedata['Studentid'];
		$selectedpicktype=$Routedata['selectedpicktype'];
		$selectedbusid=$Routedata['selectedbusid'];
		$startaddress=$Routedata['startaddress'];
		$destinationaddress=$Routedata['destinationaddress'];
		$selectschoolid=$Routedata['selectschoolid'];
		$getroute=$Routedata['getroute'];
		$sortedtime=$Routedata['sortedtime'];
		$sorteddistance=$Routedata['sorteddistance'];
		$endtime=$Routedata['endtime'];
		$enddistance=$Routedata['enddistance'];
		$countstudent=count(explode("+",$studentid));
         $studentarray=explode("+",$studentid);		
		 $sortedtimearray=explode("+",$sortedtime);	
		 $sorteddistancearray=explode("+",$sorteddistance);	
		 $endtimearray=$endtime;	
		 $enddistancearray=$enddistance;	
		if($selectedpicktype=="pickup")
		{
		
		 $pickupname="AM";
		} else {
		
		$pickupname="PM";
		}
		
		
		$VehicleDetails = VehicleModel::where('AutoID', $selectedbusid)->get()->toArray();
		if($selectedpicktype=="pickup")
		{
		$lastdataseats=$VehicleDetails[0]['filledpickupseats'];
		$totalseats=$lastdataseats+$countstudent;
		$updatedata['filledpickupseats']=$countstudent;
		} else {
		$lastdataseats=$VehicleDetails[0]['filleddropoffseats'];
		$totalseats=$lastdataseats+$countstudent;
		$updatedata['filleddropoffseats']=$countstudent;
		}
		
		
		$updaterow = VehicleModel::where('AutoID', $selectedbusid)->update($updatedata);
		$getstudentidcount = TranportallocateModel::where('triptype', $pickupname)->where('busid', $selectedbusid)->where('schoolid', $selectschoolid)->count();
		if($getstudentidcount==0)
		{
		
		for($i=0;$i<$countstudent;$i++)
		{
		$storedata['studentid']=$studentarray[$i];
		$storedata['sequence']=$i+1;
		$storedata['time']=$sortedtimearray[$i];
		$storedata['distance']=$sorteddistancearray[$i];
		$storedata['triptype']=$pickupname;
		$storedata['busid']=$selectedbusid;
		$storedata['schoolid']=$selectschoolid;
		$storedata['route']=$getroute;
		$storedata['start']=$startaddress;
		$storedata['destination']=$destinationaddress;
		$storedata['destinationtime']=$endtime;
		$storedata['destinationdistance']=$enddistance;
		$storedata['buscompany']=Auth::user()->schoolid;
		$student = TranportallocateModel::create($storedata);
		}
		} else {
		$affectedRows = TranportallocateModel::where('triptype', $pickupname)->where('busid', $selectedbusid)->where('schoolid', $selectschoolid)->delete();
		for($i=0;$i<$countstudent;$i++)
		{
		$storedata['studentid']=$studentarray[$i];
		$storedata['sequence']=$i+1;
		$storedata['time']=$sortedtimearray[$i];
		$storedata['distance']=$sorteddistancearray[$i];
		$storedata['triptype']=$pickupname;
		$storedata['busid']=$selectedbusid;
		$storedata['schoolid']=$selectschoolid;
		$storedata['route']=$getroute;
		$storedata['start']=$startaddress;
		$storedata['destination']=$destinationaddress;
		$storedata['destinationtime']=$endtime;
		$storedata['destinationdistance']=$enddistance;
		$storedata['buscompany']=Auth::user()->schoolid;
		$student = TranportallocateModel::create($storedata);
		}
		}
		for($i=0;$i<$countstudent;$i++)
		{
		$getarray=array();	
		$temp=array();	
		$fdata=array();
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('id', $studentarray[$i])->with('schollresult')->with('batchresult')->get()->toArray();	
		$tripcom=$StudentAdmissionDetailsbyid[0]['tripcom'];
	
		if($tripcom=="")
		{
		$studentdata['tripcom']=$pickupname;
		} else {
	    $getarray[]=$pickupname;
		$temp=explode(",",$tripcom);
	      $result = array_merge($getarray, $temp);
		sort($result);
		$fdata=array_filter(array_unique($result));				
		$studentdata['tripcom']=implode(",",$fdata);
		}
		$affectedRows = StudentAdmissionModel::where('id', $studentarray[$i])->update($studentdata);
		}
		Session::forget('allocatestudentid');
	Session::forget('selectedpicktype');
	Session::forget('selectedbusid');
	Session::forget('startaddress');
	Session::forget('destinationaddress');
	Session::forget('selectschoolid');

		}
		public function BusList()
    {	   
		$Routedata = Input::all();
		
		
		echo '
                      <label for="p_up">Bus</label>';
					  $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
                      echo '<select class="bus" name="bus"><option value="">Select Bus</option>';
					  foreach($VehicleDetails as $Vehicle)
					  {		
$totalseats=0;
                      if($Routedata['tripvalue']=="pickup")
{					  
$totalseats=$Vehicle["filledpickupseats"];
} else {
$totalseats=$Vehicle["filleddropoffseats"];
}
				if($totalseats < $Vehicle["NumberSeats"])
{				
                         echo '<option value="'.$Vehicle["AutoID"].'">'.$Vehicle["VehicleCode"].'-('.$totalseats.'/'.$Vehicle["NumberSeats"].')</option>';
                        }}
                      echo '</select>
			
                    ';
		
		
		
		}
		public function SearchDriverList()
        {	   
		$schooldata = Input::all();
		$schoolid=$schooldata['SchoolName'];
		echo '<script>

$(document).ready(function(){



$("#example").dataTable();

});

</script>
             <div class="panel-row list-row">
             <div class="dash-content-head tabContaier">
             <h5>Bus List</h5>
             </div>
             <div class="panel-tab-row"> <!---------------- unassigned listing table start ------>
				<table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th width="20"> </th>
                    <th> Bus Code</th>
					<th> Pickup Seats</th>
					<th> Your School Pickup Students</th>
					<th> Dropoff Seats</th>	
                    <th> Your School Dropoff Students</th>					
                    <th> Driver Name </th>
                  </tr>
                </thead>
                <tbody>';
				$transportdetails = TranportallocateModel::where('schoolid', $schoolid)->groupBy('busid')->get()->toArray();
				foreach($transportdetails as $transport)
				{
				$vid= $transport['busid'];
				$driveridcount = TimingModel::where('VehicleCode', $vid)->count();
				if($driveridcount !=0)
				{
				$vehicledetails = VehicleModel::where('AutoID', $vid)->get()->toArray();
				$driverid = TimingModel::where('VehicleCode', $vid)->get()->toArray();
				$getdriver=$driverid[0]['DriverName'];
				$drivername = DriverModel::where('AutoID', $getdriver)->get()->toArray();
				$getdropoffstudent = TranportallocateModel::where('schoolid', $schoolid)->where('busid', $vid)->where('triptype', 'PM')->get()->toArray();				
				$getpickupstudent = TranportallocateModel::where('schoolid', $schoolid)->where('busid', $vid)->where('triptype', 'AM')->get()->toArray();
				
				if(count($getpickupstudent)==0)
				{
				$pstudent=0;
				}else{
				foreach($getpickupstudent as $getpickup)
				{
				 $getps[]=$getpickup['studentid'];
				}
				$pstudent=count($getps);
				}
				if(count($getdropoffstudent)==0)
				{
				$dstudent=0;
				}else{
				foreach($getdropoffstudent as $getdropoff)
				{
				 $getds[]=$getdropoff['studentid'];
				}
				$dstudent=count($getds);
				
				}
				if(!empty($vehicledetails) && !empty($driverid) && !empty($drivername) )
				{
				  
				
                      echo '<tr>
                        <td><input  name="chkSelectRow" type="radio" class="buslist" value="'.$transport["busid"].'"></td>              
                        <td>'.$vehicledetails[0]["VehicleCode"].'</td>
						 <td>('.$vehicledetails[0]["filledpickupseats"].'/'.$vehicledetails[0]["NumberSeats"].')</td>
						  <td>'.$pstudent.'</td>
						 <td>('.$vehicledetails[0]["filleddropoffseats"].'/'.$vehicledetails[0]["NumberSeats"].')</td>
						  <td>'.$dstudent.'</td>
                        <td> '.$drivername[0]["DriverName"].' </td>
                      </tr>';
					  }
					  }
					  }
                     
                    echo '</tbody>
                  </table>
             </div>                      <!---------------- unassigned listing table end ------>
             <div class="bottom-tab-row">
			 <p class="error" style="display:none;color:red;margin-bottom: 11px;">Select any bus in buslist</p>
                <div class="col-left">
                    <button class="btn-mti  showpickup">Show Pick up list</button>
                    <button class="btn-mti showdropoff">Show Drop off list</button>
                </div>
             </div>
             </div>
			 <script>
			 $(".showpickup").click(function(){
			 var value="pickup";
			 var getid="";
			 var getid=$("input[name=chkSelectRow]:checked").val();			
			 if(typeof $("input[name=chkSelectRow]:checked").val() != "undefined")
			 {			 
			 $(".error").hide();
			 $(".triptypedata").val(value);
			  $(".busiddata").val(getid);
			   $(".schooliddata").val($("#SchoolName").val());
			 $.ajax({
                    type: "POST",
                    url : "viewtriplist",
                   data : { tripvalue: value,getid: getid},
                    success : function(data){
					
					$(".result1").html(data);
			         $(".showpickup").addClass("btn-mti-active");
					 $(".showdropoff").removeClass("btn-mti-active");
				}
				});
				} else {
				
				$(".error").show();
				
				
				}
			 });
			 $(".showdropoff").click(function(){
			 var value="dropoff";
			 var getid=$("input[name=chkSelectRow]:checked").val();
			  if(typeof $("input[name=chkSelectRow]:checked").val() != "undefined")
			 {	
			 $(".triptypedata").val(value);
			 $(".schooliddata").val($("#SchoolName").val());
			 $(".busiddata").val(getid);
			 $.ajax({
                    type: "POST",
                    url : "viewtriplist",
                   data : { tripvalue: value,getid: getid},
                    success : function(data){
					
					$(".result1").html(data);
			 $(".showdropoff").addClass("btn-mti-active");
			  $(".showpickup").removeClass("btn-mti-active");
				}
				});
				} else {
				
				$(".error").show();
				
				
				}
			 });
			 </script>
			 ';
		
		
		}
		public function ViewTripList()
        {	
       $route="";		
		$schooldata = Input::all();
		$tripvalue=$schooldata['tripvalue'];
		$getid=$schooldata['getid'];
		if($tripvalue=="pickup")
		{
		$dataval="AM";
		$title="Pick Up";
		} else {
		$dataval="PM";
		$title="Drop Off";
		}
		$transportdetails = TranportallocateModel::where('busid', $getid)->where('triptype', $dataval)->get()->toArray();
		$count = TranportallocateModel::where('busid', $getid)->where('triptype', $dataval)->count();
		
		 if($count==0)
		 {
		 $class="unwant";
		 $route="";
		 $idval="";
		 $emptyclass="";
		 } else {
		 $class="";
		  $emptyclass="unwant";
		  foreach($transportdetails as $transport)
		  {
		 $getstudentid=$transport['studentid'];
		 $idval=$transport['id'];		 
		 $studentdetails = StudentAdmissionModel::where('id', $getstudentid)->get()->toArray();	
foreach($studentdetails as $studentdatavalue)
{
$locationdataarray[]=$studentdatavalue['lat'].",".$studentdatavalue['long'];
$locationaddress[]=$studentdatavalue['Street'].",".$studentdatavalue['ContactCity'].",".$studentdatavalue['ContactState'];
}
$startaddress=$transport['start'];
$destinationaddress=$transport['destination'];
$checkfinalarray=implode("/",$locationdataarray);
$route=$transport['route'];
}
echo '

<script type="text/javascript">

  var directionDisplay;
  var directionsService = new google.maps.DirectionsService();
  var map;


 
    directionsDisplay = new google.maps.DirectionsRenderer();
    var chicago = new google.maps.LatLng(41.850033, -87.6500523);
    var myOptions = {
      zoom: 6,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: chicago
    }
    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    directionsDisplay.setMap(map);
    calcRoute();

  
  function calcRoute() {
   var waypts = [];
  var check="'.$checkfinalarray.'";
  console.log(check);
var checkboxArray = check.split("/");
console.log(checkboxArray);
   for (var i = 0; i < checkboxArray.length; i++) { 
console.log(checkboxArray[i]);   
      waypts.push({
          location:checkboxArray[i],
          stopover:true});
   
  }
    var request = {
        origin: "'.$startaddress.'",
        destination: "'.$destinationaddress.'",
         waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: google.maps.DirectionsTravelMode.DRIVING
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(response);
        var route = response.routes[0];
       // var summaryPanel = document.getElementById("directions_panel");
	   var summaryPanel ="";
        summaryPanel.innerHTML = "";
        // For each route, display summary information.
        for (var i = 0; i < route.legs.length; i++) {
          var routeSegment = i + 1;
		  if(routeSegment%2==0)
		  {
		  var classname="route-box even";
		  } else {
		  var classname="route-box";
		  }
		   
          
        }
      } else {
        alert("directions response "+status);
      }
    });
  }
  
</script>';
		 }
		
		echo '<div class="panel-row list-row list-row-btn">   <!----- allote transport section start ------->
              <div class="dash-content-head tabContaier tabContaier-tab">
            <div class="col-left">
            <ul>    <!------------- tab button section start ------------>
                <li><a class="active" href="#tab1">Route View</a></li>
            </ul>   <!------------- tab button section close ------------>
            </div>
            <div class="col-right '.$class.'">
            <a href="javascript:;" class="btn-sb pass-btn addstudent" id="'.$idval.'"><span class="icon_btn icon_plus"></span>Add Student</a>
            </div>
            </div>
            <div class="tabDetails '.$class.'">
              <div id="tab1" class="tabContents" style="display: block;">
                  <div class="map_view">
                  <div class="col-left route-map-section  '.$class.'" id="map_canvas">
				  
</div>
<div class="map-route-list-section col-right  '.$class.'">
<div class="dash-content-head">
<h5>Bus Route List('.$title.')</h5>
</div>
'.$route.'
</div> 
                  </div>
              </div>
              
              </div>
			   <div class=" '.$emptyclass.'">
              <div id="tab1" class="tabContents" style="display: block;">
                  <div class="map_view">
				  <h5>No Results Found</h5>
                  
                  </div>
              </div>
              
              </div>
              <!---------------- unassigned listing table end ------>
            </div>
			<script>
			$(".addstudent").click(function(){
			var idval=$(this).attr("id");
			$(".updateid").val(idval);
			$(".generateroutemap").submit();
			});
			$(".removefrombus").click(function(){
			var idval=$(this).attr("id");
			$(".requeststudentid").val(idval);
			$(".updateid").val($(".addstudent").attr("id"));
			$(".removestudentdatadetails").submit();
			});
			</script>
			';
		}
		public function AddStudentdataDetails()
    {	   
		$Routedata = Input::all();
		
	Session::put('updateid', $Routedata['updateid']);
	Session::put('triptypedata', $Routedata['triptypedata']);
	Session::put('busiddata', $Routedata['busiddata']);
	Session::put('schooliddata', $Routedata['schooliddata']);
	Session::put('actiontype', "add");
	return Redirect::to('addstudenttobus');

		}
		public function ReGenerateMapRoute()
    {	   
		$updateid = Session::get('updateid');
$selectedpicktype = Session::get('triptypedata');
$selectedbusid = Session::get('busiddata');
$selectschoolid = Session::get('schooliddata');
$requeststudentid = Session::get('requeststudentid');
if($selectedpicktype=="pickup")
		{
		$dataval="AM";
		
		} else {
		$dataval="PM";
		
		}
		$transportdetails = TranportallocateModel::where('busid', $selectedbusid)->where('triptype', $dataval)->where('schoolid', $selectschoolid)->get()->toArray();
		foreach($transportdetails as $transport)
		{
$getstudent[]=$transport['studentid'];	
$startaddress=$transport['start'];
$destinationaddress=$transport['destination'];	

}
$combine=implode(",",$getstudent);
$allocatestudentid=$combine.",".$requeststudentid;
$lastcombine=explode(",",$allocatestudentid);
$studentdetails = StudentAdmissionModel::whereIn('id', $lastcombine)->get()->toArray();	
foreach($studentdetails as $studentdatavalue)
{
$locationdataarray[]=$studentdatavalue['lat'].",".$studentdatavalue['long'];

$locationaddress[]=$studentdatavalue['Street'].",".$studentdatavalue['ContactCity'].",".$studentdatavalue['ContactState'];
$locationdatastudentarray[]=$studentdatavalue['id'];
$locationstudentnameaddress[]=$studentdatavalue['PersonalFirstName'].",".$studentdatavalue['PersonalLastName'];
}

        return View::make('studentadmission/regeneratemaproute')->with('allocatestudentid', $allocatestudentid)->with('selectedpicktype', $selectedpicktype)->with('startaddress', $startaddress)->with('destinationaddress', $destinationaddress)->with('selectedbusid', $selectedbusid)->with('locationdataarray', $locationdataarray)->with('selectschoolid', $selectschoolid)->with('locationaddress', $locationaddress)->with('updateid', $updateid)->with('locationdatastudentarray', $locationdatastudentarray)->with('locationstudentnameaddress', $locationstudentnameaddress);
    }
	public function PostAddStudentData()
    {	   
		$Routedata = Input::all();
		//print_r($Routedata);
	
		$error="";
		if(empty($Routedata['studentname']))
		{
	$error .="Select Student Name</br>";
		}
		
		if(empty($Routedata['grade']))
		{
		 $error .="Select Student Grade</br>";
		}
		if(empty($Routedata['age']))
		{
		 $error .="Select Student Age</br>";
		}
	
		if(empty($Routedata['addstudent']))
		{
		 $error .="Select add to bus option</br>";
		}
$sbusid=Session::get('busiddata');	
$selectedtrip = Session::get('triptypedata');
$VehicleDetails = VehicleModel::where('AutoID', $sbusid)->get()->toArray();
$totalseats=0;
                      if($selectedtrip=="pickup")
{					  
$totalseats=$VehicleDetails[0]["filledpickupseats"]+1;
} else {
$totalseats=$VehicleDetails[0]["filleddropoffseats"]+1;
}
if($totalseats > $VehicleDetails[0]["NumberSeats"])
{	
 $error .="This bus haven't seats.</br>";
}					
		if(empty($error))
		{
	Session::put('requeststudentid', $Routedata['studentname']);
	
	return Redirect::to('regeneratemaproute');
	} else {
	return Redirect::to('addstudenttobus')->with('Message', $error)->withInput();
	}

		}
			public function UpdateRoute()
    {	   
		$Routedata = Input::all();
			
		$studentid=$Routedata['Studentid'];
		$selectedpicktype=$Routedata['selectedpicktype'];
		$selectedbusid=$Routedata['selectedbusid'];
		$startaddress=$Routedata['startaddress'];
		$destinationaddress=$Routedata['destinationaddress'];
		$selectschoolid=$Routedata['selectschoolid'];
		$getroute=$Routedata['getroute'];
		$updateid=$Routedata['updateid'];
		$sortedtime=$Routedata['sortedtime'];
		$sorteddistance=$Routedata['sorteddistance'];
		$endtime=$Routedata['endtime'];
		$enddistance=$Routedata['enddistance'];
		$countstudent=count(array_filter(explode("+",$studentid)));
		
         $studentarray=explode("+",$studentid);	
 		$sortedtimearray=explode("+",$sortedtime);	
		 $sorteddistancearray=explode("+",$sorteddistance);	
		 $endtimearray=$endtime;	
		 $enddistancearray=$enddistance;	
		if($selectedpicktype=="pickup")
		{
		
		 $pickupname="AM";
		} else {
		
		$pickupname="PM";
		}
		
		
		$VehicleDetails = VehicleModel::where('AutoID', $selectedbusid)->get()->toArray();
		if($selectedpicktype=="pickup")
		{
		$lastdataseats=$VehicleDetails[0]['filledpickupseats'];
		$totalseats=$countstudent;
		$updatedata['filledpickupseats']=$countstudent;
		} else {
		$lastdataseats=$VehicleDetails[0]['filleddropoffseats'];
		$totalseats=$countstudent;
		$updatedata['filleddropoffseats']=$countstudent;
		}		
		$updaterow = VehicleModel::where('AutoID', $selectedbusid)->update($updatedata);
		$affectedRows = TranportallocateModel::where('triptype', $pickupname)->where('busid', $selectedbusid)->where('schoolid', $selectschoolid)->delete();
		for($i=0;$i<$countstudent;$i++)
		{
		$storedata['studentid']=$studentarray[$i];
		$storedata['sequence']=$i+1;
		$storedata['time']=$sortedtimearray[$i];
		$storedata['distance']=$sorteddistancearray[$i];
		$storedata['triptype']=$pickupname;
		$storedata['busid']=$selectedbusid;
		$storedata['schoolid']=$selectschoolid;
		$storedata['route']=$getroute;
		$storedata['start']=$startaddress;
		$storedata['destination']=$destinationaddress;
		$storedata['destinationtime']=$endtime;
		$storedata['destinationdistance']=$enddistance;
		$storedata['buscompany']=Auth::user()->schoolid;
		$student = TranportallocateModel::create($storedata);
		}
		
	
if($countstudent !=0)	
{	
		for($i=0;$i<$countstudent;$i++)
		{
		$getarray=array();	
		$temp=array();	
		$fdata=array();
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('id', $studentarray[$i])->with('schollresult')->with('batchresult')->get()->toArray();	
		$tripcom=$StudentAdmissionDetailsbyid[0]['tripcom'];
	
		if($tripcom=="")
		{
		$studentdata['tripcom']=$pickupname;
		} else {
	    $getarray[]=$pickupname;
		$temp=explode(",",$tripcom);
	      $result = array_merge($getarray, $temp);
		sort($result);
		$fdata=array_filter(array_unique($result));				
		$studentdata['tripcom']=implode(",",$fdata);
		}
		$affectedRows = StudentAdmissionModel::where('id', $studentarray[$i])->update($studentdata);
		}
		}
		
		Session::forget('allocatestudentid');
	Session::forget('selectedpicktype');
	Session::forget('selectedbusid');
	Session::forget('startaddress');
	Session::forget('destinationaddress');
	Session::forget('selectschoolid');
	Session::forget('updateid');
	Session::forget('triptypedata');
	Session::forget('busiddata');
	Session::forget('schooliddata');
	Session::forget('requeststudentid');
	Session::forget('actiontype');

		}
			public function RemoveStudentDataDetails()
    {	   
		$Routedata = Input::all();
		
	Session::put('updateid', $Routedata['updateid']);
	Session::put('triptypedata', $Routedata['triptypedata']);
	Session::put('busiddata', $Routedata['busiddata']);
	Session::put('schooliddata', $Routedata['schooliddata']);
	Session::put('requeststudentid', $Routedata['requeststudentid']);
	Session::put('actiontype', "remove");
	return Redirect::to('removeregeneratemaproute');

		}
		public function RemoveReGenerateMapRoute()
    {	   
		$updateid = Session::get('updateid');
$selectedpicktype = Session::get('triptypedata');
$selectedbusid = Session::get('busiddata');
$selectschoolid = Session::get('schooliddata');
$requeststudentid = Session::get('requeststudentid');
if($selectedpicktype=="pickup")
		{
		$dataval="AM";
		
		} else {
		$dataval="PM";
		
		}
		$transportdetails = TranportallocateModel::where('busid', $selectedbusid)->where('triptype', $dataval)->where('schoolid', $selectschoolid)->get()->toArray();
foreach($transportdetails as $transport)
		{
$getstudent[]=$transport['studentid'];	
$startaddress=$transport['start'];
$destinationaddress=$transport['destination'];	

}
$key = array_search($requeststudentid, $getstudent);
unset($getstudent[$key]);
$allocatestudentid=implode(",",$getstudent);
$lastcombine=explode(",",$allocatestudentid);
$count=count($lastcombine);
if($count !=0)
{
$studentdetails = StudentAdmissionModel::whereIn('id', $lastcombine)->get()->toArray();	
foreach($studentdetails as $studentdatavalue)
{
$locationdataarray[]=$studentdatavalue['lat'].",".$studentdatavalue['long'];
$locationaddress[]=$studentdatavalue['Street'].",".$studentdatavalue['ContactCity'].",".$studentdatavalue['ContactState'];
$locationdatastudentarray[]=$studentdatavalue['id'];
$locationstudentnameaddress[]=$studentdatavalue['PersonalFirstName'].",".$studentdatavalue['PersonalLastName'];
}
} else {
$locationdataarray=array();
$locationaddress=array();
$locationdatastudentarray=array();
$locationstudentnameaddress=array();
}


        return View::make('studentadmission/regeneratemaproute')->with('allocatestudentid', $allocatestudentid)->with('selectedpicktype', $selectedpicktype)->with('startaddress', $startaddress)->with('destinationaddress', $destinationaddress)->with('selectedbusid', $selectedbusid)->with('locationdataarray', $locationdataarray)->with('selectschoolid', $selectschoolid)->with('locationaddress', $locationaddress)->with('updateid', $updateid)->with('locationdatastudentarray', $locationdatastudentarray)->with('locationstudentnameaddress', $locationstudentnameaddress);
    }
}