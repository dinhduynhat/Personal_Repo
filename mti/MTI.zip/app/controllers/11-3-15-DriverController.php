<?php

class DriverController extends BaseController
{
    
    public function DriverLayout()
    {
	
	        $licenceDetails = LisenceModel::get()->toArray();
			   $DriverDetails = DriverModel::all()->toArray();
      $licensetypeDetails = LisenceModel::lists('licensetype', 'licensetype');
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails)->with('licensetypeDetails', $licensetypeDetails)->with('licenceDetails', $licenceDetails);
    
    }
    
    public function DriverProcess()
    {
	
        $messagedata="";
        $DriverData = Input::all();

		$lisencetype=implode(",",$DriverData['LisenceType']);
		$LicenseNumber=implode(",",$DriverData['LicenseNumber']);
		$LicenseExpiry=implode(",",$DriverData['LicenseExpiry']);
		if(count($DriverData['LisenceType']) !=count(array_filter($DriverData['LicenseNumber'])) && count($DriverData['LisenceType'])!= count(array_filter($DriverData['LicenseExpiry'])))
		{		
		$messagedata.="LicenseNumber && LicenseNumber is required</br>";	
		
		}else{
		$messagedata.="";		 
		}
		if(count($DriverData['LisenceType']) != count(array_unique($DriverData['LisenceType'])))
		{		
		$messagedata.="LisenceType have duplicate entry</br>";		 
		}else{
		$messagedata .="";		 
		}
		// if($messagedata !="")
		// {
			// return Redirect::to('driver')->withInput()->with('Messagedata', $messagedata);
		// }
		unset($DriverData['LisenceType']);
		unset($DriverData['LicenseNumber']);
		unset($DriverData['LicenseExpiry']);

        $validation = Validator::make($DriverData, DriverModel::$rules);       
       if ($validation->passes() && $messagedata =="") 
        {
		$DriverData['LisenceType']=$lisencetype;
		$DriverData['LicenseNumber']=$LicenseNumber;
		$DriverData['LicenseExpiry']=$LicenseExpiry;
            DriverModel::create($DriverData);
            return Redirect::to('driver')->with('Message', 'Vehicle Details Saved Succesfully');
        } else 
        {
		return Redirect::to('driver')->withInput()->withErrors($validation->messages())->with('Messagedata', $messagedata);
        }
    }
	public function DriverEdit($data=NULL)
    {
	$licenceDetails = LisenceModel::get()->toArray();
	    $editvehicle=$data;
		$DriverDetailsbyid = DriverModel::where('AutoID', $editvehicle)->get()->toArray();
         $DriverDetails = DriverModel::all()->toArray();
      $licensetypeDetails = LisenceModel::lists('licensetype', 'licensetype');
        return View::make('driver/driverupdate')->with('DriverDetails', $DriverDetails)->with('DriverDetailsbyid', $DriverDetailsbyid)->with('licensetypeDetails', $licensetypeDetails)->with('licenceDetails', $licenceDetails);
	}
	public function DriverupdateProcess($data=NULL)
    {
	$messagedata="";
	$update = array(       
		'DriverName' =>array('required','Regex:/^[A-Za-z0-9\-! ,]+$/'),
        'Age' => 'required|integer', 
        'Address' => 'required',         
        'DateOfBirth' => 'required',       
        'DriverPhoto' => 'image|max:2000',
        'LicensePhoto' => 'image|max:2000',		
		'Mobile' => array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),        );
        $DriverData = Input::except(array('_token','student-listing-table_length'));
		
		$lisencetype=implode(",",$DriverData['LisenceType']);
		$LicenseNumber=implode(",",$DriverData['LicenseNumber']);
		$LicenseExpiry=implode(",",$DriverData['LicenseExpiry']);
	
		if(count($DriverData['LisenceType']) !=count(array_filter($DriverData['LicenseNumber'])) && count($DriverData['LisenceType'])!= count(array_filter($DriverData['LicenseExpiry'])))
		{		
		$messagedata.="LicenseNumber && LicenseNumber is required</br>";	
		
		}else{
		$messagedata.="";		 
		}
		
	
		if(count($DriverData['LisenceType']) != count(array_unique($DriverData['LisenceType'])))
		{		
		$messagedata.="LisenceType have duplicate entry</br>";		 
		}else{
		$messagedata .="";		 
		}
		
		if($messagedata !="")
		{
		
			return Redirect::to('driveredit/'.$data)->with('Messagedata', $messagedata);
		}
		unset($DriverData['LisenceType']);
		unset($DriverData['LicenseNumber']);
		unset($DriverData['LicenseExpiry']);
		
	  $validation  = Validator::make($DriverData, $update);        
        if ($validation->passes()) 
        {
		$DriverData['LisenceType']=$lisencetype;
		$DriverData['LicenseNumber']=$LicenseNumber;
		$DriverData['LicenseExpiry']=$LicenseExpiry;
		$DriverData=array_filter($DriverData);
		if(!empty($DriverData['DriverPhoto']))
	{
	Input::file('DriverPhoto')->move('assets/uploads/driver/', $data . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalName());
	$DriverPhoto=$data . '-DriverPhoto.' . Input::file('DriverPhoto')->getClientOriginalName();
	unset($DriverData['DriverPhoto']);
	$DriverData['DriverPhoto']=$DriverPhoto;
	}
	if(!empty($DriverData['LicensePhoto']))
	{
	Input::file('LicensePhoto')->move('assets/uploads/driver/', $data . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalName());
	$LicensePhoto=$data . '-LicensePhoto.' . Input::file('LicensePhoto')->getClientOriginalName();
	unset($DriverData['LicensePhoto']);
	$DriverData['LicensePhoto']=$LicensePhoto;
}
		   $affectedRows = DriverModel::where('AutoID', $data)->update($DriverData);
            //VehicleModel::create($VehicleData);
            return Redirect::to('driveredit/'.$data)->with('Message', 'Driver Details Update Succesfully');
        } else 
        {
            return Redirect::to('driveredit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function driverdelete($data=NULL)
    {
	    $editvehicle=$data;
			$vehiclebyid = DriverModel::where('AutoID', $editvehicle)->get()->toArray();
		$DriverName=$vehiclebyid[0]['DriverName'];
	 $count = TimingModel::where('DriverName', '=', $DriverName)->count();

	if($count==0)
	{
		$affectedRows = DriverModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('driver')->with('Message', 'Driver Details Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	       $DriverDetails = DriverModel::all()->toArray();
      $licensetypeDetails = LisenceModel::lists('licensetype', 'licensetype');
	   $licenceDetails = LisenceModel::get()->toArray();
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails)->with('deleteerror', $deleteerror)->with('licensetypeDetails', $licensetypeDetails)->with('licenceDetails', $licenceDetails);	   
        
	   }
	}
	public function DriverDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['driverdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$vehiclebyid = DriverModel::where('AutoID', $data[$i])->get()->toArray();
		$DriverName=$vehiclebyid[0]['DriverName'];
	 $count[] = TimingModel::where('DriverName', '=', $DriverName)->count();	
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = DriverModel::where('AutoID', $data[$i])->delete();
     
	}
	  return Redirect::to('driver')->with('Message', 'Driver Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	   $DriverDetails = DriverModel::all()->toArray();
      $licensetypeDetails = LisenceModel::lists('licensetype', 'licensetype');
	   $licenceDetails = LisenceModel::get()->toArray();
        return View::make('driver/driver')->with('DriverDetails', $DriverDetails)->with('deleteerror', $deleteerror)->with('licensetypeDetails', $licensetypeDetails)->with('licenceDetails', $licenceDetails);
	}
	}


	public function DriversOnMap()
    {
    	
    	if(Auth::user()->usertype==1)
    	{
    	$DriverDetails = VehicleLocation::all()->toArray();	
    	}
    	if(Auth::user()->usertype==2)
    	{
		#$DriverDetails = VehicleLocation::all()->toArray();	
    	$DriverDetails = TranportallocateModel::where('schoolid', Auth::user()->schoolid)->first();
    	} 

    	
        return View::make('settings/mapdriver')->with('DriverDetails', $DriverDetails);
    }
}