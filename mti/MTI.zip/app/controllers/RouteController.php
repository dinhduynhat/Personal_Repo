<?php

class RouteController extends BaseController
{
    
    public function RouteLayout()
    {
        //$VehicleDetails = VehicleModel::all();
		$RouteDetails = RouteModel::all()->toArray();
        $VehicleDetails = VehicleModel::lists('VehicleCode', 'VehicleCode');
        return View::make('route/route')->with('VehicleDetails', $VehicleDetails)->with('RouteDetails', $RouteDetails);
    }
    
    public function RouteProcess()
    {
        
        $RouteData  = Input::all();
        $validation = Validator::make($RouteData, RouteModel::$rules);
        
        if ($validation->passes()) 
        {
            RouteModel::create($RouteData);
            return Redirect::to('route')->with('Message', 'Route Details Saved Succesfully');
        } else 
        {
            return Redirect::to('route')->withInput()->withErrors($validation->messages());
            $messages = $validation->messages();
        }
    }
	public function RouteEdit($data=NULL)
    {
	    $editvehicle=$data;
		$RouteDetailsbyid = RouteModel::where('AutoID', $editvehicle)->get()->toArray();
        $RouteDetails = RouteModel::all()->toArray();
        $VehicleDetails = VehicleModel::lists('VehicleCode', 'VehicleCode');
        return View::make('route/routeupdate')->with('VehicleDetails', $VehicleDetails)->with('RouteDetails', $RouteDetails)->with('RouteDetailsbyid', $RouteDetailsbyid);
	}
	 public function RouteupdateProcess($data=NULL)
    {
        $RouteData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($RouteData, RouteModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = RouteModel::where('AutoID', $data)->update($RouteData);
            
            return Redirect::to('routeedit/'.$data)->with('Message', 'Route Details Update Succesfully');
        } else 
        {
            return Redirect::to('routeedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function RouteDelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = RouteModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('route')->with('Message', 'Route Details Delete Succesfully');
	}
}