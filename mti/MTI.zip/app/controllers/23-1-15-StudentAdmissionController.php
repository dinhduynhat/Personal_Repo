<?php

class StudentAdmissionController extends BaseController
{
    
    public function StudentAdmissionSettingsLayout()
    {
	
	    $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$gender= array("Male"=>"Male", "Female"=>"Female");
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('gender', $gender);
    }
    public function StudentAdmissionProcess()
    {	
        $StudentAdmissionData = Input::all();		
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {		
		   $student = StudentAdmissionModel::create($StudentAdmissionData);
		  
            return Redirect::to('studentadmission')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentadmission')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentListSettingsLayout()
    {
	
	 $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');	
    return View::make('studentadmission/studentlist')->with('ClassDetails', $ClassDetails)->with('years', $years);
    }
	public function SearchStudentProcess()
	{
	$StudentAdmissionData = array_filter(Input::except(array('_token')));	
$StudentAdmissionData['StudentCourse']=$_POST['StudentCourse'];
	if(!empty($StudentAdmissionData))
	{
	
	if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where($StudentAdmissionData)->with('batchresult')->with('schollresult')->get()->toArray();	
		}
		
		//print_r($StudentAdmissionDetailsbyid);
		echo "<script>
$(document).ready(function(){ $('#student-listing-table').dataTable();
});
</script>";
echo '<div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Student List</h5>
        </div>
     
        <div class="panel-tab-row"><table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Name</th>
        <th>Grade</th>
		<th>Section</th>
        <th>Batch</th>
        </tr>
        </thead>
        <tbody>';
		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
		
       echo '<tr>
        <td><span class="tab-check"></span>'.$StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'].'</td>
        <td>'.$StudentAdmissionDetailvalue['StudentCourse'].'</td>
		<td>'.$StudentAdmissionDetailvalue['StudentSection'].'</td>
        <td>'.$StudentAdmissionDetailvalue['StudentBatch'].'</td>        
           
        </tr>';
		
        } 
		echo '</tbody>
        </table></div>
        </div>';
	} 
	
	}
	public function StudentadmissionEdit($data=NULL)
    {
	    $editvehicle=$data;
		$StudentAdmissioneditbyid= StudentAdmissionModel::where('id', $editvehicle)->get()->toArray();
		$gender= array("Male"=>"Male", "Female"=>"Female");
          $startyear=intval(date("Y"))+intval(10);
	$endyear=intval(date("Y"))-intval(100);
	$years = array_combine(range($startyear, $endyear), range($startyear, $endyear));
	$ClassDetails = ClassModel::lists('GradeName', 'GradeName');
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		}else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}
		$SectionDetails = SectionModel::lists('Section', 'Section');
		$laguageDetails = LanguageModel::lists('language', 'language');
		//$studentcategory = StudentCategoryModel::lists('category', 'id');
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}
		
        return View::make('studentadmission/studentadmission')->with('CountryDetails', $CountryDetails)->with('ClassDetails', $ClassDetails)->with('years', $years)->with('SchoolDetails', $SchoolDetails)->with('SectionDetails', $SectionDetails)->with('laguageDetails', $laguageDetails)->with('StudentAdmissionDetailsbyid', $StudentAdmissionDetailsbyid)->with('StudentAdmissioneditbyid', $StudentAdmissioneditbyid)->with('gender', $gender);
	}
	public function Studentupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token')));

        $validation  = Validator::make($GeneralData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {
			
		   if(!empty($GeneralData['ContactUploadLogo']))
	{
	Input::file('ContactUploadLogo')->move('assets/uploads/ContactUploadLogo/',$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName());
	$ContactUploadLogo=$data.'ContactUploadLogo.' . Input::file('ContactUploadLogo')->getClientOriginalName();
	unset($GeneralData['ContactUploadLogo']);
	$GeneralData['ContactUploadLogo']=$ContactUploadLogo;
	}
	  $updatedata=array_filter($GeneralData);
	   $affectedRows = StudentAdmissionModel::where('id', $data)->update($updatedata);
		   
            return Redirect::to('studentadmissionedit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
            return Redirect::to('studentadmissionedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function Studentdelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = StudentAdmissionModel::where('id', $editvehicle)->delete();		
       return Redirect::to('studentadmission')->with('Message', 'Student Delete Succesfully');
	}
	 public function StudentAdmissionImportLayout()
    {	   
		if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		} else {	
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		}		
        return View::make('studentadmission/studentimport')->with('SchoolDetails', $SchoolDetails);
    }

    public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();
	
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/studentdata/','importfile' . Input::file('importfile')->getClientOriginalName());
	$importfile='importfile' . Input::file('importfile')->getClientOriginalName();
	
	}
	
		
$uploaddata['SchoolName']=$StudentAdmissionData['SchoolName'];	
$uploaddata['StudentBatch']=$StudentAdmissionData['StudentBatch'];
$results=Excel::load('assets/uploads/studentdata/'.$importfile, function($reader) {

})->get()->toArray();



function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

$test=array_filter($finaldata);


foreach($finaldata as $final)
{

$uploaddata['StudentCourse']=$final['grade'];
$uploaddata['StudentLanguage']=$final['language'];	
$uploaddata['PersonalFirstName']=$final['firstname'];
$uploaddata['PersonalMiddleName']=$final['middlename'];	
$uploaddata['PersonalLastName']=$final['lastname'];
$uploaddata['Age']=$final['age'];	
$uploaddata['Gender']=$final['gender'];
$uploaddata['ContactPresentAddress']=$final['pickupaddress'];	
$uploaddata['ContactCity']=$final['pickupcity'];
$uploaddata['ContactState']=$final['pickupstate'];	
$uploaddata['ContactPin']=$final['pickuppin'];
$uploaddata['ContactCountry']=$final['pickupcountry'];
$uploaddata['ContactPhone']=$final['pickupphone'];	
$uploaddata['ContactMobile']=$final['pickupmobile'];
$uploaddata['GuardianFirstName']=$final['parentfirstname'];	
$uploaddata['GuardianMiddleName']=$final['parentmiddlename'];
$uploaddata['GuardianLastName']=$final['parentlastname'];	
$uploaddata['GuardianPresentAddress']=$final['dropaddress'];
$uploaddata['GuardianCity']=$final['dropcity'];	
$uploaddata['GuardianState']=$final['dropstate'];
$uploaddata['GuardianPin']=$final['droppin'];	
$uploaddata['GuardianCountry']=$final['dropcountry'];
$uploaddata['GuardianPhone']=$final['dropphone'];	
$uploaddata['GuardianMobile']=$final['dropmobile'];
$uploaddata['StartTime']=$final['pickuptime'];
$uploaddata['DropTime']=$final['droptime'];
$GradeName=$final['grade'];	
$language=$final['language'];
if($final['pickupaddress'] !="none" && $final['dropaddress'] !="none")
{
$uploaddata['pickupoption']=3;
}
if($final['pickupaddress'] !="none" && $final['dropaddress'] =="none")
{
$uploaddata['pickupoption']=1;
}
if($final['pickupaddress'] =="none" && $final['dropaddress'] !="none")
{
$uploaddata['pickupoption']=2;
}
if(!empty($GradeName))
{
   $count = ClassModel::where('GradeName', '=', $GradeName)->count();
     if($count==0)
	 {
	 
	 $ClassData['GradeName']=$GradeName;
	 ClassModel::create($ClassData);
	 }
	 }

	 	 if(!empty($language))
{
	 $languagecount = LanguageModel::where('language', '=', $language)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['language']=$language;
	 LanguageModel::create($StudentLanguageData);
	 }
	 }

	 if(!empty($final['firstname']))
	 {
	 	
	$student = StudentAdmissionModel::create($uploaddata);
	}
	
}

            return Redirect::to('studentadmission')->with('Message', 'StudentAdmission Details Saved Succesfully');
        } else 
        {
            return Redirect::to('studentimport')->withInput()->withErrors($validation->messages());
        }
    }
	public function StudentAdmissionExportLayout()
    {	


if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $schoolid)->get()->toArray();
		$mtidetail=$schoolDetailsbyid[0]['SchoolName'];
		}else {	
		$mtidetail="studentdetails";
		}

Excel::create($mtidetail, function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
if(Auth::user()->usertype==2)
		{
		$schoolid=Auth::user()->schoolid;
			
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();	
		
		}else {	
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();	
		}	

foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)
{
$uploaddata[$StudentAdmissionDetailvalue['id']]['Firstname']=$StudentAdmissionDetailvalue['PersonalFirstName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Middlename']=$StudentAdmissionDetailvalue['PersonalMiddleName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Lastname']=$StudentAdmissionDetailvalue['PersonalLastName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Grade']=$StudentAdmissionDetailvalue['StudentCourse'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Gender']=$StudentAdmissionDetailvalue['Gender'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Language']=$StudentAdmissionDetailvalue['StudentLanguage'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Age']=$StudentAdmissionDetailvalue['Age'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupaddress']=$StudentAdmissionDetailvalue['ContactPresentAddress'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupcity']=$StudentAdmissionDetailvalue['ContactCity'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupstate']=$StudentAdmissionDetailvalue['ContactState'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickuppin']=$StudentAdmissionDetailvalue['ContactPin'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupcountry']=$StudentAdmissionDetailvalue['ContactCountry'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupphone']=$StudentAdmissionDetailvalue['ContactPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickupmobile']=$StudentAdmissionDetailvalue['ContactMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Parentfirstname']=$StudentAdmissionDetailvalue['GuardianFirstName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Parentmiddlename']=$StudentAdmissionDetailvalue['GuardianMiddleName'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Parentlastname']=$StudentAdmissionDetailvalue['GuardianLastName'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropaddress']=$StudentAdmissionDetailvalue['GuardianPresentAddress'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropcity']=$StudentAdmissionDetailvalue['GuardianCity'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropcity']=$StudentAdmissionDetailvalue['GuardianState'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropstate']=$StudentAdmissionDetailvalue['GuardianPin'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropcountry']=$StudentAdmissionDetailvalue['GuardianCountry'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Droppin']=$StudentAdmissionDetailvalue['GuardianPin'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropphone']=$StudentAdmissionDetailvalue['GuardianPhone'];	
$uploaddata[$StudentAdmissionDetailvalue['id']]['Dropmobile']=$StudentAdmissionDetailvalue['GuardianMobile'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Pickuptime']=$StudentAdmissionDetailvalue['StartTime'];
$uploaddata[$StudentAdmissionDetailvalue['id']]['Droptime']=$StudentAdmissionDetailvalue['DropTime'];
}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('studentadmission');		
       
    }
}
