<?php

class PDFController extends BaseController
{
    
	
    public function PDF()
    {
	  
        $pdf = App::make('dompdf');
		$pdf->loadHTML('<h1>Test</h1>');
		$pdf->set_paper('a4', 'landscape');
		return $pdf->stream();
    }


    public function ExportStudentAttendance($data=NULL,$data1=NULL,$data2=NULL)
    {
    	$html_print = View::make('pdf/stud')->with('School', $data)->with('Month', $data1)->with('Year', $data2);
        $pdf = App::make('dompdf');
        $pdf->loadHTML($html_print);
		return $pdf->stream();
    }

    public function ExportStudentAttendance1($data=NULL,$data1=NULL,$data2=NULL)
    {
        $html_print = View::make('pdf/att')->with('School', $data)->with('Month', $data1)->with('Year', $data2);
        $pdf = App::make('dompdf');
        $pdf->loadHTML($html_print);
        return $pdf->stream();
    }


}