<?php

class LanguageController extends BaseController
{
    
    public function LanguageLayout()
    {
	
	    $languageDetails = LanguageModel::all()->toArray();
	
        return View::make('language/language')->with('languageDetails', $languageDetails);
     
    }
	public function Languageprocess()
    {

       
        $StudentCategoryData = Input::all();
        $validation = Validator::make($StudentCategoryData, LanguageModel::$rules);
        
        if ($validation->passes()) 
        {
            LanguageModel::create($StudentCategoryData);
            return Redirect::to('languagesection')->with('Message', 'language Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('languagesection')->withInput()->withErrors($validation->messages());
        }
    }
    public function LanguageEdit($data=NULL)
    {
	    $editcategory=$data;
		$languageDetailsbyid = LanguageModel::where('id', $editcategory)->get()->toArray();
      $languageDetails = LanguageModel::all()->toArray();
	
        return View::make('language/languageupdate')->with('languageDetails', $languageDetails)->with('languageDetailsbyid', $languageDetailsbyid);
	}
	public function Languageupdateprocess($data=NULL)
    {
        $categoryEditData = array_filter(Input::except(array('_token')));
	
	  $validation = Validator::make($categoryEditData, LanguageModel::$updaterules);        
        if ($validation->passes()) 
        {
		   $affectedRows = LanguageModel::where('id', $data)->update($categoryEditData);
            
            return Redirect::to('languageedit/'.$data)->with('Message', 'language Details Update Succesfully');
        } else 
        {
            return Redirect::to('languageedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
public function Languagedelete($data=NULL)
    {
	$editvehicle=$data;
		$ClassDetailsbyid = LanguageModel::where('id', $editvehicle)->get()->toArray();
		$language=$ClassDetailsbyid[0]['language'];
	 $count = StudentAdmissionModel::where('StudentLanguage', '=', $language)->count();

	if($count==0)
	{
	    $editcategory=$data;
		$affectedRows = LanguageModel::where('id', $editcategory)->delete();		
       return Redirect::to('languagesection')->with('Message', 'language Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	 $languageDetails = LanguageModel::all()->toArray();
	
        return View::make('language/language')->with('languageDetails', $languageDetails)->with('deleteerror', $deleteerror);
	}
	}
    public function Importprocess()
    {	
	$uploaddata=Array();
        $StudentAdmissionData = Input::all();

        $validation  = Validator::make($StudentAdmissionData, LanguageModel::$importrules);        
        if ($validation->passes()) 
        {
		
		 if(!empty($StudentAdmissionData['importfile']))
	{
	Input::file('importfile')->move('assets/uploads/language/','language' . Input::file('importfile')->getClientOriginalName());
	$importfile='language' . Input::file('importfile')->getClientOriginalName();
	
	}
$results=Excel::load('assets/uploads/language/'.$importfile, function($reader) {

})->get()->toArray();

function calc_dimensions(array $array) {
    $dimensions = 1;
    $max = 0;
    foreach ($array as $value) {
        if (is_array($value)) {
            $subDimensions = calc_dimensions($value);
            if ($subDimensions > $max) {
                $max = $subDimensions;
            }
        }
    }

    return $dimensions+$max;
}
$dimension=calc_dimensions(array_filter($results));
if($dimension == 3)
{

$finaldata=$results[0];
} else {
$finaldata=array_filter($results);
}

foreach($finaldata as $final)
{
$language=$final['language'];	
 	 if(!empty($language))
{
	 $languagecount = LanguageModel::where('language', '=', $language)->count();
  if($languagecount==0)
	 {
	 $StudentLanguageData['language']=$language;
	 LanguageModel::create($StudentLanguageData);
	 }
	 }
	 }
 return Redirect::to('languagesection')->with('Message', 'language Details Saved Succesfully');
        } else 
        {
            
            return Redirect::to('languagesection')->withInput()->withErrors($validation->messages());
        }
}
public function LanguageExportLayout()
    {	

Excel::create('language', function($excel) {

    $excel->sheet('Sheetname', function($sheet) {
	$uploaddata=Array();
		$ClassDetails = LanguageModel::all()->toArray();


foreach ($ClassDetails as $ClassDetailsvalue)
{
$uploaddata[$ClassDetailsvalue['id']]['language']=$ClassDetailsvalue['language'];	

}

        $sheet->fromArray($uploaddata);

    });

})->export('xlsx');	

    return Redirect::to('class');		
       
    }
}