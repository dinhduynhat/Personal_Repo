<?php

class VehicleController extends BaseController
{
    
    public function VehicleLayout()
    {
        $VehicleDetails = VehicleModel::all()->toArray();
        $VehicleTypeDetails = VehicleTypeModel::lists('VehicleTypeName', 'VehicleType');
        return View::make('vehicle/vehicle')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails);
    }
    
    public function VehicleProcess()
    {
        $VehicleData = Input::all();
        $validation  = Validator::make($VehicleData, VehicleModel::$rules);        
        if ($validation->passes()) 
        {
            VehicleModel::create($VehicleData);
            return Redirect::to('vehicle')->with('Message', 'Vehicle Details Saved Succesfully');
        } else 
        {
            return Redirect::to('vehicle')->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleEdit($data=NULL)
    {
	    $editvehicle=$data;
		$VehicleDetailsbyid = VehicleModel::where('AutoID', $editvehicle)->get()->toArray();
        $VehicleDetails = VehicleModel::all()->toArray();
        $VehicleTypeDetails = VehicleTypeModel::lists('VehicleTypeName', 'VehicleType');
        return View::make('vehicle/vehicleupdate')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('VehicleDetailsbyid', $VehicleDetailsbyid);
	}
	 public function VehicleupdateProcess($data=NULL)
    {
        $VehicleData = array_filter(Input::except(array('_token')));
	  $validation  = Validator::make($VehicleData, VehicleModel::$updaterules);        
        if ($validation->passes()) 
        {
		if(!empty($VehicleData['InsurancePhoto']))
	{
	Input::file('InsurancePhoto')->move('assets/uploads/vehicle/', $data . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalName());
	$InsurancePhoto=$data . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalName();
	unset($VehicleData['InsurancePhoto']);
	$VehicleData['InsurancePhoto']=$InsurancePhoto;
	}
	if(!empty($VehicleData['RCPhoto']))
	{
	Input::file('RCPhoto')->move('assets/uploads/vehicle/', $data . '-RCPhoto.' . Input::file('RCPhoto')->getClientOriginalName());
	$RCPhoto=$data . '-RCPhoto.' . Input::file('RCPhoto')->getClientOriginalName();
	unset($VehicleData['RCPhoto']);
	$VehicleData['RCPhoto']=$RCPhoto;
}
		   $affectedRows = VehicleModel::where('AutoID', $data)->update($VehicleData);
            //VehicleModel::create($VehicleData);
            return Redirect::to('vehicleedit/'.$data)->with('Message', 'Vehicle Details Update Succesfully');
        } else 
        {
            return Redirect::to('vehicleedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleDelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = VehicleModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to('vehicle')->with('Message', 'Vehicle Details Delete Succesfully');
	}
}