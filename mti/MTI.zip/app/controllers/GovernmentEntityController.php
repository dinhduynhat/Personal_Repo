<?php

class GovernmentEntityController extends BaseController
{
    
    public function AddGovernmentEntity()
    {
        $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
		$SchoolName = GeneralSettingModel::where('GovtEntityAllocated', '')->lists('SchoolName', 'id');
		
		
		
        return View::make('govtentity/addgovtentity')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails)->with('SchoolName', $SchoolName);
    }
    
    public function AddGovernmentEntityProcess()
    {
        
        $DriverData = Input::all();
		
		
        $AllSchool = Input::get('SchoolName');
		
		
        $validation = Validator::make($DriverData, GovernmentEntityModel::$rules);       
        if ($validation->passes()) 
        {
            #return $DriverData;
           $InsertedId = GovernmentEntityModel::create($DriverData);
           $inserteduserdataId = $InsertedId->id;

            $riderModel = new User;
            $riderModel->email = Input::get('GovernmentEntityEmail');
            $riderModel->UserName = Input::get('GovernmentEntityName');
            $riderModel->FirstName = Input::get('GovernmentEntityName');
            $riderModel->password = Input::get('Password');
            $riderModel->usertype = '3';
            $riderModel->schoolid = $inserteduserdataId;
            $riderModel->save();
			
			
			
			if (!empty($AllSchool))
		{
		foreach($AllSchool as $School)
		{
		$Data['GovtEntityAllocated'] = $inserteduserdataId;
		$affectedRows = GeneralSettingModel::where('id', $School)->update($Data);
		}
		}
			
			
			
			
            #GovernmentEntityModel::create($DriverData);
            #User::create($DriverData);
            #return $userdata;

            return Redirect::to(Session::get('urlpath').'/addgovtentity')->with('Message', 'Government Entity Details Saved Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/addgovtentity')->withInput()->withErrors($validation->messages());
        }
    }
    public function ListGovernmentEntity()
    {
        #ListGovernmentEntity


        $GeneralSettingDetails = GovernmentEntityModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('govtentity/listgovtentity')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails);


    }
	public function EditGovernmentEntity($data=NULL)
    {
	    $editvehicle=$data;
		$DriverDetailsbyid = GovernmentEntityModel::where('id', $editvehicle)->get()->toArray();
        $OwnSchoolName = GeneralSettingModel::where('GovtEntityAllocated', $data)->lists('SchoolName', 'id');
		$AllSchoolName = GeneralSettingModel::where('GovtEntityAllocated', '')->lists('SchoolName', 'id');
		
		
		
		$SchoolName = array_replace($OwnSchoolName, $AllSchoolName);
		
		
		
		$SchoolId = GeneralSettingModel::where('GovtEntityAllocated', $data)->lists('id');
		
		
        if (empty($DriverDetailsbyid)) 
        {
        return Redirect::to(Session::get('urlpath').'/listgovtentity');
        }
        else
        {
         $DriverDetails = GovernmentEntityModel::all()->toArray();
        return View::make('govtentity/editgovtentity')->with('DriverDetails', $DriverDetails)->with('DriverDetailsbyid', $DriverDetailsbyid)->with('SchoolName', $SchoolName)->with('SchoolId', $SchoolId);
        }

	}

	public function EditGovernmentEntityProcess($data=NULL)
    {
        $DriverData = array_filter(Input::except(array('_token')));
		
        $updaterulegovt = array(
        'GovernmentEntityName' =>  array('required'),
        'GovernmentEntityAddress' => 'required', 
        #'GovernmentEntityEmail' => array('required', 'unique:users,email','unique:govtentityinformation'), 
        'GovernmentEntityEmail' => 'required|unique:govtentityinformation,GovernmentEntityEmail,'.$data.',id',
        #'SchoolEmail' =>  'required|unique:schoolinformation,SchoolEmail,'.$data.',id',
        #'Password' => 'required', 
        'GovernmentEntityPhone' => 'required'
        
        );


        $validation  = Validator::make($DriverData, $updaterulegovt);        
        


        if ($validation->passes()) 
        {
        #$affectedRows = GovernmentEntityModel::where('id', $data)->update($DriverData);
        $GovtUpdate = GovernmentEntityModel::where('id', $data)->first();
        $GovtUpdate->GovernmentEntityName = Input::get('GovernmentEntityName');
        $GovtUpdate->GovernmentEntityAddress = Input::get('GovernmentEntityAddress');
        $GovtUpdate->GovernmentEntityEmail = Input::get('GovernmentEntityEmail');
        $GovtUpdate->GovernmentEntityPhone = Input::get('GovernmentEntityPhone');
        $GovtUpdate->GovernmentEntityMobile = Input::get('GovernmentEntityMobile');
        $GovtUpdate->GovernmentEntityContactPerson = Input::get('GovernmentEntityContactPerson');
        $GovtUpdate->Password = Input::get('Password');
        $GovtUpdate->save();

        $RiderUpdate = User::where('schoolid', $data)->first();
        $RiderUpdate->email = Input::get('GovernmentEntityEmail');
        $RiderUpdate->FirstName = Input::get('GovernmentEntityName');
        #$RiderUpdate->UserName = Input::get('GovernmentEntityName');
        $RiderUpdate->password = Input::get('Password');

        
        $RiderUpdate->save();
		
		$AllSchool = Input::get('SchoolName');
		#return $AllSchool;
		
$RemoveSchool = Input::get('SchoolName');
	if (empty($RemoveSchool ))		{

		$Datas['GovtEntityAllocated'] = '';
		$affectedRows = GeneralSettingModel::where('GovtEntityAllocated', $data)->update($Datas);
		}

		
	if (!empty($AllSchool))
		{

$RemoveSchool = Input::get('SchoolName');
	if (!empty($RemoveSchool ))		{

		$Datas['GovtEntityAllocated'] = '';
		$affectedRows = GeneralSettingModel::where('GovtEntityAllocated', $data)->update($Datas);
		}

		foreach($AllSchool as $School)
		{
		$Data['GovtEntityAllocated'] = $data;
		$affectedRows = GeneralSettingModel::where('id', $School)->update($Data);
		}
		}
		
		

        return Redirect::to(Session::get('urlpath').'/govtentityedit/'.$data)->with('Message', 'Government Entity Record Updated Succesfully');
        }
        else

        {
#            return $validation->messages();
#return Redirect::to('govtentityedit/'.$data)->with('Message', 'Government Entity Details Updated Succesfully');
        return Redirect::to(Session::get('urlpath').'/govtentityedit/'.$data)->withInput()->withErrors($validation->messages());

        } 



    }
	public function DeleteGovernmentEntity($data=NULL)
    {
	    $gdata=$data;
		$affectedRows = GovernmentEntityModel::where('id', $gdata)->delete();
        $affectedRows = User::where('schoolid', $gdata)->delete();       
		
		$Data['GovtEntityAllocated'] = '';
		$affectedRows = GeneralSettingModel::where('GovtEntityAllocated', $data)->update($Data);
		
		
       return Redirect::to(Session::get('urlpath').'/listgovtentity')->with('Message', 'Government Entity Record Deleted Succesfully');
	}



    public function FeePayment()
    {
        $age=array();
        $grade=array(); 
        $schoolname=array();
        $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }

        #$StudentAdmissionDetailsbyid = GovernmentEntityModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();
         $StudentAdmissionDetailsbyid = GeneralSettingModel::all();
		 #$StudentAdmissionDetailsbyid = GeneralSettingModel::where('id', $selectschool);
		 

        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $schoolname[]=$StudentAdmissionDetails['SchoolName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } 
		else if(Auth::user()->usertype==3)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } 
		else if(Auth::user()->usertype==4)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
		$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        } 
		else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('GovtEntityAllocated', $schoolid)->lists('SchoolName', 'id');
        }
        $checkresult=array();
        $BusCompanyName = BusCompanyModel::lists('Companyname', 'id');
		if(Auth::user()->usertype==3)
		{
		
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('GovtEntityAllocated', $schoolid)->lists('SchoolName', 'id');
		}
		#return $SchoolDetails;
        return View::make('govtentity/feepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('BusCompanyName', $BusCompanyName);
    }
		public function getNewSchool() 
		{
		$School = Input::get('school');
		
		$CompanyDetails = StudentAdmissionModel::where('SchoolName', $School)->lists('Company');
		$CompanyDetails = array_unique($CompanyDetails);
		if(!empty($CompanyDetails))
		{
		$BusDetails = '<select class="chosen-select" id="BusCompanyName" name="BusCompanyName">';
		
		foreach($CompanyDetails as $Company)
		{
			
			$Name = BusCompanyModel::where('id', '=', $Company)->pluck('Companyname');
			$BusDetails .= '<option value='.$Company.'>'.$Name.'</option>';
				
			
		}
		
		$BusDetails .= '</select>';
				
		return $BusDetails;
		
		}
		else
		{
		$BusDetails = '<select class="chosen-selec" id="BusCompanyName" name="BusCompanyName" disabled>
<option value="" >No Bus Allocated For this School</option>
</select>';
		
		return $BusDetails;
		
		}
		
		
		
		
		}
	
        public function FeePaymentProcess()
    {   


        $count = FeeModel::where('SchoolName', Input::get('SchoolName'))->where('BusCompanyName', Input::get('BusCompanyName'))->where('PayMonth', Input::get('PayMonth'))->where('PayYear', Input::get('PayYear'))->count();
        if ($count!='0') 
        {
            return '<font color="red">Payment Already done for the school';
        }
        $FeeData = Input::except(array('_token'));
        
        $FeeData['PaidBy'] = Auth::user()->usertype;
        $validation = Validator::make($FeeData, FeeModel::$rules);       
        if ($validation->passes()) 
        {
            FeeModel::create($FeeData);
            return '<font color="green">Payment Details Saved Succesfully';
            exit();
            return Redirect::to(Session::get('urlpath').'/feepayment')->with('Message', 'Payment Details Saved Succesfully');
        } else 
        {

            $err = implode(',',$validation->errors()->all());
            $err = '<font color ="red">'.$err;
        	return $err;

            $er =  $validation->messages();
            $er = print_r($er);

            return Response::json($er);


            
            #return Redirect::to('feepayment')->with('Message', $validation->messages());
            return Redirect::to(Session::get('urlpath').'/feepayment')->withInput()->withErrors($validation->messages());

        }
    }
    public function StudentFeeDetails()
    {


   $count = FeeModel::where('SchoolName', Input::get('SchoolName'))->where('BusCompanyName', Input::get('BusCompanyName'))->where('PayMonth', Input::get('PayMonth'))->where('PayYear', Input::get('PayYear'))->count();

        if ($count!='0') 
        {
            return '<p><h3><font color="red">Fee Payment already done to the School</h3></p>';
            exit();
        }
        else
        {


        $ValSchool = Input::get('SchoolName');
        $PayMonth = Input::get('PayMonth');
        $PayYear = Input::get('PayYear');
        $BusCompanyName = Input::get('BusCompanyName');

$SchoolDetails = StudentAdmissionModel::where('SchoolName', Input::get('SchoolName'))->get();

$SchoolDetailsCount = StudentAdmissionModel::where('SchoolName', Input::get('SchoolName'))->count();

if ($SchoolDetailsCount=='0') 
{
    return '<h3><font color="red">No Students allocated to this school</h3>';
}


$TotalStudentsById = TranportallocateModel::where('buscompany', '=', $BusCompanyName)->where('schoolid', '=', $ValSchool)->groupBy('studentid')->get()->ToArray();




        $TotalStudentsList ='';
        foreach ($TotalStudentsById as $TotKey)
        {
        
        $TotalStudentsList .= $TotKey['studentid'].',';
        
        
        }
    
        $TotalStudentsList = array_filter(explode(',', $TotalStudentsList));

#return $TotalStudentsList;



$FirstBody ='';
$VehicleArray ='';
foreach ($TotalStudentsList as $Data) 
{

$StudentData = StudentAdmissionModel::where('id', $Data)->first();

$FromDate = Input::get('PayYear').'-'.Input::get('PayMonth').'-'.'1';
$ToDate = Input::get('PayYear').'-'.Input::get('PayMonth').'-'.'31';

$ToSchool = StudentAttandenceModel::where('studentid', $Data)->where('toschool', '1')->whereBetween('date', array($FromDate, $ToDate))->count();
$FromSchool = StudentAttandenceModel::where('studentid', $Data)->where('fromschool', '1')->whereBetween('date', array($FromDate, $ToDate))->count();

$TotalCount = $ToSchool + $FromSchool;
$TotalCount = $TotalCount/2;

$VehicleTypeji = TranportallocateModel::where('studentid', '=', $Data)->pluck('busid');
$VehicleTypes = VehicleModel::where('AutoID', '=', $VehicleTypeji)->pluck('VehicleType');
$VehicleTypej = VehicleTypeModel::where('AutoID', '=', $VehicleTypes)->pluck('triptype');

$VehicleType = TariffTypeModel::where('id', '=', $VehicleTypej)->pluck('charge');
$VehicleTypedd = TariffTypeModel::where('id', '=', $VehicleTypej)->pluck('triptype');



$FirstBody .= "
<tr>
<td  style='display:none'></td>
<td><span class='tab-check'></span>".$StudentData['PersonalFirstName']." ".$StudentData['PersonalLastName']."</td>
<td>


<input type ='text' class='items ".'typeid'.$VehicleTypeji."' id='".$VehicleTypeji."' value='".$TotalCount."' readonly style='border:none'>



</td>

<td>".$VehicleTypedd."</td>

</tr>

";
}


$FirstTable = "



<form name='frms' id='frms' class='frms'>





<script>

$(document).ready(function() {


  


  $(document).ready(function () {
  //called when key is pressed in textbox
    $('[id^=quantity]').keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
//        $('#errmsg').html('Digits Only').show().fadeOut('slow');
               return false;
    }
   });
});



$('#firethebill').click(function(e){
             e.preventDefault();          
             console.log('fire');
              var datastring = $('#frms').serialize();
                $.ajax({
                    type: 'POST',
                    url : 'feepaymentprocess',
                    data : datastring,
                    success : function(data)
                    {
                    console.log(data);
                    $('#err').html(data);         
                    //$('#firsttable').html(data);         
                    }
                });
        });





















$('.items').each(function () {

    var sum = 0;
    var itemNumber = $(this).attr('class').split(' ');
    itemNumber.splice(itemNumber.indexOf('items'), 1);



    $('.'+itemNumber).each(function () {
    

    
   var newval = $(this).attr('id');

    sum += parseFloat($(this).val());

    $('.multiply_'+newval).val(sum);
    
});


});

var totalElement = $('.total');

$('.item').each(function () {
    



    var itemNumber = $(this).attr('class').split(' ');
    itemNumber.splice(itemNumber.indexOf('item'), 1);

    var sumElement = $('.sum_' + itemNumber);
    var sum = (sumElement.val() == '') ? 0 : parseFloat(sumElement.val());
    sum += parseFloat($(this).val());
    
    //sumElement.val(sum);

    var multiple=$('.multiply_'+itemNumber).val();
    var funalsum=parseFloat(multiple)*parseFloat(sum);
    $('.sum_' + itemNumber).val(funalsum);
    console.log(multiple);


    calculateTotal();
});

$(document).on('change', '.item', function () {
    var sum = 0;
    var itemNumber = $(this).attr('class').split(' ');
    itemNumber.splice(itemNumber.indexOf('item'), 1);
    $('.' + itemNumber).each(function () {
        sum += parseFloat($(this).val());
    });
    
  var multiple=$('.multiply_'+itemNumber).val();

    var funalsum=parseFloat(multiple)*parseFloat(sum);
    $('.sum_' + itemNumber).val(funalsum);


    calculateTotal();
});

// $('.item').keypress(function(){
    
	// var sum = 0;
    // var itemNumber = $(this).attr('class').split(' ');
    // itemNumber.splice(itemNumber.indexOf('item'), 1);
    // $('.' + itemNumber).each(function () {
        // sum += parseFloat($(this).val());
    // });
    
  // var multiple=$('.multiply_'+itemNumber).val();

    // var funalsum=parseFloat(multiple)*parseFloat(sum);
    // $('.sum_' + itemNumber).val(funalsum);


    // calculateTotal();
// });


function calculateTotal() {


    var total = 0;
    $('[class^=sum_]').each(function () {
        total += parseFloat($(this).val());
    });
    totalElement.val(total);
}






});



$(document).ready(function() {
$('#example').dataTable( {'aoColumnDefs': [{ 'bSortable': false, 
    'aTargets': [ '4']
     }] } );
} );















</script>
<div class='dash-content-head tabContaier'>
<h5>Student List</h5></div>
<table class='example tab' id='example'>
<tfoot class='tabl tab-abs'><tr>
<th style='display:none'></th>
<th style='display:none'></th>
<th style='display:none'></th>       
</th>
</tr></tfoot>   
<thead>    
<tr>
<th style='display:none'><input type='checkbox' id='selecctall'></th>
<th>Student Name</th>
<th>Number of Trip</th>
<th>Tariff Type</th>
</tr>
</thead>
".$FirstBody."
</table>

<!-- end -->



";


$TotalStudentsById = TranportallocateModel::where('buscompany', '=', $BusCompanyName)->where('schoolid', '=', $ValSchool)->get()->ToArray();




        $MatchedBus ='';
        foreach ($TotalStudentsById as $TotKey)
        {
        
        $MatchedBus .= $TotKey['busid'].',';
        
        
        }
    
        $MatchedBus = array_filter(explode(',', $MatchedBus));

        $MatchedBus =  array_unique($MatchedBus);

$SecondBody = "";
        foreach ($MatchedBus as $Matchkey) 
{
            
#$VehicleType = TranportallocateModel::where('studentid', '=', $Data)->pluck('busid');
$VehicleTypes = VehicleModel::where('AutoID', '=', $Matchkey)->pluck('VehicleType');
$VehicleType = VehicleTypeModel::where('AutoID', '=', $VehicleTypes)->pluck('VehicleTypeName');
$Rates = VehicleTypeModel::where('AutoID', '=', $VehicleTypes)->pluck('triptype');
$Rate = TariffTypeModel::where('id', '=', $Rates)->pluck('charge');




$SecondBody .= "
<tr>
<td>".$VehicleType."</td>
<td>
<input type ='text' class='item ".$Matchkey."' value='".$Rate."' id='quantity".$Matchkey."'><span id='errmsg'>
</td>
<td>
<input type ='text' class='multiply_".$Matchkey."' value='0' readonly style='border:none'>
</td>
<td>
<input type ='text' class='sum_".$Matchkey."'' readonly style='border:none'>   
</td>
</tr>";

}















$SecondTable ="


<div class='panel-row list-row'>
<div class='dash-content-head tabContaier'>
<h5>Payment Summary</h5>
</div>
<div class='panel-tab-row'>



<table id='example' class='display' cellspacing='0' width='100%'>
<thead>
<tr>
<th> Tariff Type</th>
<th> Rate </th>
<th> Number of Trips </th>
<th> Total </th>
</tr>
</thead>
<tbody>
".$SecondBody."
<tr>
<td></td>
<td>
 
</td>
<td >
<p align='right'>
 Total :
</p>
 </td>

<td>
 <input type ='text' name='Amount' class='total' value='' readonly style='border:none'>
 <input type ='hidden' name='SchoolName' value='".$ValSchool."'>
 <input type ='hidden' name='BusCompanyName' value='".$BusCompanyName."'>
 <input type ='hidden' name='PayMonth' value='".$PayMonth."'>
 <input type ='hidden' name='PayYear' value='".$PayYear."'>

 </td>

</tr>

<tr>
<td></td>
<td>
 Paid : <br><br>
 Paid Date : <br><br>
 Cheque Number :  <br><br>


</td>
<td ><br><br>
<input type ='checkbox' name='Paid' value='1' ><br>
<input class='datetimepicker1 DateOfBirth Startdate' name='PaidDate' type='text'><br><br>





<input type ='text' name='Cheque' ><br><br>

 <button class='btn-mti btn-mti-active' id='firethebill'>Save</button>
 </td>
<td>
 
 </td>

</tr>

</tbody>
</table>

<div id='err'>
</div>



</div>
<div class='bottom-tab-row'>
<div class='col-left'>
<!--
<button class='btn-mti btn-mti-active'>Show Pick up list</button>
<button class='btn-mti'>Show Drop off list</button>
-->
</div>
</div>
</div>
</form>


";












        $Result = $FirstTable.$SecondTable;

    return $Result;        
        }
return 'sankarbai';



        
    }

       public function EditFeePayment()
    {
    $age=array();
    $grade=array(); 
    $studentname=array();
    $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }
        
        $StudentAdmissionDetailsbyids = GeneralSettingModel::all();
        foreach($StudentAdmissionDetailsbyids as $StudentAdmissionDetails)
        {
                        $schoolname[]=$StudentAdmissionDetails['SchoolName'];
}
        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
 
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");

        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }

        $checkresult=array();
        return View::make('govtentity/editfeepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult);

    }

public function EditFeePayments()
{
    $age=array();
    $grade=array(); 
    $studentname=array();
    $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }
        
        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        return View::make('govtentity/editfeepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult);
}

public function ListFeePayment()
{
    $age=array();
    $grade=array(); 
    $studentname=array();
    $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }
        
        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
		$schoolid=Auth::user()->schoolid;
		$SchoolDetails = GeneralSettingModel::where('GovtEntityAllocated', $schoolid)->lists('SchoolName', 'id');
        #$SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        #$result = FeeModel::orderBy('PaidDate','asc')->where($cond)->get()->toArray();
        $GeneralSettingDetails = FeeModel::orderBy('Payyear','desc')->orderBy('created_at','desc')->get()->toArray();

        return View::make('govtentity/editfeepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('GeneralSettingDetails', $GeneralSettingDetails);
}


public function ListFeePaymentGE()
{
    $age=array();
    $grade=array(); 
    $studentname=array();
    $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }
        
        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        }
else if(Auth::user()->usertype==4)
        {
		
		$bus=array();
		$StudentAdmissionDetailsbyid = StudentAdmissionModel::where('Company', Auth::user()->schoolid)->with('schollresult')->with('batchresult')->get()->toArray();
        foreach($StudentAdmissionDetailsbyid as $company)
{
$bus[]=$company['SchoolName'];
}	
$relat=array_filter(array_unique($bus));	
if(!empty($relat))
{
	    $GeneralSettingDetails = GeneralSettingModel::whereIn('id', $relat)->lists('SchoolName', 'id');
		} else {
		
		 $GeneralSettingDetails =array();
		}	
		
		$SchoolDetails = $GeneralSettingDetails;
        #$schoolid=Auth::user()->schoolid;
        #$SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        }

		else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        #$result = FeeModel::orderBy('PaidDate','asc')->where($cond)->get()->toArray();
        #$GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('created_at','desc')->get()->toArray();
        $GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();

		
		
		
        return View::make('govtentity/editfeepaymentge')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('GeneralSettingDetails', $GeneralSettingDetails);
}



        public function FeePaymentEdit()
    { 


         $age=array();
    $grade=array(); 
    $schoolname=array();
    $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }

        #$StudentAdmissionDetailsbyid = GovernmentEntityModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();
         $StudentAdmissionDetailsbyid = GeneralSettingModel::all();





        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $schoolname[]=$StudentAdmissionDetails['SchoolName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        
        return View::make('govtentity/editfeepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult);
    }

    public function ListPaymentEdit()
    {



         if(Auth::user()->usertype=='1' || Auth::user()->usertype=='4' || Auth::user()->usertype=='2')
    {
        $check ='style="display:none"';
    }
    else
    {
        $check = '';
    }

    if (Input::get('schoolid')=='' && Input::get('PayMonth')=='' && Input::get('PayYear')=='')
    {

    #$GeneralSettingDetails = FeeModel::all()->toArray();   
    $GeneralSettingDetails = FeeModel::orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();
    goto Query;
    } 

    $cond='';
    if (Input::get('schoolid')!='')
    {
        $cond['SchoolName'] = Input::get('schoolid');
    }
    if (Input::get('PayMonth')!='')
    {
        $cond['PayMonth'] = Input::get('PayMonth');
    }
    if (Input::get('PayYear')!='')
    {
        $cond['PayYear'] = Input::get('PayYear');
    }


   

    #$result = FeeModel::orderBy('PaidDate','asc')->where($cond)->get()->toArray();
    $GeneralSettingDetails = FeeModel::where($cond)->orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();
    Query:

#$GeneralSettingDetails = FeeModel::all()->toArray();   



    echo '
    <div class="new">
    <script>
$(document).ready(function(){



$(".example").dataTable(
{
         "aoColumnDefs": [
          { "bSortable": false, "aTargets": [  ] }

       ]
}
    );

});
</script>


        <table class="example tab" id="example">

      <tfoot class="tabl tab-abs"><tr>
        <th></th>
        <th></th>
        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>
        <th style="display:none"></th>

        

      

        </tr></tfoot> 

        <thead>

    

        <tr>

<th style="display:none"></th>   

        <th>Status</th>
    
        <th>School Name</th>
    
        <th>Amount</th>

        <th>Month & Year</th>    
        <th>Payment Created</th>    
        <th>Payment Raised</th>    
        <th class="sorting lastth" '.$check.' >Action</th>
        
        
         

     

        </tr>

        </thead>
        <tbody>

        ';

    

    

    foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{
$date = $GeneralSettingDetailsvalue["PaidDate"];
$m = date("M", mktime(0, 0, 0, $GeneralSettingDetailsvalue["PayMonth"], 10));
$y = $GeneralSettingDetailsvalue['PayYear'];
$date = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['PaidDate']));
$date1 = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['created_at']));




if ($GeneralSettingDetailsvalue["Status"]=="1") 
{
  
  $Status = "Rejected";
}
else
{
$Status = "Accepted";
}
$SchoolName = GeneralSettingModel::where("id", "=", $GeneralSettingDetailsvalue["SchoolName"])->pluck("SchoolName");
#<?php echo URL::to(.'/studentimport');
#return Redirect::to(Session::get('urlpath').'/listfeepayment/')->with('Message', 'Payment Details Updated Succesfully');
    #here
echo ' 
        <tr>
<td style="display:none"></td>
    

         <td>'.$Status.'</td>
        <td>'.$SchoolName.'</td>
        <td>'.$GeneralSettingDetailsvalue["Amount"].'</td>
        <td>'.$m.', '.$y.'</td>
        <td>'.$date1.'</td>
        <td>'.$date.'</td>
    

       
         
    

        <td '.$check.' >       
<a href="'.URL::to(Session::get('urlpath').'/updatepayment').'/'.$GeneralSettingDetailsvalue['id'].'"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>


</td>

 </tr>
        
';
}
echo "       </tbody>

</div>
";
   
    }


	 public function ListPaymentEditAdmin()
    {


    if (Input::get('schoolid')=='' && Input::get('PayMonth')=='' && Input::get('PayYear')=='')
    {
    $GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();
    #$GeneralSettingDetails = FeeModel::all()->toArray();   
    goto Query;
    } 

    $cond='';
    if (Input::get('schoolid')!='')
    {
        $cond['SchoolName'] = Input::get('schoolid');
    }
    if (Input::get('PayMonth')!='')
    {
        $cond['PayMonth'] = Input::get('PayMonth');
    }
    if (Input::get('PayYear')!='')
    {
        $cond['PayYear'] = Input::get('PayYear');
    }


    #$result = FeeModel::orderBy('PaidDate','asc')->where($cond)->get()->toArray();
    $GeneralSettingDetails = FeeModel::where($cond)->get()->toArray();
    #$GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('created_at','desc')->get()->toArray();
    Query:

#$GeneralSettingDetails = FeeModel::all()->toArray();   



    echo '
    <div class="new">
    <script>
$(document).ready(function(){



$(".example").dataTable(
{
         "aoColumnDefs": [
          { "bSortable": false, "aTargets": [  ] }

       ]
}
    );

});
</script>


        <table class="example tab" id="example">

      <tfoot class="tabl tab-abs"><tr>
        <th></th>
        <th></th>
        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>
        <th style="display:none"></th>

        

      

        </tr></tfoot> 

        <thead>

    

        <tr>

<th style="display:none"></th>   

        <th>Status</th>
    
        <th>School Name</th>
    
        <th>Amount</th>

        <th>Month & Year</th> 
         <th>Payment Created</th>    
        <th>Payment Raised</th>    

        

        
        
         

     

        </tr>

        </thead>
        <tbody>

        ';

    

    

    foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{
$date = $GeneralSettingDetailsvalue["PaidDate"];
$m = date("M", mktime(0, 0, 0, $GeneralSettingDetailsvalue["PayMonth"], 10));
$y = $GeneralSettingDetailsvalue['PayYear'];
$date = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['PaidDate']));
$date1 = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['created_at']));


if ($GeneralSettingDetailsvalue["Status"]=="1") 
{
  $Status = "Rejected";
}
else
{
$Status = "Accepted";
}
$SchoolName = GeneralSettingModel::where("id", "=", $GeneralSettingDetailsvalue["SchoolName"])->pluck("SchoolName");

    
echo ' 
        <tr>
<td style="display:none"></td>
    

          <td>'.$Status.'</td>
        <td>'.$SchoolName.'</td>
        <td>'.$GeneralSettingDetailsvalue["Amount"].'</td>
        <td>'.$m.', '.$y.'</td>
        <td>'.$date1.'</td>
        <td>'.$date.'</td>
    

       
         
    


 </tr>
        
';
}
echo "       </tbody>

</div>
";
    }
	
    public function ListPaymentEditAdminss()
    
{

    if (Input::get('schoolid')=='' && Input::get('PayMonth')=='' && Input::get('PayYear')=='')
    {
    $GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();
    #$GeneralSettingDetails = FeeModel::all()->toArray();   
    goto Query;
    } 

    $cond='';
    if (Input::get('schoolid')!='')
    {
        $cond['SchoolName'] = Input::get('schoolid');
    }
    if (Input::get('PayMonth')!='')
    {
        $cond['PayMonth'] = Input::get('PayMonth');
    }
    if (Input::get('PayYear')!='')
    {
        $cond['PayYear'] = Input::get('PayYear');
    }


    #$result = FeeModel::orderBy('PaidDate','asc')->where($cond)->get()->toArray();
    $GeneralSettingDetails = FeeModel::where($cond)->get()->toArray();
    #$GeneralSettingDetails = FeeModel::where('Paid', '>' ,'1')->orderBy('created_at','desc')->get()->toArray();
    Query:

#$GeneralSettingDetails = FeeModel::all()->toArray();   



    echo '
    <div class="new">
    <script>
$(document).ready(function(){



$(".example").dataTable(
{
         "aoColumnDefs": [
          { "bSortable": false, "aTargets": [  ] }

       ]
}
    );

});
</script>


        <table class="example tab" id="example">

      <tfoot class="tabl tab-abs"><tr>
        <th></th>
        <th></th>
        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>
        <th style="display:none"></th>

        

      

        </tr></tfoot> 

        <thead>

    

        <tr>

<th style="display:none"></th>   

        <th>Status</th>
    
        <th>School Name</th>
    
        <th>Amount</th>

        <th>Month & Year</th> 
         <th>Payment Created</th>    
        <th>Payment Raised</th>    

        

        
        
         

     

        </tr>

        </thead>
        <tbody>

        ';

    

    

    foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{
$date = $GeneralSettingDetailsvalue["PaidDate"];
$m = date("M", mktime(0, 0, 0, $GeneralSettingDetailsvalue["PayMonth"], 10));
$y = $GeneralSettingDetailsvalue['PayYear'];
$date = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['PaidDate']));
$date1 = date("m-d-Y",strtotime($GeneralSettingDetailsvalue['created_at']));


if ($GeneralSettingDetailsvalue["Status"]=="1") 
{
  $Status = "Rejected";
}
else
{
$Status = "Accepted";
}
$SchoolName = GeneralSettingModel::where("id", "=", $GeneralSettingDetailsvalue["SchoolName"])->pluck("SchoolName");

    
echo ' 
        <tr>
<td style="display:none"></td>
    

          <td>'.$Status.'</td>
        <td>'.$SchoolName.'</td>
        <td>'.$GeneralSettingDetailsvalue["Amount"].'</td>
        <td>'.$m.', '.$y.'</td>
        <td>'.$date1.'</td>
        <td>'.$date.'</td>
    

       
         
    


 </tr>
        
';
}
echo "       </tbody>

</div>
";
    }


public function UpdatePayment($data = NULL)
{
  $curid = $data;
  #$SchoolNameVal = GeneralSettingModel::where('id', '=', $data)->pluck('SchoolName');  
  $SchoolNameVal = FeeModel::where('id', '=', $data)->pluck('SchoolName');  
  $SchoolNameVal = GeneralSettingModel::where('id', '=', $SchoolNameVal)->pluck('SchoolName');
  #return $SchoolNameVal;  
  $editvehicle=$data;
  $DriverDetails = FeeModel::where('id', $editvehicle)->get()->toArray();
  $status= array("1"=>"Active", "0"=>"Blocked");
 /* return View::make('govtentity/updatepayment')->with('DriverDetails', $DriverDetails)->with('status', $status);
  exit();*/
#return View::make('govtentity/updatepayment')->with('gender', $gender);
 $age=array();
        $grade=array(); 
        $schoolname=array();
        $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }

        #$StudentAdmissionDetailsbyid = GovernmentEntityModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();
         $StudentAdmissionDetailsbyid = GeneralSettingModel::all();

        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $schoolname[]=$StudentAdmissionDetails['SchoolName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        $SchoolNameVal = FeeModel::where('id', '=', $data)->pluck('SchoolName');  
        $SchoolNameVal = GeneralSettingModel::where('id', '=', $SchoolNameVal)->pluck('SchoolName');
        #return $SchoolNameVal;
        return View::make('govtentity/updatepayment')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('DriverDetails', $DriverDetails)->with('SchoolNameVal', $SchoolNameVal)->with('ScId', $curid);
}


    public function UpdatePaymentProcess()
    {

        $data = Input::except(array('_token'));
        $id = Input::get('SchoolName');
        $data['SchoolName'] = Input::get('SchoolId');

        unset($data['SchoolNameval']);
        unset($data['SchoolId']);


        $validation  = Validator::make($data, FeeModel::$updaterules);
        if ($validation->passes()) 
        {   
            $affectedRows = FeeModel::where('id', $id)->update($data);
            return Redirect::to(Session::get('urlpath').'/listfeepayment/')->with('Message', 'Payment Details Updated Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/updatepayment/'.Input::get('SchoolName'))->withInput()->withErrors($validation->messages());
            
            #return ::to('updatepayment/'.Input::get('SchoolName'))->with('Message', $validation->messages());
        }



    }

    public function ListPaymentEdits()
    {

      $StudentAdmissionData = Input::all();
$checkarray=array();

 $studentcheckarray = array();
  $studentcheckarray['TripType']=$TripType;

  if(!empty($StudentAdmissionData['TripType']))
 {
 $TripType=$StudentAdmissionData['TripType'];
 $studentcheckarray['TripType']=$TripType;
 } else {
  $TripType="";
 }

$checkresult = StudentAdmissionModel::where($studentcheckarray)

->whereHas('attendance',function($q)
{
if(!empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->whereBetween('date', array($Startdate,$Enddate));
    
    }
    if(!empty($StudentAdmissionData['Startdate']) && empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '>', $Startdate);
    }
    if(empty($StudentAdmissionData['Startdate']) && !empty($StudentAdmissionData['Enddate']))
 {
    $q->where('date', '<', $Enddate);
    }
    if(!empty($StudentAdmissionData['AttendenceFrom']))
 {
 if($AttendenceFrom=="all") 
 {
 if($status==0)
 {
 $q->where('toschool', '=', '0')->where('tohome', '=', '0');    
 #changehere
 }
 if($status==1)
 {
 $q->where('toschool', '=', '1')->where('tohome', '=', '1');    
 }
 }
 if($AttendenceFrom=="fromschool") 
 {
  if($status==0)
 {
 $q->where('toschool', '=', '0');   
 } 
   if($status==1)
 {
 $q->where('toschool', '=', '1');   
 } 
 }
 if($AttendenceFrom=="fromhome") 
 {
  if($status==1)
 {
 $q->where('tohome', '=', '1'); 
 } 
  if($status==0)
 {
 $q->where('tohome', '=', '0'); 
 } 
 }
 
 }
    
})
->with('attendance') // Optional eager loading, but recommended
->with('schollresult')->with('batchresult')->get()->toArray();
if(Auth::user()->usertype ==2)

        {
        $class="unwant";        
        } else {
        $class="";
        }
 echo '<script>
$(document).ready(function(){

$("#student-listing-table").dataTable();
});
</script>

        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">';
        if(!empty($checkresult))
        {
        echo '<a href="'.url().'/exportattendenceprocess/'.$StudentAdmissionData['schoolid'].'&'.$StudentAdmissionData['studentname'].'&'.$StudentAdmissionData['Startdate'].'&'.$StudentAdmissionData['Enddate'].'&'.$StudentAdmissionData['Gender'].'&'.$StudentAdmissionData['Age'].'&'.$StudentAdmissionData['Grade'].'&'.$StudentAdmissionData['ParentName'].'&'.$StudentAdmissionData['AttendenceStatus'].'&'.$AttendenceFrom.'&'.$StudentAdmissionData['TripType'].'" class="btn-sb pass-btn">Export Student Attendence</a>';
        }
        echo '<h5>Student Attendence Report</h5>
        </div>
       
        <div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th class="'.$class.'">SchoolName</th>
        <th>Student Name</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Grade</th>
        <th>Attendence Status (From School)</th>
        <th>Attendence Status (From Home)</th>
        </tr>
        </thead>
        <tbody>';

        foreach ($checkresult as $checkresultvalue)
{
        
       echo' <tr>        
        <td class="'.$class.'">'.$checkresultvalue['schollresult']['SchoolName'].'</td>
        <td>'.$checkresultvalue['PersonalFirstName']." ".$checkresultvalue['PersonalLastName'].'</td>
        <td>'.$checkresultvalue['Gender'].'</td>
        <td>'.$checkresultvalue['Age'].'</td>
        <td>'.$checkresultvalue['StudentCourse'].'</td>
        <td>';
        if($checkresultvalue['attendance']['toschool']==1)
{
echo "Present"; 
}else{
echo "Absent";  
} echo'</td>
        <td>';
        if($checkresultvalue['attendance']['tohome']==1)
{
echo "Present"; 
}else{
echo "Absent";  
} 
echo '</td>
        </tr>';
       } 
        echo '</tbody>
        </table>
        </div>
        </div>
        ';
}

public function StudentAdmissionMoreProcess()
    {   
        $StudentAdmissionData = Input::all();       
            $schoolid = $StudentAdmissionData['SchoolName'];
            $StudentCourse = $StudentAdmissionData['StudentCourse'];
        $validation  = Validator::make($StudentAdmissionData, StudentAdmissionModel::$rules);        
        if ($validation->passes()) 
        {   
        $count = ClassModel::where('GradeName', '=', $StudentCourse)->where('schoolid', '=', $schoolid)->count();       
          if($count==0)
          {
          $ClassData['GradeName']=$StudentCourse;
          $ClassData['schoolid']=$schoolid;
           ClassModel::create($ClassData);
             }
             $key=str_random(5);
            $StudentAdmissionData['Generatekey']= $key;
            $ParentData['FirstName']=$StudentAdmissionData['GuardianFirstName'];
            $ParentData['LastName']=$StudentAdmissionData['GuardianLastName'];
            $ParentData['Mobile']=$StudentAdmissionData['ContactMobile'];
            $ParentData['House']=$StudentAdmissionData['House'];
            $ParentData['Apartment']=$StudentAdmissionData['Apartment'];
            $ParentData['Street']=$StudentAdmissionData['Street'];
            $ParentData['City']=$StudentAdmissionData['ContactCity'];
            $ParentData['State']=$StudentAdmissionData['ContactState'];
            $ParentData['Pincode']=$StudentAdmissionData['ContactPin'];
            $ParentData['Generatekey']= $key;
            
            $parent = MTIServiceParent::create($ParentData);
            $StudentAdmissionData['parentid'] = $parent->id;
           $student = StudentAdmissionModel::create($StudentAdmissionData);

          
            return Redirect::to(Session::get('urlpath').'/studentadmissionmore/'.$parent->id)->with('Message', 'StudentAdmission Details Saved Succesfully and add More students');
        } else 
        {
       return Redirect::to(Session::get('urlpath').'/studentadmission')->withInput()->withErrors($validation->messages());
        }
    }

public function PaymentList()
    {   

$age=array();
        $grade=array(); 
        $schoolname=array();
        $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }

        #$StudentAdmissionDetailsbyid = GovernmentEntityModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();
         $StudentAdmissionDetailsbyid = GeneralSettingModel::all();

        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $schoolname[]=$StudentAdmissionDetails['SchoolName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        $BusCompanyName = BusCompanyModel::lists('Companyname', 'id');
        $Fee = FeeModel::all();
        return View::make('govtentity/paymentlist')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('BusCompanyName', $BusCompanyName);

	}

   public function FeePaymentList()
    {  

            $age=array();
        $grade=array(); 
        $schoolname=array();
        $parentname=array();
            if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }

        #$StudentAdmissionDetailsbyid = GovernmentEntityModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();
         $StudentAdmissionDetailsbyid = GeneralSettingModel::all();

        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $schoolname[]=$StudentAdmissionDetails['SchoolName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $checkresult=array();
        $BusCompanyName = BusCompanyModel::lists('Companyname', 'id');
        return View::make('govtentity/paymentlist')->with('gender', $gender)->with('age', array_unique($age))->with('grade', array_unique($grade))->with('schoolname', $schoolname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('BusCompanyName', $BusCompanyName);
    }

    public function AcceptPayment()
    {  
    #return 'a';
        
 
        $UpdatePayment = FeeModel::where('id', Input::get('PaymentId'))->first();
        $UpdatePayment->AcceptedAt = date("Y-m-d");
        $UpdatePayment->Paid = '2';
        
        $UpdatePayment->save();
                
        return '1';


    }
}