<?php

class HomeController extends BaseController
{
    
	
    public function Home()
    {
	  
        return View::make('login/login');
    }
	
	
	public function Hometoadmin()
		{
		
		return Redirect::to('/admin');
		
		}
	
	 public function HomeLayout()
    {
        $SchoolCount = GeneralSettingModel::count();
        
        if(Auth::user()->usertype==2)
        {
           $ownschool = Auth::user()->schoolid; 
        $StudentCount = StudentAdmissionModel::where('SchoolName', $ownschool)->count();
        }
        else
        {
        $StudentCount = StudentAdmissionModel::count();    
        }
        $DriverCount = DriverModel::count();
        $RouteCount = '1';
        $VehicleCount = VehicleModel::count();
        return View::make('home/home')->with('VehicleCount',$VehicleCount)->with('RouteCount',$RouteCount)->with('SchoolCount',$SchoolCount)->with('DriverCount',$DriverCount)->with('StudentCount',$StudentCount);
    	 
    }

    public function HomeLayoutBack()
    {
        
                 $age=array();
    $grade=array(); 
    $studentname=array();
    $parentname=array();
        if(Auth::user()->usertype==1)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        
        } else {    
        if(Session::get('selectschool')=="")
        {       
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();
        } else {
        $selectschool=Session::get('selectschool');
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $selectschool)->with('schollresult')->with('batchresult')->get()->toArray();  
        }           
        }
        
        foreach($StudentAdmissionDetailsbyid as $StudentAdmissionDetails)
        {
          $age[$StudentAdmissionDetails['Age']]=$StudentAdmissionDetails['Age'];
          $grade[$StudentAdmissionDetails['StudentCourse']]=$StudentAdmissionDetails['StudentCourse'];
           $studentname[]=$StudentAdmissionDetails['PersonalFirstName']." ".$StudentAdmissionDetails['PersonalLastName'];
           $parentname[]=$StudentAdmissionDetails['GuardianFirstName']." ".$StudentAdmissionDetails['GuardianLastName'];
        }
        $gender= array("Male"=>"Male", "Female"=>"Female");
        $AttendenceStatus= array("1"=>"Present", "0"=>"Absent");
        $fromwhere= array("fromschool"=>"fromschool", "fromhome"=>"fromhome");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
        $SchoolDetails = GeneralSettingModel::where('id', $schoolid)->lists('SchoolName', 'id');
        } else {    
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        }
        $SchoolDetails = GeneralSettingModel::lists('SchoolName', 'id');
        $checkresult=array();

        $GeneralSettingDetails = FeeModel::all()->toArray();

        $GeneralSettingDetails = FeeModel::orderBy('Payyear','desc')->orderBy('PayMonth','desc')->get()->toArray();
                return View::make('home/payment')->with('studentname', $studentname)->with('parentname', $parentname)->with('AttendenceStatus', $AttendenceStatus)->with('fromwhere', $fromwhere)->with('SchoolDetails', $SchoolDetails)->with('checkresult', $checkresult)->with('GeneralSettingDetails', $GeneralSettingDetails);
        
         
    }

}