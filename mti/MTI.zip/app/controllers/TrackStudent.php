<?php

class TrackStudent extends BaseController
{
    
    public function TrackStudentByAdminLayout()
    {
   

$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
 
$friday = strtotime(date("Y-m-d",$monday)." +4 days");
 
$this_week_sd = date("Y-m-d",$monday);
$this_week_ed = date("Y-m-d",$friday);
function createRange($startDate, $endDate) {
    $tmpDate = new DateTime($startDate);
    $tmpEndDate = new DateTime($endDate);

    $outArray = array();
    do {
        $outArray[] = $tmpDate->format('Y-m-d');
    } while ($tmpDate->modify('+1 day') <= $tmpEndDate);

    return $outArray;
}
$dates = createRange($this_week_sd, $this_week_ed);

        $weekdays= array("0"=>"Monday", "1"=>"Tuesday","2"=>"Wednesday","3"=>"Thursday","4"=>"Friday");
        if(Auth::user()->usertype==2)
        {
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('SchoolName', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray();  
        } else if(Auth::user()->usertype==4)
        {
        
        $schoolid=Auth::user()->schoolid;
            
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::where('Company', $schoolid)->with('schollresult')->with('batchresult')->get()->toArray(); 
        } else {    
        $StudentAdmissionDetailsbyid = StudentAdmissionModel::with('batchresult')->with('schollresult')->get()->toArray();  
        }

        

        ##MyCode : 

           if (Auth::user()->usertype=='4') 
        {
        $TotalStudentList = TranportallocateModel::where('buscompany', '=', Auth::user()->schoolid)->groupBy('studentid')->get()->ToArray();        }
        else
        {
        $TotalStudentList = TranportallocateModel::where('schoolid', '=', Auth::user()->schoolid)->groupBy('studentid')->get()->ToArray();
        }
        if (!empty($TotalStudentList)=='') 
        {
            return View::make('trackstudent/trackstudentlayout')->with('StudentAdmissionDetailsbyid', $TotalStudentList)->with('weekdays', $weekdays)->with('dates', $dates);            
        }
        else
        {
            foreach ($TotalStudentList as $key) 
        {
            $FilteredList[] = $key['studentid'];
        }
        $FilteredList = StudentAdmissionModel::whereIn('id', $FilteredList)->get();
        return View::make('trackstudent/trackstudentlayout')->with('StudentAdmissionDetailsbyid', $FilteredList)->with('weekdays', $weekdays)->with('dates', $dates);
        }
        
            
    
    }
      public function TrackStudentByAdminProcess()
    {
    

    $Name = StudentAdmissionModel::where('id', Input::get('id'))->pluck('PersonalFirstName');

    $CurrentDate = date('Y-m-d');
#	return $CurrentDate;
    $AMCurrentStatus = TranportallocateModel::where('studentid', Input::get('id'))->where('triptype', 'AM')->where('traveldate', $CurrentDate)->pluck('travelstatus');
    $PMCurrentStatus = TranportallocateModel::where('studentid', Input::get('id'))->where('triptype', 'PM')->where('traveldate', $CurrentDate)->pluck('travelstatus');

    #return $AMCurrentStatus.' - '.$PMCurrentStatus;
      
    
    if (($AMCurrentStatus=='' && $PMCurrentStatus=='') || ($AMCurrentStatus=='0' && $PMCurrentStatus=='0') || ($AMCurrentStatus=='3' && $PMCurrentStatus=='2')) 
    {
        $Stat = 'Home';
        

    }
    elseif (($AMCurrentStatus=='') || ($AMCurrentStatus=='3') || $PMCurrentStatus=='1') 
    {
        $Stat = 'PM';
          
    }
    elseif ($AMCurrentStatus=='2') 
    {
        $Stat = 'School';
        
    }
    elseif ($AMCurrentStatus=='1') 
    {
        $Stat = 'AM';
        
    }
    else
    {
        $Stat = 'Home';
          
    }

	
	#return $Stat;
	#return $AMCurrentStatus.' - '.$PMCurrentStatus.' - '.$Stat;

    if ($Stat=='Home') 
    {
        #return 'Student at home'; Fetch Home Address
        $Position = StudentAdmissionModel::where('id', Input::get('id'))->select('lat','long')->get();
        $Lat = $Position[0]['lat'];
        $Long = $Position[0]['long'];
        $img = url().'/assets/images/home_map.png';    
    }
    elseif ($Stat=='AM') 
    {
    #Find Driver

    $Bus = TranportallocateModel::where('studentid', Input::get('id'))->where('triptype', 'AM')->pluck('busid');
    $Driver = TimingModel::where('VehicleCode', $Bus)->pluck('DriverName');
    $Position = VehicleLocation::where('DriverId', $Driver)->select('Lat','Long')->get();
    $Lat = $Position[0]['Lat'];
    $Long = $Position[0]['Long'];
    $img = url().'/assets/images/bus_map.png';  
    }
    elseif ($Stat=='School') 
    {
        #Find School Lat Long
    $School = StudentAdmissionModel::where('id', Input::get('id'))->pluck('SchoolName');
    $Position = GeneralSettingModel::where('id', $School)->select('lat','lon')->get();
    $Lat = $Position[0]['lat'];
    $Long = $Position[0]['lon'];
    $img = url().'/assets/images/school_map.png';    
    }
    elseif ($Stat=='PM')  
    {
    $Bus = TranportallocateModel::where('studentid', Input::get('id'))->where('triptype', 'PM')->pluck('busid');
    $Driver = TimingModel::where('VehicleCode', $Bus)->pluck('DriverName');
    $Position = VehicleLocation::where('DriverId', $Driver)->select('Lat','Long')->get();
    $Lat = $Position[0]['Lat'];
    $Long = $Position[0]['Long'];
    $img = url().'/assets/images/bus_map.png';  
    }
    else
    {
        $Position = StudentAdmissionModel::where('id', Input::get('id'))->select('lat','long')->get();
        $Lat = $Position[0]['lat'];
        $Long = $Position[0]['long'];
        $img = url().'/assets/images/home_map.png';    
    }

    #sreturn $CurrentStatus;
$RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$Lat.','.$Long."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";
$GoogleApiResult = file_get_contents($RequestUrl);
$GoogleApiResultDecoded = json_decode($GoogleApiResult);
$Address = $GoogleApiResultDecoded->results[0]->formatted_address;
$Position = StudentAdmissionModel::where('id', Input::get('id'))->select('lat','long')->get();

#$img = url().'/assets/images/bus_map.png';   
#$img = url().'/assets/images/home_map.png';   
#$img = url().'/assets/images/school_map.png';     
#return Input::get('id');


    #return 'ok';
    return '


<script>
var lats = '.$Lat.';
var lons = '.$Long.';
var myCenter=new google.maps.LatLng(lats,lons);
var marker;

$(document).ready(function(){
var mapProp = {
  center:myCenter,
  zoom:18,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:myCenter,
  //labelContent: "Chiku",
  //animation:google.maps.Animation.BOUNCE
  });


marker.setIcon("'.$img.'"); 

    var infowindow = new google.maps.InfoWindow({
  content:"'.$Name.' - '.$Address.'"
  });
infowindow.open(map,marker);
marker.setMap(map);
});

//google.maps.event.addDomListener(window, "load", initialize);
</script>

<div class="dash-content-head tabContaier" style="width: 100% !important;color:black
">

                <h5 style="color:black">Track Student</h5>

        </div>
        <div style="border:#cccccc 1px solid; padding:5px;">
<div id="googleMap" style="min-height: 300px;border: 1px solid #dddddd;
box-sizing: border-box;
padding: 1%;width: 100%;"></div></div>';



    // return '<iframe src="http://maps.google.com/maps?q=Scottish+Rite+Hamilton+ON&loc:43.25911+-79.879494&z=15&output=embed"></iframe>';
    // return Input::get('id')+2;

    }  
    
}