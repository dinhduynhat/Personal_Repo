<?php

class GeneralSettingsController extends BaseController
{
    
    public function GeneralSettingsLayout()
    {	

	    $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails);
    }
    public function GeneralProcess($data=NULL)
    {
	     $GeneralData = array_filter(Input::all());
		 $loginuserdata = Input::except(array('SchoolName','SchoolAddress','SchoolEmail','SchoolPhone','SchoolMobile','SchoolFax','AdminContactPerson','Country','UploadLogo'));
		 
		$loginarray=array();
        $validation  = Validator::make($GeneralData, GeneralSettingModel::$rules);        
        if ($validation->passes()) 
        {	
		$UserName=$GeneralData['UserName'];
	$AdminContactPerson=$GeneralData['AdminContactPerson'];
	$SchoolEmail=$GeneralData['SchoolEmail'];	
	$loginarray['FirstName']=$AdminContactPerson;
	$loginarray['LastName']=$AdminContactPerson;
	$loginarray['email']=$SchoolEmail;	
	$loginarray['usertype']=2;
	unset($GeneralData['UserName']);
	unset($GeneralData['password']);
           $validate  = Validator::make($loginuserdata, User::$rules);        
        if ($validate->passes()) 
        {	
		    $school=GeneralSettingModel::create($GeneralData);
			$insertedId = $school->id;
			$userdata=User::create($loginuserdata);
			$inserteduserdataId = $userdata->id;
			$loginarray['schoolid']=$insertedId;
			
			$affectedRows = User::where('id', $inserteduserdataId)->update($loginarray);
		} else {
		  return Redirect::to('general')->withInput()->withErrors($validate->messages());
		}
            return Redirect::to('general')->with('Message', 'General Details Saved Succesfully');
        } else 
        {
            return Redirect::to('general')->withInput()->withErrors($validation->messages());
        }
		
    }
	public function Schoolupdateprocess($data=NULL)
    {
        $GeneralData = array_filter(Input::except(array('_token','Username','Password')));

        $validation  = Validator::make($GeneralData, GeneralSettingModel::$updaterules);   

        if ($validation->passes()) 
        {	
		   if(!empty($GeneralData['UploadLogo']))
	{
	Input::file('UploadLogo')->move('assets/uploads/uploadschoollogo/',Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalName());
	$UploadLogo=Input::get('SchoolName').'UploadLogo.' . Input::file('UploadLogo')->getClientOriginalName();
	unset($GeneralData['UploadLogo']);
	$GeneralData['UploadLogo']=$UploadLogo;
	}

	  $updatedata=array_filter($GeneralData);
		   $affectedRows = GeneralSettingModel::where('id', $data)->update($updatedata);
		   
            return Redirect::to('schooledit/'.$data)->with('Message', 'General Details Update Succesfully');
        } else 
        {
	
            return Redirect::to('schooledit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function SchoolEdit($data=NULL)
    {
	    $editvehicle=$data;
		$schoolDetailsbyid = GeneralSettingModel::where('id', $editvehicle)->get()->toArray();
         $GeneralSettingDetails = GeneralSettingModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
		$CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
		$TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');
        return View::make('general/generalsetting')->with('CountryDetails', $CountryDetails)->with('CurrencyDetails', $CurrencyDetails)->with('TomeZoneDetails', $TomeZoneDetails)->with('GeneralSettingDetails', $GeneralSettingDetails)->with('schoolDetailsbyid', $schoolDetailsbyid);
	}
	public function SchoolDelete($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = GeneralSettingModel::where('id', $editvehicle)->delete();		
       return Redirect::to('general')->with('Message', 'School Delete Succesfully');
	}
    
}