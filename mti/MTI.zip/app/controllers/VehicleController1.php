<?php

class VehicleController extends BaseController
{
    
    public function VehicleLayout()
    {
        $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
        $VehicleTypeDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->lists('VehicleTypeName', 'AutoID');
		$Companydetails = BusCompanyModel::where('id',Auth::user()->schoolid)->lists('Companyname', 'id');
		
		#return Auth::user()->schoolid;
        return View::make('vehicle/vehicle')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('Companydetails', $Companydetails);
    }
    
    public function VehicleProcess()
    {
        $VehicleData = Input::all();
        $validation  = Validator::make($VehicleData, VehicleModel::$rules);        
        if ($validation->passes()) 
        {
            VehicleModel::create($VehicleData);
            return Redirect::to(Session::get('urlpath').'/addvehicle')->with('Message', 'Vehicle Details Saved Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/addvehicle')->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleEdit($data=NULL)
    {
	    $editvehicle=$data;
		$VehicleDetailsbyid = VehicleModel::where('AutoID', $editvehicle)->get()->toArray();
		 if (empty($VehicleDetailsbyid)) 
        {
        return Redirect::to(Session::get('urlpath').'/addvehicle');
        }
        else
        {

         $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
         $VehicleTypeDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->lists('VehicleTypeName', 'AutoID');
		 $Companydetails = BusCompanyModel::where('id',Auth::user()->schoolid)->lists('Companyname', 'id');
        return View::make('vehicle/vehicleupdate')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('VehicleDetailsbyid', $VehicleDetailsbyid)->with('Companydetails', $Companydetails);
    }
	}
	 public function VehicleupdateProcess($data=NULL)
    {
$update = array(
        'VehicleNumber' =>array('required','Regex:/^[A-Za-z0-9\-! ,]+$/', 'unique:vehicle,VehicleNumber,'.$data.',AutoID'),
		
        'NumberSeats' => 'required|integer', 
        'VehicleType' => 'required',         
        'VehicleCode' => 'required|unique:vehicle,VehicleCode,'.$data.',AutoID',
        'InsurancePhoto' => 'image|max:2000',
        'RcPhoto' => 'image|max:2000',
        );
        $VehicleData = array_filter(Input::except(array('_token')));
	$validation  = Validator::make($VehicleData, $update);      
        if ($validation->passes()) 
        {
		if(!empty($VehicleData['InsurancePhoto']))
	{
	Input::file('InsurancePhoto')->move('assets/uploads/vehicle/', $data . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalName());
	$InsurancePhoto=$data . '-InsurancePhoto.' . Input::file('InsurancePhoto')->getClientOriginalName();
	unset($VehicleData['InsurancePhoto']);
	$VehicleData['InsurancePhoto']=$InsurancePhoto;
	}
	if(!empty($VehicleData['RcPhoto']))
	{
	Input::file('RcPhoto')->move('assets/uploads/vehicle/', $data . '-RcPhoto.' . Input::file('RcPhoto')->getClientOriginalName());
	$RcPhoto=$data . '-RcPhoto.' . Input::file('RcPhoto')->getClientOriginalName();
	unset($VehicleData['RcPhoto']);
	$VehicleData['RcPhoto']=$RcPhoto;
}
		   $affectedRows = VehicleModel::where('AutoID', $data)->update($VehicleData);
            //VehicleModel::create($VehicleData);
            return Redirect::to(Session::get('urlpath').'/vehicleedit/'.$data)->with('Message', 'Vehicle Details Update Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/vehicleedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleDelete($data=NULL)
    {
	    $editvehicle=$data;
			$vehiclebyid = VehicleModel::where('AutoID', $editvehicle)->get()->toArray();
		$VehicleCode=$vehiclebyid[0]['VehicleCode'];
	 $count = TimingModel::where('VehicleCode', '=', $data)->count();

	if($count==0)
	{
		$affectedRows = VehicleModel::where('AutoID', $editvehicle)->delete();
       return Redirect::to(Session::get('urlpath').'/addvehicle')->with('Message', 'Vehicle Details Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	  $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
       $VehicleTypeDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->lists('VehicleTypeName', 'AutoID');
	    $Companydetails = BusCompanyModel::where('id',Auth::user()->schoolid)->lists('Companyname', 'id');
        return View::make('vehicle/vehicle')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror)->with('Companydetails', $Companydetails);
        
	   }
	}
	public function VehicleDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['vehicledeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$vehiclebyid = VehicleModel::where('AutoID', $data[$i])->get()->toArray();
		$VehicleCode=$vehiclebyid[0]['VehicleCode'];
	 $count[] = TimingModel::where('VehicleCode', '=', $data[$i])->count();	
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = VehicleModel::where('AutoID', $data[$i])->delete();
     
	}
	  return Redirect::to(Session::get('urlpath').'/addvehicle')->with('Message', 'Vehicle Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	    $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
        $VehicleTypeDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->lists('VehicleTypeName', 'AutoID');
		$Companydetails = BusCompanyModel::where('id',Auth::user()->schoolid)->lists('Companyname', 'id');
        return View::make('vehicle/vehicle')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror)->with('Companydetails', $Companydetails);
	}
	}
	
	public function tariffType()
    {
        $VehicleDetails = TariffTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/tarifftype')->with('VehicleDetails', $VehicleDetails);
    }
	
	public function VehicleTypeNameprocess()
    {

        $schoolid=Auth::user()->schoolid;
         $addrules = array(
        'VehicleTypeName' =>  array('required'), 
'Charge' =>  array('required'),		
                             );
        $ClassData = Input::all();
          $validation = Validator::make($ClassData, $addrules);

        $ClassData['Company']=Auth::user()->schoolid;
		$VehicleTypeName = $ClassData['VehicleTypeName'];
		$schoolid = Auth::user()->schoolid;
        if ($validation->passes()) 
        {
         $count = VehicleTypeModel::where('VehicleTypeName', '=', $VehicleTypeName)->where('Company', '=', $schoolid)->count();
     if($count==0)
	 {
            VehicleTypeModel::create($ClassData);
			} else {
			
			return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'Vehicle Type Name Name Already taken');
			
			}
            return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'Vehicle Type Name Saved Succesfully');
        } else 
        {
            
            return Redirect::to(Session::get('urlpath').'/vehicletype')->withInput()->withErrors($validation->messages());
        }
    }
	
	public function VehicletypeLayout()
    {
        $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      $VehicleTypeDetails = TariffTypeModel::where('Company',Auth::user()->schoolid)->lists('triptype', 'id');
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('VehicleTypeDetails', $VehicleTypeDetails);
    }
	public function tariffTypeProcess()
    {
	
		
		$TariffTypeData = Input::all();
		
		$validation  = Validator::make($TariffTypeData, TariffTypeModel::$rules);        
        if ($validation->passes()) 
        {
			$TariffTypeData['company'] =  Auth::user()->schoolid;
			$InsertedId = TariffTypeModel::create($TariffTypeData);
			return Redirect::to(Session::get('urlpath').'/tarifftype')->with('Message', 'Tariff Details Saved Succesfully');
		}
		else
		{
			return Redirect::to(Session::get('urlpath').'/tarifftype')->withInput()->withErrors($validation->messages());
		}
		
        
    }
	public function VehicleTypeEdit($data=NULL)
    {
	    $editvehicle=$data;
		$VehicleDetailsbyid = VehicleTypeModel::where('AutoID', $editvehicle)->get()->toArray();
		 if (empty($VehicleDetailsbyid)) 
        {
        return Redirect::to(Session::get('urlpath').'/vehicletype');
        }
        else
        {
        $schoolid=Auth::user()->schoolid;
	   $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('VehicleDetailsbyid', $VehicleDetailsbyid);
    }
	}
	
	
		public function tariffTypeEdit($data=NULL)
    {
	    $editvehicle=$data;
		$VehicleDetailsbyid = TariffTypeModel::where('id', $editvehicle)->get()->toArray();
		 if (empty($VehicleDetailsbyid)) 
        {
        return Redirect::to(Session::get('urlpath').'/tarifftype');
        }
        else
        {
        $schoolid=Auth::user()->schoolid;
	   
	   $VehicleDetails = TariffTypeModel::all();
	   $VehicleDetails = TariffTypeModel::where('company', $schoolid)->get()->toArray();
      $VehicleDetailsbyid = TariffTypeModel::where('id', $editvehicle)->get()->toArray();
	   
        return View::make('vehicle/tarifftype')->with('VehicleTypeDetails', $VehicleDetails)->with('VehicleDetails', $VehicleDetails)->with('VehicleDetailsbyid', $VehicleDetailsbyid);
    }
	}
	
	public function tariffTypeEditProcess($data=NULL)
	{
	
	

$update = array(
        'triptype' =>  array('required','regex:/^./','unique:triptype,triptype,'.$data.',id,triptype,'.$data),   
		'charge' =>  array('required'),   
                             );
        $ClassEditData = array_filter(Input::except(array('_token')));
	
	   $validation = Validator::make($ClassEditData, $update);        
        if ($validation->passes()) 
        {
		   $affectedRows = TariffTypeModel::where('id', $data)->update($ClassEditData);
             
            return Redirect::to(Session::get('urlpath').'/tarifftype')->with('Message', 'Tariff Details Updated Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/tarifftype')->withInput()->withErrors($validation->messages());
        }
	
	}
	
	
	public function VehicleTypeNameupdateprocess($data=NULL)
    {
$schoolid=Auth::user()->schoolid;

$update = array(
        'VehicleTypeName' =>  array('required','regex:/^./','unique:vehicletype,VehicleTypeName,'.$data.',AutoID,Company,'.$schoolid),   
                             );
        $ClassEditData = array_filter(Input::except(array('_token')));
	
	   $validation = Validator::make($ClassEditData, $update);        
        if ($validation->passes()) 
        {
		   $affectedRows = VehicleTypeModel::where('AutoID', $data)->update($ClassEditData);
            
            return Redirect::to(Session::get('urlpath').'/VehicleTypeedit/'.$data)->with('Message', 'Vehicle Type Update Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/VehicleTypeedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	
	
	public function tariffTypeDeleteProcess($data=NULL)
    {
		
		
		$editvehicle=$data;
		$count = TariffTypeModel::where('id', '=', $editvehicle)->count();
		if($count==0)
		{
		return Redirect::to(Session::get('urlpath').'/tarifftype')->with('Message', 'Tariff Details not Exist');
		}
		else
		{
		$affectedRows = TariffTypeModel::where('id', $editvehicle)->delete();		
        return Redirect::to(Session::get('urlpath').'/tarifftype')->with('Message', 'Tariff Details Deleted Succesfully');
		}
		
	   
	}
	public function VehicleTypeDelete($data=NULL)
    {
	$editvehicle=$data;
	 $schoolid=Auth::user()->schoolid;		
	 $count = VehicleModel::where('VehicleType', '=', $editvehicle)->where('Company', '=', $schoolid)->count();

	if($count==0)
	{
	    $editvehicle=$data;
		$affectedRows = VehicleTypeModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'VehicleType Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	   	$schoolid=Auth::user()->schoolid;
	 $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror);
	   }
	}
	public function VehicleTypeDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['classdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$schoolid=Auth::user()->schoolid;
		
	 $count[] = VehicleModel::where('VehicleType', '=', $data[$i])->where('Company', '=', $schoolid)->count();		
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = VehicleTypeModel::where('AutoID', $data[$i])->delete();
     	
	}
	  return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'VehicleType Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	  $schoolid=Auth::user()->schoolid;
	 $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror);
	}
	}
}