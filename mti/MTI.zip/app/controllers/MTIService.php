<?php
	
	class MTIService extends BaseController
	{
		
		############# Parent App Web Service ############################
		
		public function CheckParentDevice()
		{
			#Checks if the DeviceId matches any Record in the Parent Information Table
			$ParentData = MTIServiceParent::where('DeviceId', Input::get('DeviceId'))->pluck('id');
			if ($ParentData) 
			{
				$Response   = array(
				'success' => '1',
				'parent_id' => $ParentData
				);
				return $Response;
			}
			else
			{
				$Response   = array(
				'success' => '0',
				#'message' => 'Parent Not Found'
				);    
				return $Response;
			}
		}
		
		public function RegisterParentDevice()
		{
			
			if((Input::get('Mobile') =='') || (Input::get('Name') =='') || (Input::get('GcmId') =='')) 
			{
				$Response   = array(
				'success' => '0',
				'message' => 'Insufficient Data'
				);    
				return $Response;
				
			}
			
			$ParentData = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('Generatekey');
			$ParentId = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('id');
			
			if ($ParentData) 
			{   
                $ParentDataUpdate           = MTIServiceParent::where('id', $ParentId)->first();
                $ParentDataUpdate->GcmId    = Input::get('GcmId');
                if (Input::get('DeviceType')=='ios') 
                {
					$ParentDataUpdate->DeviceType    = 'ios';    
				} 
                $ParentDataUpdate->save();
				
				
				$ParentGCM = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('GcmId');
				$Response   = array(
				'success' => '1',
				);
                
				$DeviceType = MTIServiceParent::where('Mobile', Input::get('Mobile'))->where('FirstName', Input::get('Name'))->pluck('DeviceType');
				if ($DeviceType=='ios') 
				{
					$Message = "MTI_Activation_Code_:_".$ParentData;
					$Sender = 'Parent';
					$DeviceId = $ParentGCM;
					$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
				}
				else
				{
					$PushMessage = '{"Type" : "ActivationCode", "Title" : "MTI Activation Code", "Message" : "Activation Code is '.$ParentData.'","ActivationCode" : "'.$ParentData.'"}'; 
					$DeviceId = array($ParentGCM);
					$Message = array("price"=>urldecode($PushMessage));
					$this->PushNotification($DeviceId, $Message);       
				}
				
				return $Response;
				
			}
			else
			{
				$Response   = array(
				'success' => '0',
				'message' => 'Parent Not Found'
				);    
				return $Response;
			}
		}
		
		
		public function AuthenticateParent()
		{
			$ParentId = MTIServiceParent::where('Generatekey', '=', Input::get('UniqueCode'))->pluck('id');
			if ($ParentId) {
				$ParentData           = Input::all();
				$ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentregisterrule);
				if ($ParentDataValidation->passes()) {
					$ParentDataUpdate           = MTIServiceParent::where('id', $ParentId)->first();
					$ParentDataUpdate->DeviceId = Input::get('DeviceId');
					if (Input::get('DeviceType')=='ios') 
					{
						$ParentDataUpdate->DeviceType    = 'ios';
					}
					$ParentDataUpdate->GcmId    = Input::get('GcmId');
					$ParentDataUpdate->save();
					$Response = array(
                    'success' => '1',
                    'parent_id' => $ParentId
					);
					return json_encode($Response);
					} else {
					$Response = array(
                    'success' => '0',
                    'message' => 'Insufficient Data'
					);
					return json_encode($Response);
				}
				
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'The Unique Key does not match with a Registered Parent at MTI'
				);
				return json_encode($Response);
			}
		}
		
		public function ShowParentProfile()
		{
			$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
			if ($IsParentExist) {
				$ParentData = MTIServiceParent::find($IsParentExist);
				$Response   = array(
                'success' => '1',
                'firstname' => $ParentData->FirstName,
                'email' => $ParentData->Email,
                'phone' => $ParentData->Phone,
                'mobile' => $ParentData->Mobile,
				'address' => $ParentData->Address,
                // 'house' => $ParentData->House,
                // 'apartment' => $ParentData->Apartment,
                // 'street' => $ParentData->Street,
                // 'city' => $ParentData->City,
                // 'state' => $ParentData->State,
                'pincode' => $ParentData->Pincode
				);
				return json_encode($Response);
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
		}
		
		
		public function UpdateParentProfileOld()
		{
			$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
			if ($IsParentExist) {
				$ParentData           = Input::all();
				$ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentupdaterule);
				if ($ParentDataValidation->passes()) {
					$ParentUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();
					$ParentUpdate->FirstName = Input::get('FirstName');
					#$ParentUpdate->LastName = Input::get('LastName');
					$ParentUpdate->Email = Input::get('Mail');
					$ParentUpdate->Mobile = Input::get('Mobile');
					$ParentUpdate->Phone = Input::get('Phone');
					$ParentUpdate->Address = Input::get('Address');
					// $ParentUpdate->House = Input::get('House');
					// $ParentUpdate->Apartment = Input::get('Apartment');
					// $ParentUpdate->Street = Input::get('Street');
					// $ParentUpdate->City = Input::get('City');
					// $ParentUpdate->State = Input::get('State');
					$ParentUpdate->Pincode = Input::get('Pincode');
					$ParentUpdate->save();
					$Response = array(
					'success' => '1'
					);
					return json_encode($Response);
				}
				else {
					$Response = array(
					'success' => '0',
					'errors' => $ParentDataValidation->messages()
					);
					return json_encode($Response);
				}
				
				
				
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
		}
		
		
		public function UpdateParentProfile()
		{
			$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
			if ($IsParentExist) {
				$ParentData           = Input::all();
				
				$ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$parentupdaterule);
				if ($ParentDataValidation->passes()) {
					
					$ParentUpdate = new ParentEditModel;
					// $UpdateAttendance->studentid = Input::get('StudentId');
					// $UpdateAttendance->toschool = Input::get('ToSchool');
					// $UpdateAttendance->tohome = Input::get('ToHome');
					// $UpdateAttendance->date = Input::get('Date');
					// $UpdateAttendance->inserttime = Input::get('Time');
					// $UpdateAttendance->save();
					
					
					
					
					
					
					
					#  $ParentUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();
					$ParentUpdate->ParentId = Input::get('ParentId');
					$ParentUpdate->FirstName = Input::get('FirstName');
					$ParentUpdate->LastName = Input::get('LastName');
					$ParentUpdate->Email = Input::get('Mail');
					$ParentUpdate->Mobile = Input::get('Mobile');
					$ParentUpdate->Phone = Input::get('Phone');
					$ParentUpdate->Address = Input::get('Address');
					// $ParentUpdate->Apartment = Input::get('Apartment');
					// $ParentUpdate->Street = Input::get('Street');
					// $ParentUpdate->City = Input::get('City');
					// $ParentUpdate->State = Input::get('State');
					$ParentUpdate->Pincode = Input::get('Pincode');
					$ParentUpdate->save();
					$Response = array(
					'success' => '1',
					'message' => 'Your Profile Information has been sent for Approval'
					);
					return json_encode($Response);
				}
				else {
					$Response = array(
					'success' => '0',
					'message' => $ParentDataValidation->messages()
					);
					return json_encode($Response);
				}
				
				
				
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
		}
		
		
		
		public function ShowParentNotification()
		{
			$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
			if ($IsParentExist) {
				$ParentData = MTIServiceParent::find($IsParentExist);
				$Response   = array(
                'success' => '1',
                'pushnotify' => ''.$ParentData->MobileNotification.'',
                'emailnotify' => ''.$ParentData->EmailNotification.''
				);
				return json_encode($Response);
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
			
		}
		
		public function UpdateParentNotification()
		{
			$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
			if ($IsParentExist) {
				
				$ParentData           = Input::all();
				$ParentDataValidation = Validator::make($ParentData, MTIServiceParent::$notificationrule);
				if ($ParentDataValidation->passes()) {
					$NotificationUpdate = MTIServiceParent::where('id', Input::get('ParentId'))->first();        
					$NotificationUpdate->EmailNotification = Input::get('EmailNotification');
					$NotificationUpdate->MobileNotification = Input::get('MobileNotification');
					$NotificationUpdate->save();
					$Response = array(
					'success' => '1'
					);
					return json_encode($Response);
				}
				else {
					$Response = array(
					'success' => '0',
					'message' => 'Insufficient Data'
					#'errors' => $ParentDataValidation->messages()
					);
					return json_encode($Response);
				}
				} else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
		}
		
		
		
		
		
		public function ShowKids()
		{  
			$ParentDetails = MTIServiceParent::where('id', Input::get('ParentId'))->select('Address', 'House', 'Apartment','Street','City','State','Pincode')->get()->first();
			if ($ParentDetails) 
			{
				
				$StudentDetails = MTIServiceStudent::where('parentid', Input::get('ParentId'))->select('id','PersonalFirstName as FirstName','PersonalLastName as LastName', 'StudentCourse as Course','TripType','fromTripType','ContactUploadLogo as ProfileImage', 'tripcom as Trip')->get();
				
				$Response = array(
                'success' => '1',
                'address' => $ParentDetails,
                'student' => $StudentDetails
				);
				return json_encode($Response);
			}
			else {
				$Response = array(
                'success' => '0',
                'message' => 'No User Found'
				);
				return json_encode($Response);
			}
		}
		
		public function UpdateAttendance()
		{        
			
			
			#if (Input::get('StudentId') != '' && Input::get('ToSchool') !='' && Input::get('ToHome') !='' && Input::get('Date') !='' && Input::get('Time') !='') 
				if (Input::get('StudentId') != ''  && Input::get('Date') !='' && Input::get('Time') !=''  && Input::get('Attendance') !='' ) 
				{      
					#$IsParentExist = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
					$IsStudntExist = MTIServiceStudent::where('id', Input::get('StudentId'))->count();
					
					if ($IsStudntExist=='1') 
					{
						
						if (Input::get('Sender') == 'Driver' && Input::get('Attendance') !='')
						{
							
							if (Input::get('Attendance') =='AM')
							{
								$UpdateTransportAM = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'AM')->update(array('travelstatus' => 1, 'traveldate' => Input::get('Date')));
								
								$IsPMExist = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'PM')->count();
								
								if ($IsPMExist==1) 
								{
									$UpdateTransportPM = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'PM')->update(array('travelstatus' => 0, 'traveldate' => Input::get('Date')));   
								}         
								
							}
							else
							{
								
								$UpdateTransportPM = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'PM')->update(array('travelstatus' => 2, 'traveldate' => Input::get('Date')));
								
								$IsAMExist = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'AM')->count();
								if ($IsAMExist==1) 
								{
									$UpdateTransportAM = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'AM')->update(array('travelstatus' => 3, 'traveldate' => Input::get('Date')));
								}
								
							}
							
						}
						
						
						if (Input::get('ToSchool')=='1')
						{
							$ToSchool='1';
						}
						elseif (Input::get('ToSchool')=='2') 
						{
							$ToSchool='2';
						}
						elseif (Input::get('ToSchool')=='0') 
						{
							$ToSchool='0';
						}
						else
						{
							$ToSchool='0';
						}
						
						if (Input::get('FromSchool')=='1')
						{
							$FromSchool='1';
						}
						elseif (Input::get('FromSchool')=='2') 
						{
							$FromSchool='2';
						}
						elseif (Input::get('FromSchool')=='0') 
						{
							$FromSchool='0';
						}
						else
						{
							$FromSchool='0';
						}
						
					}
					else
					{
						$Response = array(
                        'success' => '0',
						'message' => 'Student Not Exist'
						);
						return json_encode($Response);  
						exit;
					}
					
					
					
					
					$Already = StudentAttandenceModel::where('studentid', Input::get('StudentId'))->where('date', Input::get('Date'))->count();
					#return $Already;
					if ($ToSchool!=0) 
					{
						$FoundTrip = 'AM';
					}
					else
					{
						$FoundTrip = 'PM';
					}
					
					if ($Already=='1') 
					{
						
						$Att = StudentAttandenceModel::where('studentid', Input::get('StudentId'))->where('date', Input::get('Date'))->pluck('busstatus');
						
						
						
						
						
						$Att = StudentAttandenceModel::where('studentid', Input::get('StudentId'))->where('date', Input::get('Date'))->pluck('id');
						$Atts = StudentAttandenceModel::where('studentid', Input::get('StudentId'))->where('date', Input::get('Date'))->pluck('busstatus');
						$UpdateAttendance = StudentAttandenceModel::where('id', $Att)->first();
						$UpdateAttendance->toschool = $ToSchool;
						$UpdateAttendance->fromschool = $FromSchool;
						$UpdateAttendance->date = Input::get('Date');
						
						$AttendanceType = Input::get('Attendance');
						
						if ($ToSchool!=0) 
						{
							#$FoundTrip = 'AM';
							if ($Atts==1 || $Atts==2) 
							{
								$Response = array(
								'success' => '0',
								'message' => 'Driver Already Marked'
								);
								return json_encode($Response);       
							} 
							
							if (Input::get('Sender') == 'Driver')
							{
								$UpdateAttendance->busstatus = '1';        
							}
							
							
						}
						
						if($FromSchool!=0)  
						{
							$FoundTrip = 'PM';
							if ($Atts==2) 
							{
								$Response = array(
								'success' => '0',
								'message' => 'Driver Already Marked'
								);
								return json_encode($Response);       
							}
							#$UpdateAttendance->busstatus = '2';
							if (Input::get('Sender') == 'Driver')
							{
								$UpdateAttendance->busstatus = '2';        
							}
						}
						else
						{
							$FoundTrip = 'AM';   
						}
						
						
						
						$UpdateAttendance->inserttime = Input::get('Time');
						$UpdateAttendance->save();
						
						
						} else {
						
						
						$UpdateAttendance = new StudentAttandenceModel;
						$UpdateAttendance->studentid = Input::get('StudentId');
						$UpdateAttendance->toschool = $ToSchool;
						
						if (Input::get('Sender') == 'Driver')
						{
							$AttendanceType = Input::get('Attendance');
							
							if ($AttendanceType=='AM') 
							{
								
								$UpdateAttendance->busstatus = '1';
							}
							if ($AttendanceType=='PM') 
							{
								
								$UpdateAttendance->busstatus = '2';
							}
						}
						$UpdateAttendance->fromschool = $FromSchool;
						$UpdateAttendance->date = Input::get('Date');
						$UpdateAttendance->inserttime = Input::get('Time');
						$UpdateAttendance->save();
						
						
					}
					#return $ToSchool.' - '.$FromSchool;
					
					
					
					$StudentFirstName = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('PersonalFirstName');
					$StudentLastName = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('PersonalLastName');
					
					
					
					if (Input::get('Sender') == 'Parent' && ($FromSchool =='2' || $ToSchool=='2'))
					{
						
						
						$DriverName = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', $FoundTrip)->pluck('busid');
						$driver = TimingModel::where('VehicleCode', $DriverName)->pluck('DriverName');
						
						
						$DeviceType = MTIServiceDriver::where('AutoID', $driver)->pluck('DeviceType');
						$drivergcm = MTIServiceDriver::where('AutoID', $driver)->pluck('GcmId');
						
						if ($DeviceType=='ios') 
						{
							
							$Message = "The_student_".$StudentFirstName."_".$StudentLastName."_is_not_taking_today";
							$Sender = 'Driver';
							$DeviceId = $drivergcm;
							$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						else
						{
							$drivergcm = MTIServiceDriver::where('AutoID', $driver)->pluck('GcmId');   
							$PushMessage = "The student ".$StudentFirstName.' '.$StudentLastName." is not taking today"; 
							$PushMessage = "{'Title' : 'MTI Driver Alert', 'Message' : '".$PushMessage."'}"; 
							$DeviceId = array($drivergcm);
							$Message = array("price"=>urldecode($PushMessage));
							$this->PushNotification($DeviceId, $Message);
							
						}
						
						
						
						
						
						
					}
					
					if (Input::get('Sender') == 'Driver' && ($FromSchool =='2' || $ToSchool=='2'))
					{
						$PushMessage = "Your Child ".$StudentFirstName.' '.$StudentLastName." is not taking the bus today"; 
						$PushMessage = "{'Title' : 'MTI Parent Alert', 'Message' : '".$PushMessage."'}"; 
						$student = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
						
						// $DeviceType = MTIServiceDriver::where('AutoID', $driver)->pluck('DeviceType');
						// $drivergcm = MTIServiceDriver::where('AutoID', $driver)->pluck('GcmId');
						$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
						$DeviceType = MTIServiceParent::where('id', $student)->pluck('DeviceType');
						if ($DeviceType=='ios') 
						{
							$Message = "Your_Child_".$StudentFirstName."_".$StudentLastName."_is_not_taking_the_bus_today";
							$Sender = 'Parent';
							$DeviceId = $parentgcm;
							$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						else
						{
							$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
							$DeviceId = array($parentgcm);
							$Message = array("price"=>urldecode($PushMessage));
							$this->PushNotification($DeviceId, $Message);    	
						}
						
						
						
						
						
						
					}
					
					
					if (Input::get('Sender') == 'Driver' && Input::get('FromSchool')=='1')
					{
						#$PushMessage = "Your Child ".$StudentFirstName.' '.$StudentLastName." didn't get on the bus today"; 
						$student = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid'); 
						$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
						$DeviceType = MTIServiceParent::where('id', $student)->pluck('DeviceType');
						if ($DeviceType=='ios') 
						{
							$Message = "This_message_is_to_notify_you_that_your_child_".$StudentFirstName."_".$StudentLastName."_has_dropped_from_the_school_bus";
							$Sender = 'Parent';
							$DeviceId = $parentgcm;
							$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						else
						{
							
							$PushMessage = "This message is to notify you that your child ".$StudentFirstName." ".$StudentLastName." has dropped from the school bus"; 
							$PushMessage = "{'Title' : 'Boarding Alert', 'Message' : '".$PushMessage."'}"; 
							$student = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
							$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
							$DeviceId = array($parentgcm);
							$Message = array("price"=>urldecode($PushMessage));
							$this->PushNotification($DeviceId, $Message);	
						}
						
					}
					
					
					if (Input::get('Sender') == 'Driver' && Input::get('ToSchool')=='1')
					{
						#$PushMessage = "Your Child ".$StudentFirstName.' '.$StudentLastName." didn't get on the bus today"; 
						$student = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
						
						$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
						$DeviceType = MTIServiceParent::where('id', $student)->pluck('DeviceType');
						if ($DeviceType=='ios') 
						{
							$Message = "This_message_is_to_notify_you_that_your_child_".$StudentFirstName."_".$StudentLastName."_has_boarded_the_school_bus_and_is_on_the_way_to_school";
							$Sender = 'Parent';
							$DeviceId = $parentgcm;
							$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						else
						{
							
							
							
							$PushMessage = "This message is to notify you that your child ".$StudentFirstName." ".$StudentLastName." has boarded the school bus and is on the way to school"; 
							$PushMessage = "{'Title' : 'Boarding Alert', 'Message' : '".$PushMessage."'}"; 
							$student = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
							$parentgcm = MTIServiceParent::where('id', $student)->pluck('GcmId');
							$DeviceId = array($parentgcm);
							$Message = array("price"=>urldecode($PushMessage));
							$this->PushNotification($DeviceId, $Message);
						}
						
						
						
					}
					
					if (Input::get('Sender') == 'Driver')
					{
						$StudentId = Input::get('StudentId');
						
						$DriverName = TranportallocateModel::where('studentid', '=', Input::get('StudentId'))->where('triptype', '=', 'PM')->pluck('busid');
						$DriverId = TimingModel::where('VehicleCode', $DriverName)->pluck('DriverName');
						#return $DriverName;
						$DriverId = MTIServiceDriver::where('AutoID', $DriverId)->pluck('AutoID');   
						$Date = Input::get('Date');
						#return $StudentId.' - '.$DriverId.' - '.$Date;
						#return $DriverId;
						#return $FoundTrip;
						return $this->NewResponse($StudentId,$FoundTrip,Input::get('DriverId'),$Date);
						#if (Input::get('StudentId')!='' && Input::get('Trip')!='' && Input::get('DriverId')  && Input::get('Date'))
							
							$Response = array(
							'success' => '1',
							'message' => 'Success'
							);
							return json_encode($Response);          
						}
						else
						{
							$Response = array(
							'success' => '1',
							'message' => 'Success'
							);
							return json_encode($Response);          
							
						}
						
					}
					else
					{
						$Response = array(
						'success' => '0',
						'message' => 'Insufficient Data'
						);
						return json_encode($Response);       
					}
					//}
					// else
					// {
					// $Response = array(
                    // 'success' => '0',
                    // 'message' => 'Insufficient Data'
					// );
					// return json_encode($Response);       
					
					// }
					
				}
				
				
				
				
				public function NewResponse($StudentId,$Trip,$DriverId,$Date)
				{
					
					#return $DriverId;
					if ($StudentId!='' && $Trip!='' && $DriverId  && $Date)
					{
						$Driver = $DriverId;
						$StudentCount = MTIServiceStudent::where('id', '=', $StudentId)->count();       
						if ($StudentCount=='1') 
						{
							
							
							$IsDriverExist = MTIServiceDriver::where('AutoID', $DriverId)->pluck('AutoID');
							$student = $StudentId;
							$Student = $StudentId;
							
							if ($IsDriverExist=='') 
							{
								$Response = array(
								'success' => '0',
								'message' => 'Driver Not Exist');
								return json_encode($Response);
							}
							
							#workhere
							$BusId = TimingModel::where('DriverName', '=', $IsDriverExist)->pluck('VehicleCode');
							
							if ($BusId=='') 
							{
								$Response = array(
								'success' => '0',
								'message' => 'Bus Not Allocated');
								return json_encode($Response);
							}
							
							
							if ($Trip=='AM') 
							{
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								#return $TotalStudentsList;
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', $Date)->where('toschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								$TotalStudentsListFull = $TotalStudentsList;
								#Removing Marked Student3
								
								$MarkedStudents ='';
								foreach ($TotalStudentsList as $FinderKey) 
								{
									if($Trip=='AM')
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', $Date)->where('busstatus', '!=', '0')->pluck('studentid');
										
									}
									else
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', $Date)->where('busstatus', '!=', '1')->pluck('studentid');
										
									}
									
									if ($AbsentStudentsList) 
									{
										$MarkedStudents .= $AbsentStudentsList.',';
									}
								}
								$MarkedStudents = array_filter(explode(',', $MarkedStudents));
								
								$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
								#return $TotalStudentsListFull;
								$Full =  count($TotalStudentsListFull);
								$Total =  count($TotalStudentsList);
								#return $Total;
								/*
									$ShowKidsList ='[';
									foreach ($TotalStudentsList as $FinalOutputMake) 
									{
									$Student = MTIServiceStudent::where('id', '=', $FinalOutputMake)->get()->first();
									$ShowKidsList .= '{ "StudentId" : "'.$FinalOutputMake.'", "StudentName" : "'.$Student['PersonalFirstName'].' '.$Student['PersonalLastName'].'", "Lat" : "'.$Student['lat'].'", "Long" : "'.$Student['long'].'"},';
									}
									$ShowKidsList = substr($ShowKidsList, 0, -2);
									$ShowKidsList = $ShowKidsList.'}]';     
									return '{"success":"1","kids":' . $ShowKidsList . '}';
								*/
							}
							
							
							
							if ($Trip=='PM') 
							{
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								#return $TotalStudentsList;
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', $Date)->where('fromschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								$TotalStudentsListFull = $TotalStudentsList;
								#Removing Marked Student3
								
								$MarkedStudents ='';
								foreach ($TotalStudentsList as $FinderKey) 
								{
									if(Input::get('Trip')=='AM')
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', $Date)->where('busstatus', '!=', '0')->pluck('studentid');
										
									}
									else
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', $Date)->where('busstatus', '!=', '1')->pluck('studentid');
										
									}
									
									if ($AbsentStudentsList) 
									{
										$MarkedStudents .= $AbsentStudentsList.',';
									}
								}
								$MarkedStudents = array_filter(explode(',', $MarkedStudents));
								
								$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
								#return $TotalStudentsListFull;
								$Full =  count($TotalStudentsListFull);
								$Total =  count($TotalStudentsList);
								
							}
							
							
							
							#########3333
							#$StudentName = $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'];
							#$Address = $StudentData['House'].' '.$StudentData['Apartment'].' '.$StudentData['Street'].' '.$StudentData['ContactCity'].' '.$StudentData['ContactState'];
							return '{"success":"1", "total": "'.$Total.'", "full": "'.$Full.'"}'; 
							
							#return $Attendance;
							
							
							
							exit();
							
							/*
								$Response = array(
								'success' => '1',
								'studentname' => $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'],
								'grade' => $StudentData['StudentCourse'],
								'parentname' => $ParentName,
								'address' => ,
								'triptype' =>  $StudentData['TripType'],
								'totriptype' =>  $StudentData['fromTripType'],
								'starttime' =>  $StudentData[$StartTime],
								'endtime' =>  $StudentData[$EndTime],
								'attendance' =>  $Attendance,
								'success' => '1'
								);
								return json_encode($Response);
							*/ 
						} else 
						{
							$Response = array(
							'success' => '0',
							'message' => 'Student Not Found');
							
							return json_encode($Response);
						}
					}
					else
					{
						$Response = array(
						'success' => '0',
						'message' => 'Insufficient Data');
						return json_encode($Response);
					}
					
				}
				
				
				
				
				public function AlertParent()
				{
					if (Input::get('StudentId') != '' && Input::get('Message') != '' ) 
					{      
						$IsStudntExist = MTIServiceStudent::where('id', Input::get('StudentId'))->count();
						if ($IsStudntExist=='1') 
						{
							$Parent = MTIServiceStudent::where('id', Input::get('StudentId'))->pluck('parentid');
							$ParentGCM = MTIServiceParent::where('id', $Parent)->pluck('GcmId');
							
							#here
							#$PushMessage = Input::get('Message'); 
							
							$parentgcm = MTIServiceParent::where('id', $Parent)->pluck('GcmId');
							$DeviceType = MTIServiceParent::where('id', $Parent)->pluck('DeviceType');
							if ($DeviceType=='ios') 
							{
								$Message = Input::get('Message');
								$Message = str_replace(" ", "_", $Message);
								$Sender = 'Parent';
								$DeviceId = $parentgcm;
								$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
								$Response = array(
								'success' => '1',
								'message' => 'Success'
								);
							}
							else
							{
								
								
								$PushMessage = "{'Title' : 'MTI Bus Started', 'Message' : '".Input::get('Message')."'}"; 
								$DeviceId = array($ParentGCM);
								$Message = array("price"=>urldecode($PushMessage));
								$this->PushNotification($DeviceId, $Message);
								$Response = array(
								'success' => '1',
								'message' => 'Success'
								);
							}
							return json_encode($Response);  
							
							
						}
						else
						{
							$Response = array(
							'success' => '0',
							'message' => 'Student Not Found'
							);
							return json_encode($Response);       
							
						}
					}
					else
					{
						$Response = array(
						'success' => '0',
						'message' => 'Insufficient Data'
						);
						return json_encode($Response);       
						
					}
					
				}
				
				public function GetDriverLocationParent()
				{
					
					
					if (Input::get('ParentId') != '' && Input::get('TripType') != '' ) 
					{  
						
						$StudentData = MTIServiceStudent::where('parentid', Input::get('ParentId'))->get();
						
						$LatLong = '';
						foreach ($StudentData as $key) 
						{
							
							$VehicleNumber = TranportallocateModel::where('studentid', $key->id)->pluck('busid');
							$BusId = TimingModel::where('VehicleCode', '=', $VehicleNumber)->pluck('VehicleCode');
							
							
							if ($BusId) 
							{
								$Vehicle = VehicleLocation::where('VehicleId', $BusId)->get()->first();
								$LatLong .= '{"Bus" : "'.$VehicleNumber.'", "Lat" : "'.$Vehicle['Lat'].'", "Long" : "'.$Vehicle['Long'].'"},';
							} else 
							{
								$LatLong .= '{"Bus" : "'.$VehicleNumber.'", "Lat" : "0", "Long" : "0"},';
							}        
						}
						
						
						
						$LatLong = substr($LatLong, 0, -1);
						
						#return $LatLong;
						
						
						$LatLong = '['.$LatLong.']';
						;
						if ($LatLong=='[]') 
						{
							$Response   = array(
							'success' => '0',
							'message' => 'Bus Not Found'
							);    
							return $Response;
						} else 
						{
							$LatLong = json_decode($LatLong,true);
							$LatLong = array_map("unserialize", array_unique(array_map("serialize", $LatLong)));
							
							
							$ParentLat = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('lat');
							$ParentLong = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('long');
							
							
							// $PLatLong = '{"Bus" : "'.$VehicleNumber.'", "Lat" : "'.$ParentLat.'", "Long" : "'.$ParentLong.'"},';
							// $PLatLong = substr($PLatLong, 0, -1);
							// $PLatLong = '['.$PLatLong.']';
							// $PLatLong = json_decode($PLatLong,true);
							// $PLatLong = array_map("unserialize", array_unique(array_map("serialize", $PLatLong)));
							return '{"success":"1","busdata":' . json_encode($LatLong) . ',"parentlat":"' . $ParentLat .'","parentlong":"'.$ParentLong.'"}';
						}
						
					}
					else
					{
						$Response   = array(
						'success' => '0',
						'message' => 'Insufficient Data'
						);    
						return $Response;
					}
					
					
					return $newfinal;
					
					
					
					
					
					
					
					
					
					
					return $busid.' - '.$latbus;
					
					
					/*
						#Checks if the DeviceId matches any Record in the Parent Information Table
						$ParentData = MTIServiceParent::where('id', Input::get('ParentId'))->pluck('id');
						if ($ParentData) 
						{       
						$StudentDataCount = MTIServiceStudent::where('parentid', Input::get('ParentId'))->count();
						$StudentData = MTIServiceStudent::where('parentid', Input::get('ParentId'))->get();
						$Student = '';
						$BusId = '';       
						
						$arrayName = array('val' => 1,2,3 );
						
						foreach ($StudentData as $key) 
						{
						$Student .=$key->id.',';
						
						$Bus = TranportallocateModel::whereIn('id',  $arrayName)->get();
						
						$BusId .=$Bus;
						}
						
						
						return $BusId;
						
						
						
						return DB::getQueryLog();
						
						return $Student.' - '.$BusId;
						#return $Student;
						
						
						
						$Response   = array(
						'success' => '1',
						'parent_id' => $StudentParentData
						);
						return $Response;
						}
						else
						{
						$Response   = array(
						'success' => '0',
						'parent_id' => 'Parent Not Found'
						);    
						return $Response;
						}
					*/
					
				}
				
				
				
				############# Bus Operator Web Service ############################
				
				
				
				public function CheckBusOperatorDevice()
				{
					#Checks if the Bus OperatorId matches any Record in the Driver Information Table
					$DriverId = MTIServiceDriver::where('DeviceId', Input::get('DeviceId'))->where('LoginStatus', '1')->pluck('AutoId');
					if ($DriverId) 
					{
						$Response   = array(
						'success' => '1',
						'driver_id' => $DriverId
						);
						return $Response;
					}
					else
					{
						$Response   = array(
						'success' => '0',
						#            'driver_id' => 'Bus Not Found'
						);    
						return $Response;
					}
				}
				
				public function AuthenticateBusOperator()
				{
					
					if(Input::get('UniqueCode')!='' && Input::get('DeviceId')!='' && Input::get('GcmId')!='') 
					{
						
						#Updates the DeviceId, GcmId with the matching Record in the Driver Table
						$DriverId = MTIServiceDriver::where('UniqueCode', Input::get('UniqueCode'))->pluck('AutoId');        
						if ($DriverId) {
							#Update the DeviceId and GCMId of the Device in the Driver Table
							$DriverData = Input::all();
							
							if(Input::get('UniqueCode')!='' || Input::get('DeviceId')!='') 
							{
								$RiderUpdate = MTIServiceDriver::where('UniqueCode', Input::get('UniqueCode'))->first();
								$RiderUpdate->DeviceId = Input::get('DeviceId');
								$RiderUpdate->GcmId = Input::get('GcmId');
								$RiderUpdate->LoginStatus = 1;
								if (Input::get('DeviceType')=='ios') 
								{
									$RiderUpdate->DeviceType    = 'ios';    
								}
								else
								{
									$RiderUpdate->DeviceType    = '';   
								}
								$RiderUpdate->save();
								$Response = array(
								'success' => '1',
								'driver_id' => $DriverId
								);
								return json_encode($Response);
								
							}
							else {
								$Response = array(
								'success' => '0',
								'message' => 'The Unique Code does not match with a Registered Driver at MTI'
								);
								return json_encode($Response);
							}
							
							} else {
							$Response = array(
							'success' => '0',
							'message' => 'The Unique Code does not match with a Registered Driver at MTI'
							);
							return json_encode($Response);
						}
					}
					else
					{
						$Response = array(
						'success' => '0',
						'message' => 'Insufficient Data'
						);
						return json_encode($Response);
						
					}
				}
				
				
				
				public function ShowDriverNotification()
				{
					$IsParentExist = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->pluck('AutoId');
					if ($IsParentExist) {
						$ParentData = MTIServiceDriver::find($IsParentExist);
						$Response   = array(
						'success' => '1',
						'pushnotify' => ''.$ParentData->MobileNotification.'',
						'emailnotify' => ''.$ParentData->EmailNotification.''
						);
						return json_encode($Response);
						} else {
						$Response = array(
						'success' => '0',
						'message' => 'Driver Not Found'
						);
						return json_encode($Response);
					}
					
				}
				
				
				
				
				public function UpdateDriverNotification()
				{
					
					if(Input::get('DriverId')!='' && Input::get('EmailNotification')!='' && Input::get('MobileNotification')!='') 
					{
						
						$IsParentExist = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->pluck('AutoId');
						if ($IsParentExist) {
							$ParentData           = Input::all();
							$NotificationUpdate = MTIServiceDriver::where('AutoId', Input::get('DriverId'))->first();        
							$NotificationUpdate->EmailNotification = Input::get('EmailNotification');
							$NotificationUpdate->MobileNotification = Input::get('MobileNotification');
							$NotificationUpdate->save();
							$Response = array(
							'success' => '1'
                            );
							return json_encode($Response);   
						}
						else
						{
							$Response = array(
							'success' => '0',
							'message' => 'Parent Not Exist'
                            );
							return json_encode($Response);   
						}
						
						
					}
					else
					{
						
						$Response = array(
						'success' => '0',
						'message' => 'Insufficient Data'
						);
						return json_encode($Response);   
					}
					
					
				}
				
				
				public function UpdateDriverLocation()
				{   
					
					if(Input::get('driver_id') && Input::get('Lat')!='' && Input::get('Long')!='') #If all three parameters were given
					{
						
						$DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
						if ($DriverCount=='1') 
						{
							$DriverUpdate = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->first();
							$DriverUpdate->Lat = Input::get('Lat');
							$DriverUpdate->Long = Input::get('Long');
							$DriverUpdate->save();
							$Response = array('success' => '2','message' => 'Updated');
							return json_encode($Response);
						}
						else
						{
							$Response = array('success' => '1','message' => 'Driver Not Found');
							return json_encode($Response);
						}
					}
					else
					{
						$Response = array('success' => '0','message' => 'Insufficient Data');
						return json_encode($Response);   
					}
				}
				
				
				public function ShowDriverProfile()
				{
					$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
					if ($IsDriverExist) {
						$DriverData = MTIServiceDriver::find($IsDriverExist);
						$Response   = array(
						'success' => '1',
						'name' => $DriverData->DriverName,
						'mobile' => $DriverData->Mobile,
						'email' => $DriverData->Email,
						'address' => $DriverData->Address,
						'age' => $DriverData->Age
						
						);
						return json_encode($Response);
						} else {
						$Response = array(
						'success' => '0',
						'message' => 'No Driver Found'
						);
						return json_encode($Response);
					}
				}
				
				
				public function UpdateDriverProfile()
				{
					$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
					if ($IsDriverExist) {
						$DriverData           = Input::all();
						$ParentDataValidation = Validator::make($DriverData, MTIServiceDriver::$driverupdaterule);
						if ($ParentDataValidation->passes()) {
							$ParentUpdate = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->first();
							$ParentUpdate->DriverName = Input::get('DriverName');
							$ParentUpdate->Email = Input::get('Email');
							$ParentUpdate->Mobile = Input::get('Mobile');
							$ParentUpdate->Address = Input::get('Address');
							$ParentUpdate->save();
							$Response = array(
							'success' => '1',
							'message' => 'Profile Updated Succesfully'
							
                            );
                            return json_encode($Response);
						}
						else {
							$Response = array(
							'success' => '0',
							#'errors' => $ParentDataValidation->messages()
							'message' => 'Insufficient Data'
							);
							return json_encode($Response);
						}
						
						
						
						} else {
						$Response = array(
						'success' => '0',
						'message' => 'No User Found'
						);
						return json_encode($Response);
					}
				}
				
				
				
				
				public function KidsonMap()
				{
					
					if (Input::get('Trip')!='' && Input::get('DriverId')!='' && Input::get('Date')!='') 
					{	
						$BusId = TimingModel::where('DriverName', '=', Input::get('DriverId'))->pluck('VehicleCode');        
						
						
						if (Input::get('Trip')=='AM') 
						{
							$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
							$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
							#return $BusId;
							$TotalStudentsList ='';
							foreach ($TotalStudentsById as $TotKey)
							{
								$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
								$TotalStudentsList .= $TotalStudentsLists.',';
							}
							
							$TotalStudentsListCount = $TotalStudentsList;
							$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
							
							
							
							if($TotalStudentsListCount=='')
							{
								$Response = array(
								'success' => '0',
								'message' => 'No Bus Not Allocated');
								return json_encode($Response);
							}
							#Removing Absentees
							$AbsentStudents ='';
							foreach ($TotalStudents as $FinderKey) 
							{
								$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('toschool', '=', '2')->pluck('studentid');
								
								if ($AbsentStudentsList) 
								{
									$AbsentStudents .= $AbsentStudentsList.',';
								}
							}
							$AbsentStudents = array_filter(explode(',', $AbsentStudents));
							
							$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
							#Removing Marked Student1
							$MarkedStudents ='';
							foreach ($TotalStudentsList as $FinderKey) 
							{
								$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '0')->pluck('studentid');
								
								if ($AbsentStudentsList) 
								{
									$MarkedStudents .= $AbsentStudentsList.',';
								}
							}
							$MarkedStudents = array_filter(explode(',', $MarkedStudents));
							#return $MarkedStudents;
							$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
							
							$ShowKidsList ='[';
							foreach ($TotalStudentsList as $FinalOutputMake) 
							{
								
								
								$SchoolIDforLat = $FinalOutputMake;
								
								if($SchoolIDforLat)
								{
									$SchoolName = StudentAdmissionModel::where('id', '=', $FinalOutputMake)->pluck('SchoolName');
									$SchoolLat = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lat');
									$SchoolLong = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lon');
								}
								
								
								
								$Student = MTIServiceStudent::where('id', '=', $FinalOutputMake)->get()->first();
								$ShowKidsList .= '{ "StudentId" : "'.$FinalOutputMake.'", "StudentName" : "'.$Student['PersonalFirstName'].' '.$Student['PersonalLastName'].'", "Lat" : "'.$Student['lat'].'", "Long" : "'.$Student['long'].'"},';
							}
							$ShowKidsList = substr($ShowKidsList, 0, -2);
							
							
							
							$FirstStudent = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->first();
							$SchoolName =  $FirstStudent['schoolid'];
							$SchoolLat = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lat');
							$SchoolLong = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lon');
							$SchoolData = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->first();
							
							#return $FirstStudent;
							$Meter = 300;
							if ($ShowKidsList!='') 
							{
								$ShowKidsList = $ShowKidsList.'}]';     
								return '{"success":"1","kids":' . $ShowKidsList .',"lat":"'.$SchoolLat.'","long":"'.$SchoolLong.'","meter":"'.$Meter.'"}';
							}
							else
							{
								return '{"success":"1","kids":[],"lat":"'.$SchoolLat.'","long":"'.$SchoolLong.'","meter":"'.$Meter.'"}';
								
							}
							
							
							
						}
						
						if (Input::get('Trip')=='PM') 
						{
							$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
							$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
							
							$TotalStudentsList ='';
							foreach ($TotalStudentsById as $TotKey)
							{
								$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
								$TotalStudentsList .= $TotalStudentsLists.',';
							}
							
							$TotalStudentsListCount = $TotalStudentsList;
							$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
							
							#return $TotalStudentsList;
							
							if($TotalStudentsListCount=='')
							{
								$Response = array(
								'success' => '0',
								'message' => 'No Bus Not Allocated');
								return json_encode($Response);
							}
							#Removing Absentees
							$AbsentStudents ='';
							foreach ($TotalStudents as $FinderKey) 
							{
								$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
								
								if ($AbsentStudentsList) 
								{
									$AbsentStudents .= $AbsentStudentsList.',';
								}
							}
							$AbsentStudents = array_filter(explode(',', $AbsentStudents));
							$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
							#Removing Marked Student2
							
							$MarkedStudents ='';
							foreach ($TotalStudentsList as $FinderKey) 
							{
								$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '=', '2')->pluck('studentid');
								
								
								if ($AbsentStudentsList) 
								#if ($AbsentStudentsList) 
									{
										$MarkedStudents .= $AbsentStudentsList.',';
									}
								}
								$MarkedStudents = array_filter(explode(',', $MarkedStudents));
								#return $MarkedStudents;    
								$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
								
								$ShowKidsList ='[';
								foreach ($TotalStudentsList as $FinalOutputMake) 
								{
									
									
									$Student = MTIServiceStudent::where('id', '=', $FinalOutputMake)->get()->first();
									
									$SchoolIDforLat = $FinalOutputMake;
									
									if($SchoolIDforLat)
									{
										$SchoolName = StudentAdmissionModel::where('id', '=', $FinalOutputMake)->pluck('SchoolName');
										$SchoolLat = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lat');
										$SchoolLong = GeneralSettingModel::where('id', '=', $SchoolName)->pluck('lon');
									}
									
									
									
									
									
									
									$ShowKidsList .= '{ "StudentId" : "'.$FinalOutputMake.'", "StudentName" : "'.$Student['PersonalFirstName'].' '.$Student['PersonalLastName'].'", "Lat" : "'.$Student['lat'].'", "Long" : "'.$Student['long'].'"},';
								}
								$ShowKidsList = substr($ShowKidsList, 0, -2);
								
								$Meter = 300;
								if ($ShowKidsList!='') 
								{
									$ShowKidsList = $ShowKidsList.'}]';     
									return '{"success":"1","kids":' . $ShowKidsList .',"lat":"'.$SchoolLat.'","long":"'.$SchoolLong.'","meter":"'.$Meter.'"}';
								}
								else
								{
									return '{"success":"1","kids":[],"lat":"'.$SchoolLat.'","long":"'.$SchoolLong.'","meter":"'.$Meter.'"}';
								}
								
								
								#return '{"success":"1","kids":' . $ShowKidsList . '}';
								
							}
							
							
							
						}
						else
						{
							$Response = array(
							'success' => '0',
							'message' => 'Insufficient Data');
							return json_encode($Response);
						}
						
						
					}
					
					
					
					
					
					
					
					public function DriverLatLong()
					{
						if (Input::get('DriverId')!='' && Input::get('Lat')!='' && Input::get('Long')!='')
						{
							$Driver = VehicleLocation::where('DriverId', '=', Input::get('DriverId'))->count(); 
							if ($Driver=='1') 
							{
								
								$DriverUpdate           = VehicleLocation::where('DriverId', Input::get('DriverId'))->first();
								$DriverUpdate->Lat = Input::get('Lat');
								$DriverUpdate->Long    = Input::get('Long');
								$DriverUpdate->save();
								$Response = array(
								'success' => '1',
								
								);
								return json_encode($Response);
								
							}
							else
							{
								$Response = array(
								'success' => '0',
								'message' => 'Driver Not Found'
								);
								return json_encode($Response);
							}
						}
						else
						{
							$Response = array(
							'success' => '0',
							'message' => 'Insufficient Data'
							);
							return json_encode($Response);
						}
						
					}
					
					
					
					public function GetStudentDetail()
					{
						#return 'a';
						
						if (Input::get('StudentId')!='' && Input::get('Trip')!='' && Input::get('DriverId')  && Input::get('Date'))
						{
							$StudentCount = MTIServiceStudent::where('id', '=', Input::get('StudentId'))->count();       
							if ($StudentCount=='1') 
							{
								
								
								$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
								
								if ($IsDriverExist=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Driver Not Exist');
									return json_encode($Response);
								}
								
								#workhere
								$BusId = TimingModel::where('DriverName', '=', $IsDriverExist)->pluck('VehicleCode');
								
								if ($BusId=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Bus Not Allocated');
									return json_encode($Response);
								}
								
								
								if (Input::get('Trip')=='AM') 
								{
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
									$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
									
									$TotalStudentsList ='';
									foreach ($TotalStudentsById as $TotKey)
									{
										$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
										$TotalStudentsList .= $TotalStudentsLists.',';
									}
									
									$TotalStudentsListCount = $TotalStudentsList;
									$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
									
									#return $TotalStudentsList;
									
									if($TotalStudentsListCount=='')
									{
										$Response = array(
										'success' => '0',
										'message' => 'No Bus Not Allocated');
										return json_encode($Response);
									}
									#Removing Absentees
									$AbsentStudents ='';
									foreach ($TotalStudents as $FinderKey) 
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('toschool', '=', '2')->pluck('studentid');
										
										if ($AbsentStudentsList) 
										{
											$AbsentStudents .= $AbsentStudentsList.',';
										}
									}
									$AbsentStudents = array_filter(explode(',', $AbsentStudents));
									$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
									$TotalStudentsListFull = $TotalStudentsList;
									#Removing Marked Student3
									
									$MarkedStudents ='';
									foreach ($TotalStudentsList as $FinderKey) 
									{
										if(Input::get('Trip')=='AM')
										{
											$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '0')->pluck('studentid');
											
										}
										else
										{
											$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '1')->pluck('studentid');
											
										}
										
										if ($AbsentStudentsList) 
										{
											$MarkedStudents .= $AbsentStudentsList.',';
										}
									}
									$MarkedStudents = array_filter(explode(',', $MarkedStudents));
									
									$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
									#return $TotalStudentsListFull;
									$Full =  count($TotalStudentsListFull);
									$Total =  count($TotalStudentsList);
									#return $Total;
									/*
										$ShowKidsList ='[';
										foreach ($TotalStudentsList as $FinalOutputMake) 
										{
										$Student = MTIServiceStudent::where('id', '=', $FinalOutputMake)->get()->first();
										$ShowKidsList .= '{ "StudentId" : "'.$FinalOutputMake.'", "StudentName" : "'.$Student['PersonalFirstName'].' '.$Student['PersonalLastName'].'", "Lat" : "'.$Student['lat'].'", "Long" : "'.$Student['long'].'"},';
										}
										$ShowKidsList = substr($ShowKidsList, 0, -2);
										$ShowKidsList = $ShowKidsList.'}]';     
										return '{"success":"1","kids":' . $ShowKidsList . '}';
									*/
								}
								
								
								
								if (Input::get('Trip')=='PM') 
								{
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
									$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
									
									$TotalStudentsList ='';
									foreach ($TotalStudentsById as $TotKey)
									{
										$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
										$TotalStudentsList .= $TotalStudentsLists.',';
									}
									
									$TotalStudentsListCount = $TotalStudentsList;
									$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
									
									#return $TotalStudentsList;
									
									if($TotalStudentsListCount=='')
									{
										$Response = array(
										'success' => '0',
										'message' => 'No Bus Not Allocated');
										return json_encode($Response);
									}
									#Removing Absentees
									$AbsentStudents ='';
									foreach ($TotalStudents as $FinderKey) 
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
										
										if ($AbsentStudentsList) 
										{
											$AbsentStudents .= $AbsentStudentsList.',';
										}
									}
									$AbsentStudents = array_filter(explode(',', $AbsentStudents));
									$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
									$TotalStudentsListFull = $TotalStudentsList;
									#Removing Marked Student3
									
									$MarkedStudents ='';
									foreach ($TotalStudentsList as $FinderKey) 
									{
										if(Input::get('Trip')=='AM')
										{
											$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '0')->pluck('studentid');
											
										}
										else
										{
											$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '1')->pluck('studentid');
											
										}
										
										if ($AbsentStudentsList) 
										{
											$MarkedStudents .= $AbsentStudentsList.',';
										}
									}
									$MarkedStudents = array_filter(explode(',', $MarkedStudents));
									
									$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
									#return $TotalStudentsListFull;
									$Full =  count($TotalStudentsListFull);
									$Total =  count($TotalStudentsList);
									
								}
								
								#lastchange
								
								
								$StartTime =  date('l').'InTime';
								
								$EndTime =  date('l').'outTime';    
								########
								
								
								$Intime="";
								$outtime="";
								$timingarray= array();
								
								$timingseconarray= array();
								#lastchange
								$dayname=date('l');
								#$dayname="Friday";
								
								$weekdays= array("0"=>"Monday", "1"=>"Tuesday","2"=>"Wednesday","3"=>"Thursday","4"=>"Friday");
								
								##Input::get('StudentId')
								$StudentData = MTIServiceStudent::where('id', '=', Input::get('StudentId'))->get()->ToArray();
								
								
								foreach($StudentData as $StudentAdmissionDetailvalue)
								{
									
									
									if($StudentAdmissionDetailvalue['timingoption']==1)
									
									{
										
										$start=$dayname;
										#$start="Friday";
										
										
										
										
										$startkey = array_search($start, $weekdays);
										
										if($start!='')
										{
											
											$timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];
											
											$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];
											
											$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];
											
											$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
											
											$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];
											
											$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
											
											$timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];
											
											$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];
											
											$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];
											
											$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];
											
											for($i=$startkey;$i<=$start;$i++)
											
											{
												
												$timingarray['In'.$i]=$StudentAdmissionDetailvalue['weekInTime'];
												
												$timingarray['Out'.$i]=$StudentAdmissionDetailvalue['weekoutTime'];
												
											}   
											} else {
											
											$timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];
											
											$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];
											
											$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];
											
											$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
											
											$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];
											
											$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
											
											$timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];
											
											$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];
											
											$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];
											
											$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];
										}
										
										
										} else {
										
										$timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];
										
										$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];
										
										$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];
										
										$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];
										
										$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];
										
										$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];
										
										$timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];
										
										$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];
										
										$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];
										
										$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];
										
										
										
									}
									if($dayname=="Monday")
									{
										$Intime=$timingarray['In0'];
										$outtime=$timingarray['Out0'];
									}
									if($dayname=="Tuesday")
									{
										$Intime=$timingarray['In1'];
										$outtime=$timingarray['Out1'];
									}
									if($dayname=="Wednesday")
									{
										$Intime=$timingarray['In2'];
										$outtime=$timingarray['Out2'];
									}
									if($dayname=="Thursday")
									{
										$Intime=$timingarray['In3'];
										$outtime=$timingarray['Out3'];
									}
									if($dayname=="Friday")
									{
										$Intime=$timingarray['In4'];
										$outtime=$timingarray['Out4'];
									}
									
								}
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								########
								
								#return $EndTime;
								#Attendance Calculation starts
								$Attendance = '1';
								$dt_min = new DateTime("Monday this week");
								$dt_max = clone($dt_min);
								$dt1 = clone($dt_min);
								$dt2 = clone($dt_min);
								$dt3 = clone($dt_min);
								$dt4 = clone($dt_min);
								$dt_max->modify('+4 days');
								$dt1->modify('+1 days');
								$dt2->modify('+2 days');
								$dt3->modify('+3 days');
								$dt4->modify('+4 days');
								
								$Attendance = '{';
								$Monday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt_min->format('Y-m-d'))->first();
								if($Monday)
								{
									$Attendance .= '"MondayIn" : "'.$Monday['toschool'].'", "MondayOut" : "'.$Monday['fromschool'].'",';
								}
								$Tuesday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt1->format('Y-m-d'))->first();
								if($Tuesday)
								{
									$Attendance .= '"TuesdayIn" : "'.$Tuesday['toschool'].'", "TuesdayOut" : "'.$Tuesday['fromschool'].'",';
								}
								$Wednesday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt2->format('Y-m-d'))->first();
								if($Wednesday)
								{
									$Attendance .= '"WednesdayIn" : "'.$Wednesday['toschool'].'", "WednesdayOut" : "'.$Wednesday['fromschool'].'",';
								}
								$Thursday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt3->format('Y-m-d'))->first();
								if($Thursday)
								{
									$Attendance .= '"ThursdayIn" : "'.$Thursday['toschool'].'", "ThursdayOut" : "'.$Thursday['fromschool'].'",';
								}
								$Friday = StudentAttandenceModel::where('studentid', '=', Input::get('StudentId'))->where('date', '=', $dt4->format('Y-m-d'))->first();
								if($Friday)
								{
									$Attendance .= '"FridayIn" : "'.$Friday['toschool'].'", "FridayOut" : "'.$Friday['fromschool'].'",';
								}
								$Attendance .= '}';
								$Attendance = substr($Attendance, 0, -2);
								$Attendance = $Attendance.'}';          
								#Attendance Calculation Ends
								$StudentData = MTIServiceStudent::where('id', '=', Input::get('StudentId'))->first();
								$ParentName = MTIServiceParent::where('id', '=', $StudentData['parentid'])->pluck('FirstName'); 
								$ParentPhone = MTIServiceParent::where('id', '=', $StudentData['parentid'])->pluck('Mobile'); 
								
								$Timing = TimingModel::where('DriverName', '=', Input::get('DriverId'))->first();   
								$StudentName = $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'];
								$Address = $StudentData['Address'];
								
								if ($Attendance=='}')
								{
									#return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$StudentData[$StartTime].'", "endtime" : "'.$StudentData[$EndTime].'", "total": "'.$Total.'", "full": "'.$Full.'"}'; 
									return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$Intime.'", "endtime" : "'.$outtime.'", "total": "'.$Total.'", "full": "'.$Full.'"}'; 
								} 
								else 
								{
									#return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$StudentData[$StartTime].'", "endtime" : "'.$StudentData[$EndTime].'", "attendance": '.$Attendance.', "total": "'.$Total.'", "full": "'.$Full.'"}';
									return '{"success":"1","parentphone":"'.$ParentPhone.'","studentname": "'.$StudentName.'", "grade": "' .$StudentData['StudentCourse'].'", "parentname": "'.$ParentName.'", "address": "'.$Address.'", "triptype": "'.$StudentData['TripType'].'","totriptype": "'.$StudentData['fromTripType'].'","starttime": "'.$Intime.'", "endtime" : "'.$outtime.'", "attendance": '.$Attendance.', "total": "'.$Total.'", "full": "'.$Full.'"}';
								}
								
								#return $Attendance;
								
								
								
								exit();
								
								/*
									$Response = array(
									'success' => '1',
									'studentname' => $StudentData['PersonalFirstName'].' '.$StudentData['PersonalLastName'],
									'grade' => $StudentData['StudentCourse'],
									'parentname' => $ParentName,
									'address' => ,
									'triptype' =>  $StudentData['TripType'],
									'totriptype' =>  $StudentData['fromTripType'],
									'starttime' =>  $StudentData[$StartTime],
									'endtime' =>  $StudentData[$EndTime],
									'attendance' =>  $Attendance,
									'success' => '1'
									);
									return json_encode($Response);
								*/ 
							} else 
							{
								$Response = array(
								'success' => '0',
								'message' => 'Student Not Found');
								
								return json_encode($Response);
							}
						}
						else
						{
							$Response = array(
							'success' => '0',
							'message' => 'Insufficient Data');
							return json_encode($Response);
						}
						
					}
					
					public function ShowTotalPickUp()
					{
						
						$BusId = TimingModel::where('DriverName', '=', Input::get('DriverId'))->pluck('VehicleCode');
						if ($BusId!='') 
						{
							
							
							$VehicleAMCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->count();
							if ($VehicleAMCount>=1) 
							{
								$DriverDataAM = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('toschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								
								#Removing Marked Student4
								$MarkedStudents ='';
								foreach ($TotalStudentsList as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '1')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$MarkedStudents .= $AbsentStudentsList.',';
									}
								}
								$MarkedStudents = array_filter(explode(',', $MarkedStudents));
								
								$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
								#return $TotalStudentsList;
								$AmCount = count($TotalStudentsList);
							}
							else
							{
								$AmCount = '0';
							}
							
							
							
							
							
							
							$VehiclePMCount = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->count();
							if ($VehiclePMCount>=1) 
							{
								$DriverDataAM = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								#return $TotalStudentsList;
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								#Removing Marked Student5
								$MarkedStudents ='';
								foreach ($TotalStudentsList as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$MarkedStudents .= $AbsentStudentsList.',';
									}
								}
								$MarkedStudents = array_filter(explode(',', $MarkedStudents));
								
								$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
								
								$PmCount = count($TotalStudentsList);
							}
							else
							{
								$PmCount = '0';
							}
							
							$DriverData = TranportallocateModel::where('busid', '=', $BusId)->first();
							$VehicleCode = VehicleModel::where('AutoID', '=', $DriverData['busid'])->first();
							$Timing = TimingModel::where('DriverName', '=', Input::get('DriverId'))->first();
							
							
							
							
							
							
							
							$Trips = 'AM';
							
							#if (Input::get('Trip')=='AM') 
								if ($Trips=='AM') 
								{
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
									$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
									
									$TotalStudentsList ='';
									foreach ($TotalStudentsById as $TotKey)
									{
										$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
										$TotalStudentsList .= $TotalStudentsLists.',';
									}
									
									
									$TotalStudentsListCount = $TotalStudentsList;
									$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
									
									
									
									if($TotalStudentsListCount=='')
									{
										$Response = array(
										'success' => '0',
										'message' => 'No Bus Not Allocated');
										#  return json_encode($Response);
									}
									#Removing Absentees
									
									$AbsentStudents ='';
									foreach ($TotalStudents as $FinderKey) 
									{
										
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('toschool', '=', '2')->pluck('studentid');
										
										if ($AbsentStudentsList) 
										{
											$AbsentStudents .= $AbsentStudentsList.',';
										}
									}
									$AbsentStudents = array_filter(explode(',', $AbsentStudents));
									#return $AbsentStudents;
									$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
									$TotalStudentsListFull = $TotalStudentsList;
									
									#return $TotalStudentsListFull;
									#Removing Marked Student3
									
									$MarkedStudents ='';
									foreach ($TotalStudentsList as $FinderKey) 
									{
										
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '!=', '0')->pluck('studentid');
										
										
										if ($AbsentStudentsList) 
										{
											$MarkedStudents .= $AbsentStudentsList.',';
										}
									}
									
									$MarkedStudents = array_filter(explode(',', $MarkedStudents));
									
									$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
									
									$AMFull =  count($TotalStudentsListFull);
									$AMTotal =  count($TotalStudentsList);
									
								}
								
								
								
								
								$Trips = 'PM';
								
								
								if ($Trips=='PM') 
								{
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
									$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
									
									$TotalStudentsList ='';
									foreach ($TotalStudentsById as $TotKey)
									{
										$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
										$TotalStudentsList .= $TotalStudentsLists.',';
									}
									
									$TotalStudentsListCount = $TotalStudentsList;
									$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
									
									#return $TotalStudentsList;
									
									if($TotalStudentsListCount=='')
									{
										$Response = array(
										'success' => '0',
										'message' => 'No Bus Not Allocated');
										#    return json_encode($Response);
									}
									#Removing Absentees
									$AbsentStudents ='';
									foreach ($TotalStudents as $FinderKey) 
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
										if ($AbsentStudentsList) 
										{
											$AbsentStudents .= $AbsentStudentsList.',';
										}
									}
									$AbsentStudents = array_filter(explode(',', $AbsentStudents));
									
									$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
									$TotalStudentsListFull = $TotalStudentsList;
									#Removing Marked Student3
									#return $AbsentStudents;
									
									$MarkedStudents ='';
									foreach ($TotalStudentsList as $FinderKey) 
									{
										
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey)->where('date', '=', Input::get('Date'))->where('busstatus', '=', '2')->pluck('studentid');
										
										if ($AbsentStudentsList) 
										{
											$MarkedStudents .= $AbsentStudentsList.',';
										}
									}
									$MarkedStudents = array_filter(explode(',', $MarkedStudents));
									#return $MarkedStudents;
									$TotalStudentsList =  array_diff($TotalStudentsList, $MarkedStudents);
									
									
									
									$PMFull =  count($TotalStudentsListFull);
									$PMTotal =  count($TotalStudentsList);
									
								}
								
								#return $MarkedStudents;
								
								
								
								
								
								
								
								
								$Response = array(
								'success' => '1',
								'vehiclecode' => $VehicleCode['VehicleCode'],
								'vehiclenumber' => $VehicleCode['VehicleNumber'],
								'amlist' => $AmCount,
								'pmlist' => $PmCount,
								'starttime' => $Timing['StartTime'],
								'endtime' => $Timing['EndTime'],
								'amfull' => $AMFull,
								'amtotal' => $AMTotal,
								'pmfull' => $PMFull,
								'pmtotal' => $PMTotal,
								
								
								
								
								);
								return json_encode($Response);
								
								
								
								
								#	return $AmCount.' - '.$PmCount;
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								return $VehicleAMCount;
							}
							else
							{
								$Response = array(
								'success' => '0',
								'message' => 'Insufficient Data');
								return json_encode($Response);
							}
							
							
						}
						
						
						
						public function GetDriverLocation()
						{   
							
							if(Input::get('driver_id')) #If all three parameters were given
							{
								$DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
								$DriverCount = VehicleLocation::where('DriverId', '=', Input::get('driver_id'))->count();
								if ($DriverCount=='1') 
								{
									
									$DriverData = VehicleLocation::select('Lat','Long')->where('DriverId', '=', Input::get('driver_id'))->get();
									$Response = array('success' => '1','lat' => $DriverData[0]->Lat, 'long' => $DriverData[0]->Long);
									
									$RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$DriverData[0]->Lat.','.$DriverData[0]->Long."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";  
									$GoogleApiResult = file_get_contents($RequestUrl);
									$GoogleApiResultDecoded = json_decode($GoogleApiResult);
									if($GoogleApiResultDecoded->status!='ZERO_RESULTS')
									{
										$Response = array('success' => '1','location' => $GoogleApiResultDecoded->results[0]->formatted_address);
										return json_encode($Response);
									}
									else
									{
										$Response = array('success' => '2','message' => 'Location Error');
										return json_encode($Response);    
									}
								}
								else
								{
									$Response = array('success' => '1','message' => 'Driver Not Found');
									return json_encode($Response);
								}
							}
							else
							{
								$Response = array('success' => '0','message' => 'Insufficient Data');
								return json_encode($Response);   
							}
						}
						
						
						public function PushNotification($DeviceId,$Message) 
						{
							$url = 'https://android.googleapis.com/gcm/send';
							$fields = array(
							'registration_ids' => $DeviceId,
							'data' => $Message
							);
							$headers = array(
							'Authorization: key = AIzaSyCUx1PyeAonGjbHAuVvAc74pbk9F_wVfKE',
							'Content-Type: application/json'
							);
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, $url);
							curl_setopt($ch, CURLOPT_POST, true);
							curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
							curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
							$result = curl_exec($ch);
							if ($result === FALSE) {
								die('Curl failed: ' . curl_error($ch));
							}
							curl_close($ch);
							
						}
						public function PushNotificationIos() 
						{
							$DeviceId = '7ca26d8415b35e8fab1c9dbede66abcef6b91a61ea3ada84274ada974c2ec30b';
							$Message = "MTI Activation Code : 54534";
							$Sender = 'Parent';
							return $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						
						public function PushNotificationIosDri() 
						{
							$DeviceId = '88c5d9956857ec7373b2a94146c2abc9976760fd8c10deeaba0abdb24f93ccaf';
							$Message = "MTI drivertest";
							$Sender = 'Driver';
							return $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
						}
						
						
						public function PushNotificationIosParentDriver($Sender,$DeviceId,$Message) 
						{
							if ($Sender=='Parent') 
							{    
								$ParentPemUrl = "http://projects.bizarresoftware.in/mti/pushparent.php?DeviceId=".$DeviceId.'&Message='.$Message;
								$TriggerParent = file_get_contents($ParentPemUrl);
								#exit;    
							}
							else
							{
								$ParentPemUrl = "http://projects.bizarresoftware.in/mti/pushdriver.php?DeviceId=".$DeviceId.'&Message='.$Message;  
								$TriggerParent = file_get_contents($ParentPemUrl);
								#exit;
							}
						}
						
						
						
						
						public function ClickAM()
						{
							#Currentlag long, driver id, Date, Schoollatlong
							
							if (Input::get('DriverId')!=''  && Input::get('Date')!='')
							{
								
								
								
								$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
								
								if ($IsDriverExist=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Driver Not Exist');
									return json_encode($Response);
								}
								
								
								$DriverId = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoId');        
								
								if ($DriverId) 
								{
									$BusId = TimingModel::where('DriverName', '=', $DriverId)->pluck('VehicleCode');
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
									
									foreach ($TotalStudents as $FinderKey) 
									{
										$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'AM')->update(array('travelstatus' => 0, 'traveldate' => '0000-00-00'));
										#    echo $FinderKey['studentid'].'-';
									}
								}
								
								
								if ($DriverId) 
								{
									$BusId = TimingModel::where('DriverName', '=', $DriverId)->pluck('VehicleCode');
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
									
									foreach ($TotalStudents as $FinderKey) 
									{
										$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'PM')->update(array('travelstatus' => 0, 'traveldate' => '0000-00-00'));
										#    echo $FinderKey['studentid'].'-';
									}
								}
								
								
								$BusId = TimingModel::where('DriverName', '=', $IsDriverExist)->pluck('VehicleCode');
								
								if ($BusId=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Bus Not Allocated');
									return json_encode($Response);
								}
								
								
								
								
								
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
								
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
								
								
								
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('toschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								
								
								
								
								$Parent =array();
								foreach ($TotalStudentsList as $TotalStudentsListTrigger) 
								{
									
									$Parents = MTIServiceStudent::where('id', '=', $TotalStudentsListTrigger)->get()->ToArray();
									
									$Parent[$TotalStudentsListTrigger]= $Parents[0]['parentid'];
								}
								
								
								$Parent = array_filter(array_unique($Parent));
								
								
								if(count($Parent)!=0)
								{
									$Find ='';
									foreach($Parent as $key => $ParentData)
									{
										
										#$Parents = MTIServiceStudent::where('parent', '=', $ParentData)->pluck('studentid');
										$FirstStudent = TranportallocateModel::where('studentid', '=', $key)->pluck('time');
										
										$parentgcm = MTIServiceParent::where('id', $ParentData)->pluck('GcmId');   
										$Find .=$ParentData.',';
										$PushMessage = "Please be aware that pending traffic the bus will be arriving within the next ".$FirstStudent.".  We kindly ask to please have your child ready"; 
										#$PushMessage = "This message is to notify you that your child has boarded from school bus and is on the way to home"; 
										
										$PushMessage = "{'Title' : 'MTI Bus Started', 'Message' : '".$PushMessage."'}";
										
										$DeviceType = MTIServiceParent::where('id', $ParentData)->pluck('DeviceType');
										$drivergcm = MTIServiceParent::where('id', $ParentData)->pluck('GcmId');
										
										if ($DeviceType=='ios') 
										{
											$FirstStudent = str_replace(" ", "_", $FirstStudent);
											$Message = "Please_be_aware_that_pending_traffic_the_bus_will_be_arriving_within_the_next_".$FirstStudent."._We_kindly_ask_to_please_have_your_child_ready";
											$Sender = 'Parent';
											$DeviceId = $drivergcm;
											$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
										}
										else
										{
											
											
											#$PushMessage = "The bus is started it will reach in ".$time; 
											#$PushMessage = "{'Title' : 'MTI Bus Started', 'Message' : '".$PushMessage."'}"; 
											$DeviceId = array($parentgcm);
											$Message = array("price"=>urldecode($PushMessage));
											$this->PushNotification($DeviceId, $Message);
										}
										
									}
									
								}
								
								
								
								$Response = array('success' => '1','message' => 'Information sent to all Parents');
								return json_encode($Response);
							}
							else
							{
								$Response = array('success' => '0','message' => 'Insufficient Data');
								return json_encode($Response);
							}
							
						}   
						
						
						public function ClickPM()
						{
							#Currentlag long, driver id, Date, Schoollatlong
							
							if (Input::get('DriverId')!=''  && Input::get('Date')!='')
							{
								
								
								
								
								$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
								
								if ($IsDriverExist=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Driver Not Exist');
									return json_encode($Response);
								}
								
								
								
								$DriverId = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoId');        
								
								if ($DriverId) 
								{
									$BusId = TimingModel::where('DriverName', '=', $DriverId)->pluck('VehicleCode');
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
									
									foreach ($TotalStudents as $FinderKey) 
									{
										$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'PM')->update(array('travelstatus' => 1));
										#    echo $FinderKey['studentid'].'-';
									}
								}
								
								if ($DriverId) 
								{
									$BusId = TimingModel::where('DriverName', '=', $DriverId)->pluck('VehicleCode');
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
									
									foreach ($TotalStudents as $FinderKey) 
									{
										$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'AM')->update(array('travelstatus' => 3));
										#    echo $FinderKey['studentid'].'-';
									}
								}
								
								
								
								
								
								
								$BusId = TimingModel::where('DriverName', '=', $IsDriverExist)->pluck('VehicleCode');
								
								if ($BusId=='') 
								{
									$Response = array(
									'success' => '0',
									'message' => 'Bus Not Allocated');
									return json_encode($Response);
								}
								
								
								
								
								
								$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get();
								
								$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'PM')->get()->ToArray();
								
								
								
								
								$TotalStudentsList ='';
								foreach ($TotalStudentsById as $TotKey)
								{
									$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'PM')->pluck('studentid');
									$TotalStudentsList .= $TotalStudentsLists.',';
								}
								
								$TotalStudentsListCount = $TotalStudentsList;
								$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
								
								
								if($TotalStudentsListCount=='')
								{
									$Response = array(
									'success' => '0',
									'message' => 'No Bus Not Allocated');
									return json_encode($Response);
								}
								#Removing Absentees
								$AbsentStudents ='';
								foreach ($TotalStudents as $FinderKey) 
								{
									$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
									
									if ($AbsentStudentsList) 
									{
										$AbsentStudents .= $AbsentStudentsList.',';
									}
								}
								$AbsentStudents = array_filter(explode(',', $AbsentStudents));
								$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
								
								
								
								
								$Parent =array();
								foreach ($TotalStudentsList as $TotalStudentsListTrigger) 
								{
									
									$Parents = MTIServiceStudent::where('id', '=', $TotalStudentsListTrigger)->get()->ToArray();
									$Parent[$TotalStudentsListTrigger]= $Parents[0]['parentid'];
								}
								
								
								
								$Parent = array_filter(array_unique($Parent));
								
								
								if(count($Parent)!=0)
								{
									$Find ='';
									foreach($Parent as $key => $ParentData)
									{
										
										#$Parents = MTIServiceStudent::where('parent', '=', $ParentData)->pluck('studentid');
										$FirstStudent = TranportallocateModel::where('studentid', '=', $key)->pluck('time');
										$Find .=$ParentData.',';
										$parentgcm = MTIServiceParent::where('id', $ParentData)->pluck('GcmId');   
										
										#		$PushMessage = "Please be aware that pending traffic the bus will be arriving within the next ".$FirstStudent.".  We kindly ask to please have your child ready "; 
										$PushMessage = "This message is to notify you that your child has boarded from school bus and is on the way to home"; 
										$PushMessage = "{'Title' : 'MTI Bus Started', 'Message' : '".$PushMessage."'}"; 
										
										$DeviceType = MTIServiceParent::where('id', $ParentData)->pluck('DeviceType');
										$drivergcm = MTIServiceParent::where('id', $ParentData)->pluck('GcmId');
										
										if ($DeviceType=='ios') 
										{
											$Message = "This_message_is_to_notify_you_that_your_child_has_boarded_from_school_bus_and_is_on_the_way_to_home";
											$Sender = 'Parent';
											$DeviceId = $drivergcm;
											$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
										}
										else
										{
											
											#$PushMessage = "The bus is started it will reach in ".$time; 
											#$PushMessage = "{'Title' : 'MTI Bus Started', 'Message' : '".$PushMessage."'}"; 
											$DeviceId = array($parentgcm);
											$Message = array("price"=>urldecode($PushMessage));
											$this->PushNotification($DeviceId, $Message);
										}
										
									}
									
								}
								
								
								
								$Response = array('success' => '1','message' => 'Information sent to all Parents');
								return json_encode($Response);
							}
							else
							{
								$Response = array('success' => '0','message' => 'Insufficient Data');
								return json_encode($Response);
							}
							
						}   
						
						
						
						public function SchoolReached()
						{
							
							#if (Input::get('DriverId')!='' && Input::get('Lat')!='' && Input::get('Long')!='' && Input::get('Date')!='')
								if (Input::get('DriverId')!=''  && Input::get('Date')!='')
								{
									
									
									#Checking Whether the Driver Exist or Not
									$IsDriverExist = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoID');
									if ($IsDriverExist=='') 
									{
										$Response = array(
										'success' => '0',
										'message' => 'Driver Not Exist');
										return json_encode($Response);
									}
									#Checking Whether the Bus Exist or Not
									$BusId = TimingModel::where('DriverName', '=', $IsDriverExist)->pluck('VehicleCode');
									if ($BusId=='') 
									{
										$Response = array(
										'success' => '0',
										'message' => 'Bus Not Allocated');
										return json_encode($Response);
									}
									$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get();
									$TotalStudentsById = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', 'AM')->get()->ToArray();
									
									$TotalStudentsList ='';
									foreach ($TotalStudentsById as $TotKey)
									{
										$TotalStudentsLists = TranportallocateModel::where('studentid', '=', $TotKey['studentid'])->where('triptype', '=', 'AM')->pluck('studentid');
										$TotalStudentsList .= $TotalStudentsLists.',';
									}
									
									$TotalStudentsListCount = $TotalStudentsList;
									$TotalStudentsList = array_filter(explode(',', $TotalStudentsList));
									if($TotalStudentsListCount=='')
									{
										$Response = array(
										'success' => '0',
										'message' => 'Bus Not Allocated');
										return json_encode($Response);
									}
									#Removing Absentees
									$AbsentStudents ='';
									foreach ($TotalStudents as $FinderKey) 
									{
										$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->where('fromschool', '=', '2')->pluck('studentid');
										if ($AbsentStudentsList) 
										{
											$AbsentStudents .= $AbsentStudentsList.',';
										}
									}
									$AbsentStudents = array_filter(explode(',', $AbsentStudents));
									$TotalStudentsList =  array_diff($TotalStudentsList, $AbsentStudents);
									foreach ($TotalStudentsList as $TotalStudentsListTrigger) 
									{
										$ParentName = MTIServiceStudent::where('id', '=', $TotalStudentsListTrigger)->pluck('parentid');
										$parentgcm = MTIServiceParent::where('id', $ParentName)->pluck('GcmId');
										$DeviceType = MTIServiceParent::where('id', $ParentName)->pluck('DeviceType');
										$drivergcm = MTIServiceParent::where('id', $ParentName)->pluck('GcmId');
										
										if ($DeviceType=='ios') 
										{
											$Message = "This message is to notify you that your childs vehicle has arrived at the school.";
											$Message = str_replace(" ", "_", $Message);
											$Sender = 'Parent';
											$DeviceId = $drivergcm;
											$Trigger =  $this->PushNotificationIosParentDriver($Sender,$DeviceId, $Message);
										}
										else
										{
											
											
											$PushMessage = '{"Title" : "MTI Parent Alert", "Message" : "This message is to notify you that your childs vehicle has arrived at the school."}'; 
											$DeviceId = array($parentgcm);
											$Message = array("price"=>urldecode($PushMessage));
											$this->PushNotification($DeviceId, $Message);
										}
									}
									$Response = array('success' => '1','message' => 'Information sent to all Parents');
									return json_encode($Response);
								}
								else
								{
									$Response = array('success' => '0','message' => 'Insufficient Data');
									return json_encode($Response);
								}
								
							}   
							
							public function TripComplete()
							{
								
								
								if (Input::get('DriverId')!=''  && Input::get('Attendance')!='' && Input::get('Date')!='')
								{
									
									$DriverId = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoId');        
									
									if ($DriverId) 
									{
										$BusId = TimingModel::where('DriverName', '=', $DriverId)->pluck('VehicleCode');
										$TotalStudents = TranportallocateModel::where('busid', '=', $BusId)->where('triptype', '=', Input::get('Attendance'))->get();
										foreach ($TotalStudents as $FinderKey) 
										{
											#To Reset the Given Day's Attendance
											$Reset = 1;
											#$Reset = 0;
											if($Reset == 1)
											{
												$AbsentStudentsList = StudentAttandenceModel::where('studentid', '=', $FinderKey['studentid'])->where('date', '=', Input::get('Date'))->delete();
												$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'AM')->update(array('travelstatus' => 0));
											
											$PushMessage = '{"Title" : "MTI Driver Alert", "Message" : "Trip Complete Service Called"}'; 
											$DeviceId = array('APA91bEcAmLEvKzRS4cMtrfDOClDUN2zsTnYV2XdcsHIQbHGPkhp7GTv79j1huYghzDowDPczfcTsUVpaWPSF5xaIXLH1MA9sM3bfVx60fUJON0k8yBRNRgd59GoZG5m5Pb7D36VTXqP');
											$Message = array("price"=>urldecode($PushMessage));
											$this->PushNotification($DeviceId, $Message);
											}
											else
											{
												$affectedRows = TranportallocateModel::where('studentid', '=', $FinderKey['studentid'])->where('triptype', '=', 'AM')->update(array('travelstatus' => 2));
											}
											
										}
										$Response = array('success' => '1','message' => 'Success');
										return json_encode($Response);            
										
										
										
									}
									
								}
								else
								{
									$Response = array('success' => '0','message' => 'Insufficient Data');
									return json_encode($Response);
								}
							}
							
							public function LogoutDriver()
							{
								
								$DriverId = MTIServiceDriver::where('AutoID', Input::get('DriverId'))->pluck('AutoId');        
								
								if ($DriverId) 
								{
									
									$RiderUpdate = MTIServiceDriver::where('AutoID', $DriverId)->first();
									$RiderUpdate->LoginStatus = '0';
									$RiderUpdate->save();
								$Response = array(
								'success' => '1',
								'message' => 'Logged out Succesfully'
								);
								return json_encode($Response);
								}
								else
								{
								$Response = array(
								'success' => '0',
								'message' => 'Driver Not Found'
								);
								return json_encode($Response); 
								}
								
								
								return $Response;
								
								}
								
								
								}
								
								
								
								#Done 
								
								
								#public function GetDriverLocationParent()
								#showtotalpickup
																