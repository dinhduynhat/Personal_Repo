<?php

class SettingsController extends BaseController
{
    
    public function ChangePasswordLayout()
    {
        return View::make('settings/changepassword/changepassword');
    }
    
    public function ChangePasswordProcess()
    {
        $PasswordData = Input::all();

        Validator::extend('pwdvalidation', function($field, $value, $parameters)
        {
            return Hash::check($value, Auth::user()->password);
        });
        
        $messages = array('pwdvalidation' => 'The Old Password is Incorrect');
        
        $validator = Validator::make($PasswordData, User::$rulespwd, $messages);
        if ($validator->passes()) 
        {
            $user = User::find(Auth::user()->id);
            $user->password = Input::get('NewPassword');
            $user->save();
            return Redirect::to('changepassword')->withInput()->with('Messages', 'The Password Information was Updated');
        } else 
        {
            return Redirect::to('changepassword')->withInput()->withErrors($validator);
        }
        
    }

    public function ProfileLayout()
    {
		$user = Auth::user()->id;
		$ProfileDetailsbyid = ProfileModel::where('id', $user)->get()->toArray();   
        return View::make('settings/profile/profile')->with('ProfileDetailsbyid', $ProfileDetailsbyid);
    }
	
	public function ProfileUpdateProcess($data=NULL)
    {
	
	$user = Auth::user()->id;
	$ProfileDetailsbyid = ProfileModel::where('id', $user)->get()->toArray();

        $ProfileData = array_filter(Input::except(array('_token')));
	
	  $validation  = Validator::make($ProfileData, ProfileModel::$rules);        
        if ($validation->passes()) 
        {
	
		if(!empty($ProfileData['Photo']))
	{
	Input::file('Photo')->move('assets/uploads/profilephoto/', $user . '-Photo.' . Input::file('Photo')->getClientOriginalName());
	$Photo=$user.'-Photo.' . Input::file('Photo')->getClientOriginalName();
	unset($ProfileData['Photo']);
	$ProfileData['Photo']=$Photo;
	}
	
		   $affectedRows = ProfileModel::where('id', $user)->update($ProfileData);
            //VehicleModel::create($VehicleData);
            return Redirect::to('profile')->with('Message', 'Profile Details Update Succesfully')->with('ProfileDetailsbyid', $ProfileDetailsbyid);
        } else 
        {
		   
            return Redirect::to('profile')->withInput()->withErrors($validation->messages())->with('ProfileDetailsbyid', $ProfileDetailsbyid);
        }
    }
    
    
}