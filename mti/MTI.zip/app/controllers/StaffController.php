<?php

class StaffController extends BaseController
{
    
    public function staffLayout()
    {
        $StaffDetails = StaffModel::where('BusCompany',Auth::user()->schoolid)->get()->toArray();
        return View::make('staff/staff')->with('StaffDetails', $StaffDetails);
    }
    
    public function staffProcess()
    {
        $StaffData = Input::all();
		
		$StaffData['BusCompany'] = Auth::user()->schoolid;
		if(Input::get('SchoolListing')) { $StaffData['SchoolListing'] = '1';}
		if(Input::get('StudentListing')) { $StaffData['StudentListing'] = '1';}
		if(Input::get('ProfileEditApproval')) { $StaffData['ProfileEditApproval'] = '1';}
		if(Input::get('AddTariffType')) { $StaffData['AddTariffType'] = '1';}
		if(Input::get('AddVehicleType')) { $StaffData['AddVehicleType'] = '1';}
		if(Input::get('AddVehicle')) { $StaffData['AddVehicle'] = '1';}
		if(Input::get('AddDriver')) { $StaffData['AddDriver'] = '1';}
		if(Input::get('AddTiming')) { $StaffData['AddTiming'] = '1';}
		if(Input::get('BusAllocation')) { $StaffData['BusAllocation'] = '1';}
		if(Input::get('Pickup')) { $StaffData['Pickup'] = '1';}
		if(Input::get('TrackStudent')) { $StaffData['TrackStudent'] = '1';}
		if(Input::get('AttendanceReport')) { $StaffData['AttendanceReport'] = '1';}
		if(Input::get('Payments')) { $StaffData['Payments'] = '1';}
		if(Input::get('PaymentsHistory')) { $StaffData['PaymentsHistory'] = '1';}
		if(Input::get('Export')) { $StaffData['Export'] = '1';}
		if(Input::get('AddStaff')) { $StaffData['AddStaff'] = '1';}
		if(Input::get('ManageParent')) { $StaffData['ManageParent'] = '1';}
		if(Input::get('ManageSchool')) { $StaffData['ManageSchool'] = '1';}
		if(Input::get('ManageDriver')) { $StaffData['ManageDriver'] = '1';}
		
		
        $validation  = Validator::make($StaffData, StaffModel::$rules);        
        if ($validation->passes()) 
        {
           $InsertedId = StaffModel::create($StaffData);
           $inserteduserdataId = $InsertedId->id;
		   
		   
		   $password = str_random(5);
		   
		    $riderModel = new User;
            $riderModel->email = Input::get('Email');
            $riderModel->UserName = Input::get('Name');
            $riderModel->FirstName = Input::get('Name');
            $riderModel->password = $password;
            $riderModel->usertype = '4';
            $riderModel->subuserid = $inserteduserdataId;
			$riderModel->schoolid = Auth::user()->schoolid;
			
			
            $riderModel->save();
			
				$Email = Input::get('Email');
				$Name = Input::get('Name');
			
			  Mail::send([],
     array('pass' => $password,'email' => $Email, 'username' => $Name), function($message) use ($password,$Name,$Email)
    {
        $user = MailTemplate::find(4);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
		$mail_body = str_replace("{user}", $Name, $mail_body);
        $mail_body = str_replace("{password}", $password, $mail_body);
        $mail_body = str_replace("{username}", $Email, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($Email);
        $message->subject('Password Details - MTI');
        });
		
		
			
			
            return Redirect::to(Session::get('urlpath').'/addstaff')->with('Message', 'Staff Details Saved Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/addstaff')->withInput()->withErrors($validation->messages());
        }
    }
	public function editStaff($data=NULL)
    {
		$editvehicle=$data;
		$staffData = StaffModel::where('id', $editvehicle)->get()->toArray();
		$StaffDetails = StaffModel::where('BusCompany',Auth::user()->schoolid)->get()->toArray();
		 if (empty($staffData)) 
        {
        return Redirect::to(Session::get('urlpath').'/addstaff');
        }
        else
        {
        return View::make('staff/staffupdate')->with('staffData', $staffData)->with('StaffDetails', $StaffDetails);
    }
	}
	 public function editStaffProcess($data=NULL)
    {
	
	
	$StaffData = Input::except(array('_token'));
	#return $StaffData;
		$StaffData['BusCompany'] = Auth::user()->schoolid;
		
		if(Input::get('SchoolListing')) { $StaffData['SchoolListing'] = '1'; } else { $StaffData['SchoolListing'] = '0'; }
		if(Input::get('StudentListing')) { $StaffData['StudentListing'] = '1'; } else { $StaffData['StudentListing'] = '0'; }
		if(Input::get('ProfileEditApproval')) { $StaffData['ProfileEditApproval'] = '1'; } else { $StaffData['ProfileEditApproval'] = '0'; }
		if(Input::get('AddTariffType')) { $StaffData['AddTariffType'] = '1'; } else { $StaffData['AddTariffType'] = '0'; }
		if(Input::get('AddVehicleType')) { $StaffData['AddVehicleType'] = '1'; } else { $StaffData['AddVehicleType'] = '0'; }
		if(Input::get('AddVehicle')) { $StaffData['AddVehicle'] = '1'; } else { $StaffData['AddVehicle'] = '0'; }
		if(Input::get('AddDriver')) { $StaffData['AddDriver'] = '1'; } else { $StaffData['AddDriver'] = '0'; }
		if(Input::get('AddTiming')) { $StaffData['AddTiming'] = '1'; } else { $StaffData['AddTiming'] = '0'; }
		if(Input::get('BusAllocation')) { $StaffData['BusAllocation'] = '1'; } else { $StaffData['BusAllocation'] = '0'; }
		if(Input::get('Pickup')) { $StaffData['Pickup'] = '1'; } else { $StaffData['Pickup'] = '0'; }
		if(Input::get('TrackStudent')) { $StaffData['TrackStudent'] = '1'; } else { $StaffData['TrackStudent'] = '0'; }
		if(Input::get('AttendanceReport')) { $StaffData['AttendanceReport'] = '1'; } else { $StaffData['AttendanceReport'] = '0'; }
		if(Input::get('Payments')) { $StaffData['Payments'] = '1'; } else { $StaffData['Payments'] = '0'; }
		if(Input::get('PaymentsHistory')) { $StaffData['PaymentsHistory'] = '1'; } else { $StaffData['PaymentsHistory'] = '0'; }
		if(Input::get('Export')) { $StaffData['Export'] = '1'; } else { $StaffData['Export'] = '0'; }
		if(Input::get('AddStaff')) { $StaffData['AddStaff'] = '1'; } else { $StaffData['AddStaff'] = '0'; }
		if(Input::get('ManageParent')) { $StaffData['ManageParent'] = '1'; } else { $StaffData['ManageParent'] = '0'; }
		if(Input::get('ManageSchool')) { $StaffData['ManageSchool'] = '1'; } else { $StaffData['ManageSchool'] = '0'; }
		if(Input::get('ManageDriver')) { $StaffData['ManageDriver'] = '1'; } else { $StaffData['ManageDriver'] = '0'; }
		
		
		
		$update = array(

        'Name' =>   'required|unique:staff,Name,'.$data.',id',         
	    'Email' =>  'email|required|unique:staff,Name,'.$data.',id',
		 'BusCompany' =>  array('required'),
		 'Phone' =>  array('required'),
		 'Address' =>  array('required'),
		
        );
		
		
		
		$validation  = Validator::make($StaffData, $update);        
        if ($validation->passes()) 
        {
           
           $affectedRows = StaffModel::where('id', $data)->update($StaffData);
	
            return Redirect::to(Session::get('urlpath').'/addstaff')->with('Message', 'Staff Details Updated Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/addstaff')->withInput()->withErrors($validation->messages());
        }
	
    }
	public function deleteStaff($data=NULL)
    {
	    $editvehicle=$data;
		$affectedRows = StaffModel::where('id', $editvehicle)->delete();
		$affectedRows = User::where('subuserid', $editvehicle)->delete();
       return Redirect::to(Session::get('urlpath').'/addstaff')->with('Message', 'Staff Details Delete Succesfully');
	   
	}
	public function VehicleDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['vehicledeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$vehiclebyid = VehicleModel::where('AutoID', $data[$i])->get()->toArray();
		$VehicleCode=$vehiclebyid[0]['VehicleCode'];
	 $count[] = TimingModel::where('VehicleCode', '=', $data[$i])->count();	
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = VehicleModel::where('AutoID', $data[$i])->delete();
     
	}
	  return Redirect::to(Session::get('urlpath').'/addvehicle')->with('Message', 'Vehicle Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	    $VehicleDetails = VehicleModel::where('Company',Auth::user()->schoolid)->get()->toArray();
        $VehicleTypeDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->lists('VehicleTypeName', 'AutoID');
		$Companydetails = BusCompanyModel::where('id',Auth::user()->schoolid)->lists('Companyname', 'id');
        return View::make('vehicle/vehicle')->with('VehicleTypeDetails', $VehicleTypeDetails)->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror)->with('Companydetails', $Companydetails);
	}
	}
	public function VehicletypeLayout()
    {
        $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails);
    }
	public function VehicleTypeNameprocess()
    {

        $schoolid=Auth::user()->schoolid;
         $addrules = array(
        'VehicleTypeName' =>  array('required'), 
'Charge' =>  array('required'),		
                             );
        $ClassData = Input::all();
          $validation = Validator::make($ClassData, $addrules);

        $ClassData['Company']=Auth::user()->schoolid;
		$VehicleTypeName = $ClassData['VehicleTypeName'];
		$schoolid = Auth::user()->schoolid;
        if ($validation->passes()) 
        {
         $count = VehicleTypeModel::where('VehicleTypeName', '=', $VehicleTypeName)->where('Company', '=', $schoolid)->count();
     if($count==0)
	 {
            VehicleTypeModel::create($ClassData);
			} else {
			
			return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'Vehicle Type Name Name Already taken');
			
			}
            return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'Vehicle Type Name Saved Succesfully');
        } else 
        {
            
            return Redirect::to(Session::get('urlpath').'/vehicletype')->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleTypeEdit($data=NULL)
    {
	    $editvehicle=$data;
		$VehicleDetailsbyid = VehicleTypeModel::where('AutoID', $editvehicle)->get()->toArray();
		 if (empty($VehicleDetailsbyid)) 
        {
        return Redirect::to(Session::get('urlpath').'/vehicletype');
        }
        else
        {
        $schoolid=Auth::user()->schoolid;
	   $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('VehicleDetailsbyid', $VehicleDetailsbyid);
    }
	}
	public function VehicleTypeNameupdateprocess($data=NULL)
    {
$schoolid=Auth::user()->schoolid;

$update = array(
        'VehicleTypeName' =>  array('required','regex:/^./','unique:vehicletype,VehicleTypeName,'.$data.',AutoID,Company,'.$schoolid),   
                             );
        $ClassEditData = array_filter(Input::except(array('_token')));
	
	   $validation = Validator::make($ClassEditData, $update);        
        if ($validation->passes()) 
        {
		   $affectedRows = VehicleTypeModel::where('AutoID', $data)->update($ClassEditData);
            
            return Redirect::to(Session::get('urlpath').'/VehicleTypeedit/'.$data)->with('Message', 'Vehicle Type Update Succesfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/VehicleTypeedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function VehicleTypeDelete($data=NULL)
    {
	$editvehicle=$data;
	 $schoolid=Auth::user()->schoolid;		
	 $count = VehicleModel::where('VehicleType', '=', $editvehicle)->where('Company', '=', $schoolid)->count();

	if($count==0)
	{
	    $editvehicle=$data;
		$affectedRows = VehicleTypeModel::where('AutoID', $editvehicle)->delete();		
       return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'VehicleType Delete Succesfully');
	   } else {
	   $deleteerror['error']="error";	
	   	$schoolid=Auth::user()->schoolid;
	 $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror);
	   }
	}
	public function VehicleTypeDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['classdeleteprocess'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$schoolid=Auth::user()->schoolid;
		
	 $count[] = VehicleModel::where('VehicleType', '=', $data[$i])->where('Company', '=', $schoolid)->count();		
	}
	
	if(array_sum($count)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = VehicleTypeModel::where('AutoID', $data[$i])->delete();
     	
	}
	  return Redirect::to(Session::get('urlpath').'/vehicletype')->with('Message', 'VehicleType Details Delete Succesfully');
	} else {
	 $deleteerror['error']="error";	
	  $schoolid=Auth::user()->schoolid;
	 $VehicleDetails = VehicleTypeModel::where('Company',Auth::user()->schoolid)->get()->toArray();
      
        return View::make('vehicle/vehicletype')->with('VehicleDetails', $VehicleDetails)->with('deleteerror', $deleteerror);
	}
	}
}