<?php

class BusCompanyController extends BaseController
{
    
    public function BuscompanyLayout()
    {	
        
	    $BusCompanyDetails = BusCompanyModel::all()->toArray();
       
        return View::make('buscompany/buscompany')->with('BusCompanyDetails', $BusCompanyDetails);
    }
    public function BusCompanyProcess($data=NULL)
    {

	     $GeneralData = array_filter(Input::all());
		 $loginuserdata = Input::except(array('Companyname','Address','Phone','website','Contactpersonname','Mobile','Email'));
		 
		$loginarray=array();
         
        $validation  = Validator::make($GeneralData, BusCompanyModel::$rules);        
        if ($validation->passes()) 
        {	
		
		$UserName=$GeneralData['Email'];
		$password=$loginuserdata['password'];	
        $Companyname=$GeneralData['Companyname'];		
	
	$AdminContactPerson=$GeneralData['Companyname'];
	$loginarray['FirstName']=$AdminContactPerson;
	$loginarray['LastName']=$AdminContactPerson;
	
	
	$Email=$GeneralData['Email'];
	$loginarray['UserName']=$Companyname;	
	$loginarray['email']=$Email;	
	
	$loginarray['usertype']=4;
	unset($GeneralData['password']);       
			$validate  = Validator::make($loginuserdata, User::$schoolrules);        
        if ($validate->passes()) 
        {	
		    $bus=BusCompanyModel::create($GeneralData);
			$insertedId = $bus->id;
			$userdata=User::create($loginuserdata);
			$inserteduserdataId = $userdata->id;			
			$loginarray['schoolid']=$insertedId;
			$affectedRows = User::where('id', $inserteduserdataId)->update($loginarray);
			if(!empty($Email))
	  {
	   Mail::send([],
     array('pass' => $password,'email' => $Email,'username' => $UserName,'Companyname' => $Companyname), function($message) use ($password,$Email,$UserName,$Companyname)
    {
        $user = MailTemplate::find(4);
        $mail_body = $user->MailContent;
        //$mail_body = str_replace("{password}", Session::get('sess_string'), $mail_body);
		$mail_body = str_replace("{user}", $Companyname, $mail_body);
        $mail_body = str_replace("{password}", $password, $mail_body);
        $mail_body = str_replace("{username}", $UserName, $mail_body);
        $message->setBody($mail_body, 'text/html');
        $message->to($Email);
        $message->subject('Password Details - MTI');
        });
		}
		} else {
		  return Redirect::to(Session::get('urlpath').'/buscompanylayout')->withInput()->withErrors($validate->messages());
		}
            return Redirect::to(Session::get('urlpath').'/buscompanylayout')->with('Message', 'Bus Company Details Saved Successfully');
        } else 
        {
            return Redirect::to(Session::get('urlpath').'/buscompanylayout')->withInput()->withErrors($validation->messages());
        }
		
    }
	public function BusUpdateProcess($data=NULL)
    {

	$update = array(
         
		 'Companyname' =>   'required|unique:buscompany,Companyname,'.$data.',id',
        'Address' =>  array('required'),		
		'Email' => array('email','required','unique:buscompany,Email,'.$data.',id'), 
		'Mobile' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
		'Phone' =>  array('required', 'Regex:/^[A-Za-z0-9\-! ,\'\"\/@\.:\(\)]+$/'),
		
        #'Mobile' =>array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
		#'Phone' =>  array('required', 'regex:/^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/'),
        'Contactpersonname' =>  array('required'),		 
		 'website' =>  array('required'),
		
        );
        $GeneralData = array_filter(Input::except(array('_token')));
         $loginuserdata = Input::except(array('Companyname','Address','Phone','website','Contactpersonname','Mobile','Email','password'));
		 
		 $loginarray=array();

        $validation  = Validator::make($GeneralData, $update);   

        if ($validation->passes()) 
        {
		$checkdata = User::where('schoolid', $data)->where('usertype', '4')->get()->toArray(); 
		$getdataid=$checkdata[0]['id'];
		 $checkcountdata = User::where('id','!=' ,$getdataid)->where('email',$GeneralData['Email'])->count();
	
        if($checkcountdata !=0)
              {
       return Redirect::to(Session::get('urlpath').'/busedit/'.$data)->with('Message', 'This email id already used for other module');          
              }			
        
	$AdminContactPerson=$GeneralData['Contactpersonname'];
	$loginarray['FirstName']=$AdminContactPerson;
	$loginarray['LastName']=$AdminContactPerson;	
		
	$SchoolEmail=$GeneralData['Email'];
	$loginarray['email']=$SchoolEmail;	
	
	$loginarray['UserName']=$GeneralData['Contactpersonname'];
	unset($GeneralData['password']);
	
	

	   $updatedata=array_filter($GeneralData);
	  $affectedRows = BusCompanyModel::where('id', $data)->update($updatedata);	 
	  $affectedRows2 = User::where('schoolid', $data)->where('usertype', '4')->update($loginarray);		
	
         return Redirect::to(Session::get('urlpath').'/busedit/'.$data)->with('Message', 'Bus Company Details Updated Successfully');
			
        } else 
        {
	
            return Redirect::to(Session::get('urlpath').'/busedit/'.$data)->withInput()->withErrors($validation->messages());
        }
    }
	public function BusEdit($data=NULL)
    {
	    $editvehicle=$data;
		$BusCompanybyid = BusCompanyModel::where('id', $editvehicle)->get()->toArray();
		if (empty($BusCompanybyid))
		{
		return Redirect::to(Session::get('urlpath').'/buscompanylayout');
		}
		else
		{
		$BusCompanyDetails = BusCompanyModel::all()->toArray();
		$status= array("Unblock"=>"Unblock","Block"=>"Block");
        return View::make('buscompany/buscompany')->with('BusCompanybyid', $BusCompanybyid)->with('BusCompanyDetails', $BusCompanyDetails)->with('status', $status);	
		}
		
		 
	}
	public function BusDelete($data=NULL)
    {
	$count = TranportallocateModel::where('buscompany', '=', $data)->count();
	$dcount = DriverModel::where('Company', '=', $data)->count();
	$vcount = VehicleModel::where('Company', '=', $data)->count();
	$vtcount = VehicleTypeModel::where('Company', '=', $data)->count();
	if($count==0 && $dcount==0 && $vcount==0 && $vtcount==0)
	{
	    $editvehicle=$data;
		$affectedRows = BusCompanyModel::where('id', $editvehicle)->delete();	
        $affectedRows = User::where('schoolid', $data)->where('usertype', '4')->delete();		
       return Redirect::to(Session::get('urlpath').'/buscompanylayout')->with('Message', 'Bus Company Deleted Successfully');
	   } else {	   
	   $deleteerror['error']="error";	  
	   $BusCompanyDetails = BusCompanyModel::all()->toArray();
       
        return View::make('buscompany/buscompany')->with('BusCompanyDetails', $BusCompanyDetails)->with('deleteerror', $deleteerror);
	   }
	}
    public function BusDeleteProcess()
	{

	$StudentData = Input::all();
	$schooldeletelist=$StudentData['schooldeletelist'];
	$data=explode(",",$schooldeletelist);
	for($i=0;$i<count($data);$i++)
	{
	$count[] = TranportallocateModel::where('buscompany', '=', $data[$i])->count();
	$dcount[] = DriverModel::where('Company', '=', $data[$i])->count();
	$vcount[] = VehicleModel::where('Company', '=', $data[$i])->count();
	$vtcount[] = VehicleTypeModel::where('Company', '=', $data[$i])->count();
	}
	
	if(array_sum($count)==0 && array_sum($dcount)==0 && array_sum($vcount)==0 && array_sum($vtcount)==0)
	{
	for($i=0;$i<count($data);$i++)
	{
	$affectedRows = BusCompanyModel::where('id', $data[$i])->delete();
	 $affectedRows = User::where('schoolid', $data[$i])->where('usertype', '4')->delete();		
	}
	return Redirect::to(Session::get('urlpath').'/buscompanylayout')->with('Message', 'Bus Company Deleted Successfully');
	} else {
	 $deleteerror['error']="error";	
	 $BusCompanyDetails = BusCompanyModel::all()->toArray();       
     return View::make('/buscompany/buscompany')->with('BusCompanyDetails', $BusCompanyDetails)->with('deleteerror', $deleteerror);
	}
	}
	
}