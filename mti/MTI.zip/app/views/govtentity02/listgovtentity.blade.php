@extends('layouts.dashboardlayout')

@section('body')





        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Government Entity</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Government Entity List</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    
	

		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>
		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb pass-btn">Send Login Details</a>
</div>
		  <?php 
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>

		      <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        

			<?php

		if(!empty($GeneralSettingDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>

		 

		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		

		<?php } ?>

		

		

        </div>

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        

        </div>

		<?php } ?>

	        </div>

        </div>

        <!-- dash content row end --> 

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>

		

        <table class="example tab" id="example">

			<tfoot class="tabl tab-abs"><tr>

			 <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>
        <th ></th>
        

        </th>

        </tr></tfoot>	

        <thead>

		

        <tr>

		<th><input type="checkbox" id="selecctall"></th>

        <th>Government Entity Name</th>
		
        <th>Address</th>
		
        <th>Contact Person</th>

        <th>Email</th>    

        <th>Phone</th>    
        
         <th>Status</th> 		

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{

		?>

        <tr>

		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $GeneralSettingDetailsvalue['id']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['GovernmentEntityName'];?></td>
  <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['GovernmentEntityAddress'];?></td>
        <td><?php echo $GeneralSettingDetailsvalue['GovernmentEntityContactPerson'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['GovernmentEntityEmail'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['GovernmentEntityPhone'];?></td>
         
		<td><?php echo $GeneralSettingDetailsvalue['Status'];?></td>

        <td>       

        <a href="<?php echo url();?>/govtentityedit/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/govtentitydelete/<?php echo $GeneralSettingDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>



        </table>

        </div>

        </div>

			 {{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}





		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

}

});

</script>

  @stop