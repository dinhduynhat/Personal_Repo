@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>




<?php
if(Auth::user()->usertype ==1)

{

?>
          

          <div class="scroll-wrapper">
                      <div class="dashboard-container">
                          <div class="dashboard-row">
                               <div class="dash-mod-box manage-sch-box">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Schools</p>
                                       <p class="man-count-txt">30</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('general'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      
                               
                               
                               <div class="dash-mod-box manage-student-box">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Students</p>
                                       <p class="man-count-txt">1,430</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('studentlisting'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               <div class="dash-mod-box manage-class-box">  
                                
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Drivers</p>
                                       <p class="man-count-txt">60</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('driver'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               <div class="dash-mod-box manage-parent-box">  
                               
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Bus</p>
                                       <p class="man-count-txt">40</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('vehicle'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      

                               <div class="dash-mod-box manage-route-box last">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Route</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('studentallocation'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                                                    
                               
                          </div>
                          
                          
                          <div class="dashboard-row">
                               <div class="col-left">
                               <div class="dashboard-row">
                               <div class="dash-mod-box manage-staff-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Report</p>
                                       <p class="man-count-txt">30</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('exportattendence'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               
                               <div class="dash-mod-box manage-bus-box dash-mod-box-l">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Notification</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="#">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      

                               <div class="dash-mod-box manage-trans-box dash-mod-box-l">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Profile Change Approval</p>
                                       <p class="man-count-txt">12</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="#">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               </div>
                               
                               <div class="dashboard-row">           
                               
                               
                               <div class="dash-mod-box dash-mod-l-box manage-payment-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-left mod-box-txt">
                                       <p class="manag-txt">Payment</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="#"<span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               </div>                          
                               </div>
                               
                               <div class="col-left">
                                <div class="dash-mod-box manage-settings-box last">                        <a href="#">
                                        <div class="align-center">
                                        <p class="manag-txt">Settings</p>
                                        </div>
                                        <div class="align-center">
                                        <span class="icon icon-magage-sch"></span>
                                        </div>
                                        
                                    </a>
                                    
                                </div>
                               </div>                  
                          </div>                        
                          
                          
                           <div class="dashboard-row">
                               <div class="col-left">
                                   <div class="calendar-panel dash-mod-ll-box">
                                   <div class="dash-cal-head dash-ll-head">
                                      <h6><span class="icon"></span>Calender  Schedule</h6>
                                      <ul class="tab-cal">
                                         <li class="active"><a href="#">Month</a></li>
                                         <li><a href="#">Week</a></li>
                                         <li><a href="#">Day</a></li>
                                      </ul>
                                   </div>
                                   <div class="dash-cal-content dash-ll-content"> 
                                    
                                    {{ HTML::image('assets/images/cal-img.png', 'Smart Bus') }}
                                   </div>
                                   </div>
                               </div>
                               
                                <div class="col-left">
                                    <div class="noticeboard-panel dash-mod-ll-box last">
                                   <div class="dash-notice-head dash-ll-head">
                                      <h6><span class="icon"></span>Notification</h6>
                                   </div>
                                   <div class="dash-notice-content dash-ll-content">
                                       <ul class="notice-lister">
                                          <li>
                                             <div class="col-left">
                                                <span class="icon">
                                                </span>
                                                <div class="dash-notice-row">
                                                <h4>Summer Vocation</h4>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                                </div>
                                             </div>
                                             <div class="col-right">
                                                  <span class="date-notice">
                                                          <b>15</b>
                                                          sep
                                                  </span>
                                             </div>
                                          </li>
                                          
                                          <li>
                                             <div class="col-left">
                                                <span class="icon">
                                                </span>
                                                <div class="dash-notice-row">
                                                <h4>Summer Vocation</h4>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                                </div>
                                             </div>
                                             <div class="col-right">
                                                  <span class="date-notice">
                                                          <b>15</b>
                                                          sep
                                                  </span>
                                             </div>
                                          </li>
                                          
                                          <li>
                                             <div class="col-left">
                                                <span class="icon">
                                                </span>
                                                <div class="dash-notice-row">
                                                <h4>Summer Vocation</h4>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br/>
eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                                </div>
                                             </div>
                                             <div class="col-right">
                                                  <span class="date-notice">
                                                          <b>15</b>
                                                          sep
                                                  </span>
                                             </div>
                                          </li>
                                       </ul>
                                   </div>
                                   </div>
                                  
                               </div>
                           
                           </div>
             
                      </div>                          
                      </div>



          <!-- dash content row end --> 

    

      <script>

      

  $(function() {

    var availableTags = [

  <?php foreach($studentname as $studentnamevalue) { 

echo '"'.$studentnamevalue.'"'.','; 

  ?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

      <script>

  $(function() {

    var availableTags = [

  <?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';  

  ?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

    if(Auth::user()->usertype==1)

    {

    ?>

    <script>

        $("document").ready(function(){

            

        });

    

    //end of document ready function

    </script>

  

    <?php 

    

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

} else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}  





    }  ?>

    <script>

        $("document").ready(function(){

            $(".submit-btn").click(function(e){

    

                e.preventDefault();

              

                var dataString = $("form").serialize(); 


                $.ajax({

                    type: "POST",

                    url : "editpaymentlistingadmin",

                    data : dataString,

                    success : function(data){
                      console.log(data);
          $(".firsttab").html("");            
          $(".result").html(data);

                    }

                });



        });

        });

    

    

    </script>
<?php
}
?>


        <!--dash content row end --> 


    
      
      




@stop