@extends('layouts.dashboardlayout')
@section('body')

<?php
$flag = '';
foreach ($DriverDetails as $key) 
{
$Det = VehicleLocation::where('VehicleId', $key->busid)->get();
foreach ($Det as $k) 
{
$flag .=$k['Long'];
 }
}
if ($flag=='') 
{
  ?>
        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Drivers on Map</h2>
         <body>
          <br>
          <br>
          <br>
        <div >
        <h4>  No Drivers allocated for this School</h4>
        </div>
        </body>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        </div>    
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
      
  @stop
<?php
  
} else 
{
  ?>

        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Drivers on Map</h2>
         <body onload="initialize()" >
        <div id="default" style="width:100%; height:80%"></div>
        </body>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        </div>    
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
      
  @stop

  

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyB1tbIAqN0XqcgTR1-FxYoVTVq6Is6lD98&sensor=false">
</script>
<?php 
foreach ($DriverDetails as $DriverData) 
{
#echo $DriverData['Lat']; 
}

?>
<script type="text/javascript">

var locations = [
<?php 






foreach ($DriverDetails as $key) 
{
$Det = VehicleLocation::where('VehicleId', $key->busid)->get();
foreach ($Det as $k) 
{
 
  $DriverName = DriverModel::where('AutoId', $k->DriverId)->pluck('DriverName');
  $VehicleCode = VehicleModel::where('AutoID', $k->VehicleCode)->pluck('VehicleCode');  
  $RequestUrl = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$k->Lat.','.$k->Long."&key=AIzaSyC2pESdfUbnL2i1eHrJY4v6cWLI9EJePCo";
  $GoogleApiResult = file_get_contents($RequestUrl);
  $GoogleApiResultDecoded = json_decode($GoogleApiResult);
  if($GoogleApiResultDecoded->status!='ZERO_RESULTS')
  {
    $Address = $GoogleApiResultDecoded->results[0]->formatted_address;
  }
  else
  {
    $Address = 'Location not Found';
  }



?>
[

'<?php echo $DriverName;?>, Bus No : <?php echo $VehicleCode;?>, Bus Location : <?php echo $Address?>,', <?php echo $k->Lat?>, <?php echo $k->Long?>],

<?php
}
}

?>
                                                                          ];

  function initialize() {
   
    var myOptions = {
      //center: new google.maps.LatLng(11.2100, 76.9500),
      zoom: 20,
      mapTypeId: google.maps.MapTypeId.ROADMAP

    };
    var map = new google.maps.Map(document.getElementById("default"),
        myOptions);

    setMarkers(map,locations)

  }



  function setMarkers(map,locations){

      var marker, i

for (i = 0; i < locations.length; i++)
 {  

 var loan = locations[i][0]
 var lat = locations[i][1]
 var long = locations[i][2]
 var add =  locations[i][3]
 latlngset = new google.maps.LatLng(lat, long);
  var marker = new google.maps.Marker({  
          map: map, title: loan , position: latlngset  
        });
        map.setCenter(marker.getPosition())


        //var content = "Driver Name: " + loan +  '</h3>' + " Location: " + add     
        var content = "Driver Name: " + loan +  '</h3>'

  var infowindow = new google.maps.InfoWindow()
   
google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){ 
        return function() {
           infowindow.setContent(content);
           infowindow.open(map,marker);
        };
    })(marker,content,infowindow)); 

  }
  }



  </script>


  <?php

  
}

#echo $flag;
?>