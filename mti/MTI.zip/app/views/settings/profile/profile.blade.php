@extends('layouts.dashboardlayout')

@section('body')

            <div class="form-panel">

        <div class="dash-content-head tabContaier"><!-- header-panel -->

          <!--<h2><span class="icon icon-profile"></span>Manage Profile</h2>-->
			<h5 class="heading-title" style="color:#ffffff !important; padding-left:15px !important; font-weight:normal;">Manage Profile</h5>
              <?php
            $URL = Session::get('urlpath');
            $url = Session::get('urlpath');
              ?>
            
            
              <a href="<?php echo url().'/'.Session::get('urlpath').'/'.'changepassword';?>" class="btn-sb pass-btn ">Change password</a><!-- changepswd-but -->
        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

               </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'profileupdateprocess', 'files'=> true, 'id' => 'profileupdateprocess')) }}

              <ul class="dash-form-lister">

			 

                <li>

                  <div class="label-control">                   

					 {{ Form::label('Name', 'Name ' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

				   {{ Form::text('FirstName', $ProfileDetailsbyid[0]['FirstName'], array('id' => 'ClassName')) }}                   

                  </div>

				   {{ $errors->first('FirstName', '<div class="error">:message</div>') }}

                </li>

                <li class="txbox-right">

                  <div class="label-control">

                   {{ Form::label('Image', 'Image ' ) }}

                  </div>

                  <div class="input-control input-file-control">

                  

					 {{ Form::file('Photo', ['class' => 'Photo']) }}

                     <?php

		if(!empty($ProfileDetailsbyid[0]['Photo']))

		{

		?>

		  <div class="uploaad_btn_con">{{ HTML::image('assets/uploads/profilephoto/'.$ProfileDetailsbyid[0]['Photo'], 'a picture', array('class' => 'profilepic')) }} </div>

		<?php } ?>

                    

					 

                  </div>

				   {{ $errors->first('Photo', '<div class="error">:message</div>') }}

                </li>

                <li class="unwant">

                  <div class="label-control">

                    {{ Form::label('Email', 'Email' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

                    {{ Form::text('email', $ProfileDetailsbyid[0]['email'], array('id' => 'ClassName')) }} 

                  </div>

				   {{ $errors->first('email', '<div class="error">:message</div>') }}

                </li>

              </ul>

              <div class="btn-group form-list-btn-group">

                {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

              </div>

			  {{ Form::close() }}

            </div>

          </div>

          <!-- dash content row end --> 

        </div>

        <!--dash content row end --> 

        

      </div>

    </div>

@stop