@extends('layouts.dashboardlayout')

@section('body')





        <div class="form-panel">

        <div class="header-panel">
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<a href="{{ URL::to($URL.'/studentlisting'); }}" class="fa fa-list-ul customfontawesome" title='Student Listing'></a>
		<a href="{{ URL::to($URL.'/editapproval'); }}" class="fa fa-users customfontawesome" title='Profile Edit Approval'></a>
		</span>
		<?php
		}
		?>
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
		{
		$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


		?>
		<span style='float:right;    margin-top: 0'>
		<?php $URL = Session::get('urlpath'); ?>
		<?php
if($MenuAccess['StudentListing']==1)
{
?>
		<a href="{{ URL::to($URL.'/studentlisting'); }}" class="fa fa-list-ul customfontawesome" title='Student Listing'></a>
<?php
}
if($MenuAccess['ProfileEditApproval']==1)
{
?>
		<a href="{{ URL::to($URL.'/editapproval'); }}" class="fa fa-users customfontawesome" title='Profile Edit Approval'></a>
		<?php
		}
		?>
		</span>
		<?php
		}
		?>
		
        <h2><!--<span class="icon icon-student"></span>-->Manage Student</h2>

        </div>

        <div class="dash-content-panel repanelstyle"> <!-- dash panel start -->

        

        <div class="dash-content-row  recontentrow"> <!-- dash content row start -->

        
	

		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>
		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb pass-btn">Send Login Details</a>
</div>
		  <?php 
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>

		      <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        

		
		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		

		<?php } ?>

		

		

        </div>

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        

        </div>

		<?php } ?>

	        </div>

        </div>

        <!-- dash content row end --> 
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
		<div class="dash-content-head tabContaier heading-bg">

        <h5 class="heading-title">Edit Approval</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    
		

        <table class="example tab" id="example">

			<tfoot class="tabl tab-abs"><tr>

	   <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>
        
        

        

        </tr></tfoot>	

        <thead>

		

        <tr>

		

        <th>Parent Name</th>
		
        <th>Email</th>
		
        <th>Phone</th>

        <th>Address</th>    

        
        
         <th style="display:none">Status</th> 		

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($ParentEditData as $GeneralSettingDetailsvalue)

{

		?>

        <tr>

		

        <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['FirstName'].' '.$GeneralSettingDetailsvalue['LastName'];?></td>
  <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['Email'];?></td>
        <td><?php echo $GeneralSettingDetailsvalue['Phone'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['Address'];?></td>

        
         
		<td style="display:none"><?php echo $GeneralSettingDetailsvalue['id'];?></td>

        <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/editapprovalprocess/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/editapprovalprocessdelete/<?php echo $GeneralSettingDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>



        </table>

        </div>
		
        </div>
		
		



{{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

</script>
<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

}

});

</script>

  @stop