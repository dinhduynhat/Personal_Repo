@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Change Password</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 style="display:none;">Change Password</h5>

           @if(Session::has('Messages'))

        <div class="error">{{ Session::get('Messages') }}</p>

        @endif

        {{ Form::open(array('url' => 'changepasswordprocess', 'id' => 'changepasswordprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>
		

        <div class="label-control">

        {{ Form::label('OldPassword', 'Enter Old Password ' ) }} <em>*</em>

        </div>

        <div class="input-control">       

        {{ Form::password('OldPassword') }}

        </div>
      

        {{ $errors->first('OldPassword', '<div class="errorsetting">:message</div>') }}

        </li>

        <li class="txbox-right">

        <div class="label-control">

         {{ Form::label('NewPassword', 'Enter New Password ' ) }}<em>*</em>

        </div>

        <div class="input-control">

             {{ Form::password('NewPassword') }}

        </div>

        {{ $errors->first('NewPassword', '<div class="errorsetting" style="margin-left:38%;">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('NewPassword_confirmation', 'Confirm Password ' ) }}<em>*</em>


        </div>

        <div class="input-control">

        {{ Form::password('NewPassword_confirmation') }}

        </div>

        {{ $errors->first('NewPassword_confirmation', '<div class="errorsetting">:message</div>') }}

        </li>

        </ul>

        <!--{{ Auth::user()->password }}-->

        <div class="btn-group form-list-btn-group" >
        <br><br>
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

@stop