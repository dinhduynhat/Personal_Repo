@extends('layouts.dashboardlayout')

@section('body')





        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Edit Approval</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Parent Profile Edit Approval</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>


{{ Form::open(array('url' => 'editparentapprove/'.$ParentEditData['id'], 'files'=> true, 'id' => 'studentadmissionprocess')) }}

        <div class="panel-row panel-row-wborder">   

        <div class="col-three-two"  style="margin-right: 2%;">

		<div class="panel-heading sidepanel">

                <h4 class="panel-title">Old Details</h4>

              </div>

        <ul class="dash-form-lister">

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Full Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('', $ParentData['FirstName'] , array('id'=> 'GuardianFirstName' ,'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('GuardianFirstName', '<div class="errorsetting">First name is required</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['Phone'], array('id'=> 'ContactPhone', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('ContactPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['Mobile'], array('id'=> 'ContactMobile', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('ContactMobile', '<div class="errorsetting">:message</div>') }}

        </li>
		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Email' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['Email'], array('id'=> 'ContactMobile', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('ContactMobile', '<div class="errorsetting">:message</div>') }}

        </li>
		
		
		

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Address' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['Address'], array('id'=> 'Address', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Address', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'State' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['State'], array('id'=> 'ContactState', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('ContactState', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'ZipCode' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('',$ParentData['Pincode'], array('id'=> 'ContactPin', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('ContactPin', '<div class="errorsetting">:message</div>') }}

        </li>


        </ul>

        </div>

        <div class="col-three-four">

		<div class="panel-heading sidepanel">

                <h4 class="panel-title">Newly Requested Details</h4>

              </div>

        <ul class="dash-form-lister">

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Full Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       
        <input type="hidden" name="vals" value="<?php echo $ParentData['id']?>">
       {{ Form::text('FirstName',$ParentEditData['FirstName'], array('id'=> 'GuardianFirstNames', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('FirstName', '<div class="errorsetting">First name is required</div>') }}

        </li>


		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Phone',$ParentEditData['Phone'], array('id'=> 'ContactPhone', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Phone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Mobile',$ParentEditData['Mobile'], array('id'=> 'ContactMobile', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Mobile', '<div class="errorsetting">:message</div>') }}

        </li>
        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Email' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('Email',$ParentEditData['Email'], array('id'=> 'GuardianMail', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Email', '<div class="errorsetting">Email field is required</div>') }}

        </li>
		
		
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Address' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('Address',$ParentEditData['Address'], array('id'=> 'Address', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Address', '<div class="errorsetting">:message</div>') }}

        </li>
		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'ZipCode' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Pincode',$ParentEditData['Pincode']  , array('id'=> 'ContactPin', 'readonly'=>'readonly')) }}

        </div>

         {{ $errors->first('Pincode', '<div class="errorsetting">:message</div>') }}

        </li>

        </ul>

        </div>

        <div class="btn-group form-list-btn-group">
            {{ Form::close() }}

            

    <a href="{{ URL::to(Session::get('urlpath').'/editparentapprove', [$ParentEditData['id'], $ParentData['id']] ) }}" class="parentbutton">Accept</a>
       

        
        
        <a href="{{ URL::to(Session::get('urlpath').'/editapprovalprocessdelete/'.$ParentEditData['id']) }}" class="parentbuttonreject" >Reject</a>
        

        <a href="{{ URL::to(Session::get('urlpath').'/editapproval'); }}" class="parentbuttonreject">Cancel</a>
        </div>

        </div>

		  



        </div>

		
	 

 @stop