@extends('layouts.dashboardlayout')
@section('body')

        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Add Notification</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'notificationprocess', 'files'=> true, 'id' => 'vehicleprocess')) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('Notification Name', 'Notification Name' ) }}<em>*</em>
        </div>
        <div class="input-control">       
        {{ Form::text('NotificationName') }}
        </div>
        {{ $errors->first('NotificationName', '<div class="error">:message</div>') }}
        </li>
        <!--
        <li>
        <div class="label-control">
        {{ Form::label('Notification ID', 'Notification ID' ) }}<em>*</em>
        </div>
        <div class="input-control">       
        {{ Form::text('NotificationID') }}
        </div>
        {{ $errors->first('NotificationName', '<div class="error">:message</div>') }}
        </li>
    -->
        <li>
        <div class="label-control">
        {{ Form::label('NotificationMessage', 'Notification Message' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::textarea('NotificationMessage') }}
        </div>
        {{ $errors->first('NotificationMessage', '<div class="error">:message</div>') }}
        </li>
        
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
		

		<h5>Notification List</h5>
        </div>
        <script>
$(document).ready(function(){

$('#student-listing-table').dataTable();
});
</script>
        
        </div>
        </div>

        <!-- dash content row end --> 
        </div>
        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
		
        <th>Notification Name</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($NotificationDetails as $NotificationDetail)
{
		?>
        <tr>
		
        <td><span class="tab-check"></span><?php echo $NotificationDetail['NotificationName'];?></td>
        
        
        <td>       
        <a href="<?php echo url();?>/editnotification/<?php echo $NotificationDetail['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/deletenotification/<?php echo $NotificationDetail['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
@stop