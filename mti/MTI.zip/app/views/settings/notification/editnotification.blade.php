@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Notification Settings</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Update Notification Settings</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'notificationeditprocess/'.$NotificationData[0]['id'], 'files'=> true, 'id' => 'driverprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('Name', 'Notification Name' ) }}<em>*</em>

        </div>

        <div class="input-control">

                {{ Form::text('NotificationName', Input::old('NotificationName', $NotificationData[0]['NotificationName']), array('id'=> 'GovernmentEntityName')) }}

        

        </div>

        {{ $errors->first('NotificationName', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('NotificationMessage', 'NotificationMessage ' ) }}<em>*</em>

        </div>

        <div class="input-control">

                {{ Form::textarea('NotificationMessage', Input::old('NotificationMessage', $NotificationData[0]['NotificationMessage']), array('id'=> 'NotificationMessage')) }}            

        

        </div>

        {{ $errors->first('NotificationMessage', '<div class="error">:message</div>') }}

        </li>

        

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

         <script>

$(document).ready(function(){









$('#student-listing-table').dataTable();

});

</script>





@stop