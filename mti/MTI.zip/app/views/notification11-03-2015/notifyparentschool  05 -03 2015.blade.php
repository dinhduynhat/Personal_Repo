@extends('layouts.dashboardlayout')
@section('body')

        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Notification</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Notify Parent</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => '#', 'files'=> true, 'id' => 'vehicleprocess')) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('NotificationMessage', 'Notification Message' ) }}<em>*</em>
        </div>
        <div class="input-control">       
        {{ Form::textarea('NotificationMessage') }}
        </div>
        {{ $errors->first('NotificationMessage', '<div class="error">:message</div>') }}
        </li>
        
        
        
        
        
        
        
        
        
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Send', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
  
        <h5>Parent List</h5>
        </div>
  <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {
"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,1 ] }

       ],
        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select option</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">School :</span>').appendTo('#acavails');
    $('<span class="lab-abs">parent :</span>').appendTo('#parent');

    

} );

</script>



        <div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="example tab" id="example">
            <tfoot class="tabl tab-abs" style="left: 275px;">
                <tr>
                    <th style="display:none"></th>
                    <th style="display:none"></th>
                    <th style="display:none"></th>
                    <th style="display:none"></th>
                    <th style="display:none"></th>
                    
                    
                </tr>
                
            </tfoot>
        <thead>
        <tr>
    <th><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>
        <th>Parent Name</th>
        <th>Mobile Number</th>
        <th>Email</th>        
        <th style="display:none">Action</th>
        </tr>
        </thead>
        <tbody>
    <?php
    
    foreach ($ParentData as $ParentDataVal)
{
    ?>
        <tr>
    <td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $ParentDataVal['id']; ?>"></td>
        <td><span class="tab-check"></span><?php echo $ParentDataVal['FirstName'].' '.$ParentDataVal['LastName'];?></td>
        
        <td><?php echo $ParentDataVal['Mobile'];?></td>
        <td><?php echo $ParentDataVal['Email'];?></td>
        
        <td style="display:none">       
        <a href="<?php echo url();?>/vehicleedit/<?php echo $ParentDataVal['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/vehicledelete/<?php echo $ParentDataVal['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
        </div>
        </div>
<?php 
      if(!empty($deleteerror))
    {
    ?>
      <script>
    function fnOpenNormalDialogbox() {
    $(".ui-dialog-titlebar").show();
    var url =$(this).attr("id");
    $("#dialog-confirm").html("This records used for Timing data.");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
    $(this).dialog('close');  
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
    $(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
$(document).ready(function(){
fnOpenNormalDialogbox();
});

    </script>
    <?php
    }?>
        </div>
     {{ Form::open(array('url' => 'vehicledeleteprocess', 'files'=> true, 'id' => 'vehicledeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="vehicledeleteprocess" value="" class="vehicledeleteprocess"/>

</form>
  <script>
      




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".vehicledeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>
    
        <!-- dash content row end --> 
        </div>
        </div>
@stop