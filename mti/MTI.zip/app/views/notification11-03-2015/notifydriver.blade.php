@extends('layouts.dashboardlayout')
@section('body')

        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Notification</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Message to Driver</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'notifydriverprocess', 'files'=> true, 'id' => 'vehicledeleteprocess','class'=>'unwant senddeleteform')) }}
        
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('NotificationMessage', 'Title' ) }}<em>*</em>
        </div>
        <div class="input-control">       
        {{ Form::text('Title', '', array('id' => 'Tit')) }}
        </div>
        {{ $errors->first('Title', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('NotificationMessage', 'Message' ) }}<em>*</em>
        </div>
        <div class="input-control">       
        {{ Form::textarea('Message', '', array('id' => 'Msg')) }}
        
        </div>
        {{ $errors->first('Message', '<div class="error">:message</div>') }}
        </li>
        
        
        
        
        
        
        
        
        
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::button('Send', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        <input type="hidden" name="vehicledeleteprocess" value="" class="vehicledeleteprocess"/>
        {{ Form::close() }}
        </div>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
  
        <h5>Driver List</h5>
        </div>
        <script>
$(document).ready(function(){

$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
    <th><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>
        <th>Driver Name</th>
        <th>Mobile Number</th>
         
        <th style="display:none">Action</th>
        </tr>
        </thead>
        <tbody>
    <?php
    
    foreach ($DriverData as $ParentDataVal)
{
    ?>
        <tr>
    <td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $ParentDataVal['AutoID']; ?>"></td>
        <td><span class="tab-check"></span><?php echo $ParentDataVal['DriverName'];?></td>
        
        <td><?php echo $ParentDataVal['Mobile'];?></td>
        
        
        <td style="display:none">       
        <a href="<?php echo url();?>/vehicleedit/<?php echo $ParentDataVal['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/vehicledelete/<?php echo $ParentDataVal['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
        </div>
        </div>
        <input type="hidden" name="vehicledeleteprocess" value="" class="vehicledeleteprocess"/>
<script>
            function fnOpenvehicleDialogbox() {
        $(".ui-dialog-titlebar").show();
        $(".ui-icon-closethick").show();
        var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure to send the Notification Message ?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
        $(".senddeleteform").submit();
        $(this).dialog('close');    
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
        $(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
        var url =$(this).attr("id");
        
    $("#dialog-confirm").html("Please choose any driver to send Notification");

var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {     
        $(this).dialog('close');    
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
        $(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}


function fnOpenemptymsgDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
        var url =$(this).attr("id");
    $("#dialog-confirm").html("The Title and Message should be Filled");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {     
        $(this).dialog('close');    
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
        $(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".submit-btn").click(function()
{
console.log('startji');


if($('#Tit').val() == '' || $('#Msg').val() == '' )
{

console.log('irfan');
   fnOpenemptymsgDialogbox();
}
else
{
console.log('pongaji'); 

    var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".vehicledeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
}




});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>
  <script>
      






function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>
        <!-- dash content row end --> 
        </div>
        </div>
@stop