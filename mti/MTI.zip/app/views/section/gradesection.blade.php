@extends('layouts.dashboardlayout')
@section('body')


        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Settings Master</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Grade Section</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        
        </div>
		<div class="dash-content-head tabContaier dash-content-head-half dash-content-head-last">
        <h5>Upload Grade Section</h5>
        
        </div>
        <div class="tabDetails">         
        <div class="panel-row   panel-row-over">
		<div class="col-right">
		{{ Form::open(array('url' => 'gradesectionimportprocess', 'files'=> true)) }}
        <ul class="dash-form-lister">
		<li>
                  <div class="label-control">
                   {{ Form::label('importfile', 'Import file' ) }}<em>*</em>
                  </div>
                  <div class="input-control input-file-control">
                  
					 {{ Form::file('importfile', ['class' => 'Photo']) }}
                    
                  </div>
				   {{ $errors->first('importfile', '<div class="errorimportpage">:message</div>') }}
                </li>      
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Import', ['class' => 'submit-btn']) }}    
       
        </div>
        {{ Form::close() }}
		</div>
		<div class="col-left">
		{{ Form::open(array('url' => 'sectionprocess')) }}
        <ul class="dash-form-lister">      
		 <li>
        <div class="label-control">
        {{ Form::label('Section', 'Section' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('Section', null, ['class' => 'Section']) }}
        </div>
        {{ $errors->first('Section', '<div class="errorimportpage">:message</div>') }}
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
		</div>
        </div>
<script>
$(document).ready(function(){

$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
		<?php
		if(empty($StudentCategoryDetails))
		{
		?>
		<a href="<?php echo url();?>/assets/template/Gradesection.xlsx" class="btn-sb pass-btn">Export Grade Section Details</a>
		<?php } else { ?>
			<a href="{{ URL::to('gradesectionexport'); }}" class="btn-sb pass-btn">Export Grade Section Details</a>
			<?php } ?>
        <h5>Section List</h5>
        </div>
     
        
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Section</th>
       
		<th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($StudentCategoryDetails as $StudentCategoryvalue)
{
		?>
        <tr>
        <td><span class="tab-check"></span><?php echo $StudentCategoryvalue['Section'];?></td>
        
         <td>       
        <a href="<?php echo url();?>/sectionedit/<?php echo $StudentCategoryvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/sectiondelete/<?php echo $StudentCategoryvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
@stop