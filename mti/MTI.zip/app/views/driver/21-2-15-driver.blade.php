@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Add Driver</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'driverprocess', 'files'=> true, 'id' => 'driverprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('Name', 'Name ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('DriverName') }}

        </div>

        {{ $errors->first('DriverName', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Age', 'Age ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('Age') }}

        </div>

        {{ $errors->first('Age', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Address', 'Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('Address') }}

        </div>

        {{ $errors->first('Address', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicenseNumber', 'License Number ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('LicenseNumber') }}

        </div>

        {{ $errors->first('LicenseNumber', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Date of Birth ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('DateOfBirth', null, ['class' => 'datetimepicker1']) }}        

        </div>

        {{ $errors->first('DateOfBirth', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicenseExpiryDate', 'License Expiry Date ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('LicenseExpiry', null, ['class' => 'datetimepicker1']) }}

        </div>

        {{ $errors->first('LicenseExpiryDate', '<div class="error">:message</div>') }}

        </li>   

        <li>

        <div class="label-control">

        {{ Form::label('DriverPhoto', 'Driver Photo ' ) }}

        </div>

        <div class="input-control">

        {{ Form::file('DriverPhoto') }}

        </div>

        {{ $errors->first('DriverPhoto', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicensePhoto', 'LicensePhoto ' ) }}

        </div>

        <div class="input-control">

        {{ Form::file('LicensePhoto') }}

        </div>

        {{ $errors->first('LicensePhoto', '<div class="error">:message</div>') }}

        </li>

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>Driver List</h5>
<?php

		if(!empty($DriverDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>
        </div>

      		 <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

</script>

        <div class="panel-tab-row"> <!---------------- student listing table start ------>

        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>
<th><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>
        <th>DriverName</th>

        <th>LicenseNumber</th>

        <th>LicenseExpiry</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($DriverDetails as $Drivervalue)

{

		?>

        <tr>
<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Drivervalue['AutoID']; ?>"></td>
        <td><span class="tab-check"></span><?php echo $Drivervalue['DriverName'];?></td>

        <td><?php echo $Drivervalue['LicenseNumber'];?></td>

        <td><?php echo $Drivervalue['LicenseExpiry'];?></td>

        <td>       

        <a href="<?php echo url();?>/driveredit/<?php echo $Drivervalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

       <a href="javascript:;" id="<?php echo url();?>/driverdelete/<?php echo $Drivervalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

       <?php } ?>

        </tbody>

        </table>

        </div>

        </div>

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>
<?php 
		  if(!empty($deleteerror))
		{
		?>
			<script>
		function fnOpenNormalDialogbox() {
		$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("This records used for timing  data.");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
$(document).ready(function(){
fnOpenNormalDialogbox();
});

		</script>
		<?php
		}?>	
		{{ Form::open(array('url' => 'driverdeleteprocess', 'files'=> true, 'id' => 'driverdeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="driverdeleteprocess" value="" class="driverdeleteprocess"/>

</form>
	<script>
			function fnOpenvehicleDialogbox() {
		$(".ui-dialog-titlebar").show();
		$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the driver to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".driverdeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>
@stop