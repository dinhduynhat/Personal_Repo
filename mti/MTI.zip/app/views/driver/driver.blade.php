@extends('layouts.dashboardlayout')
@section('body')

{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$('document').ready(function() {


    $("#Mobile").mask("999-999-9999");
});
</script>


	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('Address'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.k;
                var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
			  //var longitude = place.geometry.location.D;
	//		  $('#latitude').val(latitude);
	//		  $('#longitude').val(longitude);
            });
        });
    </script>


        <div class="form-panel">



        <div class="header-panel">

<?php
		if(Auth::user()->usertype ==4)
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/driver'); }}" class="fa fa-plus customfontawesome" title='Add Driver'></a>
		<a href="{{ URL::to($URL.'/driver'); }}" class="fa fa-list-ul customfontawesome" title='List Driver'></a>
		
		</span>
		<?php
		}
		?>

        <h2><!--<span class="icon icon-student"></span>-->Manage Transport</h2>



        </div>



        <div class="dash-content-panel"> <!-- dash panel start -->



        <div class="dash-content-row "> <!-- dash content row start -->



        <div class="dash-content-head tabContaier">



        <h5 class="heading-title">Add Driver</h5>

</div>



        @if(Session::has('Message'))



        <p class="alert">{{ Session::get('Message') }}</p>



        @endif



        {{ Form::open(array('url' => 'driverprocess', 'files'=> true, 'id' => 'driverprocess')) }}



        



        <div class="tabDetails">         



        <div class="panel-row">



        <ul class="dash-form-lister">



        <li>



        <div class="label-control">



        {{ Form::label('Name', 'Name ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        {{ Form::text('DriverName') }}



        </div>



        {{ $errors->first('DriverName', '<div class="errorsetting">:message</div>') }}



        </li>



        <li>



        <div class="label-control">



        {{ Form::label('Age', 'Age ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        {{ Form::text('Age') }}



        </div>



        {{ $errors->first('Age', '<div class="errorsetting">:message</div>') }}



        </li>



        <li>



        <div class="label-control">



        {{ Form::label('Address', 'Address ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        {{ Form::textarea('Address', null,['class' => 'Address','id' => 'Address','size' => '100x100']) }}



        </div>



        {{ $errors->first('Address', '<div class="errorsetting">:message</div>') }}



        </li>

		<li>



        <div class="label-control">



        {{ Form::label('LicenseNumber', 'Mobile Number ' ) }}<em>*</em>



        </div>



        <div class="input-control">


{{ Form::text('Mobile',null, array('id'=> 'Mobile')) }}
        



        </div>



        {{ $errors->first('Mobile', '<div class="errorsetting">:message</div>') }}



        </li>

		        <li>



        <div class="label-control">



        {{ Form::label('DriverPhoto', 'Driver Photo ' ) }}



        </div>



        <div class="input-control">



        {{ Form::file('DriverPhoto') }}



        </div>



        {{ $errors->first('DriverPhoto', '<div class="errorsetting">:message</div>') }}



        </li>



        <li>



        <div class="label-control">



        {{ Form::label('LicensePhoto', 'LicensePhoto ' ) }}



        </div>



        <div class="input-control">



        {{ Form::file('LicensePhoto') }}



        </div>



        {{ $errors->first('LicensePhoto', '<div class="errorsetting">:message</div>') }}



        </li>

        <li>



        <div class="label-control">



        {{ Form::label('DateOfBirth', 'Date of Birth ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        {{ Form::text('DateOfBirth', null, ['class' => 'dob DateOfBirth']) }}        



        </div>



        {{ $errors->first('DateOfBirth', '<div class="errorsetting">:message</div>') }}



        </li>
<li>



        <div class="label-control">



        {{ Form::label('Email', 'Email ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        {{ Form::text('Email') }}



        </div>



        {{ $errors->first('Email', '<div class="errorsetting">:message</div>') }}



        </li>
	</ul>

	

	<input type="hidden" class="countid" value="1"/>

    <div class="license-section appenddata" id="1">

	@if(Session::has('Messagedata'))



        <p class="alert">{{ Session::get('Messagedata') }}</p>



        @endif

    <ul>	

        <li>

        <div class="label-control">

        <label for="VehicleType">Lisence Type</label> <em>*</em>

        </div>

        <div class="input-control">

        <select name="LisenceType[]"><?php foreach($licenceDetails as $licence){ ?><option value="<?php echo $licence['licensetype'];?>"><?php echo $licence['licensetype'];?></option><?php } ?></select>

        </div>

        </li>

        <li>



        <div class="label-control">



        {{ Form::label('LicenseNumber', 'License Number ' ) }}<em>*</em>



        </div>



        <div class="input-control">



       <input name="LicenseNumber[]" type="text" id="LicenseNumber">



        </div>

       

        </li>

        <li>

        <div class="label-control">



        {{ Form::label('LicenseExpiryDate', 'License Expiry Date ' ) }}<em>*</em>



        </div>



        <div class="input-control">



        <input class="datetimepicker1" name="LicenseExpiry[]" type="text">



        </div>





        </li>

<div class="btn-sm-group">

        <a href="javascript:;" class="plus plus-btn btn-sm ">

        <span class="icon"></span>

        </a>

       

        </div>		

        </ul>

        

       </div>



       

        <div class="btn-group form-list-btn-group" >



        {{ Form::submit('Save', ['class' => 'submit-btn savedata']) }}    



        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}



        </div>



        {{ Form::close() }}



        </div>



        <div class="panel-row list-row">



        

			 <script>

			

function deletefunction(event){

var id = event.currentTarget.id;

    $("#newrow"+id).remove();



}



</script>

      		 <script>



$(document).ready(function(){

$(".plus").click(function(){

var tot=$(".countid").val();

var newtot=parseInt(tot)+parseInt(1);

var html='<ul  style="margin-top: 20px;" id="newrow'+newtot+'" ><li><div class="label-control"><label for="VehicleType">Lisence Type</label> <em>*</em></div><div class="input-control"><select name="LisenceType[]"><?php foreach($licenceDetails as $licence){ ?><option value="<?php echo $licence['licensetype'];?>"><?php echo $licence['licensetype'];?></option><?php } ?></select></div></li><li><div class="label-control"><label for="LicenseNumber">License Number </label><em>*</em></div><div class="input-control"><input name="LicenseNumber[]" type="text" id="LicenseNumber"></div></li><li><div class="label-control"><label for="LicenseExpiryDate">License Expiry Date </label><em>*</em></div><div class="input-control"><input class="datetimepicker1" name="LicenseExpiry[]" type="text"></div></li><div class="btn-sm-group"><a href="javascript:;" class="delete delete-btn btn-sm " id="'+newtot+'" onclick="deletefunction(event)"><span class="icon"></span></a></div></ul>';

$( ".appenddata" ).append(html);

$(".countid").val(newtot);

$('.datetimepicker1').datetimepicker({



	timepicker:false,



	format:'Y/m/d',



	formatDate:'Y/m/d',





});

});



$('#student-listing-table').dataTable();



});

</script>



        



        </div>



        </div>



        </div>



        <!-- dash content row end --> 



        </div>

		<div class="panel-tab-row"> <!---------------- student listing table start ------>
		<div class="dash-content-head tabContaier">



        <h5>Driver List</h5>
		<input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;margin-right: 6px;
margin-bottom: 7px;">
<?php



		if(!empty($DriverDetails))



		{



		?>



	       



<?php } ?>

        </div>


        <table class="student-listing-table" id="student-listing-table">



        <thead>



        <tr>

<th class="lastth" style="background:#39a2d2 !important;"><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>

        <th>DriverName</th>

<th>LicenseType</th>

        <th>LicenseNumber</th>



        <th>LicenseExpiry</th>
		
		<th>Activation Code</th>



        <th>Action</th>



        </tr>



        </thead>



        <tbody>



		<?php



		



		foreach ($DriverDetails as $Drivervalue)



{



		?>



        <tr>

<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Drivervalue['AutoID']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $Drivervalue['DriverName'];?></td>

    <td><?php echo $Drivervalue['LisenceType'];?></td>

        <td><?php echo $Drivervalue['LicenseNumber'];?></td>



        <td><?php echo date("m/d/Y", strtotime($Drivervalue['LicenseExpiry']) );?></td>
		<td><?php echo $Drivervalue['UniqueCode'];?></td>



        <td>       



        <a class="edtit-btn btn-sm" href="<?php echo url().'/'.Session::get('urlpath');?>/driveredit/<?php echo $Drivervalue['AutoID'];?>"><span class="icon"></span></a>



       <a href="javascript:;" class="delete-btn btn-sm btnOpenDialog " id="<?php echo url();?>/driverdelete/<?php echo $Drivervalue['AutoID'];?>" class="btnOpenDialog"><span class="icon"></span></a></td>



        </tr>



       <?php } ?>



        </tbody>



        </table>



        </div>

        </div>
		
		

<?php 

		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		$(".ui-dialog-titlebar").show();

		  var url =$(this).attr("id");
          //console.

    $("#dialog-confirm").html("This records used for timing data.");

var buttonsConfig = [

    {
        
        text: "OK",
        

        "class": "ok",

        click: function() {
        //fn
        ProceedDelete();
		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}?>	

		{{ Form::open(array('url' => 'driverdeleteprocess', 'files'=> true, 'id' => 'driverdeleteprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="driverdeleteprocess" value="" class="driverdeleteprocess"/>



</form>

	<script>

			function fnOpenvehicleDialogbox() {

		$(".ui-dialog-titlebar").show();

		$(".ui-icon-closethick").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

function fnOpenemptyDialogbox() {

$(".ui-dialog-titlebar").show();

$(".ui-icon-closethick").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Choose any of the driver to delete");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {		

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}









$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".driverdeleteprocess").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenvehicleDialogbox();

} else {

fnOpenemptyDialogbox();

}

});

function ProceedDelete()
{


    var id = "<?php echo url().'/'.Session::get('urlpath').'/driverdeletefull/'.Session::get('deletedriver')?>";
     window.location = id;



}
function CheckedAll(){    

     if (document.getElementById('selecctall').checked) {

         for(i=0; i<document.getElementsByTagName('input').length;i++){

         document.getElementsByTagName('input')[i].checked = true;

         }

     }

     else {

         for(i=0; i<document.getElementsByTagName('input').length;i++){

          document.getElementsByTagName('input')[i].checked = false;

         }

     }

   }

</script>

<script>
  $('#DateOfBirth').change(function(){

       var newdate = $("#DateOfBirth").val();
       var currentdate = $.datepicker.formatDate( "mm/dd/yy",  new Date() );
      // console.log(newdate);
      // console.log(currentdate);



 function myDateFormatter (dateObject) {
        var d = new Date(dateObject);
        var day = d.getDate();
        var month = d.getMonth() + 1;
        var year = d.getFullYear();
        if (day < 10) {
            day = "0" + day;
        }
        if (month < 10) {
            month = "0" + month;
        }
        var date = day + "/" + month + "/" + year;
        var dates = year + "-" + month + "-" + day;

        return dates;
    }; 

var cdate = myDateFormatter(newdate);
//console.log(myDateFormatter(newdate));

var calculateAge = function(birthday) {
    var now = new Date();
    var past = new Date(birthday);
    var nowYear = now.getFullYear();
    var pastYear = past.getFullYear();
    var age = nowYear - pastYear;

    return age;
};

var ok = calculateAge(cdate)
console.log(ok);

$("#Age").val(ok);



//console.log(calculateAge('2011-10-02'));



      
      
})

</script>

@stop