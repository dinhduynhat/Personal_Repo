@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Update Driver</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'driverupdateprocess/'.$DriverDetailsbyid[0]['AutoID'], 'files'=> true, 'id' => 'driverprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('Name', 'Name ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('DriverName',null, array('id'=> 'DriverName')) }}

        </div>

        {{ $errors->first('DriverName', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Age', 'Age ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('Age',null, array('id'=> 'Age')) }}

        </div>

        {{ $errors->first('Age', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Address', 'Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('Address',null, array('id'=> 'Address')) }}

        </div>

        {{ $errors->first('Address', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicenseNumber', 'License Number ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('LicenseNumber',null, array('id'=> 'LicenseNumber')) }}

        </div>

        {{ $errors->first('LicenseNumber', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Date of Birth ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('DateOfBirth', null, ['class' => 'datetimepicker1 DateOfBirth']) }}        

        </div>

        {{ $errors->first('DateOfBirth', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicenseExpiryDate', 'License Expiry Date ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('LicenseExpiry', null, ['class' => 'datetimepicker1 LicenseExpiry']) }}

        </div>

        {{ $errors->first('LicenseExpiryDate', '<div class="error">:message</div>') }}

        </li>   

        <li>

        <div class="label-control">

        {{ Form::label('DriverPhoto', 'Driver Photo ' ) }}

        </div>

        <div class="input-control">

        {{ Form::file('DriverPhoto', ['class' => 'DriverPhoto']) }}

			<?php

		if(!empty($DriverDetailsbyid[0]['DriverPhoto']))

		{

		?>

		{{ HTML::image('assets/uploads/driver/'.$DriverDetailsbyid[0]['DriverPhoto'],'Close',['width'=>"50", 'height'=>"27"]) }}

		<?php } ?>

        </div>

        {{ $errors->first('DriverPhoto', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('LicensePhoto', 'LicensePhoto ' ) }}

        </div>

        <div class="input-control">

        {{ Form::file('LicensePhoto', ['class' => 'LicensePhoto']) }}

			<?php

		if(!empty($DriverDetailsbyid[0]['LicensePhoto']))

		{

		?>

		{{ HTML::image('assets/uploads/driver/'.$DriverDetailsbyid[0]['LicensePhoto'],'Close',['width'=>"50", 'height'=>"27"]) }}

		<?php } ?>

        </div>

        {{ $errors->first('LicensePhoto', '<div class="error">:message</div>') }}

        </li>

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>Driver List</h5>

        </div>

      		 <script>

$(document).ready(function(){

$("#DriverName").val("<?php echo $DriverDetailsbyid[0]['DriverName']?>");

$("#Age").val("<?php echo $DriverDetailsbyid[0]['Age']?>");

$("#Address").val("<?php echo $DriverDetailsbyid[0]['Address']?>");

$("#LicenseNumber").val("<?php echo $DriverDetailsbyid[0]['LicenseNumber']?>");

$(".DateOfBirth").val("<?php echo $DriverDetailsbyid[0]['DateOfBirth']?>");

$(".LicenseExpiry").val("<?php echo $DriverDetailsbyid[0]['LicenseExpiry']?>");

$('#student-listing-table').dataTable();

});

</script>

        <div class="panel-tab-row"> <!---------------- student listing table start ------>

        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

        <th>DriverName</th>

        <th>LicenseNumber</th>

        <th>LicenseExpiry</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($DriverDetails as $Drivervalue)

{

		?>

        <tr>

        <td><span class="tab-check"></span><?php echo $Drivervalue['DriverName'];?></td>

        <td><?php echo $Drivervalue['LicenseNumber'];?></td>

        <td><?php echo $Drivervalue['LicenseExpiry'];?></td>

        <td>       

        <a href="<?php echo url();?>/driveredit/<?php echo $Drivervalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

 

		<a href="javascript:;" id="<?php echo url();?>/driverdelete/<?php echo $Drivervalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

       <?php } ?>

        </tbody>

        </table>

        </div>

        </div>

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

@stop