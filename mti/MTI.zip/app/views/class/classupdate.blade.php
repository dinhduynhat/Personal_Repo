@extends('layouts.dashboardlayout')
@section('body')
        <div class="form-panel">
        <div class="header-panel">
		<?php if(Auth::user()->usertype ==2) { $URL = Session::get('urlpath'); ?>
		<span style='float:right'>
		<a href="{{ URL::to($URL.'/class'); }}" class="fa fa-plus customfontawesome" title='Add Grade'></a>
		<a href="{{ URL::to($URL.'/class'); }}" class="fa fa-list-ul customfontawesome" title='List Grade'></a>
		</span>
		<?php } ?>
        <h2><!--<span class="icon icon-student"></span>-->Settings Master</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5 class="heading-title">Edit Grade</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'classupdateprocess/'.$ClassDetailsbyid[0]['AutoID'])) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('GradeName', 'Grade' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('GradeName', null, array('id' => 'ClassName')) }}
        </div>
        {{ $errors->first('GradeName', '<div class="error">:message</div>') }}
        </li>
        
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
<script>
$(document).ready(function(){
$("#ClassName").val("<?php echo $ClassDetailsbyid[0]['GradeName']?>");

$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-row list-row">

     
        
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
		        <div class="dash-content-head tabContaier">
		<?php
		if(!empty($ClassDetails))
		{
		?>
	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;
margin-right: 6px;margin-bottom: 7px;">  

<?php } ?>
<a href="<?php echo url();?>/assets/template/Grade.xlsx" class="btn-sb pass-btn">Export example format</a>
		<?php

		if(empty($ClassDetails))

		{

		?>
		<?php } else { ?>

		<a href="{{ URL::to('gradeexport'); }}" class="btn-sb pass-btn">Export Grade Details</a>

		<?php } ?>
        <h5>Grade List</h5>
        </div>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
       <th><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>
        <th>GradeName</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($ClassDetails as $Classvalue)
{
		?>
        <tr>
		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Classvalue['AutoID']; ?>"></td>
        <td><span class="tab-check"></span><?php echo $Classvalue['GradeName'];?></td>
       
         <td>
         <?php
        if ($Classvalue['schoolid']==0) 
        {
            
        }
        else
        {
        ?>       
        <a href="<?php echo url().'/'.Session::get('urlpath');?>/classedit/<?php echo $Classvalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        
		<a href="javascript:;" id="<?php echo url();?>/classdelete/<?php echo $Classvalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a>
        <?php
        }
        ?>
        </td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
        </div>
		
		
		
		{{ Form::open(array('url' => 'classdeleteprocess', 'files'=> true, 'id' => 'classdeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="classdeleteprocess" value="" class="classdeleteprocess"/>

</form>
	<script>
			function fnOpenvehicleDialogbox() {
		$(".ui-dialog-titlebar").show();
		$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the Grade to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".classdeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>

@stop