@extends('layouts.dashboardlayout')

@section('body')
{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
	<style>

	.poplink

	{

	margin-left: -250px !important;

margin-top: 64px !important;
width: 490px !important;

	}

	.poplink2

	{

	margin-left: -130px !important;

margin-top: 64px !important;
width: 490px !important;

	}


	</style>

        <div class="form-panel">

        <div class="header-panel">
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/studentallocation'); }}" class="fa fa-street-view customfontawesome" title='Bus Allocation'></a>
		<a href="{{ URL::to($URL.'/transportlist'); }}" class="fa fa-list-ul customfontawesome" title='Pick up / Drop Off List'></a>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		
		</span>
		<?php
		}
		?>
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
		{
		$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<?php
if($MenuAccess['BusAllocation']==1)
{
?>		
		<a href="{{ URL::to($URL.'/studentallocation'); }}" class="fa fa-street-view customfontawesome" title='Bus Allocation'></a>
		<?php
}
if($MenuAccess['Pickup']==1)
{
?>
		<a href="{{ URL::to($URL.'/transportlist'); }}" class="fa fa-list-ul customfontawesome" title='Pick up / Drop Off List'></a>
		<?php
}
if($MenuAccess['TrackStudent']==1)
{
?>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		<?php
}

?>
		

		</span>
		<?php
		}
		?>
		<?php if(Auth::user()->usertype ==2) { $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/studentadmission'); }}" class="fa fa-plus customfontawesome" title='Register Student'></a>
		<a href="{{ URL::to($URL.'/studentlisting'); }}" class="fa fa-list-ul customfontawesome" title='Student Listing'></a>
		<a href="{{ URL::to($URL.'/studentattendence'); }}" class="fa fa-pencil-square-o customfontawesome" title='Update Attendance'></a>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		</span>
		<?php } ?>

        <h2><!--<span class="icon icon-student"></span>-->Track Student</h2>

        </div>

        <div class="dash-content-panel repanelstyle"> <!-- dash panel start -->

        

        <div class="dash-content-row recontentrow"> <!-- dash content row start -->

        <div class="tabContaier">
<div class="errorsetting" style="float: right;color: red;display:none"><em>*</em> Click Student Name And View Student Information.</div>
       

       </div>
@if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
   		  <script>



$(document).ready(function() {

    $('#example').DataTable( {
"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,1 ] }

       ],

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select option</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">School :</span>').appendTo('#acavails');
$('<span class="lab-abs">Parent :</span>').appendTo('#parent');
    

} );

</script>



		 

        </div>



        <!-- dash content row end --> 

        </div>
		
		<div class="panel-row list-row">

        <div class="dash-content-head tabContaier heading-bg">

		<?php

		if(Auth::user()->usertype !=4)

		{
		if(!empty($StudentAdmissionDetailsbyid))

		{

		?>

	     <input style="display:none" class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>

		<a href="<?php echo url();?>/assets/template/studentformat.xlsx" class="btn-sb pass-btn" style="display:none">Download student data excel format</a>

		<?php

		if(empty($StudentAdmissionDetailsbyid))

		{

		?>

		

		<?php } else { ?>

		<a href="{{ URL::to(Session::get('urlpath').'/studentexport'); }}" class="btn-sb pass-btn" style="display:none">Export Student Details</a>

		<?php } ?>

			

		<a href="{{ URL::to(Session::get('urlpath').'/studentimport'); }}" class="btn-sb pass-btn" style="display:none">Import Student Details</a>
		
<?php } ?>
        <h5 class="heading-title">Student List</h5>
        <div  id="downs" style="display:none;height: 14px; float: right;
  margin-top: 9px;
  margin-right: 13px;">
{{ HTML::image('assets/images/down_2.png', 'Smart Bus') }}        	
        </div>

        <div  id="ups" style="display:none;height: 14px; float: right;
  margin-top: 9px;
  margin-right: 13px;">
{{ HTML::image('assets/images/up_2.png', 'Smart Bus') }}        	
        </div>


	

        </div>

						 		<div class="panel-tab-row"> <!---------------- student listing table start ------>
<div id="tablecover">
       <table class="example tab" id="example">

	  <?php 

		if(Auth::user()->usertype != 2)

		{

		?>

	   <tfoot class="tabl tab-abs" style="left: 275px;"><tr>

	 <th  style="display:none;"> 

        </th>

	    <th  id="acavails"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		
		 <th  id="parent"> 

        </th>

        </tr></tfoot>	

		<?php } else { ?>
		 <tfoot class="tabl tab-abs"><tr>

	   <th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		<th  style="display:none;"> 

        </th>
		 <th  id="parent"> 

        </th>

        </tr></tfoot>
		<?php } ?>

        <thead>

        <tr>

		<?php 

		if(Auth::user()->usertype !=2)

		{

		?>

		<th style="display:none;">School</th>

		<?php } ?>

		<th style="display:none"><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>

        <th>Name</th>

        <th>Grade</th>

		<th>Age</th>

        <th>Gender</th>      

        <th>Parent Name</th>  		

		<th>Parent Mobile</th> 
		
		

<th>Track</th> 

        </tr>

        </thead>

        <tbody>

		<?php



		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)

{

		?>

        <tr>

		<td style="display:none"><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $StudentAdmissionDetailvalue['id']; ?>"></td>

		<?php 

		if(Auth::user()->usertype !=2)

		{

		?>

		  <td style="display:none;"><?php echo $StudentAdmissionDetailvalue['schollresult']['SchoolName'];?></td>   

		  <?php } ?>

        <td><span class="tab-check"></span><a class="fancybox attandencelink" href="#inline<?php echo $StudentAdmissionDetailvalue['id']; ?>" id="<?php echo $StudentAdmissionDetailvalue['id']; ?>"><?php echo $StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'];?></td>

        <td><?php echo $StudentAdmissionDetailvalue['StudentCourse'];?></a>

			<div id="attandence<?php echo $StudentAdmissionDetailvalue['id']; ?>" title="Basic dialog" style="display: none;">

	

  <div class="work-sch-contain">

        <div class="panel-heading">

        <h4 class="panel-title">Weekly Attendence Schedule</h4>

        </div>

        <div class="work-row work-row-head">

              <div class="work-right">

			  <?php

                 echo '<ul>

                      <li>'.date("m-d-y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-y", strtotime($dates[4])).'</br>Fri</li>

                 </ul>'; ?>

              </div>

        </div>

        <div class="work-row work-row-present">

             <div class="work-left">

                 <p>From Home</p>

             </div>

             <div class="work-right">

                 <ul>

				 <?php 

				 

				 for($i=0;$i<count($dates);$i++)

				 {

				 $attandsdata['studentid']=$StudentAdmissionDetailvalue['id'];

	$attandsdata['date']=$dates[$i];

	$count = StudentAttandenceModel::where($attandsdata)->count();

	if($count !=0)

	{

		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();

		if($StudentAttandence[0]['toschool']==1)

		{

                 echo'<li><span class="icon-work icon-work-present"></span></li>';
				  }  if($StudentAttandence[0]['toschool']==2)
		            {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				   if($StudentAttandence[0]['toschool']==0)
		            {
				   echo'<li><span class="icon-work no_attendence"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';

				   }}

                echo '</ul>

             </div>

        </div>

        <div class="work-row work-row-absent">

             <div class="work-left">

                 <p>From School</p>

             </div>

             <div class="work-right">

                  <ul>';

				 for($i=0;$i<count($dates);$i++)

				 {

				 $attandsdata['studentid']=$StudentAdmissionDetailvalue['id'];

	$attandsdata['date']=$dates[$i];

	$count = StudentAttandenceModel::where($attandsdata)->count();

	if($count !=0)

	{

		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();

		

		if($StudentAttandence[0]['fromschool']==1)

		{

                 echo'<li><span class="icon-work icon-work-present"></span></li>';
				  }  if($StudentAttandence[0]['fromschool']==2)
		            {
				   echo'<li><span class="icon-work icon-work-absent"></span></li>';
				  }
				   if($StudentAttandence[0]['fromschool']==0)
		            {
				   echo'<li><span class="icon-work no_attendence"></span></li>';
				  }
				  } else {
                   echo '<li><span class="icon-work no_attendence"></span></li>';

				   }}

                 ?></ul>

             </div>

        </div>

    </div>

</div>

		</td>

		<td><?php echo $StudentAdmissionDetailvalue['Age'];?></td>    

        <td><?php echo $StudentAdmissionDetailvalue['Gender'];?></td>  

        <td><?php echo $StudentAdmissionDetailvalue['GuardianFirstName'];?></td> 

        <td><?php echo $StudentAdmissionDetailvalue['ContactMobile'];?></td> 		
		
<td>
	<button class="edtit-btn btn-sm tabl-button track" id="<?php echo $StudentAdmissionDetailvalue['id'];?>">Track Student</button>

</td>
        </tr>

<!---test---->
		<div id="inline<?php echo $StudentAdmissionDetailvalue['id']; ?>" class="pop-des" style="display: none;">

		

		<div class="panel-heading">

                <h2 class="">Student Information</h2>

              </div>

		<div class="coln_box">

		<div class="coln coln_1">

		

		<div class="panel-heading">

                <h4 class="panel-title">Student Details</h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>Name: </span><?php echo $StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName']; ?></label>

        </div>       

        </li>	

         <li>

        <div class="label-control">

        <label for="r_no"><span>Gender: </span><?php echo $StudentAdmissionDetailvalue['Gender']; ?></label>

        </div>       

        </li>

        <li>

        <div class="label-control">

        <label for="r_no"><span>Age:</span><?php echo $StudentAdmissionDetailvalue['Age'];?></label>

        </div>       

        </li>

          <li>

        <div class="label-control">

        <label for="r_no"><span>Grade:</span><?php echo $StudentAdmissionDetailvalue['StudentCourse']; ?></label>

        </div>       

        </li>         		

        </ul>        

		</div>

		<div class="coln coln_2">

		

		<div class="panel-heading">

                <h4 class="panel-title">Parent Details</h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>Name: </span><?php echo $StudentAdmissionDetailvalue['GuardianFirstName']; ?></label>

        </div>       

        </li>	

         <li>

        <div class="label-control">

        <label for="r_no"><span>Mobile:</span> <?php echo $StudentAdmissionDetailvalue['ContactMobile']; ?></label>

        </div>       

        </li>

        <li>

        <div class="label-control">

        <label for="r_no"><span>Address: </span><p><?php echo $StudentAdmissionDetailvalue['Address'];  ?></p></label>

        </div>       

        </li>          	

        </ul> 

		

		</div>

		<div class="coln coln_3">

		

		<div class="panel-heading">

                <h4 class="panel-title">School Timing for students </h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>DAY </span><span>IN </span><span>OUT </span></label>

        </div>       

        </li>	

          <?php

		   

			 $timingarray= array();

			 $timingseconarray= array();

           if($StudentAdmissionDetailvalue['timingoption']==1)

		   {

		    $start=$StudentAdmissionDetailvalue['Weekdaysfrom'];

			$end=$StudentAdmissionDetailvalue['Weekdaysto'];

			$startkey = array_search($start, $weekdays);

			$endkey = array_search($end, $weekdays);
            if($start !="" && $end !="")
			{

			$timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];

			$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];

			$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];

			$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];

			$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];

			$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];

		    $timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];

			$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];

			$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];

			$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];

			for($i=$startkey;$i<=$endkey;$i++)

		   {

		    $timingarray['In'.$i]=$StudentAdmissionDetailvalue['weekInTime'];

			 $timingarray['Out'.$i]=$StudentAdmissionDetailvalue['weekoutTime'];

		   }	  
             } else {
			 
			 $timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];

			$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];

			$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];

			$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];

			$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];

			$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];

		    $timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];

			$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];

			$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];

			$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];
			 }
		  

		   } else {

		   $timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];

			$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];

			$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];

			$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];

			$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];

			$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];

		    $timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];

			$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];

			$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];

			$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];

		   

		   }

          for($i=0;$i<count($weekdays);$i++)

		   {

          ?>	

		   <li>

        <div class="label-control">

        <label for="r_no"><span><?php echo $weekdays[$i]; ?> </span><span><?php echo $timingarray["In".$i]; ?> </span><span><?php echo $timingarray["Out".$i]; ?> </span></label>

        </div>       

        </li>

<?php } ?>		 
	
	  

        </ul> 

		

		</div>

		</div>

		

	</div>

<!---test---->

	

        <?php } ?>

        </tbody>

        </table>
        </div>

        </div>

        

        </div>

		
		
		
		
		
			
        <div class="newmap" style="width:100%; clear:both;">
        <!-- dash content row end --> 



      <div class="defaultmap" style="width:100%; clear:both;"><!--col-one-two-margin-->

			



		    <div id="map" style="min-height: 300px;border: 1px solid #dddddd;
box-sizing: border-box;
padding: 1%;width: 100%;"></div>
			<script type="text/javascript">
    var locations = [
      
    ];

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 7,      
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
	navigator.geolocation.getCurrentPosition(function(position) {
        
            var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            map.setCenter(geolocate);
            
        });
        
  

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
  </script>
                
            </div>

        

		

        </div>
		
		</div>

    

		<script type="text/javascript">

		$(document).ready(function() {

		

			$('.fancybox').fancybox();

			$(".fancybox-effects-a").fancybox({

			

				helpers: {

					title : {

						type : 'outside'

					},

					overlay : {

						speedOut : 0

					}

				}

			});

			$('.attandencelink').mouseover(function (e) {

                 var id=$(this).attr("id");

				 $("#attandence"+id).show();				

				  $("#attandence"+id).dialog();

				  $(".ui-draggable-handle").hide();

				   $(".ui-icon-closethick").hide();

				   $(".ui-dialog").addClass("poplink");

				   var parentOffset = $(this).parent().offset(); 

				   $(".poplink").css({"top": parentOffset.top-55});

                   if(localStorage.getItem("users")=="lock")

	              {

				   $(".ui-dialog").removeClass("poplink");

	                $(".ui-dialog").addClass("poplink2");

	                 } else {

					  $(".ui-dialog").addClass("poplink");

					  $(".ui-dialog").removeClass("poplink2");

					 

					 }

				 })

				 .mouseout(function() {

				 $(".poplink").css({"top": "0px"});

				  $(".ui-dialog").removeClass("poplink");

				    $(".ui-dialog").removeClass("poplink2");

				$(".ui-icon-closethick").trigger("click");

				 });
 $(".paginate_button").click(function(){
				 $('.attandencelink').mouseover(function (e) {
                 var id=$(this).attr("id");
				 
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-55});
                   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				 });
				 });

 });

		

	</script>
	 {{ Form::open(array('url' => 'studentdeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="studentdeletelist" value="" class="studentdeletelist"/>

</form>
	<script>
		function fnOpenNormalDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the student to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}

		</script>

<script>
$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".studentdeletelist").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenNormalDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>	
<?php 

		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		$(".ui-dialog-titlebar").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for route allocation.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}?>


<script type="text/javascript">


$("#ups").click(function()
{
	
	$("#tablecover").toggle();
     $(".defaultmap").show();
      $("#ups").hide();
      $("#downs").show();
    
});

$("#downs").click(function()
{
	
	
     $(".defaultmap").show();
     $("#tablecover").toggle();
      $("#downs").hide();
      $("#ups").show();
    
});

      $(".track").click(function(){


      $("#tablecover").toggle();
     $(".defaultmap").show();
       $("#ups").show();
       $("#downs").hide();
    
    

      	 var id = this.id;
  console.log(id);
           var title = $(this).text();
            $.ajax({
                type: "POST",
                url : "trackstudentprocess",
                 data: { 
                'id': id, 
            },
                success : function(data)
                {
                console.log(data);

                $(".defaultmap").html(data);
                }
            },"json");
        });
</script>

@stop