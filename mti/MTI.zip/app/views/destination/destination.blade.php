@extends('layouts.dashboardlayout')
@section('body')
        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Add Destination</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'destinationprocess')) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('rv_code', 'Route Name ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::select('RouteName', array(''=>'Select Routename')+$RouteDetails)}}
        </div>
           {{ $errors->first('RouteName', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('destination', 'Destination ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('Destination') }}
        </div>
           {{ $errors->first('Destination', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('Monthlycost', 'Monthly Cost ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('MonthlyCost') }}
        </div>
        {{ $errors->first('MonthlyCost', '<div class="error">:message</div>') }}
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
		<script>
$(document).ready(function(){

$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Route List</h5>
        </div>
      
        
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Route</th>
        <th>Destination</th>
        <th>Monthly Cost</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($DestinationDetails as $Destinationvalue)
{
		?>
        <tr>
        <td><span class="tab-check"></span><?php echo $Destinationvalue['RouteName'];?></td>
        <td><?php echo $Destinationvalue['Destination'];?></td>
        <td><?php echo $Destinationvalue['MonthlyCost'];?></td>
         <td>       
        <a href="<?php echo url();?>/destinationedit/<?php echo $Destinationvalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/destinationdelete/<?php echo $Destinationvalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
@stop