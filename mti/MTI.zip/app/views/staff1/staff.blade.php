@extends('layouts.dashboardlayout')

@section('body')

	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('Address'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.k;
                var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
			  //var longitude = place.geometry.location.D;
	//		  $('#latitude').val(latitude);
	//		  $('#longitude').val(longitude);
            });
        });
    </script>

{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$('document').ready(function() {
    $("#Phone").mask("999-999-9999");
});
</script>

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Manage Staff</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 class="heading-title">Add Staffs</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'staffprocess', 'files'=> true, 'id' => 'staffprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">
         
		 
        <li>

        <div class="label-control">

        {{ Form::label('StaffName', 'Staff Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

        {{ Form::text('Name') }}

        </div>

        {{ $errors->first('Name', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

         {{ Form::label('Staff Email', 'Staff Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">

             {{ Form::text('Email') }}

        </div>

        {{ $errors->first('Email', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Phone', 'Phone ' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Phone',null, array('id'=> 'Phone')) }}

        </div>

        {{ $errors->first('Phone', '<div class="error">:message</div>') }}

        

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('VehicleAddress', 'Address ' ) }}

        </div>

        <div class="input-control">

        {{ Form::textarea('Address', null,['class' => 'Address','id' => 'Address','size' => '100x100']) }}

        </div>

        {{ $errors->first('VehicleAddress', '<div class="error">:message</div>') }}

        </li>

		
		<li>

        <div class="label-control">

        {{ Form::label('Menu Access Rights', 'Rights ' ) }}

        </div>

        <div class="input-control" style="width:196px">
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('SchoolAccess', '1') }} &nbsp;&nbsp;Manage School<br>
		</div>
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('StudentAccess', '1') }} &nbsp;&nbsp;Manage Student<br>
		</div>
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('TransportAccess', '1') }} &nbsp;&nbsp;Manage Transport<br>
		</div>
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('ReportAccess', '1') }} &nbsp;&nbsp;Manage Report<br>
		</div>
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('StaffAccess', '1') }} &nbsp;&nbsp;Manage Staff<br>
		</div>
		<div style="float:left; padding:0px 0px 5px 5px">
		{{ Form::checkbox('NotificationAccess', '1') }} &nbsp;&nbsp;Manage Notification<br>
		</div>
		
		
		
		
		
		

        </div>

        {{ $errors->first('VehicleAddress', '<div class="error">:message</div>') }}

        </li>


        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        <div class="panel-row list-row">

        

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

</script>

        

        </div>

        </div>

<?php 

		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		$(".ui-dialog-titlebar").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for Timing data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}?>

        </div>

		 {{ Form::open(array('url' => 'vehicledeleteprocess', 'files'=> true, 'id' => 'vehicledeleteprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="vehicledeleteprocess" value="" class="vehicledeleteprocess"/>



</form>

	<script>

			function fnOpenvehicleDialogbox() {

		$(".ui-dialog-titlebar").show();

		$(".ui-icon-closethick").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

function fnOpenemptyDialogbox() {

$(".ui-dialog-titlebar").show();

$(".ui-icon-closethick").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Choose any of the vehicle to delete");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {		

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}









$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".vehicledeleteprocess").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenvehicleDialogbox();

} else {

fnOpenemptyDialogbox();

}

});

function CheckedAll(){    

     if (document.getElementById('selecctall').checked) {

         for(i=0; i<document.getElementsByTagName('input').length;i++){

         document.getElementsByTagName('input')[i].checked = true;

         }

     }

     else {

         for(i=0; i<document.getElementsByTagName('input').length;i++){

          document.getElementsByTagName('input')[i].checked = false;

         }

     }

   }

</script>

		

        <!-- dash content row end --> 

        </div>
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
		<div class="dash-content-head tabContaier">

		<?php

		if(!empty($StaffDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;margin-right: 6px;
margin-bottom: 7px;">  

<?php } ?>

        <h5>Staff List</h5>

        </div>
        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

		<th class="lastth" style="background:#39a2d2 !important;"><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>

		
        <th>Staff Name</th>

		<th>Bus Company</th>        
		
        <th>Email</th>

        <th>Phone</th>        

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($StaffDetails as $Vehiclevalue)

{

		?>

        <tr>

		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Vehiclevalue['id']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $Vehiclevalue['Name'];?></td>

		<td><?php echo $Vehiclevalue['Email'];?></td>
		
        <td><?php echo $Vehiclevalue['Phone'];?></td>

        <td><?php echo $Vehiclevalue['Phone'];?></td>

        

        <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/editstaff/<?php echo $Vehiclevalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/deletestaff/<?php echo $Vehiclevalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>

        </table>

        </div>
        </div>

		
@stop