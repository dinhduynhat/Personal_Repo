@extends('layouts.dashboardlayout')

@section('body')





        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->School</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>School</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    

<?php 

if(!empty($schoolDetailsbyid))

{

?>

{{ Form::open(array('url' => 'schoolupdateprocess/'.$schoolDetailsbyid[0]['id'], 'files'=> true, 'id' => 'generalprocess')) }}

<?php } else { ?>		

        {{ Form::open(array('url' => 'generalprocess', 'files'=> true, 'id' => 'generalprocess')) }}

		<?php } ?>

        <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolName',null, array('id'=> 'SchoolName')) }}

        </div>

        {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>

         <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','size' => '100x100']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('SchoolEmail',null, array('id'=> 'SchoolEmail')) }}

        </div>

         {{ $errors->first('SchoolEmail', '<div class="errorsetting">:message</div>') }}

        </li>			

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Admin Contact Person' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('AdminContactPerson',null, array('id'=> 'AdminContactPerson')) }}

        </div>

         {{ $errors->first('AdminContactPerson', '<div class="errorsetting">:message</div>') }}

        </li>

         <li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'User Name' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?>  <em>*</em> <?php } ?>

        </div>

		<?php

		if(!empty($schooluserDetailsbyid))

{ $user=$schooluserDetailsbyid[0]['UserName']; } else { $user=""; }

		?>

        <div class="input-control">       

       {{ Form::text('UserName',$user, array('id'=> 'Username')) }}

        </div>

         {{ $errors->first('UserName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li id="Password"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?> <em>*</em> <?php } ?>

        </div>

        <div class="input-control">       

       {{ Form::password('password',array('id'=> 'Password')) }}

	   

        </div>

         {{ $errors->first('password', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolPhone',null, array('id'=> 'SchoolPhone')) }}

        </div>

         {{ $errors->first('SchoolPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Mobile' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolMobile',null, array('id'=> 'SchoolMobile')) }}

        </div>

         {{ $errors->first('SchoolMobile', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Fax' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolFax',null, array('id'=> 'SchoolFax')) }}

        </div>

         {{ $errors->first('SchoolFax', '<div class="errorsetting">:message</div>') }}

        </li>	

		<li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'Country' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Country', $CountryDetails,null, array('id'=> 'Country'))}}		

      

        </div>

         {{ $errors->first('Country', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Logo' ) }}

		

        </div>

        <div class="input-control">       

       {{ Form::file('UploadLogo') }}

	  <?php

		if(!empty($schoolDetailsbyid[0]['UploadLogo']))

		{

		?>

		  <div class="uploaad_btn_con">{{ HTML::image('assets/uploads/uploadschoollogo/'.$schoolDetailsbyid[0]['UploadLogo'], 'a picture', array('class' => 'schoollogo')) }} </div>

		<?php } ?>

        </div>

         {{ $errors->first('UploadLogo', '<div class="errorsetting">:message</div>') }}

        </li>

		<?php 

if(!empty($schoolDetailsbyid))

{

?>

 <li >

        <div class="label-control">

        {{ Form::label('r_no', 'Status' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Status', $status,null, array('id'=> 'Status'))}}		

      

        </div>

         {{ $errors->first('Status', '<div class="errorsetting">:message</div>') }}

        </li>	

<?php } ?>		

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}
		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>

		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb pass-btn">Send Login Details</a>

</div>
		  <?php 
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>

		      <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>School List</h5>

			<?php

		if(!empty($GeneralSettingDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>

		 <a href="<?php echo url();?>/assets/template/Schoolformat.xlsx" class="btn-sb pass-btn">Download example format</a>

		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		<a href="{{ URL::to('schoolexport'); }}" class="btn-sb pass-btn">Export School Details</a>

		<?php } ?>

		<a href="{{ URL::to('schoolimport'); }}" class="btn-sb pass-btn">Import School Details</a>

		

        </div>

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {
"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,1 ] }

       ],

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        <div class="panel-tab-row"> <!---------------- student listing table start ------>

		

        <table class="example tab" id="example" >

			<tfoot class="tabl tab-abs"><tr>

			 <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        

        <th style="display:none"></th>
        <th style="display:none"></th>
        <th  id="acavails"> 

        </th>

        </tr></tfoot>	

        <thead>

		

        <tr>

		<th><input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();"></th>

        <th style="width:113px !important;">School Name</th>
		
        <th style="width:163px !important;">School Address</th>
        <th>Email</th>    

        <th>Phone</th>    
<th>Send Login Details</th>
         <th>Status</th> 		

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{

		?>

        <tr>

		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $GeneralSettingDetailsvalue['id']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['SchoolName'];?></td>
  <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['SchoolAddress'];?></td>
        

        <td><?php echo $GeneralSettingDetailsvalue['SchoolEmail'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['SchoolPhone'];?></td>
         <td><?php if($GeneralSettingDetailsvalue['Schoolloginstatus']==1) { echo "YES"; } else { echo "No";  }?></td>
		<td><?php echo $GeneralSettingDetailsvalue['Status'];?></td>

        <td>       

        <a href="<?php echo url();?>/schooledit/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/schooldelete/<?php echo $GeneralSettingDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>



        </table>

        </div>

        </div>

		<?php } ?>

	        </div>

        </div>

        <!-- dash content row end --> 

        </div>

     

			 {{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the school to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

} else {
fnOpenemptyDialogbox();
}

});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>

  @stop