@extends('layouts.dashboardlayout')

@section('body')





        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->School</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>School</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    

<?php 

if(!empty($schoolDetailsbyid))

{

?>

{{ Form::open(array('url' => 'schoolupdateprocess/'.$schoolDetailsbyid[0]['id'], 'files'=> true, 'id' => 'generalprocess')) }}

<?php } else { ?>		

        {{ Form::open(array('url' => 'generalprocess', 'files'=> true, 'id' => 'generalprocess')) }}

		<?php } ?>

        <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolName',null, array('id'=> 'SchoolName')) }}

        </div>

        {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>

         <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','size' => '100x100']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('SchoolEmail',null, array('id'=> 'SchoolEmail')) }}

        </div>

         {{ $errors->first('SchoolEmail', '<div class="errorsetting">:message</div>') }}

        </li>			

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Admin Contact Person' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('AdminContactPerson',null, array('id'=> 'AdminContactPerson')) }}

        </div>

         {{ $errors->first('AdminContactPerson', '<div class="errorsetting">:message</div>') }}

        </li>

          <li id="Username"> 

        <div class="label-control">

        {{ Form::label('r_no', 'User Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('UserName',null, array('id'=> 'Username')) }}

        </div>

         {{ $errors->first('UserName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li id="Password"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::password('password',array('id'=> 'Password')) }}

	   

        </div>

         {{ $errors->first('password', '<div class="errorsetting">:message</div>') }}

        </li>		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolPhone',null, array('id'=> 'SchoolPhone')) }}

        </div>

         {{ $errors->first('SchoolPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolMobile',null, array('id'=> 'SchoolMobile')) }}

        </div>

         {{ $errors->first('SchoolMobile', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Fax' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolFax',null, array('id'=> 'SchoolFax')) }}

        </div>

         {{ $errors->first('SchoolFax', '<div class="errorsetting">:message</div>') }}

        </li>	

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Country' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Country', array(''=>'Select Country')+$CountryDetails,null, array('id'=> 'Country'))}}		

      

        </div>

         {{ $errors->first('Country', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Logo' ) }}

		

        </div>

        <div class="input-control">       

       {{ Form::file('UploadLogo') }}

	  <?php

		if(!empty($schoolDetailsbyid[0]['UploadLogo']))

		{

		?>

		  <div class="uploaad_btn_con">{{ HTML::image('assets/uploads/uploadschoollogo/'.$schoolDetailsbyid[0]['UploadLogo'], 'a picture', array('class' => 'schoollogo')) }} </div>

		<?php } ?>

        </div>

         {{ $errors->first('UploadLogo', '<div class="errorsetting">:message</div>') }}

        </li>		

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}

		  <?php 

if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo $schoolDetailsbyid[0]['SchoolAddress']?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

$("#Username").val("<?php echo "temp"; ?>");	

$("#Username").hide();	

$("#Password").val("<?php echo "temp"; ?>");	

$("#Password").hide();		

		});



</script>

<?php } if(Auth::user()->usertype !=2)

		{ ?>

		      <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>School List</h5>

        </div>

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});



</script>



        <div class="panel-tab-row"> <!---------------- student listing table start ------>

        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

        <th>School Name</th>

        <th>Contact Person</th>

        <th>Email</th>    

        <th>Mobile</th>    		

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{

		?>

        <tr>

        <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['SchoolName'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['AdminContactPerson'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['SchoolEmail'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['SchoolMobile'];?></td>

        <td>       

        <a href="<?php echo url();?>/schooledit/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/schooldelete/<?php echo $GeneralSettingDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>

        </table>

        </div>

        </div>

		<?php } ?>

	        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

  @stop