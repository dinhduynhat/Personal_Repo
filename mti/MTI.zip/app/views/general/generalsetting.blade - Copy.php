@extends('layouts.dashboardlayout')

@section('body')


<script type="text/javascript">
  function ajaxindicatorstart(text)
  {
    if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
    jQuery('body').append('<div id="resultLoading" style="display:none"><div>{{ HTML::image('assets/css/ajax-loader.gif', 'Loading . . . ') }}<div>'+text+'</div></div><div class="bg"></div></div>');
    }
    
    jQuery('#resultLoading').css({
      'width':'100%',
      'height':'100%',
      'position':'fixed',
      'z-index':'10000000',
      'top':'0',
      'left':'0',
      'right':'0',
      'bottom':'0',
      'margin':'auto'
    }); 
    
    jQuery('#resultLoading .bg').css({
      'background':'#000000',
      'opacity':'0.7',
      'width':'100%',
      'height':'100%',
      'position':'absolute',
      'top':'0'
    });
    
    jQuery('#resultLoading>div:first').css({
      'width': '250px',
      'height':'75px',
      'text-align': 'center',
      'position': 'fixed',
      'top':'0',
      'left':'0',
      'right':'0',
      'bottom':'0',
      'margin':'auto',
      'font-size':'16px',
      'z-index':'10',
      'color':'#ffffff'
      
    });

      jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeIn(300);
      jQuery('body').css('cursor', 'wait');
  }

  function ajaxindicatorstop()
  {
      jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeOut(300);
      jQuery('body').css('cursor', 'default');
  }
  
  function callAjax()
  {
    jQuery.ajax({
      type: "GET",
      url: "fetch_data.php",
      cache: false,
      success: function(res){
          jQuery('#ajaxcontent').html(res);
      }
    });
  }
  
  jQuery(document).ajaxStart(function () {
      //show ajax indicator
    ajaxindicatorstart('loading data.. please wait..');
  }).ajaxStop(function () {
    //hide ajax indicator
    ajaxindicatorstop();
  });
</script>



{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$(document).ready(function() {
    $("#SchoolPhone").mask("999-999-9999");
	$("#SchoolMobile").mask("999-999-9999");
});
</script>
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('SchoolAddress'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                // var latitude = place.geometry.location.k;
                // var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                // mesg += "\nLatitude: " + latitude;
                // mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
        //var longitude = place.geometry.location.D;
        <?php

 if(!empty($schoolDetailsbyid[0]['SchoolEmail']))

    {

        ?>
          $.ajax({
           type: "POST",
           url : "../googleplace",
           data: {address: address},
           success : function(data){
          console.log(data);
          arr = data.split(',');
          var latitude = arr[0];
          var longitude = arr[1];
          console.log(arr[0]);
          console.log(arr[1]);
          $('#latitude').val(latitude);
        $('#longitude').val(longitude);
          }
        });


  <?php
}
else
{
?>
 $.ajax({
           type: "POST",
           url : "googleplace",
           data: {address: address},
           success : function(data){
          console.log(data);
          arr = data.split(',');
          var latitude = arr[0];
          var longitude = arr[1];
          console.log(arr[0]);
          console.log(arr[1]);
          $('#latitude').val(latitude);
        $('#longitude').val(longitude);
          }
        });

<?php
}
?>
        
        

        // console.log(address);
        // console.log(latitude);
        // console.log(longitude);


            });
        });
    </script>
<?php $date = ['00:00:00' => '12:00 AM','00:30:00' => '12:30 AM','01:00:00' => '01:00 AM','01:30:00' => '01:30 AM','02:00:00' => '02:00 AM','02:30:00' => '02:30 AM','03:00:00' => '03:00 AM','03:30:00' => '03:30 AM','04:00:00' => '04:00 AM','04:30:00' => '04:30 AM','05:00:00' => '05:00 AM','05:30:00' => '05:30 AM','06:00:00' => '06:00 AM','06:30:00' => '06:30 AM','07:00:00' => '07:00 AM','07:30:00' => '07:30 AM','08:00:00' => '08:00 AM','08:30:00' => '08:30 AM','09:00:00' => '09:00 AM','09:30:00' => '09:30 AM','10:00:00' => '10:00 AM','10:30:00' => '10:30 AM','11:00:00' => '11:00 AM','11:30:00' => '11:30 AM','12:00:00' => '12:00 PM','12:30:00' => '12:30 PM','13:00:00' => '01:00 PM','13:30:00' => '01:30 PM','14:00:00' => '02:00 PM','14:03:00' => '02:30 PM','15:00:00' => '03:00 PM','15:30:00' => '03:30 PM','16:00:00' => '04:00 PM','16:30:00' => '04:30 PM','17:00:00' => '05:00 PM','17:30:00' => '05:30 PM','18:00:00' => '06:00 PM','18:30:00' => '06:30 PM','19:00:00' => '07:00 PM','19:30:00' => '07:30 PM','20:00:00' => '08:00 PM','20:30:00' => '08:30 PM','21:00:00' => '09:00 PM','21:30:00' => '09:30 PM','22:00:00' => '10:00 PM','22:30:00' => '10:30 PM','23:00:00' => '11:00 PM','23:30:00' => '11:30 PM']; ?>
		
<?php

$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$getpath=explode("/",$actual_link);

if (end($getpath)!='general')
{
if(Auth::user()->usertype==4)
{
?>
        <div class="form-panel">
		<div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Manage School</h2>
        </div>
<?php
}
}
else
{
}
if(Auth::user()->usertype==1)
{
?>
<div class="form-panel">
<div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Manage School</h2>
        </div>
<?php
}
?>
<?php
if(Auth::user()->usertype==3)
{
?>
<div class="form-panel">
<div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Manage School</h2>
        </div>
<?php
}
?>
		<?php
		if(Auth::user()->usertype!=4)
		{
		?>
        <div class="dash-content-panel"> <!-- dash panel start -->
		<?php
		}
		?>
        

        <div class="dash-content-row" <?php if(Auth::user()->usertype==4) { ?>style="padding-bottom:0px;" <?php } ?>> <!-- dash content row start -->
		<?php

if(Auth::user()->usertype ==1 || Auth::user()->usertype ==3  || Auth::user()->usertype ==2)

{

?>
        <div class="dash-content-head tabContaier">

        

          <?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$getpath=explode("/",$actual_link);

if (end($getpath)!='general')
{
?>
<h5 class="heading-title">Edit School</h5>
<?php    
}
else
{
  ?>
<h5 class="heading-title">Add School</h5>
  <?php

}

?>





		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    

<?php 

if(!empty($schoolDetailsbyid))

{

?>

{{ Form::open(array('url' => 'schoolupdateprocess/'.$schoolDetailsbyid[0]['id'], 'files'=> true, 'id' => 'generalprocess')) }}

<?php } else { ?>		

        {{ Form::open(array('url' => 'generalprocess', 'files'=> true, 'id' => 'generalprocess')) }}

		<?php } ?>

		<!-- problem i n dis blk-->
		  <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolName',null, array('id'=> 'SchoolName')) }}

        </div>

        {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('SchoolEmail',null, array('id'=> 'SchoolEmail')) }}

        </div>

         {{ $errors->first('SchoolEmail', '<div class="errorsetting">:message</div>') }}

        </li>
		
         <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','id' => 'SchoolAddress','size' => '100x100']) }}
	   {{ Form::text('lat', null,['class' => 'unwant','id' => 'latitude','size' => '100x100']) }}
	   {{ Form::text('lon', null,['class' => 'unwant','id' => 'longitude','size' => '100x100']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>

		 			

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Contact Person' ) }}

        </div>

        <div class="input-control">       

<style>       
.license-section
{
background :#e9f4fa !important;
}
.license-section input[type='text']
{
width: 292px !important;
}
</style>       
	   
	   <input type="hidden" class="countid" value="1"/>
	   <div class="license-section appenddata" id="1">
	   {{ Form::text('AdminContactPerson',null, array('id'=> 'AdminContactPerson')) }}
	   
	   <span style="float:right"><a href="javascript:;" class="plus plus-btn btn-sm "><span class="icon"></span></a></span>
	   </div>

        </div>

         {{ $errors->first('AdminContactPerson', '<div class="errorsetting">:message</div>') }}

        </li>

         <li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'User Name' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?>  <em>*</em> <?php } ?>

        </div>

		<?php

		if(!empty($schooluserDetailsbyid))

{ $user=$schooluserDetailsbyid[0]['UserName']; } else { $user=""; }

		?>

        <div class="input-control">       

       {{ Form::text('UserName',$user, array('id'=> 'Username')) }}

        </div>

         {{ $errors->first('UserName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li id="Password"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?> <em>*</em> <?php } ?>

        </div>

        <div class="input-control">       

       {{ Form::password('password',array('id'=> 'Password')) }}

	   

        </div>

         {{ $errors->first('password', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">
	
	 

		<li>

        <div class="in-out-control">		
			<div class="label-control">
		{{ Form::label('r_no', 'Grade' ,array('class' => 'label-input', 'id' => 'Grade')) }}
		<em style="float: left;margin-left: -60px;">*</em>
			</div>
		<div class="timing">

@if(Session::has('SFrom'))
<select id="GradeFrom" class="general-select" name="GradeFrom">
  <option selected disabled>Grade From</option>
     @foreach($ClassDetails as $ClassDetail)
     <option value="<?php echo $ClassDetail['AutoID'].'"';
    
    if($ClassDetail['AutoID']==Session::get('SFrom'))
    {
    echo ' selected ';
    }
    
    ?>><?php echo $ClassDetail['GradeName'] 
    ?></option>
     @endforeach
 </select>
 {{ Session::forget('SFrom'); }}
@else
<select id="GradeFrom" class="general-select" name="GradeFrom">
  <option selected disabled>Grade From</option>
     @foreach($ClassDetails as $ClassDetail)
     <option value="<?php echo $ClassDetail['AutoID'].'"';
	if(isset($schoolDetailsbyid[0]['GradeFrom']))
	{
	if($ClassDetail['AutoID']==$schoolDetailsbyid[0]['GradeFrom'])
	{
	echo ' selected ';
	}
	}
	?>><?php echo $ClassDetail['GradeName'] 
	?></option>
     @endforeach
 </select>
@endif
		  {{ $errors->first('GradeFrom', '<div class="errorsetting" >:message</div>') }}

		 </div>

		 <div class="timing">
@if(Session::has('STo'))
		 <select id="GradeTo" style="width:116px;margin-left:10px" name="GradeTo">
  <option selected disabled>Grade To</option>
     @foreach($ClassDetails as $ClassDetail)
     <option value="<?php echo $ClassDetail['AutoID'].'"'; 
	
	if($ClassDetail['AutoID']==Session::get('STo'))
	{
	echo ' selected';
	}
	
	?>><?php echo $ClassDetail['GradeName'] 
	?></option>
     @endforeach
 </select>
{{ Session::forget('STo'); }}
@else
 <select id="GradeTo" class="general-select" name="GradeTo">
  <option selected disabled>Grade To</option>
     @foreach($ClassDetails as $ClassDetail)
     <option value="<?php echo $ClassDetail['AutoID'].'"'; 
    if(isset($schoolDetailsbyid[0]['GradeTo']))
    {
    if($ClassDetail['AutoID']==$schoolDetailsbyid[0]['GradeTo'])
    {
    echo ' selected';
    }
    }
    ?>><?php echo $ClassDetail['GradeName'] 
    ?></option>
     @endforeach
 </select>
 @endif
		

 

		  {{ $errors->first('GradeTo', '<div class="errorsetting" style="margin-left: 246px;">:message</div>') }}

        	</div>	

        </div>      

      </li>
		
		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolPhone',null, array('id'=> 'SchoolPhone')) }}

        </div>

         {{ $errors->first('SchoolPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Mobile' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolMobile',null, array('id'=> 'SchoolMobile')) }}

        </div>

         {{ $errors->first('SchoolMobile', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Fax' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('SchoolFax',null, array('id'=> 'SchoolFax')) }}

        </div>

         {{ $errors->first('SchoolFax', '<div class="errorsetting">:message</div>') }}

        </li>	

		<li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'Country' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Country', $CountryDetails,null, array('id'=> 'Country'))}}		

      

        </div>

         {{ $errors->first('Country', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Logo' ) }}

		

        </div>

        <div class="input-control">       

       {{ Form::file('UploadLogo') }}

	  <?php

		if(!empty($schoolDetailsbyid[0]['UploadLogo']))

		{

		?>

		  <div class="uploaad_btn_con">{{ HTML::image('assets/uploads/uploadschoollogo/'.$schoolDetailsbyid[0]['UploadLogo'], 'a picture', array('class' => 'schoollogo')) }} </div>

		<?php } ?>

        </div>

         {{ $errors->first('UploadLogo', '<div class="errorsetting">:message</div>') }}

        </li>
<li >

        <div class="in-out-control">		
			<div class="label-control">
		{{ Form::label('r_no', 'School Timing' ,array('class' => 'label-input', 'id' => 'Schooltiming')) }}<em style="float: left;
margin-left: -20px;">*</em>
			</div>
		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		{{ Form::select('SchoolInTime' ,$date,null,['class' => 'SchoolInTime', 'general-select'] )}}
		
		 <!--{{ Form::text('SchoolInTime', null, ['class' => 'datetimepicker2 SchoolInTime']) }}-->

		  {{ $errors->first('SchoolInTime', '<div class="errorsetting" >:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::select('SchooloutTime' ,$date,null,['class' => 'SchooloutTime', 'general-select'])}}
		 
		 <!--{{ Form::text('SchooloutTime', null, ['class' => 'datetimepicker2 SchooloutTime']) }}-->

		  {{ $errors->first('SchooloutTime', '<div class="errorsetting" style="margin-left: 246px;">:message</div>') }}

        	</div>	

        </div>      

      </li>
		<?php 

if(!empty($schoolDetailsbyid))

{

?>

 <li >

        <div class="label-control">

        {{ Form::label('r_no', 'Status' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Status', $status,null, array('id'=> 'Status'))}}		

      

        </div>

         {{ $errors->first('Status', '<div class="errorsetting">:message</div>') }}

        </li>	

<?php } ?>		

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetcancelbutton" type="reset" value="Cancel">

        </div>
<?php
		if(Auth::user()->usertype!=4)
		{
		?>
        </div>
		<?php
		}
		?>
		<!--243-->
		
		
		
		
		<!--end of prb block-->

		  {{ Form::close() }}
		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>

		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb savemore" style="float:right;">Send Login Details</a>

</div>
		  <?php 
}
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	
		
		
		$(".SchoolInTime").val("<?php echo $schoolDetailsbyid[0]['SchoolInTime']?>");	
		$(".SchooloutTime").val("<?php echo $schoolDetailsbyid[0]['SchooloutTime']?>");	
		
		$("#GradeFrom select").val("<?php echo $schoolDetailsbyid[0]['GradeFrom']?>");	
		
		$("#GradeTo select").val("<?php echo $schoolDetailsbyid[0]['GradeTo']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>



		<?php } ?>

	        </div>

        </div>

        <!-- dash content row end --> 

        </div>
		
		<div class="form-panel blowfrm">
		<!-- panel -->
		      <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>Manage School</h5>

			<?php


if(Auth::user()->usertype ==1 || Auth::user()->usertype ==3)

{


		if(!empty($GeneralSettingDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;
margin-right: 6px;margin-bottom: 7px;">  

<?php } ?>

		 <a href="<?php echo url();?>/assets/template/Schoolformat.xlsx" class="btn-sb pass-btn">Download example format</a>

		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		<a href="{{ URL::to('schoolexport'); }}" class="btn-sb pass-btn" style='display:none'>Export School Details</a>

		<?php } ?>

		<a href="{{ URL::to(Session::get('urlpath').'/schoolimport'); }}" class="btn-sb pass-btn">Import School Details</a>

		<?php } ?>

        </div>

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {
"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,1 ] }

       ],
        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        <div class="panel-tab-row"> <!---------------- student listing table start ------>
		<h5 class="heading-title" style="margin:10px 0 0 15px; font-weight:bold;">School List</h5>
		

        <table class="example tab" id="example">

			<tfoot class="tabl tab-abs"><tr>

			 <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        

        <th style="display:none"></th>
        <th style="display:none"></th>
        <th  id="acavails"> 

        </th>

        </tr></tfoot>	

        <thead>

		

        <tr>

		<th><input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();"></th>

        <th style="width:113px !important;">School Name</th>
		
        <th style="width:163px !important;">School Address</th>
        <th>Email</th>    

        <th>Phone</th>    
<th>Send Login Details</th>
         <th>Status</th> 		
		 <?php
if(Auth::user()->usertype ==1 || Auth::user()->usertype ==3)

{
?>
        <th style="width:55px">Action</th>
<?php } ?>
        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{

		?>

        <tr>

		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $GeneralSettingDetailsvalue['id']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['SchoolName'];?></td>
  <td><span class="tab-check"></span><?php echo $GeneralSettingDetailsvalue['SchoolAddress'];?></td>
        

        <td><?php echo $GeneralSettingDetailsvalue['SchoolEmail'];?></td>

        <td><?php echo $GeneralSettingDetailsvalue['SchoolPhone'];?></td>
         <td><?php if($GeneralSettingDetailsvalue['Schoolloginstatus']==1) { echo "YES"; } else { echo "No";  }?></td>
		<td><?php echo $GeneralSettingDetailsvalue['Status'];?></td>
		 <?php
if(Auth::user()->usertype ==1 || Auth::user()->usertype ==3)

{
?>
        <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/schooledit/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/schooldelete/<?php echo $GeneralSettingDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
		<?php } ?>

        </tr>

        <?php } ?>

        </tbody>



        </table>

        </div>

        </div>
		
		</div>
		
		
		<!--panel ends-->


			 {{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {
$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the school to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}



		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

} else {
fnOpenemptyDialogbox();
}

});

function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>

	 <script>



$(document).ready(function(){

$(".plus").click(function(){

var tot=$(".countid").val();

var newtot=parseInt(tot)+parseInt(1);

var html='<ul  style="margin-top: 20px;" id="newrow'+newtot+'" ><li><div class="label-control"><label for="VehicleType">Lisence Type</label> <em>*</em></div><div class="input-control"><select name="LisenceType[]"></select></div></li><li><div class="label-control"><label for="LicenseNumber">License Number </label><em>*</em></div><div class="input-control"><input name="LicenseNumber[]" type="text" id="LicenseNumber"></div></li><li><div class="label-control"><label for="LicenseExpiryDate">License Expiry Date </label><em>*</em></div><div class="input-control"><input class="datetimepicker1" name="LicenseExpiry[]" type="text"></div></li><div class="btn-sm-group"><a href="javascript:;" class="delete delete-btn btn-sm " id="'+newtot+'" onclick="deletefunction(event)"><span class="icon"></span></a></div></ul>';

var html = '<input id="AdminContactPerson'+newtot+'" name="AdminContactPerson" type="text">';

$( ".appenddata" ).append(html);

$(".countid").val(newtot);

$('.datetimepicker1').datetimepicker({



	timepicker:false,



	format:'Y/m/d',



	formatDate:'Y/m/d',





});

});
});
</script>

  @stop