@extends('layouts.dashboardlayout')
@section('body')
            <div class="form-panel">
        <div class="header-panel">
          <h2><!--<span class="icon icon-profile">--></span>School Register</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
          
          <div class="dash-content-row"> <!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Import School details</h5>
             </div>
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'schoolimportprocess', 'files'=> true, 'id' => 'profileupdateprocess')) }}
              <ul class="dash-form-lister">			 
                <li>
                  <div class="label-control">
                   {{ Form::label('importfile', 'Import file' ) }}<em>*</em>
                  </div>
                  <div class="input-control input-file-control">
                  
					 {{ Form::file('importfile', ['class' => 'Photo']) }}
                    
                  </div>
				   {{ $errors->first('importfile', '<div class="error">:message</div>') }}
                </li>
               
              </ul>
              <div class="btn-group form-list-btn-group">
                {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
              </div>
			  {{ Form::close() }}
            </div>
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
        
      </div>
    </div>
@stop