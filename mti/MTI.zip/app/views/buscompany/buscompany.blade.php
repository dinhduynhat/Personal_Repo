@extends('layouts.dashboardlayout')

@section('body')
<?php
if(!empty($BusCompanybyid))
{
?>
<style>
.site-footer{
	position:absolute;
}
</style>
<?php
}
?>


<script type="text/javascript">
  function ajaxindicatorstart(text)
  {
    if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
    jQuery('body').append('<div id="resultLoading" style="display:none"><div>{{ HTML::image('assets/css/ajax-loader.gif', 'Loading . . . ') }}<div>'+text+'</div></div><div class="bg"></div></div>');
    }
    
    jQuery('#resultLoading').css({
      'width':'100%',
      'height':'100%',
      'position':'fixed',
      'z-index':'10000000',
      'top':'0',
      'left':'0',
      'right':'0',
      'bottom':'0',
      'margin':'auto'
    }); 
    
    jQuery('#resultLoading .bg').css({
      'background':'#000000',
      'opacity':'0.7',
      'width':'100%',
      'height':'100%',
      'position':'absolute',
      'top':'0'
    });
    
    jQuery('#resultLoading>div:first').css({
      'width': '250px',
      'height':'75px',
      'text-align': 'center',
      'position': 'fixed',
      'top':'0',
      'left':'0',
      'right':'0',
      'bottom':'0',
      'margin':'auto',
      'font-size':'16px',
      'z-index':'10',
      'color':'#ffffff'
      
    });

      jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeIn(300);
      jQuery('body').css('cursor', 'wait');
  }

  function ajaxindicatorstop()
  {
      jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeOut(300);
      jQuery('body').css('cursor', 'default');
  }
  
  function callAjax()
  {
    jQuery.ajax({
      type: "GET",
      url: "fetch_data.php",
      cache: false,
      success: function(res){
          jQuery('#ajaxcontent').html(res);
      }
    });
  }
  
  jQuery(document).ajaxStart(function () {
      //show ajax indicator
    ajaxindicatorstart('loading data.. please wait..');
  }).ajaxStop(function () {
    //hide ajax indicator
    ajaxindicatorstop();
  });
</script>


<style>
#Schooltiming {
width:100px !important;
}
</style>

{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$(document).ready(function() {
    $("#Phone").mask("999-999-9999");
	$("#Mobile").mask("999-999-9999");
});
</script>

 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('Address'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                // var latitude = place.geometry.location.k;
                // var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                // mesg += "\nLatitude: " + latitude;
                // mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
        //var longitude = place.geometry.location.D;
        
          $.ajax({
           type: "POST",
           url : "googleplace",
           data: {address: address},
           success : function(data){
          console.log(data);
          arr = data.split(',');
          var latitude = arr[0];
          var longitude = arr[1];
          console.log(arr[0]);
          console.log(arr[1]);
          $('#latitude').val(latitude);
        $('#longitude').val(longitude);
          }
        });


  

        
        

        // console.log(address);
        // console.log(latitude);
        // console.log(longitude);


            });
        });
    </script>


        <div class="form-panel">

        <div class="header-panel">
		
		
		<?php
		if(Auth::user()->usertype ==1)
		{
		?>
		<?php $URL = Session::get('urlpath'); ?>
		<span style='float:right'>
		<a href="{{ URL::to($URL.'/general'); }}" class="fa fa-plus customfontawesome" title='Add Bus Company'></a>
		<a href="{{ URL::to($URL.'/general'); }}" class="fa fa-list-ul customfontawesome" title='List Bus Company'></a>
		</span>
		<?php
		}
		?>
        <h2><!--<span class="icon icon-student"></span>-->Bus Company</h2>
		
        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 style="display:none;">Bus Company</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    

<?php 

if(!empty($BusCompanybyid))

{

?>

{{ Form::open(array('url' => 'busupdateprocess/'.$BusCompanybyid[0]['id'], 'files'=> true, 'id' => 'generalprocess')) }}

<?php 



} else { ?>		

        {{ Form::open(array('url' => 'buscompanyprocess', 'files'=> true, 'id' => 'generalprocess')) }}

		<?php } ?>

        <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Company Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Companyname',null, array('id'=> 'Companyname')) }}

        </div>

        {{ $errors->first('Companyname', '<div class="errorsetting">:message</div>') }}

        </li>

         <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('Address', null,['class' => 'Address','id' => 'Address','size' => '100x100']) }}

	   
	   {{ Form::text('lat', null,['class' => 'unwant','id' => 'latitude','size' => '100x100']) }}
	   {{ Form::text('lon', null,['class' => 'unwant','id' => 'longitude','size' => '100x100']) }}
	   
        </div>

                  {{ $errors->first('Address', '<div class="errorsetting" style="z-index:8">:message</div>') }}

        </li>

		 <li>
 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Website' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('website',null, array('id'=> 'website')) }}

        </div>

        {{ $errors->first('website', '<div class="errorsetting">:message</div>') }}

        </li>
		<li>
        <div class="label-control">

        {{ Form::label('r_no', 'Email' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('Email',null, array('id'=> 'Email')) }}

        </div>

         {{ $errors->first('Email', '<div class="errorsetting">:message</div>') }}

        </li>			

		

		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       


       {{ Form::text('Phone',null, array('id'=> 'Phone')) }}

        </div>

         {{ $errors->first('Phone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Mobile',null, array('id'=> 'Mobile')) }}

        </div>

         {{ $errors->first('Mobile', '<div class="errorsetting">:message</div>') }}

        </li>
	<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Contact Person' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Contactpersonname',null, array('id'=> 'Contactpersonname')) }}

        </div>

         {{ $errors->first('Contactpersonname', '<div class="errorsetting">:message</div>') }}

        </li>


		<li id="Password" style="display:none;"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }}  <em>*</em> 

        </div>

        <div class="input-control">       

       {{ Form::text('password',str_random(5),array('id'=> 'password')) }}

        </div>

         {{ $errors->first('password', '<div class="errorsetting">:message</div>') }}

        </li>
	<?php 

if(!empty($BusCompanybyid))

{

?>

 <li >

        <div class="label-control">

        {{ Form::label('r_no', 'Status' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('Status', $status,null, array('id'=> 'Status'))}}		

      

        </div>

         {{ $errors->first('Status', '<div class="errorsetting">:message</div>') }}

        </li>	

<?php } ?>	
        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetcancelbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}
	
		  <?php 

		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($BusCompanybyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#Companyname").val("<?php echo $BusCompanybyid[0]['Companyname']?>");

		$(".Address").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$BusCompanybyid[0]['Address']));?>");

		$("#Email").val("<?php echo $BusCompanybyid[0]['Email']?>");

		$("#Phone").val("<?php echo $BusCompanybyid[0]['Phone']?>");

		$("#Mobile").val("<?php echo $BusCompanybyid[0]['Mobile']?>");

		$("#website").val("<?php echo $BusCompanybyid[0]['website']?>");

		$("#Contactpersonname").val("<?php echo $BusCompanybyid[0]['Contactpersonname']?>");		
	 $("#Status").val("<?php echo $BusCompanybyid[0]['Status']; ?>");	

		});



</script>

<?php } 
 ?>

		      <div class="panel-row list-row">

      

        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});
$(document).ready(function() {

    $('#example').DataTable( {
"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,1 ] }

       ],
        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );


</script>

<?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$getpath=explode("/",$actual_link);

if (end($getpath)!='buscompanylayout')
{
    
}
else
{



?>



        </div>

	

	        </div>

        </div>
		
		
<?php 

		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		$(".ui-dialog-titlebar").show();

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for Timing data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}?>
        <!-- dash content row end --> 
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
 <div class="dash-content-head tabContaier">

        <h5>Bus Company List</h5>

			<?php

		if(!empty($BusCompanyDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>

		 

		

        </div>


        <table class="example tab" id="example">
<tfoot class="tabl tab-abs"><tr>

			 <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        
        <th style="display:none"></th>
        <th style="display:none"></th>
        <th style="display:none"></th>
        <th  id="acavails"> 

        </th>

        </tr></tfoot>
				

        <thead>

		

        <tr>

		<th><input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();"></th>

        <th style="width:113px !important;">Company Name</th>
		
        <th style="width:74px !important;">Address</th>
		  <th>Contact Person Name</th> 
        <th>Email</th> 
          
        <th>Mobile</th>
         <th>Website</th>
		 <th>Status</th>
		 <th style="width:55px">Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($BusCompanyDetails as $BusCompanyDetailsvalue)

{

		?>

        <tr>

		<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $BusCompanyDetailsvalue['id']; ?>"></td>

        <td><span class="tab-check"></span><?php echo $BusCompanyDetailsvalue['Companyname'];?></td>
  <td><span class="tab-check"></span><?php echo $BusCompanyDetailsvalue['Address'];?></td>
        
<td><?php echo $BusCompanyDetailsvalue['Contactpersonname'];?></td>
<td><?php echo $BusCompanyDetailsvalue['Email'];?></td>

<td><?php echo $BusCompanyDetailsvalue['Mobile'];?></td>
        <td><?php echo $BusCompanyDetailsvalue['website'];?></td>
       <td><?php echo $BusCompanyDetailsvalue['Status'];?></td>  
        <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/busedit/<?php echo $BusCompanyDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url().'/'.Session::get('urlpath');?>/busdelete/<?php echo $BusCompanyDetailsvalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>



        </table>

<?php
}
?>
        </div>

        </div>
		
		
		

			 {{ Form::open(array('url' => Session::get('urlpath').'/'.'busdeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {
$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the school to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}



		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

} else {
fnOpenemptyDialogbox();
}

});

function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>

  @stop