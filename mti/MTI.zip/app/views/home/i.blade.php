@extends('layouts.dashboardlayout')
@section('body')


        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Home</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Welcome</h5>
       
        
        </div>    

            </div>
        </div>
        <!-- dash content row end --> 
        </div>
      
  @stop