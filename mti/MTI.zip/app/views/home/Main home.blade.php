
@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>


<?php
if(Auth::user()->usertype ==3)
{
?>

        <div class="dash-content-panel"> <!-- dash panel start -->     
          <div class="dash-content-row"> <!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Home</h5>
            </div></div></div>



<?php
}
?>

<?php
if(Auth::user()->usertype ==2)
#Start of School Dashboard
{

?>
<div class="dashboard-container">
                          
                          
                          
                          <div class="dashboard-row">
                               <div class="col-left">
                               <div class="dashboard-row">
                                 
                               <div class="dash-mod-box manage-student-box">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Students</p>
                                       <p class="man-count-txt">{{ $StudentCount}}</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('studentlisting'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               
                               <div class="dash-mod-box manage-bus-box dash-mod-box-l" >   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Notification</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                      <a href="{{ URL::to('notifyparent'); }}">
                                       Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      

                               <div class="dash-mod-box manage-staff-box dash-mod-box-l" style="width: 200px;">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Attendance</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('exportattendence'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               </div>
                               
                               <div class="dashboard-row">           
                               <div class="dash-mod-box dash-mod-l-box manage-divermap-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-left mod-box-txt">
                                       <p class="manag-txt">Drivers on Map</p>
                                    </div>
                                    <div class="viewmore-pan"> 
                                       <a href="{{ URL::to('driversonmap'); }}"<span class="raq">&raquo;</span></a>
                                    </div>
                               </div>
                               
                               <div class="dash-mod-box dash-mod-l-box manage-payment-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-left mod-box-txt">
                                       <p class="manag-txt">Manage Grade</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('class'); }}"<span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               </div>                          
                               </div>
                               
                               <div class="col-left">
                                <div class="dash-mod-box manage-settings-box last">                        
                                  <a href="{{ URL::to('profile'); }}">
                                        <div class="align-center">
                                        <p class="manag-txt">Settings</p>
                                        </div>
                                        <div class="align-center">
                                        <span class="icon icon-magage-sch"></span>
                                        </div>
                                        
                                    </a>
                                    
                                </div>
                               </div>                  
                          </div>                        
                          
                          
                           
             
                      </div> 


<?php
}
#End of School Dashboard
?>


<?php
if(Auth::user()->usertype ==1)

{

?>
          
                      <div class="dashboard-container">
                          <div class="dashboard-row">
                               <div class="dash-mod-box manage-sch-box">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Schools</p>
                                       <p class="man-count-txt">{{ $SchoolCount}}</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('general'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      
                               
                               
                               <div class="dash-mod-box manage-student-box">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Students</p>
                                       <p class="man-count-txt">{{ $StudentCount}}</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('studentlisting'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               <div class="dash-mod-box manage-class-box">  
                                
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Drivers</p>
                                       <p class="man-count-txt">{{ $DriverCount}}</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('driver'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               <div class="dash-mod-box manage-parent-box">  
                               
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Bus</p>
                                       <p class="man-count-txt">{{ $VehicleCount}}</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('vehicle'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      

                               <div class="dash-mod-box manage-route-box last">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Route</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('studentallocation'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                                                    
                               
                          </div>
                          
                          
                          <div class="dashboard-row">
                               <div class="col-left">
                               <div class="dashboard-row">
                               <div class="dash-mod-box manage-staff-box dash-mod-box-l">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt ">
                                       <p class="manag-txt">Manage Report</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('exportattendence'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               
                               
                               <div class="dash-mod-box manage-bus-box dash-mod-box-l">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt">
                                       <p class="manag-txt">Manage Notification</p>
                                       <p class="man-count-txt"></p>
                                    </div>
                                    <div class="viewmore-pan">
                                      <a href="{{ URL::to('notification'); }}">
                                       Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                      
                               <!--
                               <div class="dash-mod-box manage-trans-box dash-mod-box-l">  
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-right mod-box-txt"> 
                                       <p class="manag-txt">Manage Profile Change Approval</p>
                                       <p class="man-count-txt">12</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('editapproval'); }}">Viewmore <span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               -->
                               </div>
                               
                               <div class="dashboard-row">           
                               <div class="dash-mod-box dash-mod-l-box manage-divermap-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-left mod-box-txt">
                                       <p class="manag-txt">Drivers on Map</p>
                                    </div>
                                    <div class="viewmore-pan"> 
                                       <a href="{{ URL::to('driversonmap'); }}"<span class="raq">&raquo;</span></a>
                                    </div>
                               </div>
                               
                               <div class="dash-mod-box dash-mod-l-box manage-payment-box">   
                                    <div class="col-left">
                                       <span class="icon icon-magage-sch"></span>
                                    </div>
                                    <div class="col-left mod-box-txt">
                                       <p class="manag-txt">Payment</p>
                                    </div>
                                    <div class="viewmore-pan">
                                       <a href="{{ URL::to('payments'); }}"<span class="raq">&raquo;</span></a>
                                    </div>
                               </div>                       
                               </div>                          
                               </div>
                               
                               <div class="col-left">
                                <div class="dash-mod-box manage-settings-box last">                        
                                  <a href="{{ URL::to('profile'); }}">
                                        <div class="align-center">
                                        <p class="manag-txt">Settings</p>
                                        </div>
                                        <div class="align-center">
                                        <span class="icon icon-magage-sch"></span>
                                        </div>
                                        
                                    </a>
                                    
                                </div>
                               </div>                  
                          </div>                        
                          
                          
                           
             
                      </div>                          



          <!-- dash content row end --> 

    

     <?php

    if(Auth::user()->usertype==1)

    {

    ?>

    <script>

        $("document").ready(function(){

            

        });

    

    //end of document ready function

    </script>

  

    <?php 

    

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

} else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}  





    }  ?>

    <script>

        $("document").ready(function(){

            $(".submit-btn").click(function(e){

    

                e.preventDefault();

              

                var dataString = $("form").serialize(); 


                $.ajax({

                    type: "POST",

                    url : "editpaymentlistingadmin",

                    data : dataString,

                    success : function(data){
                      console.log(data);
          $(".firsttab").html("");            
          $(".result").html(data);

                    }

                });



        });

        });

    

    

    </script>
<?php
}
?>


        <!--dash content row end --> 


    
      
      




@stop