@extends('layouts.dashboardlayout')

@section('body')

<?php
$URL = Session::get('urlpath');
?>


<script type="text/javascript">
$(document).ready(function(){

	var dd = $('.vticker').easyTicker({
		direction: 'up',
		easing: 'easeInOutBack',
		speed: 'slow',
		interval: 2000,
		height: 'auto',
		visible: 4,
		mousePause: 0,
		controls: {
			up: '.up',
			down: '.down',
			toggle: '.toggle',
			stopText: 'Stop !!!'
		}
	}).data('easyTicker');
	
	cc = 1;
	$('.aa').click(function(){
		$('.vticker ul').append('<li>' + cc + ' Triangles can be made easily using CSS also without any images. This trick requires only div tags and some</li>');
		cc++;
	});
	
	$('.vis').click(function(){
		dd.options['visible'] = 3;
		
	});
	
	$('.visall').click(function(){
		dd.stop();
		dd.options['visible'] = 0 ;
		dd.start();
	});
	
});
</script>


		
		
	
		<div class="height-class">
		
        <div class="form-panel" style="border:0px;">
		
        <div class="dash-content-panel" style="padding:0px;"> <!-- dash panel start -->
<?php
if(Auth::user()->usertype ==1)
{
#Admin User Area
?>
<div class="dash-content-row "> <!-- dash content row start -->
			<div class="dash_img">
			 <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Dashboard</h2>

        </div>
		<div class="row-dash">
		
		
		<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/buscompanylayout'); }}">{{ HTML::image('assets/images/bus.png', 'Smart Bus') }}</a>
				<span>Bus</span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/general'); }}">{{ HTML::image('assets/images/school.png', 'Smart Bus') }}
				<span>School</span>
				</a></center>
			</div>
			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentadmission'); }}">{{ HTML::image('assets/images/student2.png', 'Smart Bus') }}</a>
				<span>Student</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/addgovtentity'); }}">{{ HTML::image('assets/images/government.png', 'Smart Bus') }}</a>
				<span>Government</span>
				</center>
			</div>
			
				<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/notifyparent'); }}">{{ HTML::image('assets/images/notify-parent.png', 'Smart Bus') }}</a>
				<span>Notify Parent</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/notifybuscompany'); }}">{{ HTML::image('assets/images/notify-bus.png', 'Smart Bus') }}</a>
				<span>Notify Bus Company</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/notifyschool'); }}">{{ HTML::image('assets/images/notify-school.png', 'Smart Bus') }}</a>
				<span>Notify School</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/profile'); }}">{{ HTML::image('assets/images/setting.png', 'Smart Bus') }}</a>
				<span>Setting</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">{{ HTML::image('assets/images/report2.png', 'Smart Bus') }}</a>
				<span>Report</span>
				</center>
			</div>
			
		</div>
		
		
		
		</div>
		
		
			<div class="dash_news">
		<div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Task to do list</h2>

        </div>
		
  <div class="vticker">
	<ol>
		<li>
		<div class="numb">1</div>
		<span class="list-txt">
		<div class="news-title">View Student List</div>
		View and Manage all the Student List <a  class="link-style" href="{{ URL::to($URL.'/studentlisting'); }}"> Click here..</a>
		</span></li>
		
		<li>
		<div class="numb">2</div>
		<span class="list-txt">
		<div class="news-title">View Bus Company List</div>
		View and Manage all the Bus Company List <a  class="link-style" href="{{ URL::to($URL.'/buscompanylayout'); }}"> Click here..</a></span></li>
		
		<li>
		<div class="numb">3</div>
		<span class="list-txt">
		<div class="news-title">View School List</div>
		View and Manage all the School List<a  class="link-style" href="{{ URL::to($URL.'/general'); }}"> Click here..</a></span></li>
		
		<li>
		<div class="numb">4</div>
		<span class="list-txt">
		<div class="news-title">View Report List</div>
		Search and Export the Reports of Student<a  class="link-style" href="{{ URL::to($URL.'/exportbusattendence'); }}"> Click here..</a></span></li>
				
		
	</ol>
</div>
  
		</div>


</div>
<?php
}
?>

<?php
#Bus Company Main User Area
if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
{
?>
<div class="dash-content-row "> <!-- dash content row start -->
			<div class="dash_img">
			 <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Dashboard</h2>

        </div>
		<div class="row-dash">
		
		
		
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/general'); }}">{{ HTML::image('assets/images/school.png', 'Smart Bus') }}
				<span>School</span>
				</a></center>
			</div>
			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentlisting'); }}">{{ HTML::image('assets/images/student2.png', 'Smart Bus') }}</a>
				<span>Student</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/tarifftype'); }}">{{ HTML::image('assets/images/tarrif.png', 'Smart Bus') }}</a>
				<span>Tariff Type</span>
				</center>
			</div>
			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/driver'); }}">{{ HTML::image('assets/images/driver.png', 'Smart Bus') }}</a>
				<span>Driver</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/timing'); }}">{{ HTML::image('assets/images/time.png', 'Smart Bus') }}</a>
				<span>Timing</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentallocation'); }}">{{ HTML::image('assets/images/bus-allocation.png', 'Smart Bus') }}</a>
				<span>Bus Alloction</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/transportlist'); }}">{{ HTML::image('assets/images/picup.png', 'Smart Bus') }}</a>
				<span>Pick up / Drop off List</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/trackstudent'); }}">{{ HTML::image('assets/images/track.png', 'Smart Bus') }}</a>
				<span>Track Student</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}">{{ HTML::image('assets/images/attendance.png', 'Smart Bus') }}</a>
				<span>Attendance</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/paymentlist'); }}">{{ HTML::image('assets/images/payment.png', 'Smart Bus') }}</a>
				<span>Payments</span>
				</center>
			</div>
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/listfeepaymentge'); }}">{{ HTML::image('assets/images/payment-history.png', 'Smart Bus') }}</a>
				<span>Payments History</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">{{ HTML::image('assets/images/report2.png', 'Smart Bus') }}</a>
				<span>Report</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/addstaff'); }}">{{ HTML::image('assets/images/staff.png', 'Smart Bus') }}</a>
				<span>Staff</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/profile'); }}">{{ HTML::image('assets/images/setting.png', 'Smart Bus') }}</a>
				<span>Setting</span>
				</center>
			</div>
			
		</div>
		
		
		
		</div>
		
		
			<div class="dash_news">
		<div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Today's Trip List</h2>

        </div>
		
  <div class="vticker">
	<ol class="f">
		
		<?php
		$AllVehicle = TranportallocateModel::where('buscompany', '=', Auth::user()->schoolid)->groupby('busid')->get()->toArray();
		
		foreach($AllVehicle as $Vehicle)
		{
		$BusCode = VehicleModel::where('AutoID', $Vehicle['busid'])->pluck('VehicleCode');
		$DriverName = TimingModel::where('VehicleCode', $Vehicle['busid'])->pluck('DriverName');
		$DriverName = DriverModel::where('AutoID', $DriverName)->pluck('DriverName');
		$AMCount = TranportallocateModel::where('busid', $Vehicle['busid'])->where('triptype', 'AM')->count();
		$PMCount = TranportallocateModel::where('busid', $Vehicle['busid'])->where('triptype', 'PM')->count();
		
		
		?>
		<li>
		<div class="numb">1</div>
		<span class="list-txt">
		<div class="news-title">Name : {{ $DriverName }}</div>
		<div class="news-title">Vehicle Code : {{ $BusCode }}</div>
		Total Students : 
		
		<?php
		if($AMCount!='0')
		{
		echo 'AM - '.$AMCount;
		}
		if($PMCount!='0')
		{
		echo 'PM - '.$PMCount;
		}
?>
		</span></li>
		<?php
		}
		?>
		
	</ol>
</div>
  
		</div>


</div>
<?php
}
?>


<?php
#Bus Company Sub User Area
if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
{

if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
{

$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


?>
<div class="dash-content-row "> <!-- dash content row start -->
			<div class="dash_img">
			 <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Dashboard</h2>

        </div>
		<div class="row-dash">
		
	<?php
if($MenuAccess['SchoolListing']==1)
{
?>	
		
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/general'); }}">{{ HTML::image('assets/images/school.png', 'Smart Bus') }}
				<span>School</span>
				</a></center>
			</div>
			
<?php
}
?>	
<?php
if($MenuAccess['StudentListing']==1)
{
?>		
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentlisting'); }}">{{ HTML::image('assets/images/student2.png', 'Smart Bus') }}</a>
				<span>Student</span>
				</center>
			</div>
<?php
}
?>				
<?php
if($MenuAccess['AddTariffType']==1)
{
?>
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/tarifftype'); }}">{{ HTML::image('assets/images/tarrif.png', 'Smart Bus') }}</a>
				<span>Tariff Type</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AddVehicleType']==1)
{
?>							
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/vehicletype'); }}">{{ HTML::image('assets/images/vehicle-type.png', 'Smart Bus') }}</a>
				<span>Vehicle Type</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AddVehicle']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/addvehicle'); }}">{{ HTML::image('assets/images/vehicle.png', 'Smart Bus') }}</a>
				<span>Vehicle</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AddTariffType']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/driver'); }}">{{ HTML::image('assets/images/driver.png', 'Smart Bus') }}</a>
				<span>Driver</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AddDriver']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/timing'); }}">{{ HTML::image('assets/images/time.png', 'Smart Bus') }}</a>
				<span>Timing</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['BusAllocation']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentallocation'); }}">{{ HTML::image('assets/images/bus-allocation.png', 'Smart Bus') }}</a>
				<span>Bus Alloction</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AttendanceReport']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}">{{ HTML::image('assets/images/attendance.png', 'Smart Bus') }}</a>
				<span>Attendance</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['Payments']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/paymentlist'); }}">{{ HTML::image('assets/images/payment.png', 'Smart Bus') }}</a>
				<span>Payments</span>
				</center>
			</div>
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/listfeepaymentge'); }}">{{ HTML::image('assets/images/payment-history.png', 'Smart Bus') }}</a>
				<span>Payments History</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['Export']==1)
{
?>
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">{{ HTML::image('assets/images/report2.png', 'Smart Bus') }}</a>
				<span>Report</span>
				</center>
			</div>
<?php
}
?>
<?php
if($MenuAccess['AddStaff']==1)
{
?>			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/addstaff'); }}">{{ HTML::image('assets/images/staff.png', 'Smart Bus') }}</a>
				<span>Staff</span>
				</center>
			</div>
			
<?php
}
}
?>

			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/profile'); }}">{{ HTML::image('assets/images/setting.png', 'Smart Bus') }}</a>
				<span>Setting</span>
				</center>
			</div>
			
		</div>
		
		
		
		</div>
		
		
			<div class="dash_news">
		<div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Task to do list</h2>

        </div>
		
  <div class="vticker">
	<ol class="f">
		

<?php
if($MenuAccess['SchoolListing']==1)
{
?>			
		<li>
		<div class="numb">1</div>
		<span class="list-txt">
		<div class="news-title">Manage School List</div>
		View and Manage all the School List <a  class="link-style" href="{{ URL::to($URL.'/general'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['StudentListing']==1)
{
?>			
		<li>
		<div class="numb">2</div>
		<span class="list-txt">
		<div class="news-title">View Student List</div>
		View and Manage all the Student List<a  class="link-style" href="{{ URL::to($URL.'/studentlisting'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['ProfileEditApproval']==1)
{
?>			
		<li>
		<div class="numb">3</div>
		<span class="list-txt">
		<div class="news-title">Manage Profile Edit Approval</div>
		View and Manage Profile Edit Approval<a  class="link-style" href="{{ URL::to($URL.'/editapproval'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddTariffType']==1)
{
?>			
		<li>
		<div class="numb">4</div>
		<span class="list-txt">
		<div class="news-title">Manage Tariff List</div>
		View and Manage Tariff List<a  class="link-style" href="{{ URL::to($URL.'/tarifftype'); }}"> Click here..</a></span></li>	
<?php
}
?>
<?php
if($MenuAccess['AddVehicleType']==1)
{
?>			
		<li>
		<div class="numb">5</div>
		<span class="list-txt">
		<div class="news-title">Manage Vehicle Type List</div>
		View and Manage Vehicle Type List<a  class="link-style" href="{{ URL::to($URL.'/vehicletype'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddVehicle']==1)
{
?>			
		<li>
		<div class="numb">6</div>
		<span class="list-txt">
		<div class="news-title">Manage Vehicle List</div>
		View and Manage Vehicle List<a  class="link-style" href="{{ URL::to($URL.'/addvehicle'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddDriver']==1)
{
?>			
		<li>
		<div class="numb">7</div>
		<span class="list-txt">
		<div class="news-title">Manage Driver List</div>
		View and Driver List<a  class="link-style" href="{{ URL::to($URL.'/driver'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddTiming']==1)
{
?>			
		<li>
		<div class="numb">8</div>
		<span class="list-txt">
		<div class="news-title">Manage Timing List</div>
		View and Manage Timing List<a  class="link-style" href="{{ URL::to($URL.'/timing'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddStaff']==1)
{
?>			
		<li>
		<div class="numb">9</div>
		<span class="list-txt">
		<div class="news-title">Manage Bus Allocation List</div>
		View and Manage Bus Allocation List<a  class="link-style" href="{{ URL::to($URL.'/exportbusattendence'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['BusAllocation']==1)
{
?>			
		<li>
		<div class="numb">10</div>
		<span class="list-txt">
		<div class="news-title">Manage Pick up / Drop off List</div>
		View and Manage Pick up / Drop off List<a  class="link-style" href="{{ URL::to($URL.'/transportlist'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['TrackStudent']==1)
{
?>			
		<li>
		<div class="numb">11</div>
		<span class="list-txt">
		<div class="news-title">Track Student</div>
		Track Students and their Location<a  class="link-style" href="{{ URL::to($URL.'/trackstudent'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AttendanceReport']==1)
{
?>		
		<li>
		<div class="numb">12</div>
		<span class="list-txt">
		<div class="news-title">View Attendance List</div>
		View and Manage Attendance List<a  class="link-style" href="{{ URL::to($URL.'/exportbusattendencegovt'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['Payments']==1)
{
?>			
		<li>
		<div class="numb">13</div>
		<span class="list-txt">
		<div class="news-title">View Payments List</div>
		View and Manage Payments List<a  class="link-style" href="{{ URL::to($URL.'/paymentlist'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php
if($MenuAccess['AddStaff']==1)
{
?>			
		<li>
		<div class="numb">14</div>
		<span class="list-txt">
		<div class="news-title">View Staff List</div>
		View and Manage Staff List<a  class="link-style" href="{{ URL::to($URL.'/addstaff'); }}"> Click here..</a></span></li>
<?php
}
?>
<?php

?>					
		
	</ol>
</div>
  
		</div>


</div>
<?php
}
?>

<?php
#Government Entity Main User Area
if(Auth::user()->usertype ==3)
{
?>
<div class="dash-content-row "> <!-- dash content row start -->
			<div class="dash_img">
			 <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Dashboard</h2>

        </div>
		<div class="row-dash">
		
		
		
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/general'); }}">{{ HTML::image('assets/images/school.png', 'Smart Bus') }}
				<span>School</span>
				</a></center>
			</div>
			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentadmission'); }}">{{ HTML::image('assets/images/student2.png', 'Smart Bus') }}</a>
				<span>Student</span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/exportbusattendence'); }}">{{ HTML::image('assets/images/attendance.png', 'Smart Bus') }}</a>
				<span>Attendance</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/feepayment'); }}">{{ HTML::image('assets/images/payment.png', 'Smart Bus') }}</a>
				<span>Payment</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/listfeepayment'); }}">{{ HTML::image('assets/images/payment-history.png', 'Smart Bus') }}</a>
				<span>Payment History </span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/profile'); }}">{{ HTML::image('assets/images/setting.png', 'Smart Bus') }}</a>
				<span>Setting</span>
				</center>
			</div>
			
		</div>
		
		
		
		</div>
		
		
			<div class="dash_news">
		<div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Task to do list</h2>

        </div>
		
  <div class="vticker">
	<ol class="f">
		
		
		<li>
		<div class="news-title">Manage School List</div>
		View and Manage all the School List <a  class="link-style" href="{{ URL::to($URL.'/general'); }}"> Click here..</a></li>
		
	
		<li>
		<div class="news-title">Manage Student List</div>
		View and Manage Students<a  class="link-style" href="{{ URL::to($URL.'/studentlisting'); }}"> Click here..</a></li>	
		
		
		<li>
		<div class="news-title">Manage Attendance List</div>
		View and Manage Attendance List<a  class="link-style" href="{{ URL::to($URL.'/exportbusattendence'); }}"> Click here..</a></li>	
		
		<li>
		<div class="news-title">Manage Payment List</div>
		View and Manage Payment List<a  class="link-style" href="{{ URL::to($URL.'/feepayment'); }}"> Click here..</a></li>
		
		<li>
		<div class="news-title">Manage Payment History</div>
		View and Manage Payment History<a  class="link-style" href="{{ URL::to($URL.'/listfeepayment'); }}"> Click here..</a></li>
						
	</ol>
</div>
  
		</div>


</div>
<?php
}
?>

<?php
#School Main User Area
if(Auth::user()->usertype ==2)
{
?>
<div class="dash-content-row "> <!-- dash content row start -->
			<div class="dash_img">
			 <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Dashboard</h2>

        </div>
		<div class="row-dash">
		
		
		
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/class'); }}">{{ HTML::image('assets/images/class.png', 'Smart Bus') }}
				<span>Grade</span>
				</a></center>
			</div>
			
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentadmission'); }}">{{ HTML::image('assets/images/student2.png', 'Smart Bus') }}</a>
				<span>Student</span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentattendence'); }}">{{ HTML::image('assets/images/attendance.png', 'Smart Bus') }}</a>
				<span>Attendance</span>
				</center>
			</div>
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/trackstudent'); }}">{{ HTML::image('assets/images/track.png', 'Smart Bus') }}</a>
				<span>Track</span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">{{ HTML::image('assets/images/export.png', 'Smart Bus') }}</a>
				<span>Export </span>
				</center>
			</div>
			
			
			<div class="dash_image">
				<center><a href="{{ URL::to($URL.'/profile'); }}">{{ HTML::image('assets/images/setting.png', 'Smart Bus') }}</a>
				<span>Setting</span>
				</center>
			</div>
			
		</div>
		
		
		
		</div>
		
		
			<div class="dash_news">
		<div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Task to do list</h2>

        </div>
		
  <div class="vticker">
	<ol>
		
		
		<li>
		<div class="news-title">Manage Class List</div>
		View and Manage all the Class List <a  class="link-style" href="{{ URL::to($URL.'/class'); }}"> Click here..</a></li>
		
	
		<li>
		<div class="news-title">Manage Student List</div>
		View and Manage Students<a  class="link-style" href="{{ URL::to($URL.'/studentlisting'); }}"> Click here..</a></li>	
		
		
		<li>
		<div class="news-title">Manage Attendance List</div>
		View and Manage Attendance List<a  class="link-style" href="{{ URL::to($URL.'/studentattendence'); }}"> Click here..</a></li>	
		
		<li>
		<div class="news-title">Manage Payment List</div>
		View and Manage Payment List<a  class="link-style" href="{{ URL::to($URL.'/feepayment'); }}"> Click here..</a></li>
		
		<li>
		<div class="news-title">Track Student</div>
		Track Student and Get Information<a  class="link-style" href="{{ URL::to($URL.'/listfeepayment'); }}"> Click here..</a></li>
		
		<li>
		<div class="news-title">Manage Attendance</div>
		View and Manage Attendance<a  class="link-style" href="{{ URL::to($URL.'/exportbusattendenceschool'); }}"> Click here..</a></li>
		
		<li>
		<div class="news-title">Manage Student Details</div>
		View and Manage Student Details<a  class="link-style" href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}"> Click here..</a></li>


		
	</ol>
</div>
  
		</div>


</div>
<?php
}
?>

        </div>

        <!-- dash content row end --> 

        </div>
		
		</div>
{{ HTML::script('assets/js/jquery.vticker.js') }}
<script type="text/javascript">
$('.myclass').vTicker({
speed: 500,
pause: 3000,
showItems: 3,
animation: 'fade',
mousePause: false,
height: 0,
direction: 'up'
});

$('.myclass2').vTicker({
speed: 400,
pause: 4000,
showItems: 2,
animation: 'fade',
mousePause: false,
height: 0,
direction: 'up'
});
</script>

  @stop