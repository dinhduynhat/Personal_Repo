@extends('layouts.dashboardlayout')

@section('body')

            <div class="form-panel">

        <div class="header-panel">

          <h2><!--<span class="icon icon-profile">--></span>Student Register</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Import Student details</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'importprocess', 'files'=> true, 'id' => 'profileupdateprocess')) }}

              <?php

			  if(Auth::user()->usertype==2)

		{

$style="unwant";





} else {

$style="";



}

?>

			  <ul class="dash-form-lister">

			 

                <li class="<?php echo $style;?>">

                  <div class="label-control">                   

					 {{ Form::label('Name', 'School Name ' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

				{{ Form::select('SchoolName', $SchoolDetails,null, array('id'=> 'SchoolName'))}}		                

                  </div>

				   {{ $errors->first('UserName', '<div class="error">:message</div>') }}

                </li>
<li class="">

                  <div class="label-control">                   

					 {{ Form::label('Name', 'Bus Company' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

				{{ Form::select('Company', array(''=>'Select Companyname')+$Companyname,null, array('id'=> 'Company'))}}		                

                  </div>

				   {{ $errors->first('Company', '<div class="error">:message</div>') }}

                </li>
				 <li class="<?php echo $style;?>">

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','size' => '100x100']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>

                <li>

                  <div class="label-control">

                   {{ Form::label('importfile', 'Import file' ) }}<em>*</em>

                  </div>

                  <div class="input-control input-file-control">

                  

					 {{ Form::file('importfile', ['class' => 'Photo']) }}

                    

                  </div>

				   {{ $errors->first('importfile', '<div class="errorsetting">:message</div>') }}

                </li>

                <li class="<?php echo $style;?>">

                  <div class="label-control">

                    {{ Form::label('Email', 'Batch' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

                   {{ Form::text('StudentBatch',date("Y"), array('id'=> 'Batch','readonly')) }}    

                  </div>

				   {{ $errors->first('email', '<div class="error">:message</div>') }}

                </li>
              
              </ul>

              <div class="btn-group form-list-btn-group">

                {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

              </div>

			  {{ Form::close() }}

            </div>

          </div>

          <!-- dash content row end --> 

        </div>

        <!--dash content row end --> 

        <script>

		$("document").ready(function(){

            $("#SchoolName").change(function(e){

		

                e.preventDefault();

                var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });



        });

        });

		 $("document").ready(function(){

		 var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });

		     });

		</script>

      </div>

 

@stop