@extends('layouts.dashboardlayout')
@section('body')

{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}

 <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>

<div class="form-panel">
<div class="header-panel">  <!-------------- start header ------------->

<?php
		if(Auth::user()->usertype ==4)
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/studentallocation'); }}" class="fa fa-street-view customfontawesome" title='Bus Allocation'></a>
		<a href="{{ URL::to($URL.'/transportlist'); }}" class="fa fa-list-ul customfontawesome" title='Pick up / Drop Off List'></a>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		
		</span>
		<?php
		}
		?>

<h2>Add student to bus</h2>
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>                      <!-------------- end header ------------->
<div class="dash-content-panel">  
<!-- dash panel start -->
<div class="dash-content-row">
<!--- dash content row start -->

            <div class="dash-content-head">
              
             </div>
             
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>
 {{ Form::open(array('url' => 'postaddstudentdata', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}
	        <ul class="dash-form-lister"> 
     <li>
      <div class="label-control">
        <label for="LicenseNumber">Student Name </label>
        <em>*</em> </div>
      <div class="input-control" style='width:66% important'>
      {{ Form::select('studentname', array(''=>'Select Studentname')+$studentname,null, array('class'=> 'chosen-select', 'id'=> 'studentname' ))}}   
 <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
        
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Age">Grade </label>
        <em>*</em> </div>
      <div class="input-control">
      {{ Form::text('grade',null, array('id'=> 'grade', 'readonly'=> 'readonly')) }}

       
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Address">Age </label>
        <em>*</em> </div>
      <div class="input-control">
       
       {{ Form::text('age',null, array('id'=> 'age', 'readonly'=> 'readonly')) }}	
      </div>
    </li>

    <li>
      <div class="label-control">
        <label for="Address">Address </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::text('address',null, array('id'=> 'address', 'readonly'=> 'readonly')) }} 
      </div>
    </li>

    <li>
      <div class="label-control">
        <label for="Address">Parent Name </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::text('parentname',null, array('id'=> 'parentname', 'readonly'=> 'readonly')) }} 
      </div>
    </li>
 
    <li>
      <div class="label-control">
         <label>&nbsp;</label>
      </div>
      <div class="input-control check-input-control">
        <input name="addstudent" type="checkbox" id="add_bus" value="1">
        <label for="add_bus">Add to bus </label>
      </div>
    </li>
    </ul>
      <div class="btn-group form-list-btn-group">
    <input class="submit-btn" type="submit" value="Add">
    <input class="resetbutton" type="reset" value="Cancel">
  </div>
        </form>   
             
            </div>  <!----- allote transport section end ------->
            
            
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
       
      </div>
	  
	  <script>
    $('#studentname').change(function()
    {
      console.log('change');
var studid = $("#studentname").val();
      $.ajax({
           type: "POST",
           url : "fetchstuddata",
           data: {studid: studid},
           success : function(data){
          //console.log(data);

          var myArray = data.split('|||');
          
          $('#age').val(myArray[0]);
          $('#grade').val(myArray[1]);
          $('#address').val(myArray[2]);
          $('#parentname').val(myArray[3]);

          

          
          
          }
        });

    
    })
    </script>
 
@stop