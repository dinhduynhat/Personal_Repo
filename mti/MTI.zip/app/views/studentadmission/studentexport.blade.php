@extends('layouts.dashboardlayout')

@section('body')

	<div class="height-class">	
       <div class="form-panel">

        <div class="header-panel">
		<?php if(Auth::user()->usertype ==2) { $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/exportbusattendenceschool'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-download customfontawesome" title='Export Student Details'></a>
		</span>
		<?php } ?>
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/paymentlist'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		<a href="{{ URL::to($URL.'/listfeepaymentge'); }}" class="fa fa-list-alt customfontawesome" title='Payments History'></a>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-info customfontawesome" title='Export Student Details'></a>
		
		</span>
		<?php
		}
		?>
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
		{
		$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<?php
if($MenuAccess['AttendanceReport']==1)
{
?>		
		
		<a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		
		<?php
}
if($MenuAccess['Payments']==1)
{
?>
		<a href="{{ URL::to($URL.'/paymentlist'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		
		<?php
}
if($MenuAccess['PaymentsHistory']==1)
{
?>
		<a href="{{ URL::to($URL.'/listfeepaymentge'); }}" class="fa fa-list-alt customfontawesome" title='Payments History'></a>
		
		<?php
}
if($MenuAccess['Export']==1)
{
?>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-info customfontawesome" title='Export Student Details'></a>
		
		<?php
}

?>
		

		</span>
		<?php
		}
		?>
		<?php
		if(Auth::user()->usertype ==1)
		{
		?>
		<span style='float:right;'>
		<?php $URL = Session::get('urlpath'); ?>
		<a href="{{ URL::to($URL.'/exportbusattendence'); }}" class="fa fa-book customfontawesome" title='Export Bus Attendance'></a>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-info-circle customfontawesome" title='Export Student details'></a>
		</span>
		<?php
		}
		?>
          <h2><!--<span class="icon icon-profile">--></span>Manage Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Export Student details</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportstudentdetailprocessbyschool', 'files'=> true, 'id' => 'profileupdateprocess')) }}

              <div class="col-three-four" style="width:60%">

			  <ul class="dash-form-lister">

			 

                <li >

                  <div class="label-control">                   

					 {{ Form::label('Name', 'School Name ' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

				{{ Form::select('SchoolName', $SchoolDetails,null, array('id'=> 'SchoolName'))}}		                

                  </div>

				   {{ $errors->first('UserName', '<div class="error">:message</div>') }}

                </li>

				 <li >

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','size' => '100x100']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>

                

              </ul>
		</div>
              <div class="btn-group form-list-btn-group">

                {{ Form::submit('Export', ['class' => 'submit-btn']) }}           

              </div>

			  {{ Form::close() }}

            </div>

          </div>

          <!-- dash content row end --> 

        </div>

        <!--dash content row end --> 

        <script>

		$("document").ready(function(){

            $("#SchoolName").change(function(e){

		

                e.preventDefault();

                var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });



        });

        });

		 $("document").ready(function(){

		 var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });

		     });

		</script>

      </div>

   </div><!--height-class ends -->

@stop