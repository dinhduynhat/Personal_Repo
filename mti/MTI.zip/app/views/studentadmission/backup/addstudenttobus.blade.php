@extends('layouts.dashboardlayout')
@section('body')

{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}

 <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>

<div class="form-panel">
<div class="header-panel">  <!-------------- start header ------------->
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>                      <!-------------- end header ------------->
<div class="dash-content-panel">  
<!-- dash panel start -->
<div class="dash-content-row">
<!--- dash content row start -->

            <div class="dash-content-head">
              <h5>Add student to bus</h5>
             </div>
             
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>
 {{ Form::open(array('url' => 'postaddstudentdata', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}
	        <ul class="dash-form-lister"> 
     <li>
      <div class="label-control">
        <label for="LicenseNumber">Student Name </label>
        <em>*</em> </div>
      <div class="input-control">
      {{ Form::select('studentname', array(''=>'Select Studentname')+$studentname,null, array('class'=> 'chosen-select', 'id'=> 'studentname' ))}}   
 <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
        
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Age">Grade </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::select('grade',array(''=>'Select Grade')+$grade,null, array('id'=> 'grade'))}}	
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Address">Age </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::select('age',array(''=>'Select Age')+$age,null, array('id'=> 'age'))}}	
      </div>
    </li>
 
    <li>
      <div class="label-control">
         <label>&nbsp;</label>
      </div>
      <div class="input-control check-input-control">
        <input name="addstudent" type="checkbox" id="add_bus" value="1">
        <label for="add_bus">Add to bus </label>
      </div>
    </li>
    </ul>
      <div class="btn-group form-list-btn-group">
    <input class="submit-btn" type="submit" value="Save">
    <input class="resetbutton" type="reset" value="Cancel">
  </div>
        </form>   
             
            </div>  <!----- allote transport section end ------->
            
            
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
       
      </div>
	  
	  
 
@stop