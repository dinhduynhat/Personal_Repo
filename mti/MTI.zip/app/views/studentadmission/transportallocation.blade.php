@extends('layouts.dashboardlayout')
@section('body')
<style>
.gm-login-iframe{
display:none !important;
}
.removestudent{
display:block !important;
}
.gmnoprint{
display:none !important;
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
<div class="form-panel">
<div class="header-panel">
<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/studentallocation'); }}" class="fa fa-street-view customfontawesome" title='Bus Allocation'></a>
		<a href="{{ URL::to($URL.'/transportlist'); }}" class="fa fa-list-ul customfontawesome" title='Pick up / Drop Off List'></a>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		
		</span>
		<?php
		}
		?>
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
		{
		$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<?php
if($MenuAccess['BusAllocation']==1)
{
?>		
		<a href="{{ URL::to($URL.'/studentallocation'); }}" class="fa fa-street-view customfontawesome" title='Bus Allocation'></a>
		<?php
}
if($MenuAccess['Pickup']==1)
{
?>
		<a href="{{ URL::to($URL.'/transportlist'); }}" class="fa fa-list-ul customfontawesome" title='Pick up / Drop Off List'></a>
		<?php
}
if($MenuAccess['TrackStudent']==1)
{
?>
		<a href="{{ URL::to($URL.'/trackstudent'); }}" class="fa fa-map-marker customfontawesome" title='Track Student'></a>
		<?php
}

?>
		

		</span>
		<?php
		}
		?>
<h2><!--<span class="icon icon-student"></span>-->Manage Transport</h2>


  
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>
<div class="dash-content-panel" style="padding:0px !important;">
<!-- dash panel start -->

<div class="dash-content-row">
<!--- dash content row start -->
            <div class="dash-content-head">
              <h5 class="heading-title" style="margin-left:15px;">Transport Route Listing</h5>
             </div>
            <div class="panel-row" style="margin-left:15px;">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif

        @if(Session::has('mapsuccessmsg'))
        <p class="alert">Route Deleted Succesfully</p>
        @endif

        {{ Session::forget('mapsuccessmsg'); }}
		
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <div class="col-one-one">
            <ul class="dash-form-lister">
              <li>
                <div class="label-control">
                  <label for="r_no">School Name </label>
                  <em>*</em> </div>
                <div class="input-control">
                  {{ Form::select('SchoolName',array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'SchoolName'))}}
                </div>
              </li>
             
              
            </ul>            
            </div>
            
            </div>
		<div class="result"></div>
        <div class="result1"></div>     
		{{ Form::open(array('url' => 'addstudentdatadetails', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}

<input type="hidden" name="updateid" value="" class="updateid"/>
<input type="hidden" name="triptypedata" value="" class="triptypedata"/>
<input type="hidden" name="busiddata" value="" class="busiddata"/>
<input type="hidden" name="schooliddata" value="" class="schooliddata"/>
</form>
{{ Form::open(array('url' => 'removestudentdatadetails', 'files'=> true, 'id' => 'removestudentdatadetails','class'=>'removestudentdatadetails')) }}
<input type="hidden" name="requeststudentid" value="" class="requeststudentid"/>
<input type="hidden" name="updateid" value="" class="updateid"/>
<input type="hidden" name="triptypedata" value="" class="triptypedata"/>
<input type="hidden" name="busiddata" value="" class="busiddata"/>
<input type="hidden" name="schooliddata" value="" class="schooliddata"/>
</form>
             
            <!----- allote transport section end ------->
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
      <script>
		$("document").ready(function(){
            $("#SchoolName").change(function(e){
		
                e.preventDefault();
                var SchoolName = $("#SchoolName").val();
            
                var dataString = 'SchoolName='+SchoolName; 
                $.ajax({
                    type: "POST",
                    url : "searchdriverlist",
                    data : dataString,
                    success : function(data){
					$(".result").html(data);
                       
                    }
                });

        });
		
  });
  
		</script>
      </div>
	  
	  
 
@stop