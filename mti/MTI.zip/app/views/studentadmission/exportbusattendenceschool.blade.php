@extends('layouts.dashboardlayout')

@section('body')
<style>
.fancybox-opened
{
top: 15px !important;
}
</style>
<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>
	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}
		<div class="height-class">
            <div class="form-panel">




 <div class="header-panel">
<?php if(Auth::user()->usertype ==2) { $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/exportbusattendenceschool'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-download customfontawesome" title='Export Student Details'></a>
		</span>
		<?php } ?>
          <h2><!--<span class="icon icon-profile">--></span>Manage Report</h2>

        </div>

        

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Export Bus Attedance </h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              <div class="col-three-four">
             <ul class="dash-form-lister">
  <li style="display:none">
    <div class="label-control">
      <label for="r_no">School</label>
    </div>
    <div class="input-control">
      {{ Form::select('schoolid', $SchoolDetails,null, array('id'=> 'schoolid'))}}    
    </div>
    {{ $errors->first('schoolid', '<div class="error">:message</div>') }}
  </li>
  <li style="width:100%;">
    <div class="label-control">
      <label for="Student Name">Select Month and Year</label>
    </div>
    <div class="input-control">
    <?php
            $curmonth = date("F");
            $month = date("m");
            
            ?>

<select style='width: 130px;' name='PayMonth' id='Month'>
  <option name="PayMonth" value=''>Select Month</option>   
<?php






for($i = $month-3 ; $i <= $month; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
  <option value="<?php echo date("m",mktime(0,0,0,$i,1,date("Y"))); ?>" ><?php echo date("F",mktime(0,0,0,$i,1,date("Y")));?>
  </option>
    <?php
}?>

</select>    


<select name="PayYear" style='width: 130px;' id='Year'>
 <option name="PayYear" value=''>Select Year </option>   
<?php 

$year = date('Y');
$nextyear = date('Y')-1;


$v = date("m"); 



$tmonth =  $v-3;



if ($tmonth<=0) 
{
$from = date("Y")-1;
$to = date("Y");
} else 
{
$from = date("Y");
$to = date("Y");
}




for($i=$from; $i<=$to; $i++)


{

    echo "<option value=".$i.">".$i."</option>";
}
?> 
    
</select> 
        <div id='errorji' style="color:red;display:none; margin-left:9%">
  Month and Year should be Selected
</div>

    
           
    </div>



  </li>

</ul>
</div>
			  {{ Form::close() }}

			     <div class="btn-group form-list-btn-group">
<br>


                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>



			

			

          </div>



          <!-- dash content row end --> 
        </div>

        <!--dash content row end --> 
		<div class="result"></div>
    

      </div>
	  
	 </div><!-- height class ends-->

    
    <script>
        $("document").ready(function(){

        $(".submit-btn").click(function(e){



        if($('#Month').val() == '' || $('#Year').val() == '' )
{


        $("#errorji").show();
        $(".result").hide();
        

   
}

else
{
$(".result").show();
$("#errorji").hide();





        var schoolid = $("#schoolid").val();
        if(1==1)
           {
           e.preventDefault();
           var dataString = $("form").serialize();  
                $.ajax({
                    type: "POST",
                    url : "exportbusattendenceschoolresult",
                    data : dataString,
                    success : function(data){
                      console.log(data);
                    $(".result").html(data);
                    }
                });
            }
          }
        });
        });
    </script>


@stop