<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Smart Bus</title>
{{ HTML::style('assets/css/style.css') }}

</head>
<body>
<div class="main-total-container" >
    <header class="header home-header" id="header" style="display:none;"> 
        <div class="align-center">
        <div class="col-left">
            <div class="logo-section">
               <a href="#">{{ HTML::image('assets/images/logo.png', 'Malden Taxi and Malden Trans Inc Logo', array('class' => '')) }}</a>
            </div>
        </div>
        <div class="col-right">
        </div>
        </div>
    </header> 
@yield('body')    
</body>
</html>
