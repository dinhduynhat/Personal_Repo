<!doctype html>
<?php
$URL = Session::get('urlpath');
?>
<html>

<head>

<meta charset="utf-8">

<title>Smart Bus</title>

<!-- css section start -->

<style>
.profile
{
display:block !important;
margin-left: 30%;
}
</style>
{{ HTML::script('assets/js/jquery-1.10.2.min.js') }}


{{ HTML::style('assets/css/style.css') }}

{{ HTML::style('assets/css/jquery.jscrollpane.css') }}

{{ HTML::style('assets/css/jquery.datetimepicker.css') }}

{{ HTML::style('assets/css/jquery.dataTables.css') }}

{{ HTML::style('assets/css/main.css') }}

	

<!-- js section start -->





{{ HTML::script('assets/js/nav_script.js') }}

{{ HTML::script('assets/js/jquery.datetimepicker.js') }}

{{ HTML::script('assets/js/jquery.dataTables.js') }}

{{ HTML::script('assets/js/jquery-ui.js') }}

{{ HTML::style('assets/css/jquery-ui.css') }}

{{ HTML::script('assets/js/superfish.js') }}

{{ HTML::script('assets/js/easyaspie.min.js') }}

{{ HTML::script('assets/js/jquery.easing.min.js') }}

{{ HTML::script('assets/js/jquery.easy-ticker.js') }}






</head>

<?php
$URL = Session::get('urlpath');

?>

<script>
localStorage.setItem("users", "lock");
localStorage.removeItem("lastname");
</script>
<a href="{{ URL::to($URL.'/forgot/'); }}" class="forgot_btn gen_btn" style='display:none'>Forgot password</a>
<body class="nav-fixed-close" >

<div class="main-total-container">

        <div class="main-content-container"> <!-- main content container start -->
		
	

        <div class="left_column sidebar_left col-left">

        <div class="nav_locker"> <!--- nav locker section start -->

        <div class="onOff_tog">

        <div class="nav-toggler"> </div>

        <span class="navEx-on"> <span class="lock-nav"> Lock </span> <span class="gird_nav"> Grid </span> </span> </div>

        </div>

        <!--- nav locker section end -->

        <div class="main-navigation">

        <div class="scrroll-navigation navigation-scroll" style="width:200px;">

        <ul class="navigation menu-main">

        <li style="display:none;"><a href="{{ URL::to($URL.'/home'); }}" title="Dashboard"><span class="icon dashboard-icon"></span>Dashboard</a></li>
<?php

if(Auth::user()->usertype ==1)

{

?>

        <li  class="Busvisible"><a href="#" title="Transport Company"><span class="icon bus-icon"></span>Manage Transport Company</a>

        <ul>

        <li><a href="{{ URL::to($URL.'/buscompanylayout'); }}" class="buscompanylayout">...Add Bus Company</a></li>

        </ul>

        </li>

		<?php }?>
		
		
<?php
		
	if(3==1)
{
$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select('NotificationAccess', 'SchoolAccess', 'StudentAccess', 'TransportAccess', 'ReportAccess', 'StaffAccess')->get()->first();
	if($MenuAccess['SchoolAccess']==1)
	{
	?>
	<li class="Mastervisible"><a href="#" title="Master"><span class="icon class-icon"></span>Manage School</a>
	<ul>
	<li><a href="{{ URL::to($URL.'/general'); }}" class="School"><?php if(Auth::user()->usertype !=4) { ?>...Add School <?php } else { ?> ...School Listing<?php } ?></a></li>
	</ul>
	</li>
	
	
	<?php
		if($MenuAccess['StudentAccess']==1)
		{
		?>	
		<li  class="Studentvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Manage Student</a>
        <ul>
		<li><a href="{{ URL::to($URL.'/studentlisting'); }}"  class="studentlisting">...Student Listing</a></li> 
		<li ><a href="{{ URL::to($URL.'/editapproval'); }}"  class="editapproval">...Profile Edit Approval</a></li> 
		</ul>
		</li>
		<?php 
		}
		?>
		
		
		<?php
		if($MenuAccess['TransportAccess']==1)
		{
		?>	
		<li  class="Transportvisible"><a href="#" title="Transport"><span class="icon bus-icon"></span>Manage Transport</a>
        <ul>
		
		<li><a href="{{ URL::to($URL.'/tarifftype'); }}" class="tarifftype">...Add Tariff Type</a></li>
		
		<li><a href="{{ URL::to($URL.'/vehicletype'); }}" class="vehicletype">...Add Vehicle Type</a></li>

        <li><a href="{{ URL::to($URL.'/addvehicle'); }}" class="typevehicle">...Add Vehicle</a></li>


        <li><a href="{{ URL::to($URL.'/driver'); }}"  class="Driver">...Add Driver</a></li>

        <li><a href="{{ URL::to($URL.'/timing'); }}"  class="Timing">...Add Timing</a></li>

		<li><a href="{{ URL::to($URL.'/studentallocation'); }}" class="AlphaClassA">...Bus Allocation</a></li>
		<li><a href="{{ URL::to($URL.'/transportlist'); }}" class="transportlist">...Pick up / Drop off List</a></li>
        <li><a href="{{ URL::to($URL.'/trackstudent'); }}" class="trackstudent">...Track Student</a></li>
		
		
		</ul>
		</li>
		<?php 
		}
		?>
		
		<?php
 if($MenuAccess['ReportAccess']==1)
 {
 ?>
 <li  class="Studentreportvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Manage Report</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}"  class="exportattendencebus">...Attendance Report</a></li>   
		 <li><a href="{{ URL::to($URL.'/paymentlist'); }}"  class="exportattendencebusges">...Payments</a></li>  
		   <li><a href="{{ URL::to($URL.'/listfeepaymentge'); }}"  class="exportattendencebusgess">...Payment History</a></li>  
		   <li><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}"  class="studentexportbyschoolprocesslayout">...Export Student Details</a></li>  	
		</ul>
</li>		
 <?php
 }
 ?>
		
			<?php
	if($MenuAccess['StaffAccess']==1)
	{
	
	?>	
        <li  class="ManageStaff"><a href="#" title="Manage Staff"><span class="icon student-icon"></span>Manage Staffs</a>
        <ul>
		<li><a href="{{ URL::to($URL.'/addstaff'); }}" class="ManageStaffAlpha">...Add Staffs</a></li>
		</ul>
		</li>
		<?php 
		
		}
		?>

		<?php
 if($MenuAccess['NotificationAccess']==1)
 {
 ?>
 <li  class="Notification"><a href="#" title="Government"><span class="icon student-icon"></span>Notification</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/notifyparent'); }}" class="NotificationParent">...Notify Parent</a></li>
		<li><a href="{{ URL::to($URL.'/notifyschool'); }}" class="NotificationSchool">...Notify School</a></li>
		<li ><a href="{{ URL::to($URL.'/notifydriver'); }}" class="NotificationDriver">...Notify Driver</a></li>
		</ul>
</li>		
 <?php
 }
?>



	
	<?php
	
	}
	goto renderMenu;
}
?>
		
		
		
		<?php

if(Auth::user()->usertype ==1 || Auth::user()->usertype ==2 || Auth::user()->usertype ==3  || Auth::user()->usertype ==4)

{

?>
    <?php if(Auth::user()->usertype ==2)
    {
    ?>

        <li class="Mastervisible"><a href="#" title="Master"><span class="icon class-icon"></span>Master</a>
     <?php
      }
      else
      {
	  
	  
     ?>
     <li class="Mastervisible"><a href="#" title="Master"><span class="icon class-icon"></span>Manage School</a>
     <?php
		}
     ?>

        <ul>

		<?php

if(Auth::user()->usertype ==1 || Auth::user()->usertype ==3  || Auth::user()->usertype ==4)

{

?>

        <li><a href="{{ URL::to($URL.'/general'); }}" class="School"><?php if(Auth::user()->usertype !=4) { ?>...Add School <?php } else { ?> ...School Listing<?php } ?></a></li>
		

		<?php } if(Auth::user()->usertype ==2)

{   ?>

        <li><a href="{{ URL::to($URL.'/class'); }}"  class="Grade">...Grade</a> </li>

<?php } ?>

		<!--<li><a href="{{ URL::to($URL.'/batch'); }}">Batch</a> </li>

		<li><a href="{{ URL::to($URL.'/gradesection'); }}" class="Gradesection">Grade Section</a> </li>-->
<?php if(Auth::user()->usertype ==2)

{   ?>

        <!--<li><a href="{{ URL::to($URL.'/languagesection'); }}" class="Language">Language</a> </li>-->

       <?php } ?>

        </li>

        </ul>

        </li>
<?php
}
?>


		<?php  if(Auth::user()->usertype ==1 || Auth::user()->usertype ==2|| Auth::user()->usertype ==3 || Auth::user()->usertype ==4)

{ ?>

		 <li  class="Studentvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Manage Student</a>

        <ul>	
<?php
if(Auth::user()->usertype  !=4)

{
?>
        <li><a href="{{ URL::to($URL.'/studentadmission'); }}" class="studentadmission">...Register a Student</a></li>    

		<?php } ?>
        <li><a href="{{ URL::to($URL.'/studentlisting'); }}"  class="studentlisting">...Student Listing</a></li> 
		<?php
if(Auth::user()->usertype  ==4)

{
?>
		 <li ><a href="{{ URL::to($URL.'/editapproval'); }}"  class="editapproval">...Profile Edit Approval</a></li> 
        <?php  
		}
        if(Auth::user()->usertype ==1) {  ?>
        <!--
        <li><a href="{{ URL::to($URL.'/editapproval'); }}"  class="studentlistingapp">...Profile Edit Approval</a></li> 
        -->
        <?php } ?>
<!--<li><a href="{{ URL::to($URL.'/studentgrouplisting'); }}"  class="studentgrouplisting">Student Group Listing</a></li>	-->
		<?php

if(Auth::user()->usertype ==2)

{

?>
        <li><a href="{{ URL::to($URL.'/studentattendence'); }}"  class="studentattendence">...Update Attendence</a></li> 	

        <li><a href="{{ URL::to($URL.'/trackstudent'); }}"  class="trackstudentschool">...Track Students</a></li>  
        
<?php } ?>
        </ul>

        </li>
		<?php } 
		
		if(Auth::user()->usertype ==4)

{

?>

        <li  class="Transportvisible"><a href="#" title="Transport"><span class="icon bus-icon"></span>Manage Transport</a>

        <ul>
		<li><a href="{{ URL::to($URL.'/tarifftype'); }}" class="tarifftype">...Add Tariff Type</a></li>
        <li><a href="{{ URL::to($URL.'/vehicletype'); }}" class="vehicletype">...Add Vehicle Type</a></li>

        <li><a href="{{ URL::to($URL.'/addvehicle'); }}" class="typevehicle">...Add Vehicle</a></li>


        <li><a href="{{ URL::to($URL.'/driver'); }}"  class="Driver">...Add Driver</a></li>

        <li><a href="{{ URL::to($URL.'/timing'); }}"  class="Timing">...Add Timing</a></li>

		<li><a href="{{ URL::to($URL.'/studentallocation'); }}" class="AlphaClassA">...Bus Allocation</a></li>
		<li><a href="{{ URL::to($URL.'/transportlist'); }}" class="transportlist">...Pick up / Drop off List</a></li>
        <li><a href="{{ URL::to($URL.'/trackstudent'); }}" class="trackstudent">...Track Student</a></li>

        </ul>


        <!--<li><a href="{{ URL::to($URL.'/route'); }}"  class="Routes">Add Routes</a></li>
        <li><a href="{{ URL::to($URL.'/destination'); }}"  class="Destination">Add Destination</a></li>-->      
       <!-- <li><a href="{{ URL::to($URL.'/allocation'); }}"  class="Allocation">Add Allocation</a>

        </li>-->

        </li>

		<?php }?>
		
		<?php
  if(Auth::user()->usertype ==1 || Auth::user()->usertype ==2|| Auth::user()->usertype ==3 || Auth::user()->usertype ==4)

{
		?>
		<li  class="Studentreportvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Manage Report</a>

        <ul>
	
		 <li style="display:none !important;"><a href="{{ URL::to($URL.'/exportattendence'); }}"  class="exportattendence">...Attendance Report</a></li> 
    
    <?php 
    if(Auth::user()->usertype ==1)
    {
    ?>                 
         <li><a href="{{ URL::to($URL.'/exportbusattendence'); }}"  class="exportattendencebus">...Attendance Report</a></li>   
         <!--
         <li><a href="{{ URL::to($URL.'/listfeepaymentge'); }}"  class="exportattendencebusge">...Payments From GE</a></li>   
          -->

        <li class='unwant' style='display:none !important'><a href="{{ URL::to($URL.'/paymentlist'); }}"  class="exportattendencebusge">...Payments</a></li>  
       <li class='unwant' style='display:none !important'><a href="{{ URL::to($URL.'/listfeepaymentge'); }}"  class="exportattendencebusges">...Payment List</a></li>  		  
         <?php
     }
	
    if(Auth::user()->usertype ==3 || Auth::user()->usertype ==4)
    {
    ?>                 
         <li><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}"  class="exportattendencebus">...Attendance Report</a></li>   
        
         <?php
     }
         if(Auth::user()->usertype ==4)
    {
         ?>
		  <li><a href="{{ URL::to($URL.'/paymentlist'); }}"  class="exportattendencebusges">...Payments</a></li>  
		   <li><a href="{{ URL::to($URL.'/listfeepaymentge'); }}"  class="exportattendencebusgess">...Payment History</a></li>  
		  
 <?php 
 }
    if(Auth::user()->usertype ==2)
    {
    ?>                 
         <li><a href="{{ URL::to($URL.'/exportbusattendenceschool'); }}"  class="exportattendencebusschool">...Attendance Report</a></li>   
         <?php
     }
         ?>

		 	<?php if(Auth::user()->usertype ==1 || Auth::user()->usertype ==4 || Auth::user()->usertype ==2|| Auth::user()->usertype ==3)

{ ?>
		<li><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}"  class="studentexportbyschoolprocesslayout">...Export Student Details</a></li>  	

<?php } if(Auth::user()->usertype ==3)
{ ?>
		   <li><a href="{{ URL::to($URL.'/feepayment'); }}" class="PaymentA">...Payment</a></li>
        <li><a href="{{ URL::to($URL.'/listfeepayment'); }}" class="PaymentB">...Payment List</a></li>
		<?php } ?>
		</ul>
		</li>

<?php
}

?>

<?php
if(Auth::user()->usertype ==1)
{
?>
        <li  class="Governmentvisible"><a href="#" title="Government"><span class="icon government-icon"></span>Manage Government Entity</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/addgovtentity'); }}" class="Government">...Add Government Entity</a></li>
        <li><a href="{{ URL::to($URL.'/listgovtentity'); }}"  class="listgovtentity">...List Government Entity</a></li>
		   </ul>
        </li>
     
        </li>
<?php
}
?>


<?php
	if(Auth::user()->usertype ==4)
	{
	
	?>	
        <li  class="ManageStaff"><a href="#" title="Manage Staff"><span class="icon student-icon"></span>Manage Staffs</a>
        <ul>
		<li><a href="{{ URL::to($URL.'/addstaff'); }}" class="ManageStaffAlpha">...Add Staffs</a></li>
		</ul>
		</li>
		<?php 
		
		}
		?>


<?php
if(Auth::user()->usertype ==1 || Auth::user()->usertype ==4)
{
?>
        <li  class="Notification"><a href="#" title="Government"><span class="icon student-icon"></span>Notification</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/notifyparent'); }}" class="NotificationParent">...Notify Parent</a></li>

        <li style='display:none !important'><a href="{{ URL::to($URL.'/notifydriver'); }}" class="NotificationDriver">...Notify Driver</a></li>
<?php
if(Auth::user()->usertype ==1)
{
?>

        <li><a href="{{ URL::to($URL.'/notifybuscompany'); }}" class="NotificationBusCompany">...Notify Bus Company</a></li>
<?php
}
?>
<?php
if(Auth::user()->usertype ==4)
{
?>
<li><a href="{{ URL::to($URL.'/notifyschool'); }}" class="NotificationSchool">...Notify School</a></li>
<li ><a href="{{ URL::to($URL.'/notifydriver'); }}" class="NotificationDriver">...Notify Driver</a></li>
<?php
}
?>
<?php
if(Auth::user()->usertype !=4)
{
?>        
        <li><a href="{{ URL::to($URL.'/notifyschool'); }}" class="NotificationSchool">...Notify School</a></li>
  <?php
}
  ?>      
        



        


<!--
        <li><a href="{{ URL::to($URL.'/notifyparentinstant'); }}" class="NotificationParentInstant">...Notify Parent Instant</a></li>
-->        
        

           </ul>
        </li>
     
        </li>
<?php
}
?>

<?php
if(Auth::user()->usertype ==2 || Auth::user()->usertype ==3)
{
?>
        <li  class="NotificationPa"><a href="#" title="Government"><span class="icon student-icon"></span>Notification</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/notifyparent'); }}" class="NotificationParentPa">...Notify Parent</a></li>
<?php
if(Auth::user()->usertype ==3)
{
?>
        <li ><a href="{{ URL::to($URL.'/notifydriver'); }}" class="NotificationDriverPa">...Notify Driver</a></li>
<?php
}
?>
<?php
if(Auth::user()->usertype ==2)
{
?>
<li><a href="{{ URL::to($URL.'/notifybuscompany'); }}" class="NotificationBusPa">...Notify Bus Company</a></li>
<li  ><a href="{{ URL::to($URL.'/notifydriver'); }}" class="NotificationDriverPa">...Notify Driver</a></li>
        
<?php
}
?>

        
<?php
if(Auth::user()->usertype ==3)
{
?>

        
        <li><a href="{{ URL::to($URL.'/notifybuscompany'); }}" class="NotificationBusPa">...Notify Bus Company</a></li>
        <li  ><a href="{{ URL::to($URL.'/notifyschool'); }}" class="NotificationSchoolPa">...Notify School</a></li>
   <?php
    }
   ?>     
           </ul>
        </li>
     
        </li>
<?php
}
renderMenu:
?>


    <li  class="Settings"><a href="#" title="Government"><span class="icon icon-proifle"></span>Settings</a>
        <ul>    
        <li><a href="{{ URL::to($URL.'/profile'); }}" class="ProfileMenu">...Profile</a></li>
        <li><a href="{{ URL::to($URL.'/changepassword'); }}" class="PasswordMenu">...Change Password</a></li>
        

        


        
<!--            
        <li><a href="{{ URL::to($URL.'/notification'); }}" class="Notification">...Notification Settings</a></li>
    -->
            
           </ul>
        </li>
     
        </li>




<?php
//if(Auth::user()->usertype ==3)
//{
?>
        <!--<li  class="Govt"><a href="#" title="Government"><span class="icon student-icon"></span>Report</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}" class="GovtA">...School Report</a></li>
		
        </li>
        </ul>
        </li>-->
<?php
//}
?>

<?php
if(Auth::user()->usertype ==3)
{
?>
        <li  class="Payment unwant" style="display:none !important;"><a href="#" title="Government"><span class="icon school-icon"></span>Payable</a>
        <ul>
        <li><a href="{{ URL::to($URL.'/feepayment'); }}" class="PaymentA">...Fee Payment</a></li>
        <li><a href="{{ URL::to($URL.'/listfeepayment'); }}" class="PaymentB">...Payment List</a></li>
        </li>
        </ul>
        </li>
<?php
}
?>


        </ul>

        </div>

        </div>

        </div>

        <div class="right_column">

        <header class="header" id="header"> 

        <!-- header container start -->

        <div class="align-center">

        <div class="col-left">

        <div class="logo-section"> <a href="{{ URL::to($URL.'/home'); }}">

		
{{ HTML::image('assets/images/logo.png', 'Smart Bus') }}

		

		</a></div>

        </div>

        <div class="col-right">
    <div class="admin-cont">
	
	<?php
	/*
	if(Auth::user()->usertype==1)
		{
	
   echo '<p class="adminlog"><span class="icon"></span> Welcome<span class="adm-sty">Adminstrator</p>';
    } 
	if(Auth::user()->usertype==2)
		{
	
   echo '<p class="schoolog"><span class="icon"></span> School</p>';
    } 
	if(Auth::user()->usertype==3)
		{
	
   echo '<p class="governlog"><span class="icon"></span> Government</p>';
    } 
	if(Auth::user()->usertype==4)
		{
	
   echo '<p class="buslog"><span class="icon"></span> Bus Company</p>';
    } 
	*/
	?>
	<p class="pro-name">Welcome <span style="color: #CBE2F4;"> {{ Auth::user()->FirstName; }}</span></p>
	
    </div>
	
	<!-- <p class="logged-user">My Account<span class="icon icon-proifle"></span></p> -->
        <div class="logged-user-detail">

        <div class="logged-user-panel">


        

        <span class="log-tog-btn">Settings</span> 
		

		</div>
		
	<!-- 	<div class="logged-user-panel1">
		
		<span class="log-tog-btn">Setting</span> 
		</div> -->
		
		<div class="logged-user-panel3">
		<p><a href="{{ URL::to($URL.'/logout'); }}"><span class="icon logout-icon"></span>Logout</a></p>
		</div>

        <div class="user-tog-box">

        <div class="profile-section">

        <?php

$id=Auth::user()->id;

		$schoollogo= ProfileModel::where('id', $id)->get()->toArray();
				if(empty($schoollogo[0]['Photo']))

		{
?><div class="profile-icon"> {{ HTML::image('assets/images/profile-inner.png', 'Profile picture') }} </div><?php } else { ?> 
{{ HTML::image('assets/uploads/profilephoto/'.$schoollogo[0]['Photo'], 'Profile picture', array('class' => 'profile')) }}
<?php } ?>


        <p class="pro-name">{{ Auth::user()->FirstName; }}</p>

        </div>

        <div class="logged-lister">

        <ul>

        <li><a href="{{ URL::to($URL.'/profile'); }}"><span class="icon pro-icon"></span>Profile</a></li>

		<?php

		if(Auth::user()->usertype==2)

		{

		$schoolid=Auth::user()->schoolid;

		?>

		<li><a href="<?php echo url().'/'.Session::get('urlpath');?>/schooledit/<?php echo $schoolid;?>"><span class="icon pro-icon"></span>School Information</a></li>

		<?php } ?>
		<?php

		if(Auth::user()->usertype==4)

		{

		$schoolid=Auth::user()->schoolid;

		?>

		<li><a href="<?php echo url().'/'.Session::get('urlpath');?>/busedit/<?php echo $schoolid;?>"><span class="icon pro-icon"></span>Bus Company Information</a></li>

		<?php } ?>

        <li style="border-bottom: #C5DBE7 2px solid ; "><a href="{{ URL::to($URL.'/changepassword'); }}"><span class="icon pass-icon"></span>Change password</a></li>
        


        </ul>

        </div>

        </div>
		
		

        </div>

        </div>

        </div>

        </header>
		
			<!-- New menu-->
		
		<!-- menu -->
	<div class="menu-sec">
		<div class="align-center"> 
		 <div class="search-blk">
				<input type="text">
				<button class="go-but">GO</button>
			</div> 
<?php
if(Auth::user()->usertype ==1)
{

?>
<!-- Admin -->			
<nav class="applePie">
<div class="menubtn">Menu Button</div>
<ul id="nav">
<li class="home"><a href="{{ URL::to($URL.'/home'); }}" >Dashboard</a>
<ul>
</ul>
</li>
<li class="Busvisible"><a href="#" >Manage Company</a>
<ul>
<li  class="buscompanylayout"><a href="{{ URL::to($URL.'/buscompanylayout'); }}">Add Bus Company</a>
</li>
</ul>
</li>
<li class="Mastervisible"><a href="">Manage School</a>
<ul>
<li class="School"><a href="{{ URL::to($URL.'/general'); }}">Add School</a></li>
</ul>
</li>
<li  class="Studentvisible"><a href="">Manage Student</a>
<ul>
<li class="studentadmission"><a href="{{ URL::to($URL.'/studentadmission'); }}">Register a Student</a></li>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentlisting'); }}">Student Listing</a></li>
</ul>
</li>
<li  class="Studentreportvisible"><a href="">Manage Report</a>
<ul>
<li class="exportattendencebus"><a href="{{ URL::to($URL.'/exportbusattendence'); }}">Attendance Report</a></li>
<li class="studentexportbyschoolprocesslayout"><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">Export Student Details</a></li>
</ul>
</li>
<li class="Governmentvisible"><a href="">Manage Goverment Entry</a>
<ul>
<li class="Government"><a href="{{ URL::to($URL.'/addgovtentity'); }}">Add Government Entity</a></li>
<li class="listgovtentity"><a href="{{ URL::to($URL.'/listgovtentity'); }}">List Government Entity</a></li>
</li>
</ul>
<li  class="NotificationPa"><a href="">Notification</a>
<ul>
<li class="NotificationParentPa"><a href="{{ URL::to($URL.'/notifyparent'); }}">Notify Parent</a></li>
<li class="NotificationBusPa"><a href="{{ URL::to($URL.'/notifybuscompany'); }}">Notify Bus Company</a></li>
<li class="NotificationDriverPa" ><a href="{{ URL::to($URL.'/notifyschool'); }}">Notify School</a></li>
</li>
</nav>
<!-- Admin -->
<?php
}
?>
<?php
if(Auth::user()->usertype ==3)
{
?>
<!-- Admin -->			
<nav class="applePie">
<div class="menubtn">Menu Button</div>
<ul id="nav">
<li class="home"><a href="{{ URL::to($URL.'/home'); }}" >Dashboard</a>
<ul>
</ul>
</li>
<li class="Mastervisible"><a href="">Manage School</a>
<ul>
<li class="School"><a href="{{ URL::to($URL.'/general'); }}">Add School</a></li>
</ul>
</li>
<li  class="Studentvisible"><a href="">Manage Student</a>
<ul>
<li class="studentadmission"><a href="{{ URL::to($URL.'/studentadmission'); }}">Register a Student</a></li>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentlisting'); }}">Student Listing</a></li>
</ul>
</li>
<li  class="Studentreportvisible"><a href="">Manage Report</a>
<ul>
<li class="exportattendencebus"><a href="{{ URL::to($URL.'/exportbusattendence'); }}">Attendance Report</a></li>
<li class="PaymentA"><a href="{{ URL::to($URL.'/feepayment'); }}">Payment</a></li>
<li class="PaymentB"><a href="{{ URL::to($URL.'/listfeepayment'); }}">Payment List</a></li>

</ul>
</li>
<li  class="NotificationPa"><a href="">Notification</a>
<ul>
<li class="NotificationParentPa"><a href="{{ URL::to($URL.'/notifyparent'); }}">Notify Parent</a></li>
<li class="NotificationDriverPa"><a href="{{ URL::to($URL.'/notifydriver'); }}">Notify Bus Driver</a></li>
<li class="Bus-NotificationBusPa"><a href="{{ URL::to($URL.'/notifybuscompany'); }}">Notify Bus Company</a></li>
<li class="NotificationSchoolPa" ><a href="{{ URL::to($URL.'/notifyschool'); }}">Notify School</a></li>
</li>
</nav>
<!-- School -->
<?php
}
?>
<?php
if(Auth::user()->usertype ==2)
{
?>
<!-- Admin -->			
<nav class="applePie">
<div class="menubtn">Menu Button</div>
<ul id="nav">
<li class="home"><a href="{{ URL::to($URL.'/home'); }}" >Dashboard</a>
<ul>
</ul>
</li>
<li class="Mastervisible"><a href="">Manage Master</a>
<ul>
<li class="Grade"><a href="{{ URL::to($URL.'/class'); }}">Add Grade</a></li>
</ul>
</li>
<li  class="Studentvisible"><a href="">Manage Student</a>
<ul>
<li class="studentadmission"><a href="{{ URL::to($URL.'/studentadmission'); }}">Register a Student</a></li>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentlisting'); }}">Student Listing</a></li>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentattendence'); }}">Update Attendance</a></li>
<li class="trackstudentschool"><a href="{{ URL::to($URL.'/trackstudent'); }}">Track Student</a></li>
</ul>
</li>
<li  class="Studentreportvisible"><a href="">Manage Report</a>
<ul>
<li class="exportattendencebusschool"><a href="{{ URL::to($URL.'/exportbusattendenceschool'); }}">Attendance Report</a></li>
<li class="studentexportbyschoolprocesslayout"><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">Export Student Details</a></li>


</ul>
</li>
<li  class="NotificationPa"><a href="">Notification</a>
<ul>
<li class="NotificationParentPa"><a href="{{ URL::to($URL.'/notifyparent'); }}">Notify Parent</a></li>

<li class="Bus-NotificationBusPa"><a href="{{ URL::to($URL.'/notifybuscompany'); }}">Notify Bus Company</a></li>
<li class="NotificationDriverPa" ><a href="{{ URL::to($URL.'/notifydriver'); }}">Notify Driver</a></li>
</li>
</nav>
<!-- Admin -->
<?php
}
?>


<?php
if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
{
?>
<!-- Admin -->			
<nav class="applePie">
<div class="menubtn">Menu Button</div>
<ul id="nav">
<li class="home"><a href="{{ URL::to($URL.'/home'); }}" >Dashboard</a>
<ul>
</ul>
</li>
<li class="Mastervisible"><a href="">Manage School</a>
<ul>
<li class="School"><a href="{{ URL::to($URL.'/general'); }}">School Listing</a></li>
</ul>
</li>
<li  class="Studentvisible"><a href="">Manage Student</a>
<ul>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentlisting'); }}">Student Listing</a></li>
<li class="editapproval"><a href="{{ URL::to($URL.'/editapproval'); }}">Profile Edit Approval</a></li>
</ul>
</li>

<li  class="Transportvisible"><a href="">Manage Transport</a>
<ul>
<li class="tarifftype"><a href="{{ URL::to($URL.'/tarifftype'); }}">Add Tariff Type</a></li>
<li class="vehicletype"><a href="{{ URL::to($URL.'/vehicletype'); }}">Add Vehicle Type</a></li>
<li class="addvehicle"><a href="{{ URL::to($URL.'/addvehicle'); }}">Add Vehicle</a></li>
<li class="Driver"><a href="{{ URL::to($URL.'/driver'); }}">Add Driver</a></li>
<li class="Timing"><a href="{{ URL::to($URL.'/timing'); }}">Add Timing</a></li>
<li class="AlphaClassA"><a href="{{ URL::to($URL.'/exportbusattendence'); }}">Bus Allocation</a></li>
<li class="transportlist"><a href="{{ URL::to($URL.'/transportlist'); }}">Pick up / Drop off List</a></li>
<li class="trackstudent"><a href="{{ URL::to($URL.'/trackstudent'); }}">Track Student</a></li>
</ul>
</li>
<li  class="Studentreportvisible"><a href="">Manage Report</a>
<ul>
<li class="exportattendencebus"><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}">Attendance Report</a></li>
<li class="exportattendencebusges"><a href="{{ URL::to($URL.'/paymentlist'); }}">Payments</a></li>
<li class="exportattendencebusgess"><a href="{{ URL::to($URL.'/listfeepaymentge'); }}">Payments History</a></li>
<li class="studentexportbyschoolprocesslayout"><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">Export Student Details</a></li>
</ul>
</li>

<li  class="ManageStaff"><a href="">Manage Staffs</a>
<ul>
<li class="ManageStaffAlpha"><a href="{{ URL::to($URL.'/addstaff'); }}">Add Staffs</a></li>
</ul>
</li>

<li  class="Notification"><a href="">Notification</a>
<ul>
<li class="NotificationParent"><a href="{{ URL::to($URL.'/notifyparent'); }}">Notify Parent</a></li>
<li class="Bus-NotificationDriver"><a href="{{ URL::to($URL.'/notifydriver'); }}">Notify Driver</a></li>
<li class="NotificationSchool" ><a href="{{ URL::to($URL.'/notifyschool'); }}">Notify School</a></li>

</li>
</nav>
<!-- Admin -->
<?php
}
?>

<?php
if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
{

$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


?>
<!-- Staff -->			
<nav class="applePie">
<div class="menubtn">Menu Button</div>
<ul id="nav">
<li class="home"><a href="{{ URL::to($URL.'/home'); }}" >Dashboard</a>
<ul>
</ul>
</li>
<?php
if($MenuAccess['SchoolListing']==1)
{
?>
<li class="Mastervisible"><a href="">Manage School</a>
<ul>
<li class="School"><a href="{{ URL::to($URL.'/general'); }}">School Listing</a></li>
</ul>
</li>
<?php
}
if($MenuAccess['StudentListing']==1 || $MenuAccess['ProfileEditApproval']==1)
{
?>
<li  class="Studentvisible"><a href="">Manage Student</a>
<ul>
<?php
if($MenuAccess['StudentListing']==1)
{
?>
<li class="studentlisting"><a href="{{ URL::to($URL.'/studentlisting'); }}">Student Listing</a></li>
<?php
}
if($MenuAccess['ProfileEditApproval']==1)
{
?>
<li class="editapproval"><a href="{{ URL::to($URL.'/editapproval'); }}">Profile Edit Approval</a></li>
<?php
}
?>
</ul>
</li>
<?php
}
if($MenuAccess['AddTariffType']==1 || $MenuAccess['AddVehicleType']==1 || $MenuAccess['AddVehicle']==1 
		|| $MenuAccess['AddDriver']==1 || $MenuAccess['AddTiming']==1	|| $MenuAccess['BusAllocation']==1
		|| $MenuAccess['Pickup']==1 || $MenuAccess['TrackStudent']==1
		)
{
?>
<li  class="Transport"><a href="">Manage Transport</a>
<ul>
<?php
if($MenuAccess['AddTariffType']==1)
{
?>
<li class="tarifftype"><a href="{{ URL::to($URL.'/tarifftype'); }}">Add Tariff Type</a></li>
<?php
}
if($MenuAccess['AddVehicleType']==1)
{
?>
<li class="vehicletype"><a href="{{ URL::to($URL.'/vehicletype'); }}">Add Vehicle Type</a></li>
<?php
}
if($MenuAccess['AddVehicle']==1)
{
?>
<li class="addvehicle"><a href="{{ URL::to($URL.'/addvehicle'); }}">Add Vehicle</a></li>
<?php
}
if($MenuAccess['AddDriver']==1)
{
?>
<li class="Driver"><a href="{{ URL::to($URL.'/driver'); }}">Add Driver</a></li>
<?php
}
if($MenuAccess['AddTiming']==1)
{
?>
<li class="Timing"><a href="{{ URL::to($URL.'/timing'); }}">Add Timing</a></li>
<?php
}
if($MenuAccess['BusAllocation']==1)
{
?>
<li class="AlphaClassA"><a href="{{ URL::to($URL.'/studentallocation'); }}">Bus Allocation</a></li>
<?php
}
if($MenuAccess['Pickup']==1)
{
?>
<li class="transportlist"><a href="{{ URL::to($URL.'/transportlist'); }}">Pick up / Drop off List</a></li>
<?php
}
if($MenuAccess['TrackStudent']==1)
{
?>
<li class="trackstudent"><a href="{{ URL::to($URL.'/trackstudent'); }}">Track Student</a></li>
<?php
}
?>
</ul>
</li>
<?php
}
?>
		<?php
 if($MenuAccess['AttendanceReport']==1 ||  $MenuAccess['Payments']==1 || $MenuAccess['PaymentsHistory']==1 || 
 $MenuAccess['Export']==1 
 )
 {?>
<li  class="Studentreportvisible"><a href="">Manage Report</a>
<ul>
<?php

if($MenuAccess['AttendanceReport']==1)
{
?>
<li class="exportattendencebus"><a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}">Attendance Report</a></li>
<?php
}
if($MenuAccess['Payments']==1)
{
?>
<li class="exportattendencebusges"><a href="{{ URL::to($URL.'/paymentlist'); }}">Payments</a></li>
<?php
}
if($MenuAccess['PaymentsHistory']==1)
{
?>
<li class="exportattendencebusgess"><a href="{{ URL::to($URL.'/listfeepaymentge'); }}">Payments History</a></li>
<?php
}
if($MenuAccess['Export']==1)
{
?>
<li class="studentexportbyschoolprocesslayout"><a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}">Export Student Details</a></li>
<?php
}
?>
</ul>
</li>
<?php
}
?>
<?php
if($MenuAccess['AddStaff']==1)
{
?>
<li  class="ManageStaff"><a href="">Manage Staffs</a>
<ul>
<li class="ManageStaffAlpha"><a href="{{ URL::to($URL.'/addstaff'); }}">Add Staffs</a></li>
</ul>
</li>
<?php
}
?>
<?php
if($MenuAccess['ManageParent']==1 || $MenuAccess['ManageSchool']==1 || $MenuAccess['ManageDriver']==1)
{
?>
<li  class="Notification"><a href="">Notification</a>
<ul>
<?php
 if($MenuAccess['ManageParent']==1)
 {
 ?>
<li class="NotificationParent"><a href="{{ URL::to($URL.'/notifyparent'); }}">Notify Parent</a></li>
<?php
}
if($MenuAccess['ManageSchool']==1)
{
?>
<li class="Bus-NotificationDriver"><a href="{{ URL::to($URL.'/notifydriver'); }}">Notify Driver</a></li>
<?php
}
if($MenuAccess['ManageDriver']==1)
{
?>
<li class="NotificationSchool" ><a href="{{ URL::to($URL.'/notifyschool'); }}">Notify School</a></li>
<?php
}
?>
</li>
<?php
}
?>
</nav>
<!-- Admin -->
<?php
}
?>
		</div> 
		</div> 
		<div class="menu-below"></div> 
	</div>
	
	<!--menu ends-->
	

        <div class="scroll-wrapper">

        @yield('body')

        <div class="site-footer">

		<div id="dialog-confirm"></div>

		<script>

		function fnOpenNormalDialog() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");

    $("#dialog-confirm").html("Delete records?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');

		window.location.href=url;

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}



$('.btnOpenDialog').click(fnOpenNormalDialog);



		</script>

        <p>© Malden Taxi & Malden Trans Inc. Powered by: <a href="http://www.bizarresoftware.in/" target="_new" style="color:#323232;">BIZARRE Software Solutions Pvt Ltd</a></p>

        </div>

        </div>

        </div>

        </div>

</div>

{{ HTML::script('assets/js/jquery.jscrollpane.min.js') }}

{{ HTML::script('assets/js/custom_script.js') }}

</body>

</html>
<script>

$(function() { 



});
$(function() { 

if(1==1)

	 {
	 


		var classname=$('a[href^="'+document.URL+'"]').attr("class");	

		
		if(typeof classname=="undefined")
		 {
		  $(".home").addClass("active");
		  }
		
          $("."+classname).addClass("active");
		 if(classname=="School" || classname=="Grade" || classname=="Gradesection" || classname=="Language")
		 {
		  
		  $(".Mastervisible").addClass("active");
		  }
		   if(classname=="studentadmission" || classname=="studentlisting" || classname=="studentattendence" || classname=="trackstudentschool" || classname=="editapproval")
		 {
		  $(".Studentvisible").addClass("active");
		  }
		   if(classname=="exportattendence" || classname=="exportattendencebus" || classname=="exportattendencebusge" || classname=="exportattendencebusges" || classname=="exportattendencebusgess" ||  classname=="exportattendencebusschool" ||  classname=="studentexportbyschoolprocesslayout" ||classname=="PaymentA" || classname=="PaymentB")
		 {
		  $(".Studentreportvisible").addClass("active");
		  }
		  if(classname=="typevehicle" || classname=="Routes" || classname=="Destination" || classname=="Driver" || classname=="Timing" || classname=="Allocation" || classname=="AlphaClassA" || classname=="transportlist" || classname=="trackstudent" || classname=="vehicletype" || classname=="tarifftype" || classname=="vehiclemenu")
		 {
		  $(".Transportvisible").addClass("active");
		  }
               if(classname=="Government" || classname=="listgovtentity")
		 {
		  $(".Governmentvisible").addClass("active");
		  }
                if(classname=="GovtA")
         {
          $(".Govt").addClass("active");
          }
                if(classname=="PaymentA" || classname=="PaymentB")
         {
          //$(".Payment").addClass("hover"); NotificationDriver
          }
            if(classname=="NotificationDriver" || classname=="NotificationParent" ||  classname=="NotificationParentInstant" || classname=="NotificationDriverInstant"  || classname=="NotificationSchool"  || classname=="NotificationBusCompany")
         {
          $(".Notification").addClass("active");
          }
		  
		  if(classname=="ManageStaffAlpha")
         {
          $(".ManageStaff").addClass("active");
          }
		  
		  
            if(classname=="NotificationParentPa" || classname=="NotificationDriverPa" || classname=="NotificationBusCompanyPa" || classname=="NotificationSchoolPa" || classname=="NotificationBusPa" || classname=="NotificationDriverPa")
         {
          $(".NotificationPa").addClass("active");
          }
          if(classname=="ProfileMenu" || classname=="PasswordMenu" || classname=="LogoutMenu")
         {
          $(".Settings").addClass("active");
          }
		    if(classname=="buscompanylayout")
         {
          $(".Busvisible").addClass("active");
          }
		  
		 
		 if(classname=="Parent-NotificationGovt" || classname=="Driver-NotificationGovt" || classname=="Bus-NotificationGovt" || classname=="School-NotificationGovt")
         {
		 
          $(".NotificationGovt").addClass("active");
          }
		  
		  }
     //})
});
</script>

<script type="text/javascript">
$(document).ready(function() {

localStorage.setItem("users", "lock");
localStorage.removeItem("users");

	$('nav').easyPie();
});    
</script>
<script>
localStorage.setItem("users", "lock");
localStorage.removeItem("users");
</script>