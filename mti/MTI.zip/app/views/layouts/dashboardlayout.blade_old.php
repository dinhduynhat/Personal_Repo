<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Smart Bus</title>
<!-- css section start -->
{{ HTML::style('assets/css/style.css') }}
{{ HTML::style('assets/css/jquery.jscrollpane.css') }}
{{ HTML::style('assets/css/jquery.datetimepicker.css') }}

<!-- js section start -->

{{ HTML::script('assets/js/jquery-1.10.2.min.js') }}
{{ HTML::script('assets/js/nav_script.js') }}
{{ HTML::script('assets/js/jquery.datetimepicker.js') }}
</head>
<body class="nav-fixed-close">
<div class="main-total-container">
        <div class="main-content-container"> <!-- main content container start -->
        <div class="left_column sidebar_left col-left">
        <div class="nav_locker"> <!--- nav locker section start -->
        <div class="onOff_tog">
        <div class="nav-toggler"> </div>
        <span class="navEx-on"> <span class="lock-nav"> Lock </span> <span class="gird_nav"> Grid </span> </span> </div>
        </div>
        <!--- nav locker section end -->
        <div class="main-navigation">
        <div class="scrroll-navigation navigation-scroll" style="width:200px;">
        <ul class="navigation menu-main">
        <li><a href="#" title="Dashboard"><span class="icon dashboard-icon"></span>Dashboard</a></li>
        <li><a href="#" title="Schools"><span class="icon class-icon"></span>Master</a>
        <ul>
        <li><a href="#">Academic Year</a></li>
        <li><a href="#">Holiday Dates</a></li>
        <li><a href="#">Location</a>
        <ul>
        <li><a href="#">Counliy</a></li>
        <li><a href="#">Region</a></li>
        <li><a href="#">City</a></li>
        <li><a href="#">Area</a></li>
        </ul>
        </li>
        
        </li>
        <li><a href="#">Schools</a>
        <ul>
        <li><a href="#">Schools</a></li>
        <li><a href="#">Classes</a></li>
        </ul>
        </li>
        </ul>
        </li>
        <li><a href="#" title="Class"><span class="icon icon-proifle"></span>User</a>
        <ul>
        <li><a href="#">User Creation</a></li>
        <li><a href="#">User Rights</a></li>
        </ul>
        </li>
        <li><a href="#" title="Schools"><span class="icon parent-icon"></span>Parent</a>
        <ul>
        <li><a href="#">Profile & Child Info</a></li>
        <li><a href="#">Report</a>
        <ul>
        <li><a href="#">Student - Bus Details</a></li>
        <li><a href="#">Attendance</a></li>
        <li><a href="#">Route, Bus, liip Wise</a></li>
        </ul>
        </li>
        </ul>
        </li>
        <li><a href="#" title="Schools"><span class="icon student-icon"></span>Student</a>
        <ul>
        <li><a href="#">Students</a></li>
        <li><a href="#">Report</a>
        <ul>
        <li><a href="#">Attendance</a></li>
        <li><a href="#">Studentwise</a></li>
        </ul>
        </li>
        </ul>
        </li>
        <li><a href="#" title="Schools"><span class="icon bus-icon"></span>Transport</a>
        <ul>
        <li><a href="{{ URL::to('vehicle'); }}">Add Vehicle</a></li>
        <li><a href="{{ URL::to('route'); }}">Add Routes</a>
        <li><a href="{{ URL::to('destination'); }}">Add Destination</a>
        <li><a href="{{ URL::to('driver'); }}">Add Driver</a>
        <li><a href="{{ URL::to('timing'); }}">Add Timing</a>
        <li><a href="{{ URL::to('allocation'); }}">Add Allocation</a>
        <!--
        <ul>
        <li><a href="#">Route Mapping</a></li>
        <li><a href="#">Route Amount Fixing</a></li>
        </ul>
        -->
        </li>
        <li><a href="#">Allocation</a>
        <ul>
        <li><a href="#">Student - Bus Allocation</a></li>
        <li><a href="#">Manage Allocation</a></li>
        </ul>
        </li>
        <li><a href="#">Payment</a>
        <ul>
        <li><a href="#">Bus Company</a></li>
        </ul>
        </li>
        <li><a href="#">Report</a>
        <ul>
        <li><a href="#">Route, Bus, liip Wise</a></li>
        <li><a href="#">Attendance</a></li>
        <li><a href="#">Operator</a></li>
        <li><a href="#">Academic Yearwise</a></li>
        <li><a href="#">Today Status</a></li>
        <li><a href="#">Payment</a></li>
        </ul>
        </li>
        </ul>
        </li>
        <li><a href="#" title="Schools"><span class="icon school-icon"></span>School</a>
        <ul>
        <li><a href="#">Daily Attendance</a>
        <ul>
        <li><a href="#">Pickup & Drop Attendance</a></li>
        </ul>
        </li>
        <li><a href="#">Class</a>
        <ul>
        <li><a href="#">School - Class Mapping</a></li>
        </ul>
        </li>
        <li><a href="#">Report</a>
        <ul>
        <li><a href="#">Attendance</a></li>
        <li><a href="#">Route, Bus, liip Wise</a></li>
        </ul>
        </li>
        </ul>
        </li>
        <li><a href="#" title="Schools"><span class="icon government-icon"></span>Government Entity</a>
        <ul>
        <li><a href="#">Payment</a>
        <ul>
        <li><a href="#">All Company</a></li>
        </ul>
        </li>
        <li><a href="#">Report</a>
        <ul>
        <li><a href="#">Academic Year, Route, Bus, liip Wise</a></li>
        </ul>
        </li>
        </ul>
        </li>
        </ul>
        </div>
        </div>
        </div>
        <div class="right_column">
        <header class="header" id="header"> 
        <!-- header container start -->
        <div class="align-center">
        <div class="col-left">
        <div class="logo-section"> <a href="#">{{ HTML::image('assets/images/logo.png', 'Smart Bus') }}</a> </div>
        </div>
        <div class="col-right">
        <div class="logged-user-detail">
        <div class="logged-user-panel">
        <p class="logged-user"><span class="icon icon-proifle"></span>Jhon cena</p>
        <span class="log-tog-btn"></span> </div>
        <div class="user-tog-box">
        <div class="profile-section">
        <div class="profile-icon">{{ HTML::image('assets/images/profile-inner.png', 'Profile picture') }}</div>
        <p class="pro-name">Jhon cena</p>
        </div>
        <div class="logged-lister">
        <ul>
        <li><a href="#"><span class="icon pro-icon"></span>Profile</a></li>
        <li><a href="#"><span class="icon pass-icon"></span>Change password</a></li>
        <li><a href="#"><span class="icon logout-icon"></span>Logout</a></li>
        </ul>
        </div>
        </div>
        </div>
        </div>
        </div>
        </header>
        @yield('body')    
        </div>
        </div>
</div>
{{ HTML::script('assets/js/jquery.jscrollpane.min.js') }}
{{ HTML::script('assets/js/custom_script.js') }}
</body>
</html>