<style type="text/css">
html {
    overflow-y: hidden;
    overflow-x: hidden;
}
html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    vertical-align: baseline;
}
body
{
    padding: 0px;
    margin: 10px;
}
table.atrtendTable 
{
    border-collapse: collapse;
    border-bottom: 1px solid #e5e5e5;
    font-family: Verdana, Geneva, sans-serif;
    font-size: 10px;
}
 table.atrtendTable thead tr th:first-child {
    text-align: left;
    padding-left: 8px;
    width: 108px;
}
table.atrtendTable tbody tr {
background-color: white;
}
table.atrtendTable thead th {
    padding: 10px 2px;
    border: 1px solid #dddddd;
    border-collapse: collapse;
    text-align: center;
}
table.atrtendTable tbody tr td {
    padding: 5px 4px;
    border: 1px solid #dddddd;
    text-align: center;
}
table.atrtendTable tbody tr span, .at_icon {
    width: 10px;
    height: 12px;
    display: block;
    margin: 0 auto;
    float: none;
    text-indent: -9999px;
}
table.atrtendTable tbody tr span.sg, span.sg {
    background:  url(http://localhost/mti/assets/images/sg.png) center center no-repeat;
    margin-bottom: 5px;
}
table.atrtendTable tbody tr span.hg, span.hg {
    background:  url(http://localhost/mti/assets/images/hg.png) center center no-repeat;
    margin-bottom: 5px;
}
</style>



<?php

function countDays($year, $month, $ignore) {
    $count = 0;
    $counter = mktime(0, 0, 0, $month, 1, $year);
    while (date("n", $counter) == $month) {
        if (in_array(date("w", $counter), $ignore) == false) {
            $count++;
        }
        $counter = strtotime("+1 day", $counter);
    }
    return $count;
}
	$wdays = countDays($Year, $Month, array(0, 6)); 

		
	 $GeneralSettingDetails = GovernmentEntityModel::all()->toArray();
        $CountryDetails = CountryModel::lists('countryName', 'countryName');
        $CurrencyDetails = CountryModel::lists('currencyCode', 'currencyCode');
        $TomeZoneDetails = TimeZoneModel::lists('tmezone', 'tmezone');

$count = cal_days_in_month(CAL_GREGORIAN, $Month, $Year); 



$headcol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	$headcol .= '<th>'.$i.'</th>';
}

$SchoolDetails = StudentAdmissionModel::where('SchoolName', $School)->get();
$SchoolDetailsCount = StudentAdmissionModel::where('SchoolName', $School)->count();

$name = '';
foreach ($SchoolDetails as $key ) 
{
$totalabsent='';
$bodycol = "";	 
for ($i=1; $i <= $count	; $i++) 
{ 
	#$bodycol .= '<td><span class="fr_ho"></span><span class="fr_sc"></span></td>';
	$today = $Year.'-'.$Month.'-'.$i;


	$StudDataVal = StudentAttandenceModel::where('studentid', $key->id)->where('date', $today)->first();

$totalabsent='';
if ($StudDataVal) 
{
	if ($StudDataVal->tohome=='1')
{
	$toh = '<span class="hgr">1</span>';

}
else
{
	$toh = '<span class="hr">0</span>';
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$toh = '<span class="hg">-</span>';
	
}


if ($StudDataVal) 
{
	if ($StudDataVal->toschool=='1')
{
	$tos = '<span class="sgr">1</span>';

}
else
{
	$tos = '<span class="sr">0</span>';
	$totalabsent .= 0.5.'+';
}	
}
else
{
	$tos = '<span class="sg">-</span>';	
}
	
	$bodycol .= '<td>'.$toh.$tos.'</td>';
}
$sum = array_sum( explode( '+', $totalabsent ) );
	
$name.=	'<tr>
		<td>'.$key->PersonalFirstName.' '.$key->PersonalLastName.'</td>
    	<td>'.$key->StudentCourse.'</td>
        '.$bodycol.'
        <td>'.$wdays.'</td>
        <td>'.$sum.'</td>
        <td>'.$sum.'</td>
        </tr>';

}


$hidecount = "";
for ($i=0; $i < $count + 5	; $i++) 
{ 
	$hidecount .= $i.',';
}

$recordcount = '5';

$result = '
<p align="center">
<h2>School Name : Raja School</h2>
<h4>Attendance Report for November - 2015</h4>
</p>

        <table class="example tab atrtendTable" id="example">
        <thead>
        <tr>
		<th style="width:75px;">Student Name</th>
        <th>Grade</th>
        '.$headcol.'
        <th>Total</th>
        <th>Present</th>
        <th>Absent</th>
        </tr>
        </thead>
        <tbody>
        '.$name.'
        </tbody>
        </table>

        ';
echo $result;

        ?>