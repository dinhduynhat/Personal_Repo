<!doctype html>

<html>

<head>

<meta charset="utf-8">

<title>Smart Bus</title>

<!-- css section start -->

<style>
.profile
{
display:block !important;
margin-left: 61px;
}
</style>

{{ HTML::style('assets/css/style.css') }}

{{ HTML::style('assets/css/jquery.jscrollpane.css') }}

{{ HTML::style('assets/css/jquery.datetimepicker.css') }}

{{ HTML::style('assets/css/jquery.dataTables.css') }}



		

<!-- js section start -->



{{ HTML::script('assets/js/jquery-1.10.2.min.js') }}

{{ HTML::script('assets/js/nav_script.js') }}

{{ HTML::script('assets/js/jquery.datetimepicker.js') }}

{{ HTML::script('assets/js/jquery.dataTables.js') }}

{{ HTML::script('assets/js/jquery-ui.js') }}

{{ HTML::style('assets/css/jquery-ui.css') }}

</head>



<body class="nav-fixed-close">

<div class="main-total-container">

        <div class="main-content-container"> <!-- main content container start -->

        <div class="left_column sidebar_left col-left">

        <div class="nav_locker"> <!--- nav locker section start -->

        <div class="onOff_tog">

        <div class="nav-toggler"> </div>

        <span class="navEx-on"> <span class="lock-nav"> Lock </span> <span class="gird_nav"> Grid </span> </span> </div>

        </div>

        <!--- nav locker section end -->

        <div class="main-navigation">

        <div class="scrroll-navigation navigation-scroll" style="width:200px;">

        <ul class="navigation menu-main">

        <li><a href="{{ URL::to('home'); }}" title="Dashboard"><span class="icon dashboard-icon"></span>Dashboard</a></li>

		<?php

if(Auth::user()->usertype ==1 || Auth::user()->usertype ==2)

{

?>

        <li class="Mastervisible"><a href="#" title="Master"><span class="icon class-icon"></span>Register School</a>

        <ul>

		<?php if(Auth::user()->usertype !=2) { ?>

        <li><a href="{{ URL::to('general'); }}" class="School">...Add School</a></li>

		<?php } if(Auth::user()->usertype ==2)

{   ?>

        <li><a href="{{ URL::to('class'); }}"  class="Grade">...Grade</a> </li>

<?php } ?>

		<!--<li><a href="{{ URL::to('batch'); }}">Batch</a> </li>

		<li><a href="{{ URL::to('gradesection'); }}" class="Gradesection">Grade Section</a> </li>-->
<?php if(Auth::user()->usertype ==2)

{   ?>

        <!--<li><a href="{{ URL::to('languagesection'); }}" class="Language">Language</a> </li>-->

       <?php } ?>

        </li>

        </ul>

        </li>
<?php

if(Auth::user()->usertype ==1)

{

?>

        <li  class="Transportvisible"><a href="#" title="Transport"><span class="icon bus-icon"></span>Transport</a>

        <ul>

        <li><a href="{{ URL::to('vehicle'); }}" class="Vehicle">...Add Vehicle</a></li>

        <!---<li><a href="{{ URL::to('route'); }}"  class="Routes">Add Routes</a></li>

        <li><a href="{{ URL::to('destination'); }}"  class="Destination">Add Destination</a></li>--->

        <li><a href="{{ URL::to('driver'); }}"  class="Driver">...Add Driver</a></li>

        <li><a href="{{ URL::to('timing'); }}"  class="Timing">...Add Timing</a></li>

		<li><a href="{{ URL::to('studentallocation'); }}" class="AlphaClassA">...Bus Allocation</a></li>
		<li><a href="{{ URL::to('transportlist'); }}" class="transportlist">...Pick up / Drop off List</a></li>
		
       <!-- <li><a href="{{ URL::to('allocation'); }}"  class="Allocation">Add Allocation</a>

        </li>-->

        </ul>

        </li>

		<?php }?>


		<?php } if(Auth::user()->usertype ==1 || Auth::user()->usertype ==2)

{ ?>

		 <li  class="Studentvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Student</a>

        <ul>	

        <li><a href="{{ URL::to('studentadmission'); }}" class="studentadmission">...Register a Student</a></li>    

        <li><a href="{{ URL::to('studentlisting'); }}"  class="studentlisting">...Student Listing</a></li> 
<!--<li><a href="{{ URL::to('studentgrouplisting'); }}"  class="studentgrouplisting">Student Group Listing</a></li>	-->
		<?php

if(Auth::user()->usertype ==2)

{

?>
        <li><a href="{{ URL::to('studentattendence'); }}"  class="studentattendence">...Update Attendence</a></li> 	
<?php } ?>
        </ul>

        </li>
		<li  class="Studentreportvisible"><a href="#" title="Student"><span class="icon class-icon"></span>Report</a>

        <ul>
	
		 <li><a href="{{ URL::to('exportattendence'); }}"  class="exportattendence">...Attendance Report</a></li> 
		 	<?php if(Auth::user()->usertype ==1)

{ ?>
		<li><a href="{{ URL::to('studentexportbyschoolprocesslayout'); }}"  class="studentexportbyschoolprocesslayout">...Export Student Details</a></li>  	
<?php } ?>
		   
		</ul>
		</li>

<?php
}

?>

<?php
if(Auth::user()->usertype ==1)
{
?>
        <li  class="Governmentvisible"><a href="#" title="Government"><span class="icon government-icon"></span>Government Entity</a>
        <ul>
        <li><a href="{{ URL::to('addgovtentity'); }}" class="Government">...Add Government Entity</a></li>
        <li><a href="{{ URL::to('listgovtentity'); }}"  class="listgovtentity">...List Government Entity</a></li>
		   </ul>
        </li>
     
        </li>
<?php
}
?>




<?php
if(Auth::user()->usertype ==1)
{
?>
        <li  class="Notification"><a href="#" title="Government"><span class="icon student-icon"></span>Notification</a>
        <ul>
        <li><a href="{{ URL::to('notifyparent'); }}" class="NotificationParent">...Notify Parent</a></li>
        <li><a href="{{ URL::to('notifydriver'); }}" class="NotificationDriver">...Notify Driver</a></li>
           </ul>
        </li>
     
        </li>
<?php
}
?>

<?php
if(Auth::user()->usertype ==2)
{
?>
        <li  class="NotificationPa"><a href="#" title="Government"><span class="icon student-icon"></span>Notification</a>
        <ul>
        <li><a href="{{ URL::to('notifyparent'); }}" class="NotificationParentPa">...Notify Parent</a></li>
        
           </ul>
        </li>
     
        </li>
<?php
}
?>


<?php
if(Auth::user()->usertype ==1)
{
?>
        <li  class="Settings"><a href="#" title="Government"><span class="icon icon-proifle"></span>Settings</a>
        <ul>
            <!--
        <li><a href="{{ URL::to('notification'); }}" class="Government">Notification Settings</a></li>
            -->
           </ul>
        </li>
     
        </li>
<?php
}
?>



<?php
if(Auth::user()->usertype ==3)
{
?>
        <li  class="Govt"><a href="#" title="Government"><span class="icon student-icon"></span>Attendance</a>
        <ul>
        <li><a href="{{ URL::to('exportattendence'); }}" class="GovtA">...Student Attendance</a></li>
		
        </li>
        </ul>
        </li>
<?php
}
?>

<?php
if(Auth::user()->usertype ==3)
{
?>
        <li  class="Payment"><a href="#" title="Government"><span class="icon school-icon"></span>Fee Payment</a>
        <ul>
        <li><a href="{{ URL::to('feepayment'); }}" class="PaymentA">...Fee Payment</a></li>
        <li><a href="{{ URL::to('listfeepayment'); }}" class="PaymentB">...Edit Fee Payment</a></li>
        </li>
        </ul>
        </li>
<?php
}
?>


        </ul>

        </div>

        </div>

        </div>

        <div class="right_column">

        <header class="header" id="header"> 

        <!-- header container start -->

        <div class="align-center">

        <div class="col-left">

        <div class="logo-section"> <a href="{{ URL::to('home'); }}">

		<?php

		if(Auth::user()->usertype==2)

		{

		$schoolid=Auth::user()->schoolid;

		$schoollogo= GeneralSettingModel::where('id', $schoolid)->get()->toArray();

		if(!empty($schoollogo[0]['UploadLogo']))

		{

		?>

		{{ HTML::image('assets/uploads/uploadschoollogo/'.$schoollogo[0]['UploadLogo'], 'Smart Bus') }}

		<?php

         } else { 

		 

		 ?>

		 	{{ HTML::image('assets/images/logo.png', 'Smart Bus') }}

		 <?php

		 }	 



		} else {  ?>

		{{ HTML::image('assets/images/logo.png', 'Smart Bus') }}

     <?php } ?>

		</a></div>

        </div>

        <div class="col-right">

        <div class="logged-user-detail">

        <div class="logged-user-panel">

        <p class="logged-user"><span class="icon icon-proifle"></span>{{ Auth::user()->FirstName; }}</p>

        <span class="log-tog-btn"></span> </div>

        <div class="user-tog-box">

        <div class="profile-section">

        <?php

$id=Auth::user()->id;

		$schoollogo= ProfileModel::where('id', $id)->get()->toArray();
				if(empty($schoollogo[0]['Photo']))

		{
?><div class="profile-icon"> {{ HTML::image('assets/images/profile-inner.png', 'Profile picture') }} </div><?php } else { ?> 
{{ HTML::image('assets/uploads/profilephoto/'.$schoollogo[0]['Photo'], 'Profile picture', array('class' => 'profile')) }}
<?php } ?>


        <p class="pro-name">{{ Auth::user()->FirstName.' '.Auth::user()->LastName; }}</p>

        </div>

        <div class="logged-lister">

        <ul>

        <li><a href="{{ URL::to('profile'); }}"><span class="icon pro-icon"></span>Profile</a></li>

		<?php

		if(Auth::user()->usertype==2)

		{

		$schoolid=Auth::user()->schoolid;

		?>

		<li><a href="<?php echo url();?>/schooledit/<?php echo $schoolid;?>"><span class="icon pro-icon"></span>School Information</a></li>

		<?php } ?>

        <li><a href="{{ URL::to('changepassword'); }}"><span class="icon pass-icon"></span>Change password</a></li>

        <li><a href="{{ URL::to('logout'); }}"><span class="icon logout-icon"></span>Logout</a>

        </ul>

        </div>

        </div>

        </div>

        </div>

        </div>

        </header>

        <div class="scroll-wrapper">

        @yield('body')

        <div class="site-footer">

		<div id="dialog-confirm"></div>

		<script>

		function fnOpenNormalDialog() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Delete records?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');

		window.location.href=url;

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}



$('.btnOpenDialog').click(fnOpenNormalDialog);



		</script>

        <p>© Malden Taxi & Malden Trans Inc. Powered by: <a href="http://www.bizarresoftware.in/" target="_new">BIZARRE Software Solutions Pvt Ltd</a></p>

        </div>

        </div>

        </div>

        </div>

</div>

{{ HTML::script('assets/js/jquery.jscrollpane.min.js') }}

{{ HTML::script('assets/js/custom_script.js') }}

</body>

</html>
<script>
$(function() { 
if(localStorage.getItem("users")=="lock")

	 {


		  var classname=$('a[href^="'+document.URL+'"]').attr("class");	

          $("."+classname).addClass("active");
		 if(classname=="School" || classname=="Grade" || classname=="Gradesection" || classname=="Language")
		 {
		  $(".Mastervisible").addClass("hover");
		  }
		   if(classname=="studentadmission" || classname=="studentlisting" || classname=="studentattendence")
		 {
		  $(".Studentvisible").addClass("hover");
		  }
		   if(classname=="exportattendence" || classname=="studentexportbyschoolprocesslayout" )
		 {
		  $(".Studentreportvisible").addClass("hover");
		  }
		  if(classname=="Vehicle" || classname=="Routes" || classname=="Destination"||classname=="Driver" || classname=="Timing" || classname=="Allocation" || classname=="AlphaClassA" || classname=="transportlist")
		 {
		  $(".Transportvisible").addClass("hover");
		  }
               if(classname=="Government" || classname=="listgovtentity")
		 {
		  $(".Governmentvisible").addClass("hover");
		  }
                if(classname=="GovtA")
         {
          $(".Govt").addClass("hover");
          }
                if(classname=="PaymentA" || classname=="PaymentB")
         {
          $(".Payment").addClass("hover");
          }
            if(classname=="NotificationDriver" || classname=="NotificationParent")
         {
          $(".Notification").addClass("hover");
          }
                  if(classname=="NotificationParentPa")
         {
          $(".NotificationPa").addClass("hover");
          }
		  }
     //})
});
</script>