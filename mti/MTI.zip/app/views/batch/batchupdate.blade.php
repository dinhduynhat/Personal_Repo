@extends('layouts.dashboardlayout')
@section('body')


        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Settings Master</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Update Batch</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'batchupdateprocess/'.$batchDetailsbyid[0]['AutoID'])) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('Class', 'Class Name ' ) }}<em>*</em>
		
        </div>
        <div class="input-control">
     
		{{ Form::select('Class', array(''=>'Select Class')+$ClassDetails,null, array('id'=> 'Class'))}}		
        </div>
        {{ $errors->first('Class', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('batch', 'Batch ' ) }}<em>*</em>
        </div>
        <div class="input-control">
		{{ Form::select('batch', array(''=>'Select batch')+$years,null, array('id'=> 'batch'))}}		
      
        </div>
        {{ $errors->first('batch', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('Statedate', 'Statedate ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('Statedate', null, ['class' => 'datetimepicker1 Statedate']) }}
        </div>
        {{ $errors->first('Statedate', '<div class="error">:message</div>') }}
        </li>
		 <li>
        <div class="label-control">
        {{ Form::label('Enddate', 'Enddate ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('Enddate', null, ['class' => 'datetimepicker1 Enddate']) }}
        </div>
        {{ $errors->first('Enddate', '<div class="error">:message</div>') }}
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
<script>
$(document).ready(function(){
$("#Class").val("<?php echo $batchDetailsbyid[0]['Class'];?>");
$("#batch").val("<?php echo $batchDetailsbyid[0]['batch'];?>");
$("#Statedate").val("<?php echo $batchDetailsbyid[0]['Statedate'];?>");
$("#Enddate").val("<?php echo $batchDetailsbyid[0]['Enddate'];?>");
$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Route List</h5>
        </div>

        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>ClassName</th>
        <th>Batch</th>
        <th>StartDate</th>
        <th>EndDate</th>
		<th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($batchDetails as $batchvalue)
{
		?>
        <tr>
        <td><span class="tab-check"></span><?php echo $batchvalue['ClassName'];?></td>
        <td><?php echo $batchvalue['batch'];?></td>
        <td><?php echo $batchvalue['Statedate'];?></td>
		<td><?php echo $batchvalue['Enddate'];?></td>
         <td>       
        <a href="<?php echo url();?>/batchedit/<?php echo $batchvalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
        <a href="javascript:;" id="<?php echo url();?>/batchdelete/<?php echo $batchvalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
@stop