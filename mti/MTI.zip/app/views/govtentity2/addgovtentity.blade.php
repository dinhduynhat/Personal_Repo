@extends('layouts.dashboardlayout')

@section('body')



        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Government Entity</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Add Government Entity</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    
	

        {{ Form::open(array('url' => 'addgovtentityprocess', 'files'=> true, 'id' => 'addgovtentityprocess')) }}



        <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityName',null, array('id'=> 'GovernmentEntityName')) }}

        </div>

        {{ $errors->first('GovernmentEntityName', '<div class="errorsetting">:message</div>') }}

        </li>

         <li>

        <div class="label-control">

        <label for="r_no">Entity Address <em>*</em></label>


        </div>

        <div class="input-control">       

       {{ Form::textarea('GovernmentEntityAddress', null,['class' => 'GovernmentEntityAddress','size' => '100x100']) }}

        </div>

         {{ $errors->first('GovernmentEntityAddress', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('GovernmentEntityEmail',null, array('id'=> 'GovernmentEntityEmail')) }}

        </div>

         {{ $errors->first('GovernmentEntityEmail', '<div class="errorsetting">:message</div>') }}

        </li>			

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Contact Person' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityContactPerson',null, array('id'=> 'GovernmentEntityContactPerson')) }}

        </div>

         {{ $errors->first('GovernmentEntityContactPerson', '<div class="errorsetting">:message</div>') }}

        </li>

         <li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'User Name' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?>  <em>*</em> <?php } ?>

        </div>

		<?php

		if(!empty($schooluserDetailsbyid))

{ $user=$schooluserDetailsbyid[0]['UserName']; } else { $user=""; }

		?>

        <div class="input-control">       

       {{ Form::text('UserName',$user, array('id'=> 'Username')) }}

        </div>

         {{ $errors->first('UserName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li id="Password"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?> <em>*</em> <?php } ?>

        </div>

        <div class="input-control">       

       {{ Form::password('Password',array('id'=> 'Password')) }}

	   

        </div>

         {{ $errors->first('Password', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityPhone',null, array('id'=> 'GovernmentEntityPhone')) }}

        </div>

         {{ $errors->first('GovernmentEntityPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Mobile' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityMobile',null, array('id'=> 'GovernmentEntityMobile')) }}

        </div>

         {{ $errors->first('GovernmentEntityMobile', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}
		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>
		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb pass-btn">Send Login Details</a>
</div>
		  <?php 
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>

		     
        

			<?php

		if(!empty($GeneralSettingDetails))

		{

		?>

	    

<?php } ?>

		

		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		

		<?php } ?>

		

		


        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        

        </div>

		<?php } ?>

	        </div>

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>

		

        </div>

        <!-- dash content row end --> 

        

        
			 {{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}





		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

}

});

</script>

  @stop