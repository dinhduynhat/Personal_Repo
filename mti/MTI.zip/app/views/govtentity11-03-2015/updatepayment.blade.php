@extends('layouts.dashboardlayout')

@section('body')
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}


<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">

          <h2><!--<span class="icon icon-profile">--></span>Fee Payment Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5>Edit Fee Payment</h5>

             </div>

            <div class="panel-row">
@if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

{{ Form::open(array('url' => 'paymentupdateprocess', 'files'=> true, 'id' => 'feepaymentprocess')) }}

   <ul class="dash-form-lister">

<li>

        <div class="label-control">
          {{ Form::label('Enddate', 'School Name' ) }}
      </div>
        <div class="input-control">
          <?php
            $SchoolNameVal = FeeModel::where('id', '=', $ScId)->pluck('SchoolName');  
            $SchoolNameVal = GeneralSettingModel::where('id', '=', $SchoolNameVal)->pluck('SchoolName');
          ?>
      
      {{ Form::text('SchoolNameval', $SchoolNameVal, array('readonly'=> 'readonly')) }}
      <input type="hidden" name="SchoolId" value ="<?php echo $DriverDetails[0]['SchoolName']; ?>">
      <input type="hidden" name="SchoolName" value ="<?php echo $ScId; ?>">
      
         {{ $errors->first('SchoolName', '<div class="error">:message</div>') }}

        </div>

      

        </li>

        </li>

		

		  <li>

        <div class="label-control">
<!--
        {{ Form::label('School Name', 'School Name' ) }}
-->
        </div>

        <div class="input-control">        

         <!-- {{ Form::text('studentname',null, array('id'=> 'Searchdata','placeholder' => 'Search School')) }}		 -->

        

        </div>

        {{ $errors->first('studentname', '<div class="error">:message</div>') }}

        </li>
			 <li>

        <div class="label-control">

        {{ Form::label('Start Date', 'Paid Date' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('PaidDate', $DriverDetails[0]['PaidDate'], ['class' => 'datetimepicker1 DateOfBirth PaidDate']) }}        

        </div>

        {{ $errors->first('PaidDate', '<div class="errorsetting">:message</div>') }}

        </li>

		

        
<li>

        <div class="label-control">

        {{ Form::label('Amount', 'Amount' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Amount', $DriverDetails[0]['Amount'], ['class' => 'none']) }}        

        </div>

        {{ $errors->first('Amount', '<div class="errorsetting">:message</div>') }}

        </li>

 
<li>

          <div class="label-control">

          {{ Form::label('DateOfBirth', 'Payable For' ) }}

          </div>


          <div class="input-control">
            <?php
            $curmonth = date("F");
            $month = date("m");
            ?>


<select style='width: 112px;' name='PayMonth'>
<option name="PayMonth" value=''>Select Month</option>   
<?php
#for($i = $month-11 ; $i <= $month; $i++)
for($i = $DriverDetails[0]['PayMonth']-3 ;$i <= $DriverDetails[0]['PayMonth']; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
    <option value="<?php  echo date("m",mktime(0,0,0,$i,1,date("Y")));      ?>" <?php
if(date("m",mktime(0,0,0,$i,1,date("Y")))==$DriverDetails[0]['PayMonth'])
{
  echo ' selected';
}
?>     
    >
    <?php
    echo date("F",mktime(0,0,0,$i,1,date("Y")));
    //Close tag inside loop
    ?>
    </option>
    <?php
}?>
</select>    
{{ $errors->first('PayMonth', '<div class="errorsetting">:message</div>') }}





<select style='width: 112px;' name='PayYear'>
<option name="PayYear" value=''>Select Year</option>   
<?php
$year = date('Y');
$nextyear = date('Y')-1;
for($i=$nextyear; $i<=$year; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
    <option value="<?php 
    echo $i; 
    
    ?>" <?php
if($i==$DriverDetails[0]['PayYear'])
{
  echo ' selected';
}
?>     
    >
    <?php
    echo $i;
    //Close tag inside loop
    ?>
    </option>
    <?php
}?>

</select>    
 
{{ $errors->first('PayYear', '<div class="errorsetting">:message</div>') }}
          </div>

          

          </li>
          

       <li>

        <div class="label-control">

        {{ Form::label('Status', 'Status' ) }}

        </div>

        <div class="input-control">        





         <select id="Status" name="Status"><option value="" selected="selected">Select Status</option>
          <option value="1" <?php if ($DriverDetails[0]['Status']=='1') { echo 'selected'; }?>>Paid</option>
          <option value="2" <?php if ($DriverDetails[0]['Status']=='0') { echo 'selected'; }?>>Rejected</option>
          
          
         </select>

        

        </div>

        {{ $errors->first('Status', '<div class="error">:message</div>') }}

        </li>	


        


              </ul>

           

			  

			     <div class="btn-group form-list-btn-group">
          <input class="submit-btn" type="submit" value="Save">    
    {{ Form::close() }}
        <!--        {{ Form::submit('Update', ['class' => 'submit-btn']) }}     -->

       

              </div>

            </div>

			<div class="result"></div>

			

          </div>



          <!-- dash content row end --> 

		

        </div>

        <!--dash content row end --> 

    

      </div>

    

@stop