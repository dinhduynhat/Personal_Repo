@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Government Entity</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Update Government Entity</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'govtentityupdateprocess/'.$DriverDetailsbyid[0]['id'], 'files'=> true, 'id' => 'driverprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('Name', 'Name' ) }}<em>*</em>

        </div>

        <div class="input-control">

                {{ Form::text('GovernmentEntityName', Input::old('GovernmentEntityName', $DriverDetailsbyid[0]['GovernmentEntityName']), array('id'=> 'GovernmentEntityName')) }}

        

        </div>

        {{ $errors->first('GovernmentEntityName', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Address', 'Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">

                {{ Form::textarea('GovernmentEntityAddress', Input::old('GovernmentEntityAddress', $DriverDetailsbyid[0]['GovernmentEntityAddress']), array('id'=> 'GovernmentEntityAddress')) }}            

        

        </div>

        {{ $errors->first('GovernmentEntityAddress', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Email', 'Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">









{{ Form::text('GovernmentEntityEmail', Input::old('GovernmentEntityEmail', $DriverDetailsbyid[0]['GovernmentEntityEmail']), array('id'=> 'GovernmentEntityEmail')) }}





        </div>

        {{ $errors->first('GovernmentEntityEmail', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Phone', 'Phone ' ) }}<em>*</em>

        </div>

        <div class="input-control">





{{ Form::text('GovernmentEntityPhone', Input::old('GovernmentEntityPhone', $DriverDetailsbyid[0]['GovernmentEntityPhone']), array('id'=> 'GovernmentEntityPhone')) }}





        </div>

        {{ $errors->first('GovernmentEntityPhone', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Contact Person', 'Contact Person' ) }}<em>*</em>

        </div>

        <div class="input-control">







{{ Form::text('GovernmentEntityContactPerson', Input::old('GovernmentEntityContactPerson', $DriverDetailsbyid[0]['GovernmentEntityContactPerson']), array('id'=> 'GovernmentEntityContactPerson')) }}









        </div>

        {{ $errors->first('GovernmentEntityContactPerson', '<div class="error">:message</div>') }}

        </li>







        <li>

        <div class="label-control">

        {{ Form::label('Mobile', 'Mobile ' ) }}

        </div>

        <div class="input-control">





{{ Form::text('GovernmentEntityMobile', Input::old('GovernmentEntityMobile', $DriverDetailsbyid[0]['GovernmentEntityMobile']), array('id'=> 'GovernmentEntityMobile')) }}



        

        </div>

        {{ $errors->first('GovernmentEntityMobile', '<div class="error">:message</div>') }}

        </li>





        <li>

        <div class="label-control">

        {{ Form::label('Password', 'Password ' ) }}


        </div>

        <div class="input-control">



        {{ Form::password('Password',array('id'=> 'Password')) }}

        

        </div>

        {{ $errors->first('Password', '<div class="error">:message</div>') }}

        </li>







        

        

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

         <script>

$(document).ready(function(){









$('#student-listing-table').dataTable();

});

</script>





@stop