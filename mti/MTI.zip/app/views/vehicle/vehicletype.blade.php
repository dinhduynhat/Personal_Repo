@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">
		<?php
		if(Auth::user()->usertype ==4)
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/vehicletype'); }}" class="fa fa-plus customfontawesome" title='Add Vehicle Type'></a>
		<a href="{{ URL::to($URL.'/vehicletype'); }}" class="fa fa-list-ul customfontawesome" title='List Vehicle Type'></a>
		
		
		</span>
		<?php
		}
		?>

        <h2><!--<span class="icon icon-student"></span>-->Manage Transport</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier dash-content-head-half">
<?php 
		  if(!empty($VehicleDetailsbyid))
		{
		?>
		 <h5 class="heading-title">Edit Vehicle Type Name</h5>
		<?php } else { ?>
        <h5 class="heading-title">Add Vehicle Type Name</h5>
<?php } ?>
        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        <style>
		.dash-form-lister li {
  float: none;
  width: 48%;
  padding: 0 2% 0 0;
  margin-bottom: 16px;
}
.dash-form-lister .errorimportpage {
  border-radius: 2px;
  padding: 3px 0px;
  position: absolute;
  left: 3px;
  top: 100%;
  z-index: 9999;
  color: red;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 11px;
  margin-top: 61px;
  width: 200px;
}
		</style>

        </div>

		<div class="dash-content-head tabContaier dash-content-head-half dash-content-head-last">


        </div>

        <div class="tabDetails">         

        <div class="panel-row panel-row-over">

		

<?php 
		  if(!empty($VehicleDetailsbyid))
		{
		?>
		{{ Form::open(array('url' => 'VehicleTypeNameupdateprocess/'.$VehicleDetailsbyid[0]['AutoID'], 'files'=> true, 'id' => 'vehicleupdateprocess')) }}
		<?php } else { ?>
		{{ Form::open(array('url' => 'VehicleTypeNameprocess')) }}
		
		<?php } ?>

        <ul class="dash-form-lister">

		

        <li style="padding:15px 0;">

        <div class="label-control">

        {{ Form::label('GradeName', 'VehicleType' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('VehicleTypeName',null, array('id'=> 'VehicleTypeName', 'style'=>'width:95%')) }}

        </div>

        {{ $errors->first('VehicleTypeName', '<div class="errorimportpage">:message</div>') }}

        </li>
		<li style="padding:15px 0;">

        <div class="label-control">

        {{ Form::label('TariffType', 'Tariff Type' ) }}<em>*</em>

        </div>

        <div class="input-control">

		<?php 
		if(isset($data))
		{
		?>
		
		
		{{ Form::select('VehicleType',$VehicleTypeDetails, $data) }}
		<?php
		}else
		{
		?>
        
		{{ Form::select('VehicleType', $VehicleTypeDetails)}}
		<?php
		}
		?>
		
		

        </div>

        {{ $errors->first('tarifftype', '<div class="errorimportpage">:message</div>') }}

        </li> 
	

        </ul>

        <div class="btn-group newcenbtn" ><!-- form-list-btn-group -->

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

        </div>

        {{ Form::close() }}

		

        </div>

<script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

</script>
<?php 
		  if(!empty($deleteerror))
		{
		?>
			<script>
		function fnOpenNormalDialogbox() {
		var url =$(this).attr("id");
    $("#dialog-confirm").html("This records used for Vehicle data.");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
$(document).ready(function(){
fnOpenNormalDialogbox();
});

		</script>
		<?php
		}?>
        <div class="panel-row list-row">

        </div>

        </div>

        </div>
<?php
if(!empty($VehicleDetailsbyid))
{
?>
<script>
$(document).ready(function(){
$("#triptype").val("<?php echo $VehicleDetailsbyid[0]['triptype']?>");
$("#VehicleTypeName").val("<?php echo $VehicleDetailsbyid[0]['VehicleTypeName']?>");
});
</script>
<?php

}
?>
        <!-- dash content row end --> 

        </div>

        
		
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
			
		<div class="dash-content-head tabContaier">
		<?php



		if(!empty($VehicleDetails))



		{



		?>



	     <input class="resetbutton" type="button" value="Delete" style="float:right; margin-top:6px; margin-right:6px; margin-bottom: 7px;">  



<?php } ?>

        <h5>Vehicle Type Name List</h5>

        </div>
		
        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

       <th class="lastth" style="background:#39a2d2 !important;"><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>

        <th>VehicleTypeName</th>
		 <th>Charge</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($VehicleDetails as $Vehiclevalue)

{

		?>

        <tr>

       <td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Vehiclevalue['AutoID']; ?>"></td>

        <td><?php echo $Vehiclevalue['VehicleTypeName'];?></td>
		 <td><?php echo $Vehiclevalue['triptype'];?></td>

         <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/VehicleTypeedit/<?php echo $Vehiclevalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/VehicleTypedelete/<?php echo $Vehiclevalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>

        </table>

        </div>
		
		</div>
		
				{{ Form::open(array('url' => Session::get('urlpath').'/VehicleTypedeleteprocess', 'files'=> true, 'id' => 'classdeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="classdeleteprocess" value="" class="classdeleteprocess"/>

</form>
	<script>
			function fnOpenvehicleDialogbox() {
		$(".ui-dialog-titlebar").show();
		$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the VehicleType to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".classdeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>

@stop