<?php


Route::get('/', 'HomeController@home');
Route::post('login', 'LoginController@Login');
Route::get('logout', 'LoginController@Logout');
Route::post('forgot', 'LoginController@ForgotPassword');


Route::group(array('before' => 'auth'), function()
{

//Vehicle
/*
Route::group(array('before' => 'auth'), function(){
    Route::get('vehicle', 'VehicleController@VehicleLayout');
});
*/

Route::get('vehicle', 'VehicleController@VehicleLayout');
Route::post('vehicleprocess', 'VehicleController@VehicleProcess');

//Route
Route::get('route', 'RouteController@RouteLayout');
Route::post('routeprocess', 'RouteController@RouteProcess');

//Destination
Route::get('destination', 'DestinationController@DestinationLayout');
Route::post('destinationprocess', 'DestinationController@DestinationProcess');

//Driver
Route::get('driver', 'DriverController@DriverLayout');
Route::post('driverprocess', 'DriverController@DriverProcess');

//Timing
Route::get('timing', 'TimingController@TimingLayout');
Route::post('timingprocess', 'TimingController@TimingProcess');


//Allocation
Route::get('allocation', 'AllocationController@AllocationLayout');
Route::post('allocationprocess', 'AllocationController@AllocationProcess');

//Classes
Route::get('class', 'ClassController@ClassLayout');
Route::post('classprocess', 'ClassController@ClassProcess');

//Upload CSV
Route::get('uploadcsv', 'UploadController@UploadCsvLayout');
Route::post('uploadcsvprocess', 'UploadController@UploadCsvProcess');


//Create User
Route::get('createuser', 'LoginController@CreateUserLayout');
Route::post('createuserprocess', 'LoginController@CreateUserProcess');
   
});

//Login Screen
