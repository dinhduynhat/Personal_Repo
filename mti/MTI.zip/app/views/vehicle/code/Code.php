@if ($errors->any())
    <ul>
        {{ implode('', $errors->all('<li class="error">:message</li>')) }}
    </ul>
@endif


{{ $errors->first('VehicleNumber') }}



@if(Session::has('message'))
	<p class="alert">{{ Session::get('message') }}</p>
@endif

return Redirect::to('vehicle')->with('message', 'Vehicle Details Saved Succesfully');

return Redirect::to('vehicle')->withErrors('Vehicle Details Saved Succesfully');

#'MaximumAllowed' => 'digits_between:2,5', 
#'MaximumAllowed' => 'numeric|min:2|max:5', 


        //$password = Hash::make('secret');
        //$UserData = Input::except(array('_token'));
        //$AllData = Input::all();
        
$user = new User;
        $user->UserName = Input::get('UserName');
        $user->password = Hash::make(Input::get('password'));
        if($user->save())
        {
            return Redirect::to('createuser')->with('Message', 'User Details Saved Succesfully');
        }
        else
        {
            return Redirect::to('createuser')->with('Message', 'Error');
        }

Recent Query

        $queries = DB::getQueryLog();
        print_r(end($queries));