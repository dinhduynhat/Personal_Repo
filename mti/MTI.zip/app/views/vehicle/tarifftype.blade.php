@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">
		<?php
		if(Auth::user()->usertype ==4)
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<a href="{{ URL::to($URL.'/tarifftype'); }}" class="fa fa-plus customfontawesome" title='Add Tariff Type'></a>
		<a href="{{ URL::to($URL.'/tarifftype'); }}" class="fa fa-list-ul customfontawesome" title='List Tariff Type'></a>
		
		</span>
		<?php
		}
		?>

        <h2><!--<span class="icon icon-student"></span>-->Manage Tariff</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier dash-content-head-half">
<?php 
		  if(!empty($VehicleDetailsbyid))
		{
		?>
		 <h5 class="heading-title">Edit Tariff Type</h5>
		<?php } else { ?>
        <h5 class="heading-title">Add Tariff Type</h5>
<?php } ?>
        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        <style>
		.dash-form-lister li {
  float: none;
  width: 48%;
  padding: 0 2% 0 0;
  margin-bottom: 16px;
}
.dash-form-lister .errorimportpage {
  border-radius: 2px;
  padding: 3px 0px;
  position: absolute;
  left: 3px;
  top: 100%;
  z-index: 9999;
  color: red;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 11px;
  margin-top: 61px;
  width: 200px;
}
		</style>

        </div>

		

        <div class="tabDetails">         

        <div class="panel-row panel-row-over">

		

<?php 
		  if(!empty($VehicleDetailsbyid))
		{
		?>
		{{ Form::open(array('url' => 'tarifftypeeditprocess/'.$VehicleDetailsbyid[0]['id'], 'files'=> true, 'id' => 'vehicleupdateprocess')) }}
		<?php } else { ?>
		{{ Form::open(array('url' => 'tarifftypeprocess')) }}
		
		<?php } ?>

        <ul class="dash-form-lister">

		

        <li style="padding:15px 0;">

        <div class="label-control">

        {{ Form::label('triptype', 'Trip Type' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('triptype',null, array('id'=> 'triptype')) }}

        </div>

        {{ $errors->first('triptype', '<div class="errorimportpage">:message</div>') }}

        </li>
<li style="padding:15px 0;">

        <div class="label-control">

        {{ Form::label('charge', 'charge' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('charge',null, array('id'=> 'charge')) }}

        </div>

        {{ $errors->first('charge', '<div class="errorimportpage">:message</div>') }}

        </li> 		
<li style="padding:15px 0;">

        <div class="label-control">
        {{ Form::label('TripWay', 'TripWay' ) }}<em>*</em>

        </div>

        
	<div class="input-control" style="width:66%;">
        <?php 
		$tripway['1'] = 'One Way';
		$tripway['2'] = 'Two Way';
		if(!empty($VehicleDetailsbyid[0]['id']))
		{
		
		
		?>
		
		
		{{ Form::select('tripway',$tripway, $VehicleDetailsbyid[0]['tripway']) }}
		<?php
		}else
		{
		
		?>
        
		{{ Form::select('tripway', $tripway)}}
		<?php
		}
		?>
		

        </div>

        {{ $errors->first('tripway', '<div class="errorimportpage">:message</div>') }}

        </li> 
        </ul>

        <div class="btn-group newcenbtn" ><!-- form-list-btn-group style="padding:10px 0;"-->
		
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}
		
        </div>

        {{ Form::close() }}

		

        </div>

<script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

</script>
<?php 
		  if(!empty($deleteerror))
		{
		?>
			<script>
		function fnOpenNormalDialogbox() {
		var url =$(this).attr("id");
    $("#dialog-confirm").html("This records used for Vehicle data.");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
$(document).ready(function(){
fnOpenNormalDialogbox();
});

		</script>
		<?php
		}?>
        <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">
		<?php



		if(!empty($VehicleDetails))



		{



		?>



	      



<?php } ?>
	
        </div>

     

        

        </div>

        </div>

        </div>
		
		
		
<?php
if(!empty($VehicleDetailsbyid))
{
?>
<script>
$(document).ready(function(){
$("#triptype").val("<?php echo $VehicleDetailsbyid[0]['triptype']?>");
$("#charge").val("<?php echo $VehicleDetailsbyid[0]['charge']?>");
});
</script>
<?php

}
?>
        <!-- dash content row end --> 

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
		
		<div class="dash-content-head tabContaier dash-content-head-last"> <!-- dash-content-head-half -->  
        <h5>Tariff Type List</h5>
		<input class="resetbutton" type="submit" value="Delete" style="float: right;margin-top: 6px; margin-right: 6px; margin-bottom: 7px;">
		
		</div>

        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

       

        <th>Tariff Type</th>
		 <th>Charge</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($VehicleDetails as $Vehiclevalue)

{

		?>

        <tr>

       

        <td><?php echo $Vehiclevalue['triptype'];?></td>
		 <td><?php echo $Vehiclevalue['charge'];?></td>

         <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/tarifftypeedit/<?php echo $Vehiclevalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/tarifftypedelete/<?php echo $Vehiclevalue['id'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

        <?php } ?>

        </tbody>

        </table>

        </div>
        </div>
		
		
				{{ Form::open(array('url' => Session::get('urlpath').'/VehicleTypedeleteprocess', 'files'=> true, 'id' => 'classdeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="classdeleteprocess" value="" class="classdeleteprocess"/>

</form>
	<script>
			function fnOpenvehicleDialogbox() {
		$(".ui-dialog-titlebar").show();
		$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the VehicleType to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".classdeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>
<script>
$(document).ready(function(){

$('#charge').keypress(function(event) {
  if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
    event.preventDefault();
  }
});



});
</script>

@stop