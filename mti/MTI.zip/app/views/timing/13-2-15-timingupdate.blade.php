@extends('layouts.dashboardlayout')

@section('body')

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Edit Timing</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'timingupdateprocess/'.$TimingDetailsbyid[0]['AutoID'])) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('rv_code', 'Vehicle Code ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::select('VehicleCode', array(''=>'Select Vehiclecode')+$VehicleDetails, null, array('id' => 'VehicleCode'))}}

        </div>

         {{ $errors->first('VehicleCode', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('StartTime', 'Start Time ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('StartTime', null, ['class' => 'datetimepicker2 StartTime']) }}        

        </div>

         {{ $errors->first('StartTime', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('dr_code', 'Driver ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::select('DriverName', array(''=>'Select Drivername')+$DriverDetails, null, array('id' => 'DriverName'))}}

        </div>

         {{ $errors->first('DriverName', '<div class="error">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('End Time', 'End Time ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('EndTime', null, ['class' => 'datetimepicker2 EndTime']) }}        

        </div>

         {{ $errors->first('EndTime', '<div class="error">:message</div>') }}

        </li>

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

		      		 <script>

$(document).ready(function(){

$("#VehicleCode").val("<?php echo $TimingDetailsbyid[0]['VehicleCode']?>");

$(".StartTime").val("<?php echo $TimingDetailsbyid[0]['StartTime']?>");

$("#DriverName").val("<?php echo $TimingDetailsbyid[0]['DriverName']?>");

$(".EndTime").val("<?php echo $TimingDetailsbyid[0]['EndTime']?>");



$('#student-listing-table').dataTable();

});

</script>

        <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>Timing List</h5>

        </div>

       

        <div class="panel-tab-row"> <!---------------- student listing table start ------>

        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>

        <th>DriverName</th>

        <th>StartTime</th>

        <th>End Time</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

		

		foreach ($TimingDetails as $Timingvalue)

{

		?>

        <tr>

        <td><span class="tab-check"></span><?php echo $Timingvalue['DriverName'];?></td>

        <td><?php echo $Timingvalue['StartTime'];?></td>

        <td><?php echo $Timingvalue['EndTime'];?></td>

        <td>       

        <a href="<?php echo url();?>/timingedit/<?php echo $Timingvalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

       

		<a href="javascript:;" id="<?php echo url();?>/timingdelete/<?php echo $Timingvalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

       <?php } ?>

        </tbody>

        </table>

        </div>

        </div>

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>



@stop