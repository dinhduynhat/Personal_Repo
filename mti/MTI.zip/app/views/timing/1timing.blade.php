@extends('layouts.dashboardlayout')

@section('body')
<?php $date = ['00:00:00' => '12:00 AM','00:30:00' => '12:30 AM','01:00:00' => '01:00 AM','01:30:00' => '01:30 AM','02:00:00' => '02:00 AM','02:30:00' => '02:30 AM','03:00:00' => '03:00 AM','03:30:00' => '03:30 AM','04:00:00' => '04:00 AM','04:30:00' => '04:30 AM','05:00:00' => '05:00 AM','05:30:00' => '05:30 AM','06:00:00' => '06:00 AM','06:30:00' => '06:30 AM','07:00:00' => '07:00 AM','07:30:00' => '07:30 AM','08:00:00' => '08:00 AM','08:30:00' => '08:30 AM','09:00:00' => '09:00 AM','09:30:00' => '09:30 AM','10:00:00' => '10:00 AM','10:30:00' => '10:30 AM','11:00:00' => '11:00 AM','11:30:00' => '11:30 AM','12:00:00' => '12:00 PM','12:30:00' => '12:30 PM','13:00:00' => '01:00 PM','13:30:00' => '01:30 PM','14:00:00' => '02:00 PM','14:03:00' => '02:30 PM','15:00:00' => '03:00 PM','15:30:00' => '03:30 PM','16:00:00' => '04:00 PM','16:30:00' => '04:30 PM','17:00:00' => '05:00 PM','17:30:00' => '05:30 PM','18:00:00' => '06:00 PM','18:30:00' => '06:30 PM','19:00:00' => '07:00 PM','19:30:00' => '07:30 PM','20:00:00' => '08:00 PM','20:30:00' => '08:30 PM','21:00:00' => '09:00 PM','21:30:00' => '09:30 PM','22:00:00' => '10:00 PM','22:30:00' => '10:30 PM','23:00:00' => '11:00 PM','23:30:00' => '11:30 PM']; ?>
        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Manage Transport</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 class="heading-title">Add Timing</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'timingprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('rv_code', 'Vehicle Code ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        
        {{ Form::select('VehicleCode', array(''=>'Select Vehiclecode')+$VehicleDetails)}}

        </div>

         {{ $errors->first('VehicleCode', '<div class="errorsetting">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('StartTime', 'Start Time ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        
        {{ Form::select('StartTime' ,$date,null,['class' => 'StartTime', 'style' => 'width:100px'],  ['style' => 'width:100px'])}}

        </div>

         {{ $errors->first('StartTime', '<div class="errorsetting">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('dr_code', 'Driver ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::select('DriverName', array(''=>'Select Drivername')+$DriverDetails)}}

        </div>

         {{ $errors->first('DriverName', '<div class="errorsetting">:message</div>') }}

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('End Time', 'End Time ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        <!--{{ Form::text('EndTime', null, ['class' => 'datetimepicker2']) }}        -->
        {{ Form::select('EndTime' ,$date,null,['class' => 'EndTime', 'style' => 'width:100px'],  ['style' => 'width:100px'])}}

        </div>

         {{ $errors->first('EndTime', '<div class="errorsetting">:message</div>') }}

        </li>

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

		      		 <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

</script>

        <div class="panel-row list-row">

        

       

        

        </div>

        </div>

        </div>

        <!-- dash content row end --> 

        </div>
			<div class="panel-tab-row"> <!---------------- student listing table start ------>
		<div class="dash-content-head tabContaier">

        <h5>Timing List</h5>
<?php

		if(!empty($TimingDetails))

		{

		?>

	     <input class="resetbutton" type="button" value="Delete" style="float: right;margin-top: 6px;

margin-right: 6px;

margin-bottom: 7px;">  

<?php } ?>
        </div>
        <table class="student-listing-table" id="student-listing-table">

        <thead>

        <tr>
<th class="lastth" style="background:#39a2d2 !important;"><input type="checkbox" id="selecctall"  onchange="javascript:CheckedAll();"></th>
       <th>Vehicle Code</th>
        <th>DriverName</th>

        <th>StartTime</th>

        <th>End Time</th>

        <th>Action</th>

        </tr>

        </thead>

        <tbody>

		<?php

	

		foreach ($TimingDetails as $Timingvalue)

{


$vehiclebyid = DriverModel::where('AutoID', $Timingvalue['DriverName'])->get()->toArray();
 $VehicleDetails = VehicleModel::where('AutoID', $Timingvalue['VehicleCode'])->get()->toArray();
		$DriverName=$vehiclebyid[0]['DriverName'];
		$VehicleCode=$VehicleDetails[0]['VehicleCode'];
    
    $Company=$VehicleDetails[0]['Company'];
if ($Company==Auth::user()->schoolid) 
{
    

		?>

        <tr>
<td><input style="margin-left: 8px;" name="chkSelectRow[]" type="checkbox" class="deletelist" value="<?php echo $Timingvalue['AutoID']; ?>"></td>
<td><span class="tab-check"></span><?php echo $VehicleCode;?></td>
        <td><span class="tab-check"></span><?php echo $DriverName;?></td>

        <td><?php echo date('h:i A', strtotime($Timingvalue['StartTime']));?></td>
        <td><?php echo date('h:i A', strtotime($Timingvalue['EndTime']));?></td>

        

        <td>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/timingedit/<?php echo $Timingvalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

        <a href="javascript:;" id="<?php echo url();?>/timingdelete/<?php echo $Timingvalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>

        </tr>

       <?php }} ?>

        </tbody>

        </table>

        </div>
        </div>
		
		
<?php 
		  if(!empty($deleteerror))
		{
		?>
			<script>
		function fnOpenNormalDialogbox() {
		$(".ui-dialog-titlebar").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("This records used for route allocate data.");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
$(document).ready(function(){
fnOpenNormalDialogbox();
});

		</script>
		<?php
		}?>	
		{{ Form::open(array('url' => 'timingdeleteprocess', 'files'=> true, 'id' => 'timingdeleteprocess','class'=>'unwant senddeleteform')) }}

<input type="hidden" name="timingdeleteprocess" value="" class="timingdeleteprocess"/>

</form>
	<script>
			function fnOpenvehicleDialogbox() {
		$(".ui-dialog-titlebar").show();
		$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Are you sure want to delete selected items?");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {
		$(".senddeleteform").submit();
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}
function fnOpenemptyDialogbox() {
$(".ui-dialog-titlebar").show();
$(".ui-icon-closethick").show();
		var url =$(this).attr("id");
    $("#dialog-confirm").html("Choose any of the timing to delete");
var buttonsConfig = [
    {
        text: "Ok",
        "class": "ok",
        click: function() {		
		$(this).dialog('close');	
        }
    },
    {
        text: "Cancel",
        "class": "cancel",
        click: function() {
		$(this).dialog('close');
        }
    }
];
    // Define the Dialog and its properties.
    $("#dialog-confirm").dialog({
        resizable: false,
        modal: true,
        title: "MTI(Malden Taxi & Malden Trans Inc)",
        height: 250,
        width: 400,
        buttons: buttonsConfig,
    });
}




$(".resetbutton").click(function(){
var docnumbers = new Array();
$('input[name="chkSelectRow[]"]:checked').each(function() {
   var selectdoc=this.value;

   docnumbers.push(selectdoc);
});
$(".timingdeleteprocess").val(docnumbers);
if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {
fnOpenvehicleDialogbox();
} else {
fnOpenemptyDialogbox();
}
});
function CheckedAll(){    
     if (document.getElementById('selecctall').checked) {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
         document.getElementsByTagName('input')[i].checked = true;
         }
     }
     else {
         for(i=0; i<document.getElementsByTagName('input').length;i++){
          document.getElementsByTagName('input')[i].checked = false;
         }
     }
   }
</script>


@stop