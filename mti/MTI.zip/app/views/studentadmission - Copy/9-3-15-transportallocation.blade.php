@extends('layouts.dashboardlayout')
@section('body')
<style>
.gm-login-iframe{
display:none !important;
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
<div class="form-panel">
<div class="header-panel">
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>
<div class="dash-content-panel">
<!-- dash panel start -->

<div class="dash-content-row">
<!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Transport Route Listing</h5>
             </div>
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <div class="col-one-one">
            <ul class="dash-form-lister">
              <li>
                <div class="label-control">
                  <label for="r_no">School Name </label>
                  <em>*</em> </div>
                <div class="input-control">
                  {{ Form::select('SchoolName',array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'SchoolName'))}}	
                </div>
              </li>
             
              
            </ul>            
            </div>
            
            </div>
		<div class="result"></div>
        <div class="result1"></div>     
		{{ Form::open(array('url' => 'addstudentdatadetails', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}

<input type="hidden" name="updateid" value="" class="updateid"/>
<input type="hidden" name="triptypedata" value="" class="triptypedata"/>
<input type="hidden" name="busiddata" value="" class="busiddata"/>
<input type="hidden" name="schooliddata" value="" class="schooliddata"/>
</form>
             
            <!----- allote transport section end ------->
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
      <script>
		$("document").ready(function(){
            $("#SchoolName").change(function(e){
		
                e.preventDefault();
                var SchoolName = $("#SchoolName").val();
            
                var dataString = 'SchoolName='+SchoolName; 
                $.ajax({
                    type: "POST",
                    url : "searchdriverlist",
                    data : dataString,
                    success : function(data){
					$(".result").html(data);
                       
                    }
                });

        });
		
  });
  
		</script>
      </div>
	  
	  
 
@stop