@extends('layouts.dashboardlayout')
@section('body')
<div class="form-panel">
<div class="header-panel">  <!-------------- start header ------------->
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>                      <!-------------- end header ------------->
<div class="dash-content-panel">  
<!-- dash panel start -->
<div class="dash-content-row">
<!--- dash content row start -->

            <div class="dash-content-head">
              <h5>Add student to bus</h5>
             </div>
             
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <ul class="dash-form-lister"> 
    <li>
      <div class="label-control">
        <label for="Name">Student Name </label>
        <em>*</em> </div>
      <div class="input-control">
        <input name="DriverName" type="text">
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Age">Grade </label>
        <em>*</em> </div>
      <div class="input-control">
        <select name="LisenceType">
          <option value="" selected="selected">Select Lisence Type</option>
          <option value="1">A</option>
          <option value="2">A1</option>
          <option value="3">B</option>
          <option value="4">BE</option>
          <option value="5">C1</option>
          <option value="6">C1E</option>
          <option value="7">C</option>
          <option value="8">CE</option>
          <option value="9">D1</option>
          <option value="10">D1E</option>
          <option value="11">D</option>
          <option value="12">DE</option>
        </select>
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Address">Age </label>
        <em>*</em> </div>
      <div class="input-control">
        <select name="LisenceType">
          <option value="" selected="selected">Select Lisence Type</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="LicenseNumber">Standard </label>
        <em>*</em> </div>
      <div class="input-control">
        <select name="LisenceType">
          <option value="" selected="selected">Select Lisence Type</option>
          <option value="1">First Standard</option>
          <option value="2">Second Standard</option>
          <option value="2">Third Standard</option>
        </select>
      </div>
    </li>
    <li>
      <div class="label-control">
         <label>&nbsp;</label>
      </div>
      <div class="input-control check-input-control">
        <input name="LicensePhoto" type="checkbox" id="add_bus">
        <label for="add_bus">Add to bus </label>
      </div>
    </li>
    </ul>
      <div class="btn-group form-list-btn-group">
    <input class="submit-btn" type="submit" value="Save">
    <input class="resetbutton" type="reset" value="Cancel">
  </div>
           
             
            </div>  <!----- allote transport section end ------->
            
            
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
       
      </div>
	  
	  
 
@stop