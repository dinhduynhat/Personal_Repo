@extends('layouts.dashboardlayout')

@section('body')

	<style>
.fancybox-opened
{
top: 15px !important;
}
	
<?php
if(Auth::user()->usertype==2)
		{

?>
		.poplink2

	{

	margin-left: -180px !important;

margin-top: 64px !important;
width: 490px !important;

	}
	.poplink

	{

	margin-left: -300px !important;

margin-top: 64px !important;
width: 490px !important;

	}
<?php } else {
?>
.poplink

	{

	margin-left: -40px !important;

margin-top: 64px !important;
width: 490px !important;

	}
.poplink2

	{

	margin-left: 60px !important;

margin-top: 64px !important;

	}

<?php
}?>

	</style>

	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Student Attendence</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Search Student List</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        <!---{{ Form::open(array('url' => 'searchstudentprocess')) }}-->

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('ClassName', 'Studentname/Age/Gender' ) }}

        </div>

        <div class="input-control">        

         {{ Form::text('Searchdata',null, array('id'=> 'Searchdata')) }}		 

        

        </div>

        {{ $errors->first('Searchdata', '<div class="error">:message</div>') }}

        </li>
 <?php 

	

if(Auth::user()->usertype ==1)

{

?>
          <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}

        </div>

        <div class="input-control">

		       

       {{ Form::select('SchoolName',array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'SchoolName'))}}		

        </div>

         {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>
<?php }  else { ?>
 <li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}

        </div>

        <div class="input-control">

		       

       {{ Form::select('SchoolName',$SchoolDetails,null, array('id'=> 'SchoolName'))}}		

        </div>

         {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>
<?php
}
?>
        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Search', ['class' => 'submit-btn Search']) }}    

    

        </div>

      <!---{{ Form::close() }}-->

		

        </div>



 <div class="result"> 

        </div>

         <!---------------- student listing table start ------>

     <script>

  $(function() {

    var availableTags = [

	<?php foreach($StudentDetails as $StudentDetailsvalue) { 

echo '"'.trim($StudentDetailsvalue["PersonalFirstName"]).'_'.trim($StudentDetailsvalue["PersonalLastName"]).'/'.$StudentDetailsvalue["Age"].'/'.$StudentDetailsvalue["Gender"].'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

        

		<script>

        $("document").ready(function(){

            $(".Search").click(function(e){

		

                e.preventDefault();

                var Searchdata = $("#Searchdata").val();

                  var SchoolName = $("#SchoolName").val();

                var dataString = 'Searchdata='+Searchdata +"&SchoolName="+SchoolName;  

                $.ajax({

                    type: "POST",

                    url : "searchstudentprocess",

                    data : dataString,

                    success : function(data){

					$(".result").html(data);

                        console.log(data);

                    }

                });



        });

        });

		

		//end of document ready function

    </script>

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

		<script type="text/javascript">

		$(document).ready(function() {

		

			$('.fancybox').fancybox();

			$(".fancybox-effects-a").fancybox({

			

				helpers: {

					title : {

						type : 'outside'

					},

					overlay : {

						speedOut : 0

					}

				}

			});

			});



			

			function transpotalert(commentval){

			$('#CommentsData').val(commentval);

			}

		

	</script>





		

@stop