@extends('layouts.dashboardlayout')
@section('body')
<style type="text/css">
#header
{
	display: none;
}
.sidebar_left, .site-footer
{
	display: none;
}
.right_column
{
	width: 100%;
}
.nav-fixed-lock-open 
{
   padding-left: 0 !important;
}
.nav-fixed-close{
   padding-left: 0 !important;
}
body
{
	overflow: hidden;
}
.gm-login-iframe{
display:none !important;
}

</style>
<?php

$checkfinalarray=implode("/",$locationdataarray);
//$checkfinalarray=implode("/",$locationaddress);
?>
 <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>

<script type="text/javascript">
  var directionDisplay;
  var directionsService = new google.maps.DirectionsService();
  var map;

  function initialize() {
    directionsDisplay = new google.maps.DirectionsRenderer();
    var chicago = new google.maps.LatLng(41.850033, -87.6500523);
    var myOptions = {
      zoom: 6,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: chicago
    }
    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    directionsDisplay.setMap(map);
    calcRoute();
  }
  
  function calcRoute() {
   var waypts = [];
  var check="<?php echo $checkfinalarray; ?>";
  console.log(check);
var checkboxArray = check.split("/");
console.log(checkboxArray);
   for (var i = 0; i < checkboxArray.length; i++) { 
console.log(checkboxArray[i]);   
      waypts.push({
          location:checkboxArray[i],
          stopover:true});
   
  }
    var request = {
        origin: "<?php echo $startaddress; ?>",
        destination: "<?php echo $destinationaddress; ?>",
         waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: google.maps.DirectionsTravelMode.DRIVING
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(response);
        var route = response.routes[0];
        var summaryPanel = document.getElementById("directions_panel");
        summaryPanel.innerHTML = "";
        // For each route, display summary information.
        for (var i = 0; i < route.legs.length; i++) {
          var routeSegment = i + 1;
		  if(routeSegment%2==0)
		  {
		  var classname="route-box even";
		  } else {
		  var classname="route-box";
		  }
		   if(route.legs.length !=routeSegment)
		  {
		   summaryPanel.innerHTML +="<div class='"+classname+"'><h5>Student: " + routeSegment + "</h5><p>"+route.legs[i].start_address + " to "+route.legs[i].end_address +" "+route.legs[i].distance.text +"</div>";
          } else {
		  
		  summaryPanel.innerHTML +="<div class='"+classname+"'><h5>Destination Point</h5><p>"+route.legs[i].start_address + " to "+route.legs[i].end_address +" "+route.legs[i].distance.text +"</div>";
		  }
        }
      } else {
        alert("directions response "+status);
      }
    });
  }
  
</script>
</head>
<body onload="initialize()">
<div id="map_canvas" class="col-left  route-map-section" ></div>

<div class="map-route-list-section col-right">
<div class="dash-content-head">
<h5>Route List</h5>
</div>
<div class="getroute">

<div class="studeb-rout-list-section">
<div class="route-box even">
   <h5>Starting Point</h5>
   <p><?php echo $startaddress; ?></p>
</div>
<div id="directions_panel" ></div>      
	
</div>
</div>
 <div class="bottom-tab-row">
                <div class="col-left">                    
                    <button class="btn-mti savadata">Save</button>
					 <a class="fancybox attandencelink" href="{{ URL::to('transportlist'); }}"><button class="btn-mti">Cancel</button></a>
                </div>
             </div> 
</div>         
	<script>
	$(".savadata").click(function(){
	 var Studentid = "<?php echo $allocatestudentid;?>";
	 var selectedpicktype = "<?php echo $selectedpicktype;?>";
	 var selectedbusid = "<?php echo $selectedbusid;?>";
	 var startaddress = "<?php echo $startaddress;?>";
	 var destinationaddress = "<?php echo $destinationaddress;?>";
     var selectschoolid = "<?php echo $selectschoolid;?>";
	 var updateid = "<?php echo $updateid;?>";
	 var getroute=$(".getroute").html();
	 var redirect=$(".attandencelink").attr("href");

                $.ajax({
                    type: "POST",
                    url : "updateroute",
                    data : { Studentid: Studentid, selectedpicktype: selectedpicktype,selectedbusid: selectedbusid, startaddress: startaddress,destinationaddress: destinationaddress, selectschoolid: selectschoolid, getroute: getroute, updateid: updateid},
                    success : function(data){
					window.location.href=redirect;
                       
                    }
                });
	});
	</script>
	  
 
@stop