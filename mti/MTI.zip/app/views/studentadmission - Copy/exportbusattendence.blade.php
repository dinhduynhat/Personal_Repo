@extends('layouts.dashboardlayout')

@section('body')
<style>
.fancybox-opened
{
top: 15px !important;
}
</style>
<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>
	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}

            <div class="form-panel">


        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5>Student Attedance Report</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              
             <ul class="dash-form-lister">
  <li>
    <div class="label-control">
      <label for="r_no">School</label>
    </div>
    <div class="input-control">
      <select id="schoolid" name="schoolid">
        <option value="" selected="selected">Select School</option>
        <option value="1">Alpha School</option>
        <option value="2">Beta School</option>
        <option value="3">Charlie School</option>
        <option value="4">Kumaraguru</option>
      </select>
    </div>
  </li>
  
  <li>
    <div class="label-control">
      <label for="Student Name">From</label>
    </div>
    <div class="input-control">
      <input id="Searchdata" placeholder="Type hint" name="studentname" type="text" class="ui-autocomplete-input" autocomplete="off" disabled="disabled">
    </div>
  </li>
  <li>
    <div class="label-control">
      <label for="DateOfBirth">To</label>
    </div>
    <div class="input-control">
      <input class="datetimepicker1 DateOfBirth Startdate" name="Startdate" type="text" disabled="disabled">
    </div>
  </li>
</ul>

           

			  {{ Form::close() }}

			     <div class="btn-group form-list-btn-group">

                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>


<div class="panel-row list-row">
  <div class="dash-content-head tabContaier">
    <div class="col-left">
        <h5>January</h5>
    </div>
    <div class="col-right">
        <ul class="at_list">
           <li><span class="fr_ho at_icon"></span> From Home</li>
           <li><span class="fr_sc at_icon"></span> From School</li>
        </ul>
    </div>
  </div>
  <div class="panel-tab-row"> <!---------------- student listing table start ------>
 <table class="dataTable atrtendTable">
        <thead>
            <tr>
                <th>Student Name</th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4</th>
                <th>5</th>
                <th>6</th>
                <th>7</th>
                <th>8</th>
                <th>9</th>
                <th>10</th>
                <th>11</th>
                <th>12</th>
                <th>13</th>
                <th>14</th>
                <th>15</th>
                <th>16</th>
                <th>17</th>
                <th>18</th>
                <th>19</th>
                <th>20</th>
                <th>21</th>
                <th>22</th>
                <th>23</th>
                <th>24</th>
                <th>25</th>
                <th>26</th>
                <th>27</th>
                <th>28</th>
                <th>29</th>
                <th>30</th>
                <th>Total Presents</th>
                <th>Total Absents</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Alexia</td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td>18</td>
                <td>12</td>
            </tr>
            <tr>
                <td>Martin</td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td><span class="fr_ho"></span><span class="fr_sc"></span></td>
                <td>18</td>
                <td>12</td>
            </tr>
        </tbody>
      </table>
  </div>
</div>
			<div class="result"></div>

			

          </div>



          <!-- dash content row end --> 
        </div>

        <!--dash content row end --> 

    

      </div>

    

@stop