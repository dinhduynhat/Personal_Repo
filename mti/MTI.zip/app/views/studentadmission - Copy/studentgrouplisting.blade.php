@extends('layouts.dashboardlayout')

@section('body')



	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}

	<style>
<?php 

		if(Auth::user()->usertype ==1)

		{

		?>
	.poplink

	{

	margin-left: -100px !important;

margin-top: 64px !important;
width: 490px !important;

	}

	.poplink2

	{

	margin-left: 20px !important;

margin-top: 64px !important;
width: 490px !important;

	}

<?php } else { ?>
.poplink

	{

	margin-left: -330px !important;

margin-top: 64px !important;
width: 490px !important;

	}

	.poplink2

	{

	margin-left: -200px !important;

margin-top: 64px !important;
width: 490px !important;

	}

<?php } ?>
	</style>

        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Student Group With Parent</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">
<div class="errorsetting" style="float: right;color: red;"><em>*</em> Click Student Name And View Student Information.</div>
        <h5>Student Group With Parent</h5>

       </div>
@if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
   		  <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

"aoColumnDefs": [
          { 'bSortable': false, 'aTargets': [ 0,7,0,6,0,5,0,4,0,3,0,2,0,1 ] }

       ],
        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select School</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">School :</span>').appendTo('#acavails');

    

});

</script>



		 <div class="panel-row list-row">

        <div class="dash-content-head tabContaier">

        <h5>Student List</h5>

        </div>

     

        <div class="panel-tab-row"> <!---------------- student listing table start ------>

       <table class="example tab" id="example">

	   <?php 

		if(Auth::user()->usertype ==1)

		{

		?>

	   <tfoot class="tabl tab-abs"><tr>

<th style="display:none;"></th>

	    <th  id="acavails" > 

        </th>

        </tr></tfoot>	

		<?php } ?>

        <thead>

        <tr>

		<?php 

		if(Auth::user()->usertype ==1)

		{

		?>
<th style="display:none;"></th>
		<th >School</th>

		<?php } else { ?>
		<th style="display:none;"></th>
		<th style="display:none;"></th>
		<?php } ?>

		

        <th>Name</th>

        <th>Grade</th>

		<th>Age</th>

        <th>Gender</th>      

        <th>Parent Email</th>  		

		<th>Parent Mobile</th> 

       

        </tr>

        </thead>

        <tbody>

		<?php
$parentid="";
		$i=0;
		foreach ($StudentAdmissionDetailsbyid as $StudentAdmissionDetailvalue)

{
if($StudentAdmissionDetailvalue['parentid']==$parentid)
{
$i++;
} else {
$i=0;
}


 if($i ==0) {
	?>
	<tr role="row" class="odd parentdata" id="parentdata<?php echo $StudentAdmissionDetailvalue['parentid']; ?>">
<?php 

		if(Auth::user()->usertype ==1)

		{

		?>
		<td style="display:none;"></td> 
	<td  ></td>   
	<?php } else { ?>
		<td style="display:none;"></td> 
		<td style="display:none;"></td> 
		<?php } ?>
     <td><span class="tab-check"><b>Parent Name</b></span><?php echo $StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName'];?></td>

        <td></td>

		<td></td>    

        <td></td>  

        <td></td> 

        <td></td> 
        </tr>
		<?php } ?>
        <tr>

		

		<?php 

		if(Auth::user()->usertype ==1)

		{

		?>
<td style="display:none;"></td>  
		  <td ><?php echo $StudentAdmissionDetailvalue['schollresult']['SchoolName'];?></td>   

		<?php } else { ?>
		<td style="display:none;"></td> 
		<td style="display:none;"></td> 
		<?php } ?>

        <td><span class="tab-check"></span><a class="fancybox attandencelink" href="#inline<?php echo $StudentAdmissionDetailvalue['id']; ?>" id="<?php echo $StudentAdmissionDetailvalue['id']; ?>"><?php echo $StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName'];?></td>

        <td><?php echo $StudentAdmissionDetailvalue['StudentCourse'];?></a>

			<div id="attandence<?php echo $StudentAdmissionDetailvalue['id']; ?>" title="Basic dialog" style="display: none;">

	

  <div class="work-sch-contain">

        <div class="panel-heading">

        <h4 class="panel-title">Weekly Work Schedule</h4>

        </div>

        <div class="work-row work-row-head">

              <div class="work-right">

			  <?php

                 echo '<ul>

                      <li>'.date("m-d-Y", strtotime($dates[0])).'</br>Mon</li>
                     <li>'.date("m-d-Y", strtotime($dates[1])).'</br>Tue</li>
                     <li>'.date("m-d-Y", strtotime($dates[2])).'</br>Wed</li>
                     <li>'.date("m-d-Y", strtotime($dates[3])).'</br>Thur</li>
                     <li>'.date("m-d-Y", strtotime($dates[4])).'</br>Fri</li>

                 </ul>'; ?>

              </div>

        </div>

        <div class="work-row work-row-present">

             <div class="work-left">

                 <p>From Home</p>

             </div>

             <div class="work-right">

                 <ul>

				 <?php 

				 

				 for($i=0;$i<count($dates);$i++)

				 {

				 $attandsdata['studentid']=$StudentAdmissionDetailvalue['id'];

	$attandsdata['date']=$dates[$i];

	$count = StudentAttandenceModel::where($attandsdata)->count();

	if($count !=0)

	{

		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();

		if($StudentAttandence[0]['tohome']==1)

		{

                  echo'<li><span class="icon-work icon-work-present" ></span></li>';

				  } else {

				   echo'<li><span class="icon-work icon-work-absent"></span></li>';

				  }

				  } else {

                   echo '<li><span class="icon-work no_attendence"></span></li>';

				   }}

                echo '</ul>

             </div>

        </div>

        <div class="work-row work-row-absent">

             <div class="work-left">

                 <p>from School</p>

             </div>

             <div class="work-right">

                  <ul>';

				 for($i=0;$i<count($dates);$i++)

				 {

				 $attandsdata['studentid']=$StudentAdmissionDetailvalue['id'];

	$attandsdata['date']=$dates[$i];

	$count = StudentAttandenceModel::where($attandsdata)->count();

	if($count !=0)

	{

		$StudentAttandence = StudentAttandenceModel::where($attandsdata)->get()->toArray();

		

		if($StudentAttandence[0]['toschool']==1)

		{

                  echo'<li><span class="icon-work icon-work-present"></span></li>';

				  } else {

				   echo'<li><span class="icon-work icon-work-absent"></span></li>';

				  }

				  } else {

                   echo '<li><span class="icon-work no_attendence"></span></li>';

				   }}

                 ?></ul>

             </div>

        </div>

    </div>

</div>

		</td>

		<td><?php echo $StudentAdmissionDetailvalue['Age'];?></td>    

        <td><?php echo $StudentAdmissionDetailvalue['Gender'];?></td>  

        <td><?php echo $StudentAdmissionDetailvalue['GuardianMail'];?></td> 

        <td><?php echo $StudentAdmissionDetailvalue['ContactMobile'];?></td> 		

             
<div id="inline<?php echo $StudentAdmissionDetailvalue['id']; ?>" class="pop-des" style="display: none;">

		

		<div class="panel-heading">

                <h2 class="">Student Information</h2>

              </div>

		<div class="coln_box">

		<div class="coln coln_1">

		

		<div class="panel-heading">

                <h4 class="panel-title">Student Details</h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>Name: </span><?php echo $StudentAdmissionDetailvalue['PersonalFirstName']." ".$StudentAdmissionDetailvalue['PersonalLastName']; ?></label>

        </div>       

        </li>	

         <li>

        <div class="label-control">

        <label for="r_no"><span>Gender: </span><?php echo $StudentAdmissionDetailvalue['Gender']; ?></label>

        </div>       

        </li>

        <li>

        <div class="label-control">

        <label for="r_no"><span>Age:</span><?php echo $StudentAdmissionDetailvalue['Age'];?></label>

        </div>       

        </li>

          <li>

        <div class="label-control">

        <label for="r_no"><span>Grade:</span><?php echo $StudentAdmissionDetailvalue['StudentCourse']; ?></label>

        </div>       

        </li>         		

        </ul>        

		</div>

		<div class="coln coln_2">

		

		<div class="panel-heading">

                <h4 class="panel-title">Parent Details</h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>Name: </span><?php echo $StudentAdmissionDetailvalue['GuardianFirstName']." ".$StudentAdmissionDetailvalue['GuardianLastName']; ?></label>

        </div>       

        </li>	

         <li>

        <div class="label-control">

        <label for="r_no"><span>Mobile:</span> <?php echo $StudentAdmissionDetailvalue['ContactMobile']; ?></label>

        </div>       

        </li>

        <li>

        <div class="label-control">

        <label for="r_no"><span>Address: </span><p><?php if(!empty($StudentAdmissionDetailvalue['House'])) { echo $StudentAdmissionDetailvalue['House'].',</br>'.$StudentAdmissionDetailvalue['Street'].',</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; } else { echo $StudentAdmissionDetailvalue['Apartment'].',</br>'.$StudentAdmissionDetailvalue['Street'].',</br>'.$StudentAdmissionDetailvalue['ContactCity'].',</br>'.$StudentAdmissionDetailvalue['ContactState']; } ?></p></label>

        </div>       

        </li>          	

        </ul> 

		

		</div>

		<div class="coln coln_3">

		

		<div class="panel-heading">

                <h4 class="panel-title">School Timing for students </h4>

              </div>

        <ul class="dash-form-listerpopup"> 		

		 <li>

        <div class="label-control">

        <label for="r_no"><span>DAY </span><span>IN </span><span>OUT </span></label>

        </div>       

        </li>	

          <?php

		   

			 $timingarray= array();

			 $timingseconarray= array();

           if($StudentAdmissionDetailvalue['timingoption']==1)

		   {

		    $start=$StudentAdmissionDetailvalue['Weekdaysfrom'];

			$end=$StudentAdmissionDetailvalue['Weekdaysto'];

			$startkey = array_search($start, $weekdays);

			$endkey = array_search($end, $weekdays);

			$timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];

			$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];

			$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];

			$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];

			$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];

			$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];

		    $timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];

			$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];

			$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];

			$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];

			for($i=$startkey;$i<=$endkey;$i++)

		   {

		    $timingarray['In'.$i]=$StudentAdmissionDetailvalue['weekInTime'];

			 $timingarray['Out'.$i]=$StudentAdmissionDetailvalue['weekoutTime'];

		   }	  

		  

		   } else {

		   $timingarray['In0']=$StudentAdmissionDetailvalue['MondayInTime'];

			$timingarray['Out0']=$StudentAdmissionDetailvalue['MondayoutTime'];

			$timingarray['In1']=$StudentAdmissionDetailvalue['TuesdayInTime'];

			$timingarray['Out1']=$StudentAdmissionDetailvalue['TuesdayoutTime'];

			$timingarray['In2']=$StudentAdmissionDetailvalue['WednesdayInTime'];

			$timingarray['Out2']=$StudentAdmissionDetailvalue['WednesdayoutTime'];

		    $timingarray['In3']=$StudentAdmissionDetailvalue['ThursdayInTime'];

			$timingarray['Out3']=$StudentAdmissionDetailvalue['ThursdayoutTime'];

			$timingarray['In4']=$StudentAdmissionDetailvalue['FridayInTime'];

			$timingarray['Out4']=$StudentAdmissionDetailvalue['FridayoutTime'];

		   

		   }

		

		   for($i=0;$i<count($weekdays);$i++)

		   {

          ?>	

		   <li>

        <div class="label-control">

        <label for="r_no"><span><?php echo $weekdays[$i]; ?> </span><span><?php echo $timingarray["In".$i]; ?> </span><span><?php echo $timingarray["Out".$i]; ?> </span></label>

        </div>       

        </li>

<?php } ?>		  

        </ul> 
		</div>

		</div>
	</div>
        </tr>

        <?php   $parentid=$StudentAdmissionDetailvalue['parentid']; }  ?>

        </tbody>

        </table>

        </div>

        </div>

        </div>

		

        

		

        </div>

        <!-- dash content row end --> 

        </div>

     

		<script type="text/javascript">

		$(document).ready(function() {

		

			$('.fancybox').fancybox();

			$(".fancybox-effects-a").fancybox({

			

				helpers: {

					title : {

						type : 'outside'

					},

					overlay : {

						speedOut : 0

					}

				}

			});

			$('.attandencelink').mouseover(function (e) {

                 var id=$(this).attr("id");

				 $("#attandence"+id).show();				

				  $("#attandence"+id).dialog();

				  $(".ui-draggable-handle").hide();

				   $(".ui-icon-closethick").hide();

				   $(".ui-dialog").addClass("poplink");

				   var parentOffset = $(this).parent().offset(); 

				   $(".poplink").css({"top": parentOffset.top-55});

                   if(localStorage.getItem("users")=="lock")

	              {

				   $(".ui-dialog").removeClass("poplink");

	                $(".ui-dialog").addClass("poplink2");

	                 } else {

					  $(".ui-dialog").addClass("poplink");

					  $(".ui-dialog").removeClass("poplink2");

					 

					 }

				 })

				 .mouseout(function() {

				 $(".poplink").css({"top": "0px"});

				  $(".ui-dialog").removeClass("poplink");

				    $(".ui-dialog").removeClass("poplink2");

				$(".ui-icon-closethick").trigger("click");

				 });
 $(".paginate_button").click(function(){
				 $('.attandencelink').mouseover(function (e) {
                 var id=$(this).attr("id");
				 
				 $("#attandence"+id).show();				
				  $("#attandence"+id).dialog();
				  $(".ui-draggable-handle").hide();
				   $(".ui-icon-closethick").hide();
				   $(".ui-dialog").addClass("poplink");
				   var parentOffset = $(this).parent().offset(); 
				   $(".poplink").css({"top": parentOffset.top-55});
                   if(localStorage.getItem("users")=="lock")
	              {
				   $(".ui-dialog").removeClass("poplink");
	                $(".ui-dialog").addClass("poplink2");
	                 } else {
					  $(".ui-dialog").addClass("poplink");
					  $(".ui-dialog").removeClass("poplink2");
					 
					 }
				 })
				 .mouseout(function() {
				 $(".poplink").css({"top": "0px"});
				  $(".ui-dialog").removeClass("poplink");
				    $(".ui-dialog").removeClass("poplink2");
				$(".ui-icon-closethick").trigger("click");
				 });
				 });

 });

	// $(document).ready(function(){
// $('.parentdata').each(function () {
    // //var ar = this.id;
	// var ids = $('[id="' + this.id + '"]');
    // if (ids.length > 1) $('[id="' + this.id + '"]:gt(0)').remove();
// });
 // $(".paginate_button").click(function(){
 // $('.parentdata').each(function () {
    // var ar = $(".parentdata").attr('id');
	// alert(ar);
	// var ids = $('[id="' + ar + '"]');
    // if (ids.length > 1) $('[id="' + this.id + '"]:gt(0)').remove();
// });
 // });
	// });	

	</script>

@stop