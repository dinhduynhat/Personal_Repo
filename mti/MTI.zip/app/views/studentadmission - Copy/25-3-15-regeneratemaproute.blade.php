@extends('layouts.dashboardlayout')
@section('body')
<style type="text/css">
#header
{
	display: none;
}
.sidebar_left, .site-footer
{
	display: none;
}
.right_column
{
	width: 100%;
}
.nav-fixed-lock-open 
{
   padding-left: 0 !important;
}
.nav-fixed-close{
   padding-left: 0 !important;
}
body
{
	overflow: hidden;
}
.gm-login-iframe{
display:none !important;
}

</style>
<?php

$checkfinalarray=implode("/",$locationdataarray);
if(count($locationdataarray) !=0)
{
$studentarray=explode(",",$allocatestudentid);
	$address = str_replace(' ', '+', $startaddress);
	$url = 'http://maps.googleapis.com/maps/api/geocode/json?address='.$address.'&sensor=false';

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$geoloc = curl_exec($ch);
	
	$json = json_decode($geoloc);
	$start=array($json->results[0]->geometry->location->lat, $json->results[0]->geometry->location->lng);
	
	$unit="M";
	for($i=0;$i<count($locationdataarray);$i++)
	{
	
	 $finish=explode(",",$locationdataarray[$i]);
	 $lat2=$finish[0];
	 $lon2=$finish[1];
	  $lat1=$start[0];
	 $lon1=$start[1];
	$theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);

  if ($unit == "K") {
    echo  round(($miles * 1.609344));
  } else if ($unit == "N") {
     echo  round(($miles * 0.8684));
    } else {

   $finalarray[$locationdatastudentarray[$i]]=round($miles);    
   $finalstudentarray[$locationstudentnameaddress[$i]."_".$i."."]=round($miles);    
      }
	$finish=array();
}

asort($finalarray);
asort($finalstudentarray);
$loaddata=array_values(array_keys($finalarray));

$loadstudentnamedata=array_values(array_keys($finalstudentarray));

$checkfinalstudentarray=implode("/",$loaddata);
$checkfinalstudentnamearray=implode("/",$loadstudentnamedata);
//$checkfinalarray=implode("/",$locationaddress);
} else {
$checkfinalstudentarray="";
$checkfinalstudentnamearray="";
}
?>
 <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>

<script type="text/javascript">
  var directionDisplay;
  var directionsService = new google.maps.DirectionsService();
  var map;

  function initialize() {
    directionsDisplay = new google.maps.DirectionsRenderer();
    var chicago = new google.maps.LatLng(41.850033, -87.6500523);
    var myOptions = {
      zoom: 6,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: chicago
    }
    map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    directionsDisplay.setMap(map);
    calcRoute();
  }
  
  function calcRoute() {
   var waypts = [];
  var check="<?php echo $checkfinalarray; ?>";
    var studentdata="<?php echo $checkfinalstudentarray; ?>";
	var studentnamedata="<?php echo $checkfinalstudentnamearray; ?>";
  console.log(studentnamedata);
var checkboxArray = check.split("/");
var checkboxstudentArray = studentdata.split("/");
var checkboxstudentnameArray = studentnamedata.split("/");
console.log(checkboxstudentnameArray);
<?php if(!empty($checkfinalarray)) { ?>
   for (var i = 0; i < checkboxArray.length; i++) { 
console.log(checkboxArray[i]);   
      waypts.push({
          location:checkboxArray[i],
          stopover:true});
   
  }
  <?php } ?>
    var request = {
        origin: "<?php echo $startaddress; ?>",
        destination: "<?php echo $destinationaddress; ?>",
         waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: google.maps.DirectionsTravelMode.DRIVING
    };
    directionsService.route(request, function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
        directionsDisplay.setDirections(response);
        var route = response.routes[0];
        var summaryPanel = document.getElementById("directions_panel");
        summaryPanel.innerHTML = "";
        // For each route, display summary information.
		var docnumbers = new Array();
		var doctime = new Array();
		var docdistance = new Array();
        for (var i = 0; i < route.legs.length; i++) {
          var routeSegment = i + 1;
		  if(routeSegment%2==0)
		  {
		  var classname="route-box even";
		  } else {
		  var classname="route-box";
		  }
		   if(route.legs.length !=routeSegment)
		  {
		  docnumbers.push(checkboxstudentArray[i]);
		  doctime.push(route.legs[i].duration.text);
		  docdistance.push(route.legs[i].distance.text);
		   var regex = new RegExp('_[0-9]+\.');
            var string = checkboxstudentnameArray[i].replace(regex, '.');
		  summaryPanel.innerHTML +="<div class='"+classname+"'><h5><b>Student Name:</b> " + string + "</h5><p>"+route.legs[i].start_address + " to "+route.legs[i].end_address +" Distance:"+route.legs[i].distance.text +" Time:"+route.legs[i].duration.text +"<div style='display:none' class='removestudent'><a class='"+classname+" removefrombus' id='"+checkboxstudentArray[i]+"' href='javascript:;'>Remove</a></div></div>";
          } else {
		  
		  summaryPanel.innerHTML +="<div class='"+classname+"'><h5>Destination Point</h5><p>"+route.legs[i].start_address + " to "+route.legs[i].end_address +" Distance:"+route.legs[i].distance.text +" Time:"+route.legs[i].duration.text +"</div>";
		   var enddistance=route.legs[i].distance.text;
		var endtime=route.legs[i].duration.text;
		$(".endtime").val(endtime);
		$(".enddistance").val(enddistance);
		  }
        }
		var studentid=docnumbers.join('+');
		var sortedtime=doctime.join('+');
		var distance=docdistance.join('+');
		$(".sortedstudent").val(studentid);
		$(".sortedtime").val(sortedtime);
		$(".sorteddistance").val(distance);
      } else {
        alert("directions response "+status);
      }
    });
  }
  
</script>
</head>
<body onload="initialize()">
<div id="map_canvas" class="col-left  route-map-section" ></div>

<div class="map-route-list-section col-right">
<div class="dash-content-head">
<h5>Route List</h5>
</div>
<div class="getroute">
<input type="hidden" class="sortedstudent" value="" />
		<input type="hidden" class="sortedtime" value="" />
		<input type="hidden" class="sorteddistance" value="" />
		<input type="hidden" class="endtime" value="" />
		<input type="hidden" class="enddistance" value="" />
<div class="studeb-rout-list-section">
<div class="route-box even">
   <h5>Starting Point</h5>
   <p><?php echo $startaddress; ?></p>
</div>
<div id="directions_panel" ></div>      
	
</div>
</div>
 <div class="bottom-tab-row">
                <div class="col-left">                    
                    <button class="btn-mti savadata">Save</button>
					 <a class="fancybox attandencelink" href="{{ URL::to('transportlist'); }}"><button class="btn-mti">Cancel</button></a>
                </div>
             </div> 
</div>         
	<script>
	$(".savadata").click(function(){
	var Studentid = $(".sortedstudent").val();
	var sortedtime = $(".sortedtime").val();
	var sorteddistance = $(".sorteddistance").val();
	var endtime = $(".endtime").val();
	var enddistance = $(".enddistance").val();
	 var selectedpicktype = "<?php echo $selectedpicktype;?>";
	 var selectedbusid = "<?php echo $selectedbusid;?>";
	 var startaddress = "<?php echo $startaddress;?>";
	 var destinationaddress = "<?php echo $destinationaddress;?>";
     var selectschoolid = "<?php echo $selectschoolid;?>";
	 var updateid = "<?php echo $updateid;?>";
	 var getroute=$(".getroute").html();
	 var redirect=$(".attandencelink").attr("href");

                $.ajax({
                    type: "POST",
                    url : "updateroute",
                    data : { Studentid: Studentid, selectedpicktype: selectedpicktype,selectedbusid: selectedbusid, startaddress: startaddress,destinationaddress: destinationaddress, selectschoolid: selectschoolid, getroute: getroute, updateid: updateid,sortedtime: sortedtime, sorteddistance: sorteddistance, endtime: endtime, enddistance: enddistance},
                    success : function(data){
					window.location.href=redirect;
                       
                    }
                });
	});
	</script>
	  
 
@stop