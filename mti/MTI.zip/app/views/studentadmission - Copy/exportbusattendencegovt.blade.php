@extends('layouts.dashboardlayout')
@section('body')


<style>
a.tooltip {
	outline: none;
	display: none;
	position: absolute;
	/* border: 1px solid #333; */
	background-color: none !important;
	background-color: transparent;
	border-radius: 100%;
	padding: 0px;
	width: 12px;
	color: #fff;
	border: none !important;
	font-size: 12px Arial;
	z-index: 9999999;
	height: 12px;
}
a.tooltip {
	display: block!important;
}
a.tooltip strong {
	line-height: 30px;
}
a.tooltip:hover {
	text-decoration: none;
}
a.tooltip span {
	z-index: 10;
	display: none;
	padding: 14px 20px;
	margin-top: -30px;
	margin-left: 28px;
	width: 200px;
	line-height: 16px;
}
a.tooltip:hover span {
	display: inline;
	position: absolute;
	color: #111;
	border: 1px solid #DCA;
	background: #fffAF0;
}
.callout {
	z-index: 20;
	position: absolute;
	top: 30px;
	border: 0;
	left: -12px;
}
/*CSS3 extras*/
a.tooltip span {
	border-radius: 4px;
	box-shadow: 5px 5px 8px #CCC;
}
table.dataTable.atrtendTable tbody tr a.tooltip {
	outline: none;
	display: none;
	position: absolute;
	/* border: 1px solid #333; */
	background-color: none !important;
	border-radius: 100%;
	padding: 0px;
	width: 9px;
	color: #fff;
	font-size: 12px Arial;
	z-index: 9999999;
	height: 9px;
}
table.dataTable.atrtendTable tbody tr a.tooltip {
	display: block!important;
}
table.dataTable.atrtendTable tbody tr a.tooltip strong {
	line-height: 30px;
}
table.dataTable.atrtendTable tbody tr a.tooltip:hover {
	text-decoration: none;
}
table.dataTable.atrtendTable tbody tr a.tooltip span {
	z-index: 10;
	display: none;
	padding: 14px 20px;
	margin-top: -30px;
	margin-left: 28px;
	width: 200px;
	line-height: 16px;
	height: auto;
}
table.dataTable.atrtendTable tbody tr a.tooltip:hover span {
	display: inline;
	position: absolute;
	color: #111;
	border: 1px solid #DCA;
	background: #fffAF0;
}
table.dataTable.atrtendTable tbody tr .callout {
	z-index: 20;
	position: absolute;
	top: 30px;
	border: 0;
	left: -12px;
}
/*CSS3 extras*/
table.dataTable.atrtendTable tbody tr a.tooltip span {
	border-radius: 4px;
	box-shadow: 5px 5px 8px #CCC;
}
.fancybox-opened {
	top: 15px !important;
}

</style>

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>
	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}

            <div class="form-panel">



    <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Manage Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

          <div class="dash-content-row"> <!--- dash content row start -->

          	        

        

        

            <div class="dash-content-head">


              <h5>Export Bus Attendance</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              
             <ul class="dash-form-lister">
  <li>
    <div class="label-control">
      <label for="r_no">School</label>
    </div>
    <div class="input-control">
      {{ Form::select('schoolid', $SchoolDetails,null, array('id'=> 'schoolid'))}}    
    </div>
    {{ $errors->first('schoolid', '<div class="error">:message</div>') }}
  </li>
  <li>
    <div class="label-control">
      <label for="Student Name">Select Month and Year</label>
    </div>
    <div class="input-control">
                  <?php
            $curmonth = date("F");
            $month = date("m");
            
            ?>

<select style='width: 112px;' name='PayMonth' id='Month'>
  <option name="PayMonth" value=''>Select Month</option>   
<?php
for($i = $month-3 ; $i <= $month; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
  <option value="<?php echo date("m",mktime(0,0,0,$i,1,date("Y"))); ?>" ><?php echo date("F",mktime(0,0,0,$i,1,date("Y")));?>
  </option>
    <?php
}?>

</select>    

<?php

$v = date("m"); 



$tmonth =  $v-3;


if ($tmonth<=0) 
{
$from = date("Y");
$to = date("Y")+1;
} else 
{
$from = date("Y");
$to = date("Y");
}



?>
<select name="PayYear" style='width: 112px;' id='Year'>
 <option name="PayYear" value=''>Select Year </option>   
<?php 


$year = date('Y');
$nextyear = date('Y')-1;


$v = date("m"); 



$tmonth =  $v-3;



if ($tmonth<=0) 
{
$from = date("Y")-1;
$to = date("Y");
} else 
{
$from = date("Y");
$to = date("Y");
}




for($i=$from; $i<=$to; $i++)
{

    echo "<option value=".$i.">".$i."</option>";
}
?> 
    
</select> 
</div>

<div id='errorji' style="color:red;display:none">
  Month and Year should be Selected
</div>

  </li>

</ul>

           

			  {{ Form::close() }}

			     <div class="btn-group form-list-btn-group">

                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>



			<div class="result"></div>

			

          </div>



          <!-- dash content row end --> 
        </div>

        <!--dash content row end --> 

    

      </div>

    
    <script>
        $("document").ready(function(){

        $(".submit-btn").click(function(e){

        if($('#Month').val() == '' || $('#Year').val() == '' )
{


        $("#errorji").show();
        $(".result").hide();
        

   
}

else
{
$(".result").show();
$("#errorji").hide();

        var schoolid = $("#schoolid").val();
        if(1==1)
           {
           e.preventDefault();
           var dataString = $("form").serialize();  
                $.ajax({
                    type: "POST",
                    url : "exportbusattendencegovtresult",
                    data : dataString,
                    success : function(data){
                      console.log(data);
                    $(".result").html(data);
                    }
                });
            }

          }
        });
        });

    </script>


@stop