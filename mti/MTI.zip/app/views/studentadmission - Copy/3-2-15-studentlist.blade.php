@extends('layouts.dashboardlayout')
@section('body')

	{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}
	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}
        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Settings Master</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Search Student List</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        <!---{{ Form::open(array('url' => 'searchstudentprocess')) }}-->
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('ClassName', 'Studentname/Age/Gender' ) }}
        </div>
        <div class="input-control">        
         {{ Form::text('Searchdata',null, array('id'=> 'Searchdata')) }}		 
        
        </div>
        {{ $errors->first('Searchdata', '<div class="error">:message</div>') }}
        </li>
          
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Search', ['class' => 'submit-btn Search']) }}    
    
        </div>
      <!---{{ Form::close() }}-->
		
        </div>

 <div class="result"> 
        </div>
         <!---------------- student listing table start ------>
     <script>
  $(function() {
    var availableTags = [
	<?php foreach($StudentDetails as $StudentDetailsvalue) { 
echo '"'.$StudentDetailsvalue["PersonalFirstName"].' '.$StudentDetailsvalue["PersonalLastName"].'/'.$StudentDetailsvalue["Age"].'/'.$StudentDetailsvalue["Gender"].'"'.',';	
	?>
     
      <?php } ?>
    ];
    $( "#Searchdata" ).autocomplete({
      source: availableTags
    });
  });
  </script>
        
		<script>
        $("document").ready(function(){
            $(".Search").click(function(e){
		
                e.preventDefault();
                var Searchdata = $("#Searchdata").val();
            
                var dataString = 'Searchdata='+Searchdata; 
                $.ajax({
                    type: "POST",
                    url : "searchstudentprocess",
                    data : dataString,
                    success : function(data){
					$(".result").html(data);
                        console.log(data);
                    }
                });

        });
        });
		
		//end of document ready function
    </script>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
        </div>
		<script type="text/javascript">
		$(document).ready(function() {
		
			$('.fancybox').fancybox();
			$(".fancybox-effects-a").fancybox({
			
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});
			});

			
			function transpotalert(commentval){
			$('#CommentsData').val(commentval);
			}
		
	</script>


		
@stop