@extends('layouts.dashboardlayout')
@section('body')
            <div class="form-panel">
        <div class="header-panel">
          <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
          
          <div class="dash-content-row"> <!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Allocation & Routing Flow</h5>
             </div>
			 {{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}
            <div class="panel-row panel-row-wborder">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <div class="col-one-two allocation-list">
            <ul class="dash-form-lister">
              <li>
                <div class="label-control">
                  <label for="r_no">School </label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select>
				   <option>Select School</option>
                    <option>English School</option>
                  </select>
                </div>
              </li>
              <li>
              <ul class="inner-col-one-three">
              <li>
                <div class="label-control">
                  <label for="r_no">Timing</label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select>
                    <option>07:45 AM - 02:00 PM</option>
                    <option>08:30 AM - 02:45 PM</option>
                  </select>                </div>
              </li>
              <li>
                <div class="label-control">
                  <label for="r_no">Age </label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select multiple>
                    <option>07</option>
                    <option>09</option>
                    <option>12</option>                    
                  </select>
                </div>
              </li>
              <li>
                <div class="label-control">
                  <label for="r_no">Street/City/State</label>
                </div>
                <div class="input-control">
                  <select multiple>
                    <option>Partin street #2 Everett</option>
                    <option>Partin street #2 Everett1</option>
                    <option>Partin street #2 Everett2</option>
                  </select>
                </div>
              </li>
              </ul>
              </li>
              <li class="need-space">
                <div class="input-control">
                  <input type="submit" value="Filter Children">
                </div>
              </li>
              
            </ul>            
            </div>
            
	        <div class="col-one-two-margin">
                <div class="allocation_map">
                     
                </div>
            </div>
            
            
            </div>
             <div class="panel-row list-row">
             <div class="dash-content-head tabContaier">
             <h5>Un-Assigned Children</h5>
             <a href="#" class="btn-sb pass-btn"><span class="icon_btn icon_btn_map"></span>Show in Map</a>
             </div>
             <div class="panel-tab-row"> <!---------------- unassigned listing table start ------>
				<table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th> <input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();">
                    </th>
                    <th> Age </th>
                    <th> Student Name </th>
                    <th> Pick up Address </th>
                    <th> Drop off Address </th>
                    <th> Contact Person </th>
                    <th> Contact Number </th>
                    <th> Grade </th>
					<th> Pick up Type </th>
                    <th> Special Care(Note) </th>
                    
                  </tr>
                </thead>
                <tbody>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               <td>07</td>
                        <td> Alexis </td>
                        <td> Partin street #2 Everett </td>
                        <td> Partin street #2 Everett </td>
                        <td> Marina </td>
                        <td> 7826378473 </td>
                        <td> 03 </td>
                        <td> From Home </td>
                        <td> Nil </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               <td>07</td>
                        <td> Alexis </td>
                        <td> Partin street #2 Everett </td>
                        <td> Partin street #2 Everett </td>
                        <td> Marina </td>
                        <td> 7826378473 </td>
                        <td> 03 </td>
                        <td> From Home </td>
                        <td> Nil </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               <td>07</td>
                        <td> Alexis </td>
                        <td> Partin street #2 Everett </td>
                        <td> Partin street #2 Everett </td>
                        <td> Marina </td>
                        <td> 7826378473 </td>
                        <td> 03 </td>
                        <td> From Home </td>
                        <td> Nil </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               <td>07</td>
                        <td> Alexis </td>
                        <td> Partin street #2 Everett </td>
                        <td> Partin street #2 Everett </td>
                        <td> Marina </td>
                        <td> 7826378473 </td>
                        <td> 03 </td>
                        <td> From School </td>
                        <td> Nil </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               <td>07</td>
                        <td> Alexis </td>
                        <td> Partin street #2 Everett </td>
                        <td> Partin street #2 Everett </td>
                        <td> Marina </td>
                        <td> 7826378473 </td>
                        <td> 03 </td>
                        <td> Both</td>
                        <td> Nil </td>
                      </tr>
                    </tbody>
                  </table>
             </div>                      <!---------------- unassigned listing table end ------>
             <div class="bottom-tab-row">
                <div class="col-left">
                   <ul class="list-inline">
                       <li><input type="radio" id="p_up" name="pd_time" /><label for="p_up">Pick Up</label></li>
                       <li><input type="radio" id="d_off" name="pd_time" /><label for="d_off">Drop Off</label></li>
                   </ul>
                </div>
                <div class="col-right">
                    <button class="btn-mti">Move to Transport Allocation</button>
                </div>
             </div>
             </div>
             
             
            <div class="panel-row list-row list-row-btn">   <!----- allote transport section start ------->
              <div class="dash-content-head tabContaier">
                <h5>Allocate to Transport</h5>
                <a href="#" class="btn-sb pass-btn"><span class="icon_btn icon_btn_map"></span>Show in Map</a> </div>
              <div class="panel-tab-row tabwith_scroll"> <!---------------- unassigned listing table start ------>
                  <table id="example" class="display" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th> <input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();">
                      </th>
                      <th> Remove </th>
                      <th> Age </th>
                      <th> Student Name </th>
                      <th> Address</th>
                      <th> Contact Person </th>
                      <th> Contact Number </th>
                      <th> Grade </th>
					  <th> Pick up Type </th>
                      <th> Special Care(Note) </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                    <tr>
                      <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>
                      <td> <a href="#" class="icon-link icon-link-remove">Remove</a> </td>
                      <td>07</td>
                      <td> Alexis </td>
                      <td> Partin street #2 Everett </td>
                      <td> Marina </td>
                      <td> 7826378473 </td>
                      <td> 03 </td>
					   <td> From School </td>
                      <td> yes </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!---------------- unassigned listing table end ------>
              <div class="bottom-tab-row">
                <div class="col-left">
                  <ul class="list-inline">
                    <li>
                      <label for="p_up">Bus</label>
                      <select>
                         <option>Bus01-(0/40)</option>
                         <option>Bus02-(10/40)</option>
                         <option>Bus03-(20/40)</option>
                      </select>
                    </li>
                    <li>
                      <label for="d_off">Start</label>
                      <input type="text" />
                    </li>
                    <li>
                      <label for="d_off">Destination</label>
                      <input type="text" />
                    </li>
                  </ul>
                </div>
                <div class="col-right">
                  <a class="fancybox attandencelink" href="{{ URL::to('generatemaproute'); }}"><button class="btn-mti btn-generate">View And Save Route</button></a>
                </div>
              </div>
            </div>  <!----- allote transport section end ------->
          </div>
          <!-- dash content row end --> 
        </div>
		
        <!--dash content row end --> 
          <script type="text/javascript">

		$(document).ready(function() {

		

			$('.fancybox').fancybox();

			$(".fancybox-effects-a").fancybox({

			

				helpers: {

					title : {

						type : 'outside'

					},

					overlay : {

						speedOut : 0

					}

				}

			});
			});
			</script>
      </div>
	  
	  
 
@stop