@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">

          <h2><!--<span class="icon icon-profile">--></span>Export Student Attendence</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5>Export Student Attendence</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocess', 'files'=> true, 'id' => 'profileupdateprocess')) }}

              <ul class="dash-form-lister">

			 <li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Start date' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Startdate', null, ['class' => 'datetimepicker1 DateOfBirth']) }}        

        </div>

        {{ $errors->first('Startdate', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('Enddate', 'End date' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Enddate', null, ['class' => 'datetimepicker1 DateOfBirth']) }}        

        </div>

        {{ $errors->first('Enddate', '<div class="errorsetting">:message</div>') }}

        </li>

           <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Gender' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Gender', array(''=>'Select Gender')+$gender,null, array('id'=> 'PersonalMotherTongue'))}}		

        </div>

         {{ $errors->first('PersonalMotherTongue', '<div class="errorsetting">:message</div>') }}

        </li>

 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Age' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Age', array(''=>'Select Age')+$age,null, array('id'=> 'Age'))}}		

        </div>

         {{ $errors->first('Age', '<div class="errorsetting">:message</div>') }}

        </li>

 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Grade' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Grade', array(''=>'Select Grade')+$grade,null, array('id'=> 'Grade'))}}		

        </div>

         {{ $errors->first('Grade', '<div class="errorsetting">:message</div>') }}

        </li>		

            <li>

        <div class="label-control">

        {{ Form::label('Student Name', 'Student Name' ) }}

        </div>

        <div class="input-control">        

         {{ Form::text('studentname',null, array('id'=> 'Searchdata','placeholder' => 'Type hint')) }}		 

        

        </div>

        {{ $errors->first('studentname', '<div class="error">:message</div>') }}

        </li>

       <li>

        <div class="label-control">

        {{ Form::label('Parent Name', 'Parent Name' ) }}

        </div>

        <div class="input-control">        

         {{ Form::text('ParentName',null, array('id'=> 'ParentName','placeholder' => 'Type hint')) }}		 

        

        </div>

        {{ $errors->first('ParentName', '<div class="error">:message</div>') }}

        </li>	

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Attendence Status' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('AttendenceStatus', array(''=>'Select Attendence Status')+$AttendenceStatus,null, array('id'=> 'AttendenceStatus'))}}		

        </div>

         {{ $errors->first('AttendenceStatus', '<div class="errorsetting">:message</div>') }}

        </li>

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Attendence from' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('AttendenceFrom', array('all'=>'All')+$fromwhere,null, array('id'=> 'AttendenceFrom'))}}		

        </div>

         {{ $errors->first('AttendenceFrom', '<div class="errorsetting">:message</div>') }}

        </li>		

              </ul>

              <div class="btn-group form-list-btn-group">

                {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}

              </div>

			  {{ Form::close() }}

            </div>

          </div>

          <!-- dash content row end --> 

		 

		  <script>

		  $("#AttendenceStatus").change(function(){

		  var value=$(this).val();

		  if(value=="")

		  {

		  $("#AttendenceFrom").attr('disabled','disabled');

		  $("#AttendenceFrom").val("all");

		  } else {

		  $("#AttendenceFrom").removeAttr("disabled");

		  }

		  });

  $(function() {

    var availableTags = [

	<?php foreach($studentname as $studentnamevalue) { 

echo '"'.$studentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

  	  <script>

  $(function() {

    var availableTags = [

	<?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

        </div>

        <!--dash content row end --> 

    

      </div>

    </div>

@stop