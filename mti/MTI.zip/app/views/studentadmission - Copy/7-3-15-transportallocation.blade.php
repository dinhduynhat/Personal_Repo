@extends('layouts.dashboardlayout')
@section('body')
<div class="form-panel">
<div class="header-panel">
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>
<div class="dash-content-panel">
<!-- dash panel start -->

<div class="dash-content-row">
<!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Transport Route Listing</h5>
             </div>
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <div class="col-one-one">
            <ul class="dash-form-lister">
              <li>
                <div class="label-control">
                  <label for="r_no">School Name </label>
                  <em>*</em> </div>
                <div class="input-control">
                  <select>
                    <option>English School</option>
                  </select>
                </div>
              </li>
              <li>
                <div class="input-control">
                  <input type="submit" value="Filter School">
                </div>
              </li>
              
            </ul>            
            </div>
            
            </div>
             <div class="panel-row list-row">
             <div class="dash-content-head tabContaier">
             <h5>Bus List</h5>
             </div>
             <div class="panel-tab-row"> <!---------------- unassigned listing table start ------>
				<table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th width="20"> <input type="checkbox" id="selecctall" onchange="javascript:CheckedAll();"></th>
                    <th> Bus </th>
                    <th> Driver Name </th>
                  </tr>
                </thead>
                <tbody>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>              
                        <td> Bus02(40/42) </td>
                        <td> Edwards </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>              
                        <td> Bus02(40/42) </td>
                        <td> Edwards </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               
                        <td> Bus02(40/42) </td>
                        <td> Edwards </td>
                      </tr>
                      <tr>
                        <td><input  name="chkSelectRow[]" type="checkbox" class="deletelist" value="1"></td>               
                        <td> Bus02(40/42) </td>
                        <td> Edwards </td>
                      </tr>
                    </tbody>
                  </table>
             </div>                      <!---------------- unassigned listing table end ------>
             <div class="bottom-tab-row">
                <div class="col-left">
                    <button class="btn-mti btn-mti-active">Show Pick up list</button>
                    <button class="btn-mti">Show Drop off list</button>
                </div>
             </div>
             </div>
             
             
            <div class="panel-row list-row list-row-btn">   <!----- allote transport section start ------->
              <div class="dash-content-head tabContaier tabContaier-tab">
            <div class="col-left">
            <ul>    <!------------- tab button section start ------------>
                <li><a class="active" href="#tab1">Route View</a></li>
            </ul>   <!------------- tab button section close ------------>
            </div>
            <div class="col-right">
            <a href="{{ URL::to('addstudenttobus'); }}" class="btn-sb pass-btn"><span class="icon_btn icon_plus"></span>Add Student</a>
            </div>
            </div>
            <div class="tabDetails">
              <div id="tab1" class="tabContents">
                  <div class="map_view">
                  <div class="col-left route-map-section">
</div>
<div class="map-route-list-section col-right">
<div class="dash-content-head">
<h5>Bus Route List(Pick up)</h5>
</div>
<div class="start-point-wrap">
   <h5>Starting Point</h5>
   <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
</div>
<div class="studeb-rout-list-section">
      <div class="route-box">
         <h5>Student1</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box even">
         <h5>Student2</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box">
         <h5>Student3</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box even">
         <h5>Student4</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
	  <div class="start-point-wrap">
   <h5>Destination Point</h5>
   <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
</div>
</div>
</div> 
                  </div>
              </div>
              
              </div>
              <!---------------- unassigned listing table end ------>
            </div>  <!----- allote transport section end ------->
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
    
      </div>
	  
	  
 
@stop