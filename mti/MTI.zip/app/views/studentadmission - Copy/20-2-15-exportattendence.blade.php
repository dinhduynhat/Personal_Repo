@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">

          <h2><!--<span class="icon icon-profile">--></span>Student Attedance Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5>Student Attedance Report</h5>

             </div>

            <div class="panel-row">

			 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              <ul class="dash-form-lister">

			   <?php

  	if(Auth::user()->usertype==1)

		{

		?>

			  <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('schoolid', array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'schoolid'))}}		

        </div>

         {{ $errors->first('schoolid', '<div class="errorsetting">:message</div>') }}

        </li>

		<?php } else { ?>

		  <li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'School' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('schoolid', $SchoolDetails,null, array('id'=> 'schoolid'))}}		

        </div>

         {{ $errors->first('schoolid', '<div class="errorsetting">:message</div>') }}

        </li>

		<?php } ?>

		  <li>

        <div class="label-control">

        {{ Form::label('Student Name', 'Student Name' ) }}

        </div>

        <div class="input-control">        

         {{ Form::text('studentname',null, array('id'=> 'Searchdata','placeholder' => 'Type hint')) }}		 

        

        </div>

        {{ $errors->first('studentname', '<div class="error">:message</div>') }}

        </li>

			 <li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Attendance From' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Startdate', null, ['class' => 'datetimepicker1 DateOfBirth Startdate']) }}        

        </div>

        {{ $errors->first('Startdate', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('Enddate', 'Attendance To' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Enddate', null, ['class' => 'datetimepicker1 DateOfBirth Enddate']) }}        

        </div>

        {{ $errors->first('Enddate', '<div class="errorsetting">:message</div>') }}

        </li>

           <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Gender' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Gender', array(''=>'Select Gender')+$gender,null, array('id'=> 'PersonalMotherTongue'))}}		

        </div>

         {{ $errors->first('PersonalMotherTongue', '<div class="errorsetting">:message</div>') }}

        </li>

 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Age' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Age', array(''=>'Select Age')+$age,null, array('id'=> 'Age'))}}		

        </div>

         {{ $errors->first('Age', '<div class="errorsetting">:message</div>') }}

        </li>

 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Grade' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('Grade', array(''=>'Select Grade')+$grade,null, array('id'=> 'Grade'))}}	

        </div>

         {{ $errors->first('Grade', '<div class="errorsetting">:message</div>') }}

        </li>		

          

       <li>

        <div class="label-control">

        {{ Form::label('Parent Name', 'Parent Name' ) }}

        </div>

        <div class="input-control">        

         {{ Form::text('ParentName',null, array('id'=> 'ParentName','placeholder' => 'Type hint')) }}		 

        

        </div>

        {{ $errors->first('ParentName', '<div class="error">:message</div>') }}

        </li>	

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Attendence Status' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('AttendenceStatus', array(''=>'Select Attendence Status')+$AttendenceStatus,null, array('id'=> 'AttendenceStatus'))}}		

        </div>

         {{ $errors->first('AttendenceStatus', '<div class="errorsetting">:message</div>') }}

        </li>

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Attendence from Location' ) }}

        </div>

        <div class="input-control">              

	   {{ Form::select('AttendenceFrom', array('all'=>'All')+$fromwhere,null, array('id'=> 'AttendenceFrom'))}}		

        </div>

         {{ $errors->first('AttendenceFrom', '<div class="errorsetting">:message</div>') }}

        </li>	

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Trip Type' ) }}

        </div>

        <div class="input-control">  

		{{ Form::label('r_no', 'Both' ) }}		

       {{ Form::radio('TripType', '', true, ['class' => 'Twoway']) }}

       {{ Form::label('r_no', 'One way' ) }}		

       {{ Form::radio('TripType', 1, true, ['class' => 'Oneway']) }}

	   {{ Form::label('r_no', 'Two way' ) }}		

       {{ Form::radio('TripType', 2, true, ['class' => 'Twoway']) }}

        </div>

         {{ $errors->first('Triptype', '<div class="errorsetting">:message</div>') }}

        </li>		

              </ul>

           

			  {{ Form::close() }}

			     <div class="btn-group form-list-btn-group">

                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>

			<div class="result"></div>

			

          </div>



          <!-- dash content row end --> 

		

		  <script>

		  $("#AttendenceStatus").change(function(){

		  var value=$(this).val();

		  if(value=="")

		  {

		  $("#AttendenceFrom").attr('disabled','disabled');

		  $("#AttendenceFrom").val("all");

		  } else {

		  $("#AttendenceFrom").removeAttr("disabled");

		  }

		  });

		   $("#Enddate").change(function(){

		    var end=$(this).val();

			

		   });

  $(function() {

    var availableTags = [

	<?php foreach($studentname as $studentnamevalue) { 

echo '"'.$studentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

  	  <script>

  $(function() {

    var availableTags = [

	<?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

  	if(Auth::user()->usertype==1)

		{

		?>

		<script>

        $("document").ready(function(){

            $("#schoolid").change(function(e){

		

                e.preventDefault();

                var schoolid = $("#schoolid").val();                 

                var dataString = 'schoolid='+schoolid;  

                $.ajax({

                    type: "POST",

                    url : "sessionprocess",

                    data : dataString,

                    success : function(data){

					location.reload();

                    }

                });



        });

        });

		

		//end of document ready function

    </script>

	

		<?php	

		

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

} else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}	 





		}  ?>

		<script>

        $("document").ready(function(){

            $(".submit-btn").click(function(e){

		
var schoolid = $("#schoolid").val();
			if(schoolid !="")
			{
                e.preventDefault();

              

                var dataString = $("form").serialize();  

                $.ajax({

                    type: "POST",

                    url : "exportattendenceprocesslist",

                    data : dataString,

                    success : function(data){

					$(".result").html(data);

                    }

                });

}

        });

        });

		

		

    </script>

        </div>

        <!--dash content row end --> 

    

      </div>

 

@stop