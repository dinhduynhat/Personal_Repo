@extends('layouts.dashboardlayout')
@section('body')
<div class="form-panel">
<div class="header-panel">  <!-------------- start header ------------->
  <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
</div>                      <!-------------- end header ------------->
<div class="dash-content-panel">  
<!-- dash panel start -->
<div class="dash-content-row">
<!--- dash content row start -->

            <div class="dash-content-head">
              <h5>Add student to bus</h5>
             </div>
             
            <div class="panel-row">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>
 {{ Form::open(array('url' => 'postaddstudentdata', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}
	        <ul class="dash-form-lister"> 
     <li>
      <div class="label-control">
        <label for="LicenseNumber">Student Name </label>
        <em>*</em> </div>
      <div class="input-control">
        {{ Form::select('studentname',array(''=>'Select Studentname')+$studentname,null, array('id'=> 'studentname'))}}	
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Age">Grade </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::select('grade',array(''=>'Select Grade')+$grade,null, array('id'=> 'grade'))}}	
      </div>
    </li>
    <li>
      <div class="label-control">
        <label for="Address">Age </label>
        <em>*</em> </div>
      <div class="input-control">
       {{ Form::select('age',array(''=>'Select Age')+$age,null, array('id'=> 'age'))}}	
      </div>
    </li>
 
    <li>
      <div class="label-control">
         <label>&nbsp;</label>
      </div>
      <div class="input-control check-input-control">
        <input name="addstudent" type="checkbox" id="add_bus" value="1">
        <label for="add_bus">Add to bus </label>
      </div>
    </li>
    </ul>
      <div class="btn-group form-list-btn-group">
    <input class="submit-btn" type="submit" value="Save">
    <input class="resetbutton" type="reset" value="Cancel">
  </div>
        </form>   
             
            </div>  <!----- allote transport section end ------->
            
            
          </div>
          <!-- dash content row end --> 
        </div>
        <!--dash content row end --> 
       
      </div>
	  
	  
 
@stop