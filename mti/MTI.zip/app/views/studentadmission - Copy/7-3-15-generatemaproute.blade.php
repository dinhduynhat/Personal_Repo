@extends('layouts.dashboardlayout')
@section('body')
<style type="text/css">
#header
{
	display: none;
}
.sidebar_left, .site-footer
{
	display: none;
}
.right_column
{
	width: 100%;
}
.nav-fixed-lock-open 
{
   padding-left: 0;
}
body
{
	overflow: hidden;
}

</style>
<div class="col-left route-map-section">
</div>
<div class="map-route-list-section col-right">
<div class="dash-content-head">
<h5>Add student to bus</h5>
</div>
<div class="start-point-wrap">
   <h5>Starting Point</h5>
   <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
</div>
<div class="studeb-rout-list-section">
      <div class="route-box">
         <h5>Student1</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box even">
         <h5>Student2</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box">
         <h5>Student3</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
       <div class="route-box even">
         <h5>Student4</h5>
         <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
      </div>
	    <div class="start-point-wrap">
   <h5>Destination Point</h5>
   <p>Allen Street, New York, NY 10002, USA to Ann Street, 
New York, NY 10038, USA
2.0 mi</p>
</div>
</div>
 <div class="bottom-tab-row">
                <div class="col-left">                    
                    <button class="btn-mti">Save</button>
					 <a class="fancybox attandencelink" href="{{ URL::to('studentallocation'); }}"><button class="btn-mti">Cancel</button></a>
                </div>
             </div> 
</div>         
	 
	  
 
@stop