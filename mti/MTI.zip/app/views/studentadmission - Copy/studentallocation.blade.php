@extends('layouts.dashboardlayout')
@section('body')

<style>

	.poplink

	{

	

margin-top: 0px !important;
width:auto  !important;

	}
	.lab-abs{
	margin-left: -82px !important;
padding-top: 18px !important;
	}
	.dash-content-panel .tabl.tab-abs select{
	width: auto !important;
	}
	</style>
            <div class="form-panel">
        <div class="header-panel">

<h2><!--<span class="icon icon-student"></span>-->Manage Transport</h2>

          
          <?php /*?><h2><!--<span class="icon icon-profile">--></span>Student Register</h2><?php */?>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
          
          <div class="dash-content-row"> <!--- dash content row start -->
            <div class="dash-content-head">
              <h5>Allocation & Routing Flow</h5>
             </div>
			 {{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}
            <div class="panel-row panel-row-wborder">
			 @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
		<?php   //$yrdata= strtotime(date("Y/m/d")); ?>

	        <div class="col-one-two allocation-list">
            <ul class="dash-form-lister">
              <li>
                <div class="label-control">
                  <label for="r_no">School </label>
                  <em>*</em> </div>
                <div class="input-control">
                   {{ Form::select('SchoolName',array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'SchoolName'))}}	
                </div>
              </li>
              <li>
              <ul class="inner-col-one-three">
              <div class="result"></div>
			  <div class="result2"></div>
              <input type="hidden" class="movestudentid" value="">
			  <input type="hidden" class="triptypevalue" value="pickup">
              </ul>
              </li>
              <li class="need-space">
                <div class="input-control">
                  <input type="submit" class="filter" value="Filter Children">
                </div>
              </li>
              
            </ul>            
            </div>


            <div class="searchmap" style="display:none;">
			</div>
	        <div class="col-one-two-margin defaultmap">
			<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
		    <div id="map" style="min-height: 235px;border: 1px solid #dddddd;
box-sizing: border-box;
padding: 1%;width: 100%;"></div>
			<script type="text/javascript">
    var locations = [
      
    ];

    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 7,      
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
	navigator.geolocation.getCurrentPosition(function(position) {
        
            var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            map.setCenter(geolocate);
            
        });
        
  

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
  </script>
                
            </div>
            
            
            </div>
             <div class="resultunassigned"></div>
             <div class="movestudentdatalist"></div>
             
             {{ Form::open(array('url' => Session::get('urlpath').'/generateroutemap', 'files'=> true, 'id' => 'generateroutemap','class'=>'generateroutemap')) }}

<input type="hidden" name="allocatestudentid" value="" class="allocatestudentid"/>
<input type="hidden" name="selectedpicktype" value="" class="selectedpicktype"/>
<input type="hidden" name="selectedbusid" value="" class="selectedbusid"/>
<input type="hidden" name="startaddress" value="" class="startaddress"/>
<input type="hidden" name="destinationaddress" value="" class="destinationaddress"/>
<input type="hidden" name="schoolid" value="" class="selectschoolid"/>
</form>
          </div>
          <!-- dash content row end --> 
        </div>
		
        <!--dash content row end --> 
          <script>
		$("document").ready(function(){
            $("#SchoolName").change(function(e){
		
                e.preventDefault();
                var SchoolName = $("#SchoolName").val();
            
                var dataString = 'SchoolName='+SchoolName; 
                $.ajax({
                    type: "POST",
                    url : "searchschoolsearchdetails",
                    data : dataString,
                    success : function(data){
					$(".result").html(data);
                       
                    }
                });

        });
		
  });
  
		</script>
		
      </div>
	  
	  
 
@stop