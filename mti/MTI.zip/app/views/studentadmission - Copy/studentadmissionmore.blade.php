@extends('layouts.dashboardlayout')

@section('body')



<script>

$(document).ready(function(){

$(".week").hide();

$(".separate").show();

if ($("#some-box").is(':checked')){

    $("#main-box").show();

}

});

</script>

{{ HTML::script('assets/js/jquery.fancybox.js?v=2.1.5') }}

	{{ HTML::style('assets/css/jquery.fancybox.css?v=2.1.5') }}

	
	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('Address'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.k;
                var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
			  //var longitude = place.geometry.location.D;
			  $('#latitude').val(latitude);
			  $('#longitude').val(longitude);
            });
        });
    </script>
	
        <div class="form-panel">

        <div class="header-panel">

        <h2><!--<span class="icon icon-student"></span>-->Student Register</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5>Student Register</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>

 

        {{ Form::open(array('url' => 'studentadmissionmoreaddingprocess', 'files'=> true, 'id' => 'studentadmissionprocess')) }}

	

        <div class="panel-row panel-row-wborder">

		

        <div class="col-three-four">

		<div class="panel-heading">

                <h4 class="panel-title">School Details</h4>

              </div>

        <ul class="dash-form-lister"> 

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Name' ) }}<em>*</em>

        </div>

        <div class="input-control">

		        <?php 

	

if(Auth::user()->usertype ==1)

{

?>

       {{ Form::select('SchoolName',array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'SchoolName'))}}		

      <?php } else { ?>

	   {{ Form::select('SchoolName',$SchoolDetails,null, array('id'=> 'SchoolName'))}}	

	  <?php } ?>

        </div>

         {{ $errors->first('SchoolName', '<div class="errorsetting">:message</div>') }}

        </li>

	<li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::textarea('SchoolAddress', null,['class' => 'SchoolAddress','size' => '100x100','disabled']) }}

        </div>

         {{ $errors->first('SchoolAddress', '<div class="errorsetting">:message</div>') }}

        </li>
		<li class="">

                  <div class="label-control">                   

					 {{ Form::label('Name', 'Bus Company' ) }}<em>*</em>

                  </div>

                  <div class="input-control">

				{{ Form::select('Company', array(''=>'Select Companyname')+$Companyname,null, array('id'=> 'Company'))}}		                

                  </div>

				   {{ $errors->first('Company', '<div class="error">:message</div>') }}

                </li>

<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Grade' ) }}<em>*</em>

        </div>

        <div class="input-control gradeselectbox">

       <select id="StudentCourse" name="StudentCourse"><option value="" selected="selected">Select Grade</option></select>	

      

        </div>

         {{ $errors->first('StudentCourse', '<div class="errorsetting">:message</div>') }}

        </li>

		<li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'Batch' ) }}<em>*</em>

        </div>

        <div class="input-control">      	

	   {{ Form::text('StudentBatch',date("Y"), array('id'=> 'Batch','readonly')) }}      

        </div>

         {{ $errors->first('Batch', '<div class="errorsetting">:message</div>') }}

        </li>	

		

<li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Entrance Date' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('EntranceDate', null, ['class' => 'datetimepicker1 EntranceDate']) }}        

        </div>

        {{ $errors->first('EntranceDate', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Exit Date' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('ExitDate', null, ['class' => 'datetimepicker1 ExitDate']) }}        

        </div>

        {{ $errors->first('ExitDate', '<div class="errorsetting">:message</div>') }}

        </li>		

		 <li>

         

        <li class="no-pad">

		<div class="panel-heading suppanelheading">

                <h4 class="panel-title">Student Personal Details</h4>

              </div>

		</li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'First Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('PersonalFirstName',null, array('id'=> 'PersonalFirstName')) }}

        </div>

         {{ $errors->first('PersonalFirstName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Middle Name' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('PersonalMiddleName',null, array('id'=> 'PersonalMiddleName')) }}

        </div>

         {{ $errors->first('PersonalMiddleName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Last Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('PersonalLastName',null, array('id'=> 'PersonalLastName')) }}

        </div>

         {{ $errors->first('PersonalLastName', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Age' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('Age', null, ['class' => 'Age']) }}

        </div>

         {{ $errors->first('Age', '<div class="errorsetting">:message</div>') }}

        </li>		

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Gender' ) }}<em>*</em>

        </div>

        <div class="input-control">              

	   {{ Form::select('Gender', $gender,null, array('id'=> 'PersonalMotherTongue'))}}		

        </div>

         {{ $errors->first('PersonalMotherTongue', '<div class="errorsetting">:message</div>') }}

        </li>

		<li>

        <div class="label-control">

        {{ Form::label('DateOfBirth', 'Date of Birth ' ) }}<em>*</em>

        </div>

        <div class="input-control">

        {{ Form::text('DateOfBirth', null, ['class' => 'dob DateOfBirth']) }}        

        </div>

        {{ $errors->first('DateOfBirth', '<div class="errorsetting">:message</div>') }}

        </li>

		

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Student Image' ) }}

        </div>

        <div class="input-control">       

       {{ Form::file('ContactUploadLogo') }}

	  <?php

		if(!empty($StudentAdmissioneditbyid[0]['ContactUploadLogo']))

		{

		?>

		  <div class="uploaad_btn_con">{{ HTML::image('assets/uploads/ContactUploadLogo/'.$StudentAdmissioneditbyid[0]['ContactUploadLogo'], 'a picture', array('class' => 'profilepic')) }} </div>

		<?php } ?>

        </div>

         {{ $errors->first('ContactUploadLogo', '<div class="errorsetting">:message</div>') }}

        </li>

          <li class="no-pad">

		<div class="panel-heading suppanelheading">

                <h4 class="panel-title">Note</h4>

              </div>

		</li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Note ' ) }}

        </div>

        <div class="input-control">       

       {{ Form::textarea('Note', null,['class' => 'Note','size' => '100x100']) }}

        </div>

         {{ $errors->first('Note', '<div class="errorsetting">:message</div>') }}
        </li>

        </ul>

        </div>

        

        <div class="col-three-two">

		<div class="panel-heading sidepanel">

                <h4 class="panel-title">Parent/Guardian Details</h4>

              </div>

        <ul class="dash-form-lister">

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Full Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GuardianFirstName',null, array('id'=> 'GuardianFirstName')) }}

        </div>

         {{ $errors->first('GuardianFirstName', '<div class="errorsetting">Full name is required</div>') }}

        </li>

		<li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'Middle Name' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('GuardianMiddleName',null, array('id'=> 'GuardianMiddleName')) }}

        </div>

         {{ $errors->first('GuardianMiddleName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'Last Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GuardianLastName',null, array('id'=> 'GuardianLastName')) }}

        </div>

         {{ $errors->first('GuardianLastName', '<div class="errorsetting">Last name is required</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactPhone',null, array('id'=> 'ContactPhone')) }}

        </div>

         {{ $errors->first('ContactPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactMobile',null, array('id'=> 'ContactMobile')) }}

        </div>

         {{ $errors->first('ContactMobile', '<div class="errorsetting">:message</div>') }}

        </li>
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Email' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GuardianMail',null, array('id'=> 'GuardianMail')) }}

        </div>

         {{ $errors->first('GuardianMail', '<div class="errorsetting">:message</div>') }}

        </li>
<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Language' ) }}<em>*</em>

        </div>

        <div class="input-control">

       {{ Form::select('StudentLanguage', $laguageDetails,null, array('id'=> 'StudentLanguage'))}}		

      

        </div>

         {{ $errors->first('StudentLanguage', '<div class="errorsetting">Language field is required</div>') }}

        </li>
		<li class="no-pad">

		<div class="panel-heading suppanelheading">

                <h4 class="panel-title">Emergency Contact Details</h4>

              </div>

		</li>
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Full Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactFirstName',null, array('id'=> 'ContactFirstName')) }}

        </div>

         {{ $errors->first('ContactFirstName', '<div class="errorsetting">Full name is required</div>') }}

        </li>

		<li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'Middle Name' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('ContactMiddleName',null, array('id'=> 'ContactMiddleName')) }}

        </div>

         {{ $errors->first('ContactMiddleName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'Last Name' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactLastName',null, array('id'=> 'ContactLastName')) }}

        </div>

         {{ $errors->first('ContactLastName', '<div class="errorsetting">Last name is required</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactpersonPhone',null, array('id'=> 'ContactpersonPhone')) }}

        </div>

         {{ $errors->first('ContactpersonPhone', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Mobile' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactpersonMobile',null, array('id'=> 'ContactpersonMobile')) }}

        </div>

         {{ $errors->first('ContactpersonMobile', '<div class="errorsetting">:message</div>') }}

        </li>
		<li class="no-pad">

		<div class="panel-heading suppanelheading">

                <h4 class="panel-title">Student  Contact Details</h4>

              </div>

		</li>

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Address' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('Address',null, array('id'=> 'Address')) }}

        </div>

         {{ $errors->first('Address', '<div class="errorsetting">:message</div>') }}

        </li>
<!--
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Apartment' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('Apartment',null, array('id'=> 'Apartment')) }}

        </div>

         {{ $errors->first('Apartment', '<div class="errorsetting">:message</div>') }}

        </li>

         <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Street' ) }}<em>*</em>

        </div>

        <div class="input-control">       

      

	   {{ Form::text('Street',null, array('class' => 'ContactPresentAddress')) }}

        </div>

         {{ $errors->first('Street', '<div class="errorsetting">:message</div>') }}

        </li>		

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'City' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactCity',null, array('id'=> 'ContactCity')) }}

        </div>

         {{ $errors->first('ContactCity', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'State' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('ContactState',null, array('id'=> 'ContactState')) }}

        </div>

         {{ $errors->first('ContactState', '<div class="errorsetting">:message</div>') }}

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'ZipCode' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('ContactPin',null, array('id'=> 'ContactPin')) }}
	   <input id="parentid" name="parentid" type="hidden" readonly="readonly">
        <input id="savemoredata" name="savemore" value="" type="hidden" readonly="readonly">
        </div>

         {{ $errors->first('ContactPin', '<div class="errorsetting">:message</div>') }}

        </li>
		-->
<li>
        <div class="label-control">
        {{ Form::label('r_no', 'Trip Type' ) }}<em>*</em>
        </div>
        <div class="input-control">  
       {{ Form::label('r_no', 'One way' ) }}		
       {{ Form::radio('TripType', 1, true, ['class' => 'Oneway TripType']) }}
	   {{ Form::label('r_no', 'Two way' ) }}		
       {{ Form::radio('TripType', 2, true, ['class' => 'Twoway TripType']) }}
        </div>
         {{ $errors->first('Triptype', '<div class="errorsetting">:message</div>') }}
        </li>
			<li class="unwant onewayoption">      
        <div class="input-control">  
       {{ Form::label('r_no', 'From School' ) }}		
       {{ Form::radio('fromTripType', 1, true, ['class' => 'fromschool']) }}
	   {{ Form::label('r_no', 'From Home' ) }}		
       {{ Form::radio('fromTripType', 2, true, ['class' => 'fromhome']) }}
        </div>
         {{ $errors->first('Triptype', '<div class="errorsetting">:message</div>') }}
        </li>		

      

        <li class="no-pad">

		<div class="panel-heading suppanelheading">

                <h4 class="panel-title">Students Time In And Time Out Of School </h4>

              </div>

		</li>

		<li class="">

		<div class="form_sep">

		{{ Form::label('Language', '(If need to set same time for some week days please select below option.)' ) }}

		</br>

		

		</div>

		</li>

		 <li class="">

        <div class="label-control" style="width: 175px;">

		 {{ Form::checkbox('timingoption', 1,null,  ['class' => 'timingoption']) }}

        {{ Form::label('r_no', 'Same time some week days' ) }}		

        </div>        

         {{ $errors->first('timingoption', '<div class="errorsetting">:message</div>') }}

        </li>	

		<li class="week">

        <div class="in-out-control in-out-control-lg">		

		{{ Form::label('r_no', 'Timing' ) }}

        <div class="right-timing">

		<div class="timing weeking">

		{{ Form::label('r_no', 'Weekdays from' ) }}

		 {{ Form::select('Weekdaysfrom', array(''=>'Weekdays from')+$weekdays,null, array('id'=> 'Weekdaysfrom','class' => 'Weekdaysfrom'))}}	

		  {{ $errors->first('Weekdaysfrom', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing weeking">

		{{ Form::label('r_no', 'Weekdays To' ) }}

		 {{ Form::select('Weekdaysto', array(''=>'Weekdays To')+$weekdays,null, array('id'=> 'Weekdaysto','class' => 'Weekdaysto'))}}	

		  {{ $errors->first('Weekdaysto', '<div class="errorsetting">:message</div>') }}

		 </div>

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('weekInTime', null, ['class' => 'datetimepicker2 weekInTime']) }}

		  {{ $errors->first('weekInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('weekoutTime', null, ['class' => 'datetimepicker2 weekoutTime']) }}

		  {{ $errors->first('weekoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

            </div>

        </div>

        </li>

       <li class="separate Monday">

        <div class="in-out-control">		

		{{ Form::label('r_no', 'Monday' ) }}

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('MondayInTime', null, ['class' => 'datetimepicker2 MondayInTime']) }}

		  {{ $errors->first('MondayInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('MondayoutTime', null, ['class' => 'datetimepicker2 MondayoutTime']) }}

		  {{ $errors->first('MondayoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

        </div>

        </li>	

        <li class="separate Tuesday">

        <div class="in-out-control">		

		{{ Form::label('r_no', 'Tuesday' ) }}

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('TuesdayInTime', null, ['class' => 'datetimepicker2 TuesdayInTime']) }}

		  {{ $errors->first('TuesdayInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('TuesdayoutTime', null, ['class' => 'datetimepicker2 TuesdayoutTime']) }}

		  {{ $errors->first('TuesdayoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

        </div>

        </li>	

         <li class="separate Wednesday">

        <div class="in-out-control">		

		{{ Form::label('r_no', 'Wednesday' ) }}

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('WednesdayInTime', null, ['class' => 'datetimepicker2 WednesdayInTime']) }}

		  {{ $errors->first('WednesdayInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('WednesdayoutTime', null, ['class' => 'datetimepicker2 WednesdayoutTime']) }}

		  {{ $errors->first('WednesdayoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

        </div>

        </li>

		<li class="separate Thursday">

        <div class="in-out-control">		

		{{ Form::label('r_no', 'Thursday' ) }}

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('ThursdayInTime', null, ['class' => 'datetimepicker2 ThursdayInTime']) }}

		  {{ $errors->first('ThursdayInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('ThursdayoutTime', null, ['class' => 'datetimepicker2 ThursdayoutTime']) }}

		  {{ $errors->first('ThursdayoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

        </div>

        </li>

		<li class="separate Friday">

        <div class="in-out-control">		

		{{ Form::label('r_no', 'Friday' ) }}

		<div class="timing">

		{{ Form::label('r_no', 'IN' ) }}

		 {{ Form::text('FridayInTime', null, ['class' => 'datetimepicker2 FridayInTime']) }}

		  {{ $errors->first('FridayInTime', '<div class="errorsetting">:message</div>') }}

		 </div>

		 <div class="timing">

		 {{ Form::label('r_no', 'OUT' ) }}

		 {{ Form::text('FridayoutTime', null, ['class' => 'datetimepicker2 FridayoutTime']) }}

		  {{ $errors->first('FridayoutTime', '<div class="errorsetting">:message</div>') }}

        	</div>	

        </div>      

      

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    
          <input class="submit-btn savemore" type="button" value="Save&More">   
        <input class="resetbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}



        </div>

		<script>
           $(".savemore").click(function(){		
		   $("#savemoredata").val("savemoredata");
            var action=$('#studentadmissionprocess').attr('action');
           // var newurl ="<?php echo url()."/studentadmissionmoreaddingprocess"; ?>";
		    //$('#studentadmissionprocess').attr('action', newurl);
			$('#studentadmissionprocess').submit();
			
		   });
		   $(document).ready(function(){
		   		if($('input[name=TripType]:checked').val()==1)
		{
$(".onewayoption").show();
}else {
$(".onewayoption").hide();

}
		   $(".TripType").change(function(){
var value = $(this).val();
if(value==1)
{
$(".onewayoption").show();
}else {
$(".onewayoption").hide();

}
});
});
		<?php 

		if(!empty($StudentAdmissioneditbyid))

		{

		?>

		$(document).ready(function(){
		
$("#parentid").val("<?php echo $StudentAdmissioneditbyid[0]['parentid']; ?>");
		$("#GuardianFirstName").val("<?php echo $StudentAdmissioneditbyid[0]['GuardianFirstName']; ?>");

		$("#GuardianMiddleName").val("<?php echo $StudentAdmissioneditbyid[0]['GuardianMiddleName']; ?>");

		$("#GuardianLastName").val("<?php echo $StudentAdmissioneditbyid[0]['GuardianLastName']; ?>");		
           $("#GuardianMail").val("<?php echo $StudentAdmissioneditbyid[0]['GuardianMail']; ?>");	
		// $(".ContactPresentAddress").val("<?php echo $StudentAdmissioneditbyid[0]['Street']; ?>");	

		// $("#ContactCity").val("<?php echo $StudentAdmissioneditbyid[0]['ContactCity']; ?>");

		// $("#ContactState").val("<?php echo $StudentAdmissioneditbyid[0]['ContactState']; ?>");

		// $("#ContactPin").val("<?php echo $StudentAdmissioneditbyid[0]['ContactPin']; ?>");

		// $("#ContactPhone").val("<?php echo $StudentAdmissioneditbyid[0]['ContactPhone']; ?>");

		// $("#ContactMobile").val("<?php echo $StudentAdmissioneditbyid[0]['ContactMobile']; ?>");
		

		$("#Address").val("<?php echo $StudentAdmissioneditbyid[0]['Address']; ?>");

		// $("#Apartment").val("<?php echo $StudentAdmissioneditbyid[0]['Apartment']; ?>");
		
		$("#ContactFirstName").val("<?php echo $StudentAdmissioneditbyid[0]['ContactFirstName']; ?>");

		$("#ContactMiddleName").val("<?php echo $StudentAdmissioneditbyid[0]['ContactMiddleName']; ?>");

		$("#ContactLastName").val("<?php echo $StudentAdmissioneditbyid[0]['ContactLastName']; ?>");
		
		$("#ContactpersonPhone").val("<?php echo $StudentAdmissioneditbyid[0]['ContactpersonPhone']; ?>");

		$("#ContactpersonMobile").val("<?php echo $StudentAdmissioneditbyid[0]['ContactpersonMobile']; ?>");
$("#StudentLanguage").val("<?php echo $StudentAdmissioneditbyid[0]['StudentLanguage']; ?>");
        $("#GuardianFirstName").attr('readonly', true);

		$("#GuardianMiddleName").attr('readonly', true);

		$("#GuardianLastName").attr('readonly', true);		

		$(".ContactPresentAddress").attr('readonly', true);

		$("#ContactCity").attr('readonly', true);

		$("#ContactState").attr('readonly', true);

		$("#ContactPin").attr('readonly', true);

		$("#ContactPhone").attr('readonly', true);

		$("#ContactMobile").attr('readonly', true);		

		$("#House").attr('readonly', true);
$("#GuardianMail").attr('readonly', true);
		$("#Apartment").attr('readonly', true);	
$("#StudentLanguage").attr('readonly', true);			
$("#ContactFirstName").attr('readonly', true);		

		$("#ContactMiddleName").attr('readonly', true);		

		$("#ContactLastName").attr('readonly', true);		
		
		$("#ContactpersonPhone").attr('readonly', true);		

		$("#ContactpersonMobile").attr('readonly', true);		
		$(".timingoption").change(function(){

		if($(this).is(':checked'))

		{

		$(".week").show();

		$(".separate").hide();

		$(".MondayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['MondayInTime']; ?>");

		$(".MondayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['MondayoutTime']; ?>");

		$(".TuesdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['TuesdayInTime']; ?>");

		$(".TuesdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['TuesdayoutTime']; ?>");

		$(".WednesdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['WednesdayInTime']; ?>");

		$(".WednesdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['WednesdayoutTime']; ?>");

		$(".ThursdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['ThursdayInTime']; ?>");

		$(".ThursdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['ThursdayoutTime']; ?>");

		$(".FridayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['FridayInTime']; ?>");

		$(".FridayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['FridayoutTime']; ?>");

		$("#Weekdaysfrom").val("<?php echo $StudentAdmissioneditbyid[0]['Weekdaysfrom']; ?>");

		$("#Weekdaysto").val("<?php echo $StudentAdmissioneditbyid[0]['Weekdaysto']; ?>");

		$(".weekInTime").val("<?php echo $StudentAdmissioneditbyid[0]['weekInTime']; ?>");

		$(".weekoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['weekoutTime']; ?>");

		$("#Weekdaysto").attr("disabled", "disable");

		var timingoption="<?php echo $StudentAdmissioneditbyid[0]['timingoption']; ?>";

		if(timingoption ==1)

             {		

		$(".Weekdaysto").removeAttr("disabled");

		var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    	

        var valuefrom =$(".Weekdaysfrom").val();        	

		for (var i = 0; i < weekday.length; i++) {

		$(".Weekdaysto option[value=" + weekday[i] + "]").show();

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}		

		}	

	

		for (var k = 0; k < fromkey; k++) {		

		$(".Weekdaysto option[value=" + weekday[k] + "]").hide();

		}		

		} else {

		$(".Weekdaysto").val("");

		$(".Weekdaysto").attr("disabled", "disable");

		}

		

		var valueto = $(".Weekdaysto").val();

		for (var i = 0; i < weekday.length; i++) {

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}

		}

		for (var j = 0; j < weekday.length; j++) {

		if(weekday[j]==valueto)

		{

		var tokey=j;

		}

		}

		for (var k = 0; k < fromkey; k++) {

		console.log(weekday[k]);

		$("."+weekday[k]).show();

		$("."+weekday[k]).val("");

		}

		var startkey=parseInt(tokey)+parseInt(1);

		for (var m = startkey; m < 5; m++) {

		console.log(weekday[m]);

		$("."+weekday[m]).show();

		$("."+weekday[m]).val("");

		}

		}

		 else {

		$(".week").hide();

		$(".separate").show();

		$(".MondayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['MondayInTime']; ?>");

		$(".MondayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['MondayoutTime']; ?>");

		$(".TuesdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['TuesdayInTime']; ?>");

		$(".TuesdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['TuesdayoutTime']; ?>");

		$(".WednesdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['WednesdayInTime']; ?>");

		$(".WednesdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['WednesdayoutTime']; ?>");

		$(".ThursdayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['ThursdayInTime']; ?>");

		$(".ThursdayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['ThursdayoutTime']; ?>");

		$(".FridayInTime").val("<?php echo $StudentAdmissioneditbyid[0]['FridayInTime']; ?>");

		$(".FridayoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['FridayoutTime']; ?>");

		$("#Weekdaysfrom").val("<?php echo $StudentAdmissioneditbyid[0]['Weekdaysfrom']; ?>");

		$("#Weekdaysto").val("<?php echo $StudentAdmissioneditbyid[0]['Weekdaysto']; ?>");

		$(".weekInTime").val("<?php echo $StudentAdmissioneditbyid[0]['weekInTime']; ?>");

		$(".weekoutTime").val("<?php echo $StudentAdmissioneditbyid[0]['weekoutTime']; ?>");

		

		$("#Weekdaysto").removeAttr("disabled");

		}

		

		});

		$(".Weekdaysfrom").change(function(){

		var value = $(this).val();

		var fromkey="";

		

        if(value !="")

             {		

			 $(".Weekdaysto").val("");

		$(".Weekdaysto").removeAttr("disabled");

		var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    	

        var valuefrom = $(".Weekdaysfrom").val(); 

		for (var i = 0; i < weekday.length; i++) {

		$(".Weekdaysto option[value=" + weekday[i] + "]").show();

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}		

		}		

		for (var k = 0; k < fromkey; k++) {		

		$(".Weekdaysto option[value=" + weekday[k] + "]").hide();

		}		

		} else {

		$(".Weekdaysto").val("");

		$(".Weekdaysto").attr("disabled", "disable");

		}

		

		});

		$(".Weekdaysto").change(function(){

		 var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

			

        var valuefrom = $(".Weekdaysfrom").val();        	

		var valueto = $(this).val();

		for (var i = 0; i < weekday.length; i++) {

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}

		}

		for (var j = 0; j < weekday.length; j++) {

		if(weekday[j]==valueto)

		{

		var tokey=j;

		}

		}

		for (var k = 0; k < fromkey; k++) {

		console.log(weekday[k]);

		$("."+weekday[k]).show();

		$("."+weekday[k]).val("00:00");

		}

		var startkey=parseInt(tokey)+parseInt(1);

		for (var m = startkey; m < 5; m++) {

		console.log(weekday[m]);

		$("."+weekday[m]).show();

		$("."+weekday[m]).val("00:00");

		}

		

		});});

		<?php } ?>

		$(document).ready(function(){

       <?php 

		if(empty($StudentAdmissioneditbyid))

		{

		?>

		 // $(".ContactPresentAddress").attr('readonly', true);

		 // $(".ContactPermanentAddress").attr('readonly', true);

		 // $("#ContactCity").attr('readonly', true);

		 // $("#ContactState").attr('readonly', true);

		 // $("#ContactPin").attr('readonly', true);

		// // $("#ContactCountry").attr('disabled', true);

		 // $("#ContactPhone").attr('readonly', true);

		 // $("#ContactMobile").attr('readonly', true);

	

		// $("#Guardian").attr('disabled', true);

		 // $(".GuardianPresentAddress").attr('readonly', true);

		// $(".GuardianPermanentAddress").attr('readonly', true);

		// $("#GuardianCity").attr('readonly', true);

		// $("#GuardiantState").attr('readonly', true);

		// $("#GuardianPin").attr('readonly', true);

		// //$("#GuardianCountry").attr('disabled', true);

		// $("#GuardianPhone").attr('readonly', true);

		// $("#GuardianMobile").attr('readonly', true);

		// $("#StartTime").attr('readonly', true);

		// $("#DropTime").attr('readonly', true);

		

		$(".Weekdaysfrom").change(function(){

		var value = $(this).val();

		var fromkey="";

        if(value !="")

             {		

			 $(".Weekdaysto").val("");

		$(".Weekdaysto").removeAttr("disabled");

		var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    	

        var valuefrom = $(".Weekdaysfrom").val(); 

		for (var i = 0; i < weekday.length; i++) {

		$(".Weekdaysto option[value=" + weekday[i] + "]").show();

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}		

		}		

		for (var k = 0; k < fromkey; k++) {		

		$(".Weekdaysto option[value=" + weekday[k] + "]").hide();

		}		

		} else {

		$(".Weekdaysto").val("");

		$(".Weekdaysto").attr("disabled", "disable");

		}

		});

		$(".Weekdaysto").change(function(){

		 var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

			

        var valuefrom = $(".Weekdaysfrom").val();        	

		var valueto = $(this).val();

		for (var i = 0; i < weekday.length; i++) {

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}

		}

		for (var j = 0; j < weekday.length; j++) {

		if(weekday[j]==valueto)

		{

		var tokey=j;

		}

		}

		for (var k = 0; k < fromkey; k++) {

		console.log(weekday[k]);

		$("."+weekday[k]).show();

		$("."+weekday[k]).val("");

		}

		var startkey=parseInt(tokey)+parseInt(1);

		for (var m = startkey; m < 5; m++) {

		console.log(weekday[m]);

		$("."+weekday[m]).show();

		$("."+weekday[m]).val("");

		}

		

		});

		$(".timingoption").change(function(){

		if($(this).is(':checked'))

		{

		$(".week").show();

		$(".separate").hide();

		$(".MondayInTime").val("00:00");

		$(".MondayoutTime").val("00:00");

		$(".TuesdayInTime").val("00:00");

		$(".TuesdayoutTime").val("00:00");

		$(".WednesdayInTime").val("00:00");

		$(".WednesdayoutTime").val("00:00");

		$(".ThursdayInTime").val("00:00");

		$(".ThursdayoutTime").val("00:00");

		$(".FridayInTime").val("00:00");

		$(".FridayoutTime").val("00:00");

		$(".Weekdaysfrom").val("00:00");

		$(".Weekdaysto").val("00:00");

		$("#Weekdaysto").attr("disabled", "disable");

		}

		 else {

		$(".week").hide();

		$(".separate").show();

		$(".MondayInTime").val("00:00");

		$(".MondayoutTime").val("00:00");

		$(".TuesdayInTime").val("00:00");

		$(".TuesdayoutTime").val("00:00");

		$(".WednesdayInTime").val("00:00");

		$(".WednesdayoutTime").val("00:00");

		$(".ThursdayInTime").val("00:00");

		$(".ThursdayoutTime").val("00:00");

		$(".FridayInTime").val("00:00");

		$(".FridayoutTime").val("00:00");

		$(".weekInTime").val("00:00");

		$(".weekoutTime").val("00:00");

		$("#Weekdaysto").removeAttr("disabled");

		$(".Weekdaysfrom").val("00:00");

		$(".Weekdaysto").val("00:00");

		}

		});

		<?php } ?>

		$(".pickupoption").change(function(){

		var value=$(this).val();

		if(value==1)

		{

		 $(".ContactPresentAddress").removeAttr('readonly');

		 $(".ContactPermanentAddress").removeAttr('readonly');

		 $("#ContactCity").removeAttr('readonly');

		 $("#ContactState").removeAttr('readonly');

		 $("#ContactPin").removeAttr('readonly');

		// $("#ContactCountry").removeAttr('disabled');

		 $("#ContactPhone").removeAttr('readonly');

		 $("#ContactMobile").removeAttr('readonly');

		 $("#StartTime").removeAttr('readonly');

		// $("#Guardian").removeAttr('disabled');

		$(".GuardianPresentAddress").val("none");

		$(".GuardianPermanentAddress").val("none");

		$("#GuardianCity").val("none");		

		$("#GuardiantState").val("none");

		$("#GuardianPin").val("none");		 

		$("#GuardianPhone").val("none");

		$("#GuardianMobile").val("none");

		$("#GuardianEmail").val("none");

		$("#DropTime").val("00:00");

		 $(".GuardianPresentAddress").attr('readonly', true);

		$(".GuardianPermanentAddress").attr('readonly', true);

		$("#GuardianCity").attr('readonly', true);

		$("#GuardiantState").attr('readonly', true);

		$("#GuardianPin").attr('readonly', true);

		//$("#GuardianCountry").attr('disabled', true);

		$("#GuardianPhone").attr('readonly', true);

		$("#GuardianMobile").attr('readonly', true);

		$("#DropTime").attr('readonly', true);

		$(".ContactPresentAddress").val("");

		$(".ContactPermanentAddress").val("");

		$("#ContactCity").val("");

		$("#ContactState").val("");

		$("#ContactPin").val("");

		$("#ContactPhone").val("");

		$("#ContactMobile").val("");	

		$("#StartTime").val("");

		}

		if(value==2)

		{

		$(".GuardianPresentAddress").removeAttr('readonly');

		$(".GuardianPermanentAddress").removeAttr('readonly');

		$("#GuardianCity").removeAttr('readonly');

		$("#GuardiantState").removeAttr('readonly');

		$("#GuardianPin").removeAttr('readonly');

		//$("#GuardianCountry").attr('disabled', true);

		$("#GuardianPhone").removeAttr('readonly');

		$("#GuardianMobile").removeAttr('readonly');

		$("#DropTime").removeAttr('readonly');

		// $("#Guardian").removeAttr('disabled');

		$(".ContactPresentAddress").val("none");

		$(".ContactPermanentAddress").val("none");

		$("#ContactCity").val("none");

		$("#ContactState").val("none");

		$("#ContactPin").val("none");

		$("#ContactPhone").val("none");

		$("#ContactMobile").val("none");

        $("#StartTime").val("00:00");		

		$(".ContactPresentAddress").attr('readonly', true);

		 $(".ContactPermanentAddress").attr('readonly', true);

		 $("#ContactCity").attr('readonly', true);

		 $("#ContactState").attr('readonly', true);

		 $("#ContactPin").attr('readonly', true);

		// $("#ContactCountry").attr('disabled', true);

		 $("#ContactPhone").attr('readonly', true);

		 $("#ContactMobile").attr('readonly', true);

		 $("#StartTime").attr('readonly', true);

		 $(".GuardianPresentAddress").val("");

		$(".GuardianPermanentAddress").val("");

		$("#GuardianCity").val("");		

		$("#GuardiantState").val("");

		$("#GuardianPin").val("");		 

		$("#GuardianPhone").val("");

		$("#GuardianMobile").val("");

		$("#GuardianEmail").val("");

		$("#DropTime").val("");

		}

		if(value==3)

		{

		$(".ContactPresentAddress").removeAttr('readonly');

		 $(".ContactPermanentAddress").removeAttr('readonly');

		 $("#ContactCity").removeAttr('readonly');

		 $("#ContactState").removeAttr('readonly');

		 $("#ContactPin").removeAttr('readonly');

		 //$("#ContactCountry").removeAttr('disabled');

		 $("#ContactPhone").removeAttr('readonly');

		 $("#ContactMobile").removeAttr('readonly');

		  $("#StartTime").removeAttr('readonly');

	$(".GuardianPresentAddress").removeAttr('readonly');

		 $("#DropTime").removeAttr('readonly');

		$("#GuardianCity").removeAttr('readonly');

		$("#GuardiantState").removeAttr('readonly');

		$("#GuardianPin").removeAttr('readonly');

		//$("#GuardianCountry").attr('disabled', true);

		$("#GuardianPhone").removeAttr('readonly');

		$("#GuardianMobile").removeAttr('readonly');

		 $("#Guardian").removeAttr('disabled');

		 $(".GuardianPresentAddress").val("");		

		$("#GuardianCity").val("");		

		$("#GuardiantState").val("");

		$("#GuardianPin").val("");		 

		$("#GuardianPhone").val("");

		$("#GuardianMobile").val("");

		$("#GuardianEmail").val("");

		$(".ContactPresentAddress").val("");

		$(".ContactPermanentAddress").val("");

		$("#ContactCity").val("");

		$("#ContactState").val("");

		$("#ContactPin").val("");

		$("#ContactPhone").val("");

		$("#ContactMobile").val("");

		$("#StartTime").val("");

		$("#DropTime").val("");

		}

		});

		});

		 $("#Guardian").change(function(){

		

		 //studentcontact

		var ContactPresentAddress=$(".ContactPresentAddress").val();

		var ContactPermanentAddress=$(".ContactPermanentAddress").val();

		var ContactCity=$("#ContactCity").val();

		var ContactState=$("#ContactState").val();

		var ContactPin=$("#ContactPin").val();

		var ContactCountry=$("#ContactCountry").val();

		var ContactPhone=$("#ContactPhone").val();

		var ContactMobile=$("#ContactMobile").val();

		var ContactEmail=$("#ContactEmail").val();



	

		if($(this).is(':checked'))

		{

		

		

		$(".GuardianPresentAddress").val(ContactPresentAddress);

		$(".GuardianPermanentAddress").val(ContactPermanentAddress);

		$("#GuardianCity").val(ContactCity);

		$("#GuardiantState").val(ContactState);

		$("#GuardianPin").val(ContactPin);

		$("#GuardianCountry").val(ContactCountry);

		$("#GuardianPhone").val(ContactPhone);

		$("#GuardianMobile").val(ContactMobile);

		$("#GuardianEmail").val(ContactEmail);

		

		} else {

		$(".GuardianPresentAddress").val("");

		$(".GuardianPermanentAddress").val("");

		$("#GuardianCity").val("");

		$("#GuardianState").val("");

		$("#GuardianPin").val("");

		$("#GuardianCountry").val("");

		$("#GuardianPhone").val("");

		$("#GuardianMobile").val("");

		$("#GuardianEmail").val("");

	

		}

			});

			

		</script>

		<?php 

		if(empty($StudentAdmissioneditbyid))

		{

		?>

		<script>

        $("document").ready(function(){

            $("#SchoolName").change(function(e){

		

                e.preventDefault();

                var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });
$.ajax({

                    type: "POST",

                    url : "searchschoolgradeprocess",

                    data : dataString,

                    success : function(data){
					$("#StudentCourse").html();
					$(".gradeselectbox").html(data);
					console.log(data);
                    }

                });


        });

        });

		 $("document").ready(function(){

		 var SchoolName = $("#SchoolName").val();

            if(SchoolName !="")

			{

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });
$.ajax({

                    type: "POST",

                    url : "searchschoolgradeprocess",

                    data : dataString,

                    success : function(data){
					$("#StudentCourse").html();
					$(".gradeselectbox").html(data);
					console.log(data);
                    }

                });
				}

		     });

		

		//end of document ready function

    </script>

	<?php } else { ?>

		<script>

        $("document").ready(function(){

            $("#SchoolName").change(function(e){

		

                e.preventDefault();

                var SchoolName = $("#SchoolName").val();

            

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "../searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });

$.ajax({

                    type: "POST",

                    url : "../searchschoolgradeprocess",

                    data : dataString,

                    success : function(data){
					$("#StudentCourse").html();
					$(".gradeselectbox").html(data);
					console.log(data);
                    }

                });

        });

        });

		 $("document").ready(function(){

		 var SchoolName = $("#SchoolName").val();

           if(SchoolName!="")

		   {

                var dataString = 'SchoolName='+SchoolName; 

                $.ajax({

                    type: "POST",

                    url : "../searchschoolprocess",

                    data : dataString,

                    success : function(data){

					$(".SchoolAddress").val(data);

                       

                    }

                });
$.ajax({

                    type: "POST",

                    url : "../searchschoolgradeprocess",

                    data : dataString,

                    success : function(data){
					$("#StudentCourse").html();
					$(".gradeselectbox").html(data);
					console.log(data);
                    }

                });
				}

		     });

		

		//end of document ready function

    </script>

	<?php } 

	

	 

	?>

        </div>

        <!-- dash content row end --> 

        </div>

       

		 

		<?php 

		if(empty($StudentAdmissioneditbyid))

		{

		?>

		<script>

$(document).ready(function(){

if ($(".timingoption").is(':checked')){

 $(".week").show();

$(".separate").hide();

var value = $(".Weekdaysfrom").val();

		var fromkey="";

        if(value !="")

             {		

			 $(".Weekdaysto").val("");

		$(".Weekdaysto").removeAttr("disabled");

		var weekday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    	

        var valuefrom = $(".Weekdaysfrom").val(); 

		for (var i = 0; i < weekday.length; i++) {

		$(".Weekdaysto option[value=" + weekday[i] + "]").show();

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}		

		}		

		for (var k = 0; k < fromkey; k++) {		

		$(".Weekdaysto option[value=" + weekday[k] + "]").hide();

		}		

		} else {

		$(".Weekdaysto").val("");

		$(".Weekdaysto").attr("disabled", "disable");

		}

		

			

        var valuefrom = $(".Weekdaysfrom").val();        	

		var valueto = $(".Weekdaysto").val();

		for (var i = 0; i < weekday.length; i++) {

		$("."+weekday[i]).hide();

		$("."+weekday[i]).val("00:00");

		if(weekday[i]==valuefrom)

		{

		var fromkey=i;

		}

		}

		for (var j = 0; j < weekday.length; j++) {

		if(weekday[j]==valueto)

		{

		var tokey=j;

		}

		}

		for (var k = 0; k < fromkey; k++) {

		console.log(weekday[k]);

		$("."+weekday[k]).show();

		$("."+weekday[k]).val("");

		}

		var startkey=parseInt(tokey)+parseInt(1);

		for (var m = startkey; m < 5; m++) {

		console.log(weekday[m]);

		$("."+weekday[m]).show();

		$("."+weekday[m]).val("");

		}

		

}

});

</script>

<?php } ?>

<script type="text/javascript">

		$(document).ready(function() {

		

			$('.fancybox').fancybox();

			$(".fancybox-effects-a").fancybox({

			

				helpers: {

					title : {

						type : 'outside'

					},

					overlay : {

						speedOut : 0

					}

				}

			});

			});



		

	</script>

	 {{ Form::open(array('url' => 'studentdeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="studentdeletelist" value="" class="studentdeletelist"/>



</form>

	<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}





		</script>



<script>

$(".resetbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".studentdeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenNormalDialogbox();

}

});

</script>

 @stop