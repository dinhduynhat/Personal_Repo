@extends('layouts.dashboardlayout')
@section('body')

        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Transport</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Add Route</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'routeupdateprocess/'.$RouteDetailsbyid[0]['AutoID'])) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('r_no', 'Route Name ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('RouteName',null, array('id'=> 'RouteName')) }}
        </div>
        {{ $errors->first('RouteName', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('n_stops', 'No. of Stops ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('NumberStops',null, array('id'=> 'NumberStops')) }}
        </div>
        {{ $errors->first('NumberStops', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('rv_code', 'Vehicle Code ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::select('VehicleCode', array(''=>'Select Vehiclecode')+$VehicleDetails, null, array('id' => 'VehicleCode'))}}
        </div>
        {{ $errors->first('VehicleCode', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('n_stops', 'Route Description ' ) }}
        </div>
        <div class="input-control">
        {{ Form::text('RouteDescription',null, array('id'=> 'RouteDescription')) }}
        </div>
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
		 <script>
$(document).ready(function(){
$("#RouteName").val("<?php echo $RouteDetailsbyid[0]['RouteName']?>");
$("#NumberStops").val("<?php echo $RouteDetailsbyid[0]['NumberStops']?>");
$("#VehicleCode").val("<?php echo $RouteDetailsbyid[0]['VehicleCode']?>");
$("#RouteDescription").val("<?php echo $RouteDetailsbyid[0]['RouteDescription']?>");
$('#student-listing-table').dataTable();
});
</script>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Route List</h5>
        </div>
        
        
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Route</th>
        <th>No. of Stops</th>
        <th>Vehicle Code</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
		<?php
		
		foreach ($RouteDetails as $Routevalue)
{
		?>
        <tr>
        <td><span class="tab-check"></span><?php echo $Routevalue['RouteName'];?></td>
        <td><?php echo $Routevalue['NumberStops'];?></td>
        <td><?php echo $Routevalue['VehicleCode'];?></td>
        <td>       
        <a href="<?php echo url();?>/routeedit/<?php echo $Routevalue['AutoID'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>
       		<a href="javascript:;" id="<?php echo url();?>/routedelete/<?php echo $Routevalue['AutoID'];?>" class="btnOpenDialog"><button class="delete-btn btn-sm"><span class="icon"></span></button></a></td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
        </div>
  @stop