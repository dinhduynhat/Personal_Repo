@extends('layouts.dashboardlayout')
@section('body')
        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Settings Master</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Upload CSV File</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'classprocess')) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('ClassName', 'Class Name ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('ClassName') }}
        </div>
        {{ $errors->first('ClassName', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('ClassSection', 'Section Name ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('ClassSection') }}
        </div>
        {{ $errors->first('ClassSection', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('ClassCode', 'Code ' ) }}<em>*</em>
        </div>
        <div class="input-control">
        {{ Form::text('ClassCode') }}
        </div>
        {{ $errors->first('ClassCode', '<div class="error">:message</div>') }}
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    
        {{ Form::reset('Cancel', ['class' => 'resetbutton']) }}
        </div>
        {{ Form::close() }}
        </div>
        <div class="panel-row list-row">
        <div class="dash-content-head tabContaier">
        <h5>Route List</h5>
        </div>
        <div class="search-show-panel">
        <div class="col-left">
        <table>
        <tr>
        <td><label for="username">Search</label></td>
        <td><input type="text" id="username" name="username"/></td>
        </tr>
        </table>
        </div>
        <div class="col-right">
        <table class="show-listing-table">
        <tr>
        <td><label>Show</label></td>
        <td><select>
        <option value="10">10</option>
        <option value="20">20</option>
        </select></td>
        <td><label>entries</label></td>
        <td><button class="btn-dl delete-btn"><span>Delete</span></button></td>
        </tr>
        </table>
        </div>
        </div>
        
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>
        <table class="student-listing-table" id="student-listing-table">
        <thead>
        <tr>
        <th>Route</th>
        <th>No. of Stops</th>
        <th>Vehicle Code</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <tr>
        <td><span class="tab-check"><input type="checkbox" /></span>007 Route</td>
        <td>7</td>
        <td>007</td>
        <td>
        <button class="view-btn btn-sm"><span class="icon"></span></button>
        <button class="edtit-btn btn-sm"><span class="icon"></span></button>
        <button class="delete-btn btn-sm"><span class="icon"></span></button></td>
        </tr>
        <tr>
        <td><span class="tab-check"><input type="checkbox" /></span>007 Route</td>
        <td>7</td>
        <td>007</td>
        <td>
        <button class="view-btn btn-sm"><span class="icon"></span></button>
        <button class="edtit-btn btn-sm"><span class="icon"></span></button>
        <button class="delete-btn btn-sm"><span class="icon"></span></button></td>
        </tr>
        <tr>
        <td><span class="tab-check"><input type="checkbox" /></span>007 Route</td>
        <td>7</td>
        <td>007</td>
        <td>
        <button class="view-btn btn-sm"><span class="icon"></span></button>
        <button class="edtit-btn btn-sm"><span class="icon"></span></button>
        <button class="delete-btn btn-sm"><span class="icon"></span></button></td>
        </tr>
        <tr>
        <td><span class="tab-check"><input type="checkbox" /></span>007 Route</td>
        <td>7</td>
        <td>007</td>
        <td>
        <button class="view-btn btn-sm"><span class="icon"></span></button>
        <button class="edtit-btn btn-sm"><span class="icon"></span></button>
        <button class="delete-btn btn-sm"><span class="icon"></span></button></td>
        </tr>
        <tr>
        <td><span class="tab-check"><input type="checkbox" /></span>007 Route</td>
        <td>7</td>
        <td>007</td>
        <td>
        <button class="view-btn btn-sm"><span class="icon"></span></button>
        <button class="edtit-btn btn-sm"><span class="icon"></span></button>
        <button class="delete-btn btn-sm"><span class="icon"></span></button></td>
        </tr>
        </tbody>
        </table>
        </div>
@stop