@extends('layouts.dashboardlayoutwithoutdetails')
@section('body')
        <div class="form-panel">
        <div class="header-panel">
        <h2><!--<span class="icon icon-student"></span>-->Create username</h2>
        </div>
        <div class="dash-content-panel"> <!-- dash panel start -->
        
        <div class="dash-content-row "> <!-- dash content row start -->
        <div class="dash-content-head tabContaier">
        <h5>Add Users</h5>
        @if(Session::has('Message'))
        <p class="alert">{{ Session::get('Message') }}</p>
        @endif
        {{ Form::open(array('url' => 'createuserprocess')) }}
        </div>
        <div class="tabDetails">         
        <div class="panel-row">
        <ul class="dash-form-lister">
        <li>
        <div class="label-control">
        {{ Form::label('UserName', 'UserName ' ) }}
        </div>
        <div class="input-control">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        {{ Form::text('UserName') }}
        </div>
        {{ $errors->first('UserName', '<div class="error">:message</div>') }}
        </li>
        <li>
        <div class="label-control">
        {{ Form::label('Password', 'password ' ) }}
        </div>
        <div class="input-control">
        {{ Form::text('password') }}
        </div>
        {{ $errors->first('password', '<div class="error">:message</div>') }}
        </li>
        </ul>
        <div class="btn-group form-list-btn-group" >
        <input type="submit" class="submit-btn" name="submit-pro" value="Save"/>
        <button class="btn-sb sav_con_btn"><span>Save & Continue</span></button>
        <button class="btn-sb cance_btn"><span>Cancel</span></button>
        </div>
        {{ Form::close() }}
        </div>
        </div>
        </div>
        <!-- dash content row end --> 
        </div>
        </div>
@stop