<!-- @extends('layouts.loginlayout') -->

@section('body')
<style>
	body{
		background:none;
	}
</style>
<?php
                    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $getpath=explode("/",$actual_link);
            
            end($getpath);
    $forgoturl = prev($getpath);
    
    Session::put('forgoturl', $forgoturl);

    

                    ?>
<div class="main-content-container home-main-container login-container">              <!------------------ main content container start ------------>

          <div class="login-tot-container">   <!-------- login panel start ---------------->
					<section class="logomti">
					<a href="#">{{ HTML::image('assets/images/logo.png', 'Malden Taxi and Malden Trans Inc Logo', array('class' => '')) }}</a>
						<!-- <img src="images/logo.png" width="206" height="57" border="0" /> -->
					</section>
               <div class="login-panel">

                     <h1>Login</h1>

                    {{ Form::open(array('url' => $forgoturl.'/forgotpasswordprocess', 'files'=> true, 'id' => 'process')) }}

					@if(Session::has('Message'))
<p class="alert new-al-er">{{ Session::get('Message') }}</p>
@endif

<?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$getpath=explode("/",$actual_link);						  
$count = count($getpath);

$count = count($getpath);
$url = $getpath[$count-2];

#$url = end($getpath);
#print $test[$count-2];
?>

<ul>

                         <li>

                       <!--   <div class="profile-icon">{{ HTML::image('assets/images/profile-icon-log.png', 'Profile picture', array('class' => '')) }}</div> -->

                         </li>

						

                         <li><!-- <span class="icon username-icon"></span> --><input type="text" name="UserName" placeholder="Email" /></li>

                         
						 <?php
					  $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
						$getpath=explode("/",$actual_link);
						
						 ?>
						 
						 <input type="hidden"  name="urlpath" value='<?php echo end($getpath); ?>'/>

                        

                         <li class="submit">						 
							 <!-- <p href="{{ URL::to(end($getpath).'/forgot/'); }}" class="forgot_btn gen_btn">Forgot password<a href="index.html">Click here to reset it</a></p> -->
							 
							    

                             <input type="submit" value="Submit" />

                         </li>

						 <div class="login-panel-help">						 
						 
							 <a href="{{ URL::to($url); }}" class="forgot_btn gen_btn">Back to Login ? Click here</a>
							 
							 
							 
							 
							 
							 
						</div>

                          

                     </ul>

                    </form>

                    @if(Session::has('Message'))

                          <p class="alert new-al-er">{{ Session::get('Message') }}</p>

                          @endif

               </div>

                

               <div class="shodow_box">

               </div>

          </div>                             <!-------- login panel close ---------------->

    </div>                                            <!------------------ main content container close ------------>

</div>



@stop