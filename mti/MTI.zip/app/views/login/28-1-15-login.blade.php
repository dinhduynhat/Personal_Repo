@extends('layouts.loginlayout')
@section('body')
<div class="main-content-container home-main-container">              <!------------------ main content container start ------------>
          <div class="login-tot-container">   <!-------- login panel start ---------------->
               <div class="login-panel">
                    <div class="log-head-panel">
                       <h3>Login</h3>
                    </div>
                    {{ Form::open(array('url' => 'login', 'files'=> true, 'id' => 'process')) }}
                     <ul>
                         <li>
                         <div class="profile-icon">{{ HTML::image('assets/images/profile-icon-log.png', 'Profile picture', array('class' => '')) }}</div>
                         </li>
						
                         <li><span class="icon username-icon"></span><input type="text" name="UserName" placeholder="Username" /></li>
                         <li><span class="icon password-icon"></span><input type="password"  name="password" placeholder="Password" /></li>
                         @if(Session::has('Message'))
                          <p class="alert">{{ Session::get('Message') }}</p>
                          @endif
                         <li>
                             <a href="{{ URL::to('forgot'); }}" class="forgot_btn gen_btn">Forgot password</a>
                             <input type="submit" value="Submit" />
                         </li>
                          
                     </ul>
                    </form>
               </div>
               <div class="shodow_box">
               </div>
          </div>                             <!-------- login panel close ---------------->
    </div>                                            <!------------------ main content container close ------------>
</div>

@stop