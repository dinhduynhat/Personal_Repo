@extends('layouts.loginlayout')
@section('body')
<style>
.login-panel{
height: 272px;
}
</style>
<div class="main-content-container home-main-container">              <!------------------ main content container start ------------>
          <div class="login-tot-container">   <!-------- login panel start ---------------->
               <div class="login-panel">
                    <div class="log-head-panel">
                       <h3>Forgot password</h3>
                    </div>
                    <?php
                    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $getpath=explode("/",$actual_link);
            
            end($getpath);
    $forgoturl = prev($getpath);
    
    Session::put('forgoturl', $forgoturl);

    

                    ?>
					{{ Form::open(array('url' => $forgoturl.'/forgotpasswordprocess', 'files'=> true, 'id' => 'process')) }}
                    
@if(Session::has('Message'))
<p class="alert new-al-er">{{ Session::get('Message') }}</p>
@endif

                     <ul>
                         <li>
                         <div class="profile-icon">{{ HTML::image('assets/images/profile-icon-log.png', 'Profile picture', array('class' => '')) }}</div>
                         </li>
                         <li><span class="icon username-icon"></span><input type="text" name="UserName" placeholder="Email" /></li>
<?php
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$getpath=explode("/",$actual_link);						  
$count = count($getpath);

$count = count($getpath);
$url = $getpath[$count-2];

#$url = end($getpath);
#print $test[$count-2];
?>
                         <li>
                             <a href="{{ URL::to($url); }}" class="forgot_btn gen_btn">Back to Login</a>
                             <input type="submit" value="Send Recovery Email" name="driver"/>
                         </li>

                     </ul>
                    </form>
                    @if(Session::has('Message'))
                          <p class="alert new-al-er">{{ Session::get('Message') }}</p>
                          @endif
               </div>
               <div class="shodow_box">
               </div>
          </div>                             <!-------- login panel close ---------------->
    </div>                                            <!------------------ main content container close ------------>
</div>

@stop