@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">
<?php if(Auth::user()->usertype ==3) { $URL = Session::get('urlpath'); ?>
		<?php $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/exportbusattendence'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/feepayment'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		<a href="{{ URL::to($URL.'/listfeepayment'); }}" class="fa fa-list-alt customfontawesome" title='Payments List'></a>
		</span>
		<?php } ?>
          <h2><!--<span class="icon icon-profile">--></span>Edit Fee Payment</h2>

        </div>

        <div class="dash-content-panel" style="padding:0;"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head" style="margin-left:15px; padding-top:10px;">

              <h5 class="heading-title">Edit Fee Payment</h5>

             </div>

            <div class="panel-row" style="margin-left:15px;">

       @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              <ul class="dash-form-lister">

       

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School' ) }}

        </div>

        <div class="input-control">              

     {{ Form::select('schoolid', array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'schoolid'))}}    

        </div>

         {{ $errors->first('schoolid', '<div class="errorsetting">:message</div>') }}

        </li>

    

     


<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Select Month and Year' ) }}

        </div>

        <div class="input-control">  

    <select style='width: 112px;' name='PayMonth'>
  <option name="PayMonth" value=''>Select Month</option>   
<?php

for($i = 1 ; $i <= 12; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
    <option value="<?php 
    echo $i; 
    
    ?>" 
    >
    <?php
    echo date("F",mktime(0,0,0,$i,1,date("Y")));
    //Close tag inside loop
    ?>
    </option>
    <?php
}?>

</select>    
<select name="PayYear" style='width: 112px;'>
 <option name="PayYear" value=''>Select Year </option>   
<?php 

$year = date('Y');
$nextyear = date('Y')-1;


for($i=$nextyear; $i<=$year; $i++)
{

    echo "<option value=".$i.">".$i."</option>";
}
?> 
    
</select> 
        </div>

         {{ $errors->first('Triptype', '<div class="errorsetting">:message</div>') }}

        </li>   

              </ul>

           

        {{ Form::close() }}

           <div class="btn-group form-list-btn-group">

                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>
            <div class="firsttab">
        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>
		
        <div class="panel-tab-row"> <!---------------- student listing table start ------>
		<div class="dash-content-head tabContaier" style="background: transparent linear-gradient(to bottom, #ACC8D4 0%, #668796 2%, #598391 4%, #5B8595 6%, #5B8093 8%, #5F8296 10%, #5B8696 15%, #5F8598 17%, #6B95A5 38%, #709BAB 52%, #6994A4 54%, #6694A3 56%, #6896A5 58%, #6694A3 60%, #6A98A8 77%, rgb(107, 153, 169) 100%) repeat scroll 0% 0%;">
		<h5>Fee Payment List</h5>
		</div>
        <table class="example tab" id="example">

      <tfoot class="tabl tab-abs"><tr>
<th style="display:none"></th>
<th style="display:none"></th>       



        <th style="display:none"></th>

        <th style="display:none"></th>

        <th style="display:none"></th>

        

      

        </tr></tfoot> 

        <thead>

    

        <tr>

   <th style="display:none"></th>

        <th>Status</th>
    
        <th>School Name</th>
    
        <th>Amount</th>

        <th>Month & Year</th>    
        <th>Payment Created</th>
        <th>Payment Raised</th>    
<?php
        if(Auth::user()->usertype=='1' || Auth::user()->usertype=='4' || Auth::user()->usertype=='2')
    {
        $check ='style="display:none"';
    }
    else
    {
        $check = '';
    }
     
     ?>   
        
         <th style="display:none">Status</th>     
 
        <th <?php echo $check ?>>Action</th>

        </tr>

        </thead>

        <tbody>

    <?php

    

    foreach ($GeneralSettingDetails as $GeneralSettingDetailsvalue)

{
$date = $GeneralSettingDetailsvalue['PaidDate'];
$date1 = $GeneralSettingDetailsvalue['created_at'];
$m = date("M", mktime(0, 0, 0, $GeneralSettingDetailsvalue['PayMonth'], 10));
#$m = $GeneralSettingDetailsvalue['PayMonth'];

$y = $GeneralSettingDetailsvalue['PayYear'];
$date = date("m-d-Y", strtotime($date));
$date1 = date("m-d-Y", strtotime($date1));
if ($GeneralSettingDetailsvalue['Paid']=='1') 
{
  $Status = 'Paid';
}
elseif ($GeneralSettingDetailsvalue['Paid']=='2') 
{
$Status = 'Accepted';  
}
elseif ($GeneralSettingDetailsvalue['Paid']=='0') 
{
$Status = 'Rejected';  
}
else
{
$Status = '-';
}
$SchoolName = GeneralSettingModel::where('id', '=', $GeneralSettingDetailsvalue['SchoolName'])->pluck('SchoolName');

    ?>

        <tr>

    
         <td style="display:none"></td>
         <td><?php echo $Status;?></td>
        <td><?php echo $SchoolName;?></td>
        <td><?php echo $GeneralSettingDetailsvalue['Amount'];?></td>
        <td><?php echo $m.', '.$y;?></td>
        <td><?php echo $date1;?></td>
        <td><?php echo $date;?></td>
    

       
         
    <td style="display:none"><?php echo $GeneralSettingDetailsvalue['Amount'];?></td>

        <td <?php echo $check ?>>       

        <a href="<?php echo url().'/'.Session::get('urlpath');?>/updatepayment/<?php echo $GeneralSettingDetailsvalue['id'];?>"><button class="edtit-btn btn-sm"><span class="icon"></span></button></a>

</td>

        </tr>

        <?php } ?>

        </tbody>



        </table>

        </div>
		
</div>

      <div class="result"></div>

      

          </div>



          <!-- dash content row end --> 

    

      <script>

      

  $(function() {

    var availableTags = [

  <?php foreach($studentname as $studentnamevalue) { 

echo '"'.$studentnamevalue.'"'.','; 

  ?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

      <script>

  $(function() {

    var availableTags = [

  <?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';  

  ?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

    if(Auth::user()->usertype==1)

    {

    ?>

    <script>

        $("document").ready(function(){

            

        });

    

    //end of document ready function

    </script>

  

    <?php 

    

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

} else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}  





    }  ?>

    <script>

        $("document").ready(function(){

            $(".submit-btn").click(function(e){

    

                e.preventDefault();

              

                var dataString = $("form").serialize(); 


                $.ajax({

                    type: "POST",

                    url : "editpaymentlisting",

                    data : dataString,

                    success : function(data){
                      console.log(data);
          $(".firsttab").html("");            
          $(".result").html(data);

                    }

                });



        });

        });

    

    

    </script>

        </div>

        <!--dash content row end --> 

    

      </div>

    

@stop