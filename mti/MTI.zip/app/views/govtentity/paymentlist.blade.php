@extends('layouts.dashboardlayout')

@section('body')
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}


<script>

$(document).ready(function(){


$('input[type="checkbox"]').on('change', function() {
    $('input[name="' + this.name + '"]').not(this).prop('checked', false);
});



});

</script>





<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid=='')
		{
		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		
		<a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/paymentlist'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		<a href="{{ URL::to($URL.'/listfeepaymentge'); }}" class="fa fa-list-alt customfontawesome" title='Payments History'></a>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-info customfontawesome" title='Export Student Details'></a>
		
		</span>
		<?php
		}
		?>
		
		<?php
		if(Auth::user()->usertype ==4 && Auth::user()->subuserid!='')
		{
		$MenuAccess = StaffModel::where('id', Auth::user()->subuserid)->select(
	'SchoolListing','StudentListing','ProfileEditApproval','AddTariffType','AddVehicleType', 'AddVehicle',
	'AddDriver','AddTiming','BusAllocation','Pickup','TrackStudent', 'AttendanceReport',
	'Payments','PaymentsHistory','Export','AddStaff','ManageParent', 'ManageSchool', 'ManageDriver'


)->get()->first();


		?>
		<span style='float:right;    margin-top: 0px'>
		<?php $URL = Session::get('urlpath'); ?>
		<?php
if($MenuAccess['AttendanceReport']==1)
{
?>		
		
		<a href="{{ URL::to($URL.'/exportbusattendencegovt'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		
		<?php
}
if($MenuAccess['Payments']==1)
{
?>
		<a href="{{ URL::to($URL.'/paymentlist'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		
		<?php
}
if($MenuAccess['PaymentsHistory']==1)
{
?>
		<a href="{{ URL::to($URL.'/listfeepaymentge'); }}" class="fa fa-list-alt customfontawesome" title='Payments History'></a>
		
		<?php
}
if($MenuAccess['Export']==1)
{
?>
		<a href="{{ URL::to($URL.'/studentexportbyschoolprocesslayout'); }}" class="fa fa-info customfontawesome" title='Export Student Details'></a>
		
		<?php
}

?>
		

		</span>
		<?php
		}
		?>

          <h2><!--<span class="icon icon-profile">--></span>Manage Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Bus Company - Payment list screen</h5>

             </div>
{{ HTML::script('assets/js/jquery.cookie.js') }}
<script>
$("document").ready(function(){
//console.debug($.cookie("pay")); 
var Set; // declared local to the whole onready function
Set = $.cookie('pay');

if(Set == 1) 
{
console.log('yes');
$("#aftersuccess").show();
$.removeCookie("pay");
}

//$.cookie("pay", "1"); // Sample 1
//console.log($.cookie("example"));
});    
</script>         
<?php
#Session::put('pay', '0');
#Session::forget('payment');
#Session::put('pay', '1');
//echo Session::get('payment');

// if ('1'=='1') 
// {
  ?>
<div id="aftersuccess" class="alert" style="display:none"> Payment accepted succesfully</div>  
  <?php
#}
#Session::put('pay', '0');
#Session::forget('payment');
?>
<div id="aftersuccess"></div>
            <div class="panel-row" style="padding:0 !important;">





 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif
                
                 <div class="tabContaier_tab">
                     <div class="tab_changer">
                        <ul>
                            <li><a href="#tab1" class="active">Current Payments</a></li>
                            <li><a href="#tab2">Outstanding Payment</a></li>
                        </ul>
                     </div>
                     <div class="tabcontent-container" style="padding:0;">
                         <div class="tabContents" id="tab1">
                          <form name='form1' class='form1' id='forma'>
                          <script>
$(document).ready(function(){

$("#student-listing-table").dataTable();
$("#student-listing-table-tab").dataTable();
});
</script>

                              <table class="tab-payment" id="student-listing-table">

                                  <thead>
                                      <tr>
                                          <th style="background:#39a2d2 !important;">School Name</th>
                                          <th>Month & Year</th>
                                          <th>Cheque Number</th>
                                          <th>Payment Amount</th>
                                          <th>Date of payment Created</th>
                                          <th>Date of payment Raised</th>
                                          
                                          <th>Payment Received</th>

                                          </th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php

                                    $CurrentDate = date("Y-m-d");
                                    $TargetDate =  date('Y-m-d', strtotime($CurrentDate. ' + 5 days'));
                                    
                                    $CurrentPayment = FeeModel::where('Paid', '1')->whereBetween('created_at',  array($CurrentDate, $TargetDate))->get();
                                    $OutStandingPayment = FeeModel::where('Paid', '1')->where('created_at', '<', $CurrentDate)->get();
                                    $AdvancePayment = FeeModel::where('Paid', '1')->where('created_at', '>', $TargetDate)->get();
                                      foreach ($CurrentPayment as $PaymentsData)
                                    {
                                      $SchoolName = GeneralSettingModel::where('id', $PaymentsData->SchoolName)->pluck('SchoolName');
                                        $monthNum  = $PaymentsData->PayMonth;
                                        $dateObj   = DateTime::createFromFormat('!m', $monthNum);
                                        $Month = $dateObj->format('M').' - '.$PaymentsData->PayYear;

                                        $newDate = date("d-M-y", strtotime($PaymentsData->PaidDate));
                                        $newDateRaised = date("d-M-y", strtotime($PaymentsData->created_at));
                                    ?>

                                      <tr>
                                         <td>{{  $SchoolName }}</td>
                                         <td>{{ $Month }}</td>
                                         <td>{{ $PaymentsData->Cheque }}</td>
                                         <td>{{ $PaymentsData->Amount }}</td>

                                         
                                         <td>{{ $newDateRaised }}</td>
                                         <td>{{ $newDate }}</td>
                                         <td class="t-align"><input type="checkbox" name='PaymentId' value='{{ $PaymentsData->id }}'/></td>
                                      </tr>
                                      <?php
                                      }
                                      ?>
                                  </tbody>
                              </table>
                                <p align='right'>          
                                  <div id="CheckErrora" style="display:none;color:red">Please choose atleast one Payment</div>
                              <div class="newcenbtn"><input class="submit-btn" id="fire1" type="submit" value="Save"></div>
                              
                              
                            </p>
                          </form>
                         </div>
                         <div class="tabContents" id="tab2">
                          <form name='form1' class='form1' id='formb'>
                              <table class="tab-payment" id="student-listing-table-tab">
                                  <thead>
                                      <tr>
                                          <th style="background:#39a2d2 !important;">School Name</th>
                                          <th>Month & Year</th>
                                          <th>Cheque Number</th>
                                          <th>Payment Amount</th>
                                          <th>Date of Payment Created</th>
                                          <th>Date of Payment Raised</th>

                                          <th>Payment Received</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php
                                         foreach ($OutStandingPayment as $PaymentsData)
                                    {
                                      $SchoolName = GeneralSettingModel::where('id', $PaymentsData->SchoolName)->pluck('SchoolName');
                                        $monthNum  = $PaymentsData->PayMonth;
                                        $dateObj   = DateTime::createFromFormat('!m', $monthNum);
                                        $Month = $dateObj->format('M').' - '.$PaymentsData->PayYear;
                                        $newDate = date("d-M-y", strtotime($PaymentsData->PaidDate));
                                        $newDateRaised = date("d-M-y", strtotime($PaymentsData->created_at));
                                    ?>

                                      <tr>
                                         <td>{{  $SchoolName }}</td>
                                         <td>{{ $Month }}</td>
                                         <td>{{ $PaymentsData->Cheque }}</td>
                                         <td>{{ $PaymentsData->Amount }}</td>
                                        <td>{{ $newDateRaised }}</td>
                                         <td>{{ $newDate }}</td>

                                         <td class="t-align"><input type="checkbox" name='PaymentId' value='{{ $PaymentsData->id }}'/></td>
                                      </tr>
                                      <?php
                                      }
                                      ?>
                                        <?php
                                         foreach ($AdvancePayment as $PaymentsData)
                                    {
                                      $SchoolName = GeneralSettingModel::where('id', $PaymentsData->SchoolName)->pluck('SchoolName');
                                        $monthNum  = $PaymentsData->PayMonth;
                                        $dateObj   = DateTime::createFromFormat('!m', $monthNum);
                                        $Month = $dateObj->format('M').' - '.$PaymentsData->PayYear;
                                        $newDate = date("d-M-y", strtotime($PaymentsData->PaidDate));
                                        $newDateRaised = date("d-M-y", strtotime($PaymentsData->created_at));
                                    ?>

                                      <tr>
                                         <td>{{  $SchoolName }}</td>
                                         <td>{{ $Month }}</td>
                                         <td>{{ $PaymentsData->Cheque }}</td>
                                         <td>{{ $PaymentsData->Amount }}</td>
                                         <td>{{ $newDateRaised }}</td>
                                         <td>{{ $newDate }}</td>
                                         <td class="t-align"><input type="checkbox" name='PaymentId' value='{{ $PaymentsData->id }}'/></td>
                                      </tr>
                                      <?php
                                      }
                                      ?>
                                  </tbody>
                              </table>
                              <div id="CheckErrorb" style="display:none;color:red">Please choose only one Payment at a Time</div>
                              <div class="newcenbtn"><input class="submit-btn" id="fire2" type="submit" value="Save"></div>
                              
                              </p>
                              </form>
                         </div>
                     </div>
                 </div>
			  

			     <div class="btn-group">
          <!--<input class="submit-btn" type="submit" value="Save">    -->

    {{ Form::close() }}
        <!--        {{ Form::submit('Update', ['class' => 'submit-btn']) }}     -->

       

              </div>

            </div>

			<div class="result"></div>

			

          </div>

          
<div id="firsttable">

</div>


<!--

<script>
$(document).ready(function() {
$('#example').dataTable( {'aoColumnDefs': [{ 'bSortable': false, 
    'aTargets': [ '4']
     }] } );
} );
</script>
<div class='dash-content-head tabContaier'>
<h5>Student List</h5></div>
<table class='example tab' id='example'>
<tfoot class='tabl tab-abs'><tr>
<th style='display:none'></th>
<th style='display:none'></th>
<th style='display:none'></th>       
</th>
</tr></tfoot>   
<thead>    
<tr>
<th style='display:none'><input type='checkbox' id='selecctall'></th>
<th>Student Name</th>
<th>Number of Trip</th>
<th>Bus Type</th>
</tr>
</thead>
<tbody>
<tr>
<td  style='display:none'><input style='margin-left: 8px;' name='chkSelectRow[]' type='checkbox' class='deletelist' value='35'></td>
<td><span class='tab-check'></span>irfan</td>
<td><span class='tab-check'></span>30 </td>
<td>Yellow</td>
</tr>
<tr>
<td  style='display:none'><input style='margin-left: 8px;' name='chkSelectRow[]' type='checkbox' class='deletelist' value='36'></td>
<td><span class='tab-check'></span>Ibrabi</td>
<td><span class='tab-check'></span>40</td>
<td>Roger</td>
</tr>
</tbody>
</table>

<div class='panel-row list-row'>
<div class='dash-content-head tabContaier'>
<h5>Payment Summary</h5>
</div>

<div class='bottom-tab-row'>
<div class='col-left'>
<button class='btn-mti btn-mti-active'>Show Pick up list</button>
<button class='btn-mti'>Show Drop off list</button>
</div>
</div>
</div>
-->  


          <!-- dash content row end --> 

		

		  <script>

		  $("#AttendenceStatus").change(function(){

		  var value=$(this).val();

		  if(value=="")

		  {

		  

		  $("#AttendenceFrom").val("all");

		  } else {

		  

		  }

		  });

		   $("#Enddate").change(function(){

		    var end=$(this).val();

			

		   });

  $(function() {

    var availableTags = [

	<?php foreach($schoolname as $schoolname) { 

echo '"'.$schoolname.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

  	  <script>

  $(function() {

    var availableTags = [

	<?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

  	if(Auth::user()->usertype==1)

		{

		?>

		<script>

        $("document").ready(function(){

            $("#schoolid").change(function(e){

		

                e.preventDefault();

                var schoolid = $("#schoolid").val();                 

                var dataString = 'schoolid='+schoolid;  

                $.ajax({

                    type: "POST",

                    url : "sessionprocess",

                    data : dataString,

                    success : function(data){

					//location.reload();

                    }

                });



        });

        });

		

		//end of document ready function

    </script>

	

		<?php	

		

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

  } else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}	 





		}  ?>

		<script>



        $("document").ready(function(){
       
    $("#fire1").click(function(e){



      e.preventDefault();   
    var $checkboxes = $("input[type='checkbox']");
    if ($("input[type='checkbox']:checked").length != 1 ) 
    {
        $("input[type='checkbox']").removeAttr("checked");
        $("#CheckErrora").show();

        return false;
    }
    else
    {
      e.preventDefault();   
    $("#CheckError").hide();

    //return ; 
    }
    

             e.preventDefault();          
             console.log('fire');
              var datastring = $("#forma").serialize();            
                $.ajax({
                    type: "POST",
                    url : "acceptpayment",
                    data : datastring,
                    success : function(data)
                    {
             //       console.log(data);

                    if(data == 1) 
                    {
                      $.cookie("pay", "1"); // Sample 1
                      location.reload();
                    } 
                    else {
                      // code to be executed if condition is false
                    }

                    //location.reload();
                    $("#firsttable").html(data);

                    $('.datetimepicker1').datetimepicker({
                      timepicker:false,
                      format:'Y/m/d',
                      formatDate:'Y/m/d',
                    });

                    }
                });

        });



        });

		

		

    </script>


    <script>



        $("document").ready(function(){
       
    $("#fire2").click(function(e){

      e.preventDefault();   


    var $checkboxes = $("input[type='checkbox']");
    if ($("input[type='checkbox']:checked").length > 1) {
        $("input[type='checkbox']").removeAttr("checked");
        $("#CheckErrorb").show();

        return;
    }
    else
    {
      e.preventDefault();   
    $("#CheckErrorb").hide();  
    }
    



             e.preventDefault();          
             console.log('fire');
              var datastring = $("#formb").serialize();            
                $.ajax({
                    type: "POST",
                    url : "acceptpayment",
                    data : datastring,
                    success : function(data)
                    {
                    console.log(data);

                    if(data == 1) 
                    {
                      $.cookie("pay", "1"); // Sample 1
                      location.reload();
                  
                    } 
                    else {
                      // code to be executed if condition is false
                    }

                    
                    // /location.reload();
                    $("#firsttable").html(data);

                    $('.datetimepicker1').datetimepicker({
                      timepicker:false,
                      format:'Y/m/d',
                      formatDate:'Y/m/d',
                    });

                    }
                });

        });



        });

    

    

    </script>

        </div>

        <!--dash content row end --> 

    

      </div>

    <!-- <div class='panel-tab-row'>
    <table id='example' class='display' cellspacing='0' width='100%'>
    <thead>
    <tr>
    <th> Bus Type</th>
    <th> Rate </th>
    <th> Number of Trips </th>
    <th> Total </th>
    </tr>
    </thead>
    
    <tbody>
    <tr>
    <td> Yellow bus </td>
    <td> 85 </td>
    <td> 80 </td>
    <td> 6800 </td>
    </tr>
    <tr>
    <td> Bus A </td>
    <td> 85 </td>
    <td> 80 </td>
    <td> 6800 </td>
    </tr>
    <tr>
    <td> Bus B </td>
    <td> 85 </td>
    <td> 80 </td>
    <td> 6800 </td>
    </tr>
    
    </tbody>
    </table>
    </div> -->

@stop