@extends('layouts.dashboardlayout')

@section('body')


{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$(document).ready(function() {
    $("#GovernmentEntityPhone").mask("999-999-9999");
	$("#GovernmentEntityMobile").mask("999-999-9999");
});
</script>
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('GovernmentEntityAddress'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.k;
                var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
			  //var longitude = place.geometry.location.D;
			  $('#latitude').val(latitude);
			  $('#longitude').val(longitude);
            });
        });
    </script>

	
	

        <div class="form-panel">

        <div class="header-panel">
		<span style='float:right;'>
		<?php $URL = Session::get('urlpath'); ?>
		<a href="{{ URL::to($URL.'/addgovtentity'); }}" class="fa fa-plus customfontawesome" title='Add School Department'></a>
		<a href="{{ URL::to($URL.'/listgovtentity'); }}" class="fa fa-list-ul customfontawesome" title='School Department List'></a>
		</span>

        <h2><!--<span class="icon icon-student"></span>-->School Department</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 class="heading-title">Update School Department</h5>

        @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'govtentityupdateprocess/'.$DriverDetailsbyid[0]['id'], 'files'=> true, 'id' => 'driverprocess')) }}

        </div>

        <div class="tabDetails">         

        <div class="panel-row">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('Name', 'School Department Name' ) }}<em>*</em>

        </div>

        <div class="input-control">

                {{ Form::text('GovernmentEntityName', Input::old('GovernmentEntityName', $DriverDetailsbyid[0]['GovernmentEntityName']), array('id'=> 'GovernmentEntityName')) }}

        

        </div>

        <?php $errmsg=$errors->first('GovernmentEntityName'); $errmessage=str_replace("government entity name","School Department name",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>

        </li>
		
		
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Allocated Schools' ) }}

        </div>

        <div class="input-control">       
		
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}
<style>

.chosen-container.chosen-with-drop .chosen-drop {
  left: 0;
  width: 96%
}


.chosen-container-multi .chosen-choices {
  position: relative;
  overflow: hidden;
  margin: 0;
  padding: 0 5px;
  
  width: 96%;
  height: auto !important;
  height: 1%;
  border: 1px solid #aaa;
  background-color: #fff;
  background-image: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(1%, #eeeeee), color-stop(15%, #ffffff));
  background-image: -webkit-linear-gradient(#eeeeee 1%, #ffffff 15%);
  background-image: -moz-linear-gradient(#eeeeee 1%, #ffffff 15%);
  background-image: -o-linear-gradient(#eeeeee 1%, #ffffff 15%);
  background-image: linear-gradient(#eeeeee 1%, #ffffff 15%);
  cursor: text;
}
</style>

<!--{{ Form::select('SchoolName', array(''=>'Select School Name')+$SchoolName,null, array('id'=> 'multiple-label-example', 'tabindex'=>18, 'multiple class' => 'chosen-select', 'style'=> 'width:96%' ))}}		                -->
<!--{{ Form::select('SchoolName',array(''=>'Select School Name')+$SchoolName,null, array('id'=> 'multiple-label-example', 'tabindex'=>18, 'multiple class' => 'chosen-select', 'style'=> 'width:96%' ))}}		                -->
{{ Form::select('SchoolName[]',$SchoolName,$SchoolId, array('id'=> 'multiple-label-example', 'selected'=> 'selected', 'tabindex'=>18, 'multiple class' => 'chosen-select', 'style'=> 'width:145%' ) )}}


        


  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
	


  </script>		
      
    
    


        </div>

        

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Address', 'Address ' ) }}<em>*</em>

        </div>

        <div class="input-control">

      {{ Form::textarea('GovernmentEntityAddress', Input::old('GovernmentEntityAddress', $DriverDetailsbyid[0]['GovernmentEntityAddress']),['class' => 'GovernmentEntityAddress','id' => 'GovernmentEntityAddress','size' => '100x100']) }}



	{{ Form::text('lat', null,['class' => 'unwant','id' => 'latitude','size' => '100x100']) }}
	   {{ Form::text('lon', null,['class' => 'unwant','id' => 'longitude','size' => '100x100']) }}
        

        </div>

<?php $errmsg=$errors->first('GovernmentEntityAddress'); $errmessage=str_replace("government entity address","School Department Address",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Email', 'Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">









{{ Form::text('GovernmentEntityEmail', Input::old('GovernmentEntityEmail', $DriverDetailsbyid[0]['GovernmentEntityEmail']), array('id'=> 'GovernmentEntityEmail')) }}





        </div>

        <?php $errmsg=$errors->first('GovernmentEntityEmail'); $errmessage=str_replace("government entity email","School Department Email",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Phone', 'Phone ' ) }}<em>*</em>

        </div>

        <div class="input-control">





{{ Form::text('GovernmentEntityPhone', Input::old('GovernmentEntityPhone', $DriverDetailsbyid[0]['GovernmentEntityPhone']), array('id'=> 'GovernmentEntityPhone')) }}





        </div>

        <?php $errmsg=$errors->first('GovernmentEntityPhone'); $errmessage=str_replace("government entity phone","School Department Phone",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>

        </li>

        <li>

        <div class="label-control">

        {{ Form::label('Contact Person', 'Contact Person' ) }}

        </div>

        <div class="input-control">







{{ Form::text('GovernmentEntityContactPerson', Input::old('GovernmentEntityContactPerson', $DriverDetailsbyid[0]['GovernmentEntityContactPerson']), array('id'=> 'GovernmentEntityContactPerson')) }}









        </div>

        {{ $errors->first('GovernmentEntityContactPerson', '<div class="error">:message</div>') }}

        </li>







        <li>

        <div class="label-control">

        {{ Form::label('Mobile', 'Mobile ' ) }}

        </div>

        <div class="input-control">





{{ Form::text('GovernmentEntityMobile', Input::old('GovernmentEntityMobile', $DriverDetailsbyid[0]['GovernmentEntityMobile']), array('id'=> 'GovernmentEntityMobile')) }}



        

        </div>

        {{ $errors->first('GovernmentEntityMobile', '<div class="error">:message</div>') }}

        </li>





        <li>

        <div class="label-control">

        {{ Form::label('Password', 'Password ' ) }}


        </div>

        <div class="input-control">



        {{ Form::password('Password',array('id'=> 'Password')) }}

        

        </div>

        {{ $errors->first('Password', '<div class="error">:message</div>') }}

        </li>







        

        

        </ul>

        <div class="btn-group form-list-btn-group" >

        {{ Form::submit('Save', ['class' => 'submit-btn']) }}    

        {{ Form::reset('Cancel', ['class' => 'resetcancelbutton']) }}

        </div>

        {{ Form::close() }}

        </div>

        

        </div>

        </div>

        <!-- dash content row end --> 

        </div>

        </div>

         <script>

$(document).ready(function(){









$('#student-listing-table').dataTable();

});

</script>





@stop