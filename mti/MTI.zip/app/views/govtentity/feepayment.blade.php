@extends('layouts.dashboardlayout')
@section('body')
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}


<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>
			<div class="height-class">

            <div class="form-panel">

        <div class="header-panel">
<?php if(Auth::user()->usertype ==3) { $URL = Session::get('urlpath'); ?>
		<?php $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/exportbusattendence'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/feepayment'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		<a href="{{ URL::to($URL.'/listfeepayment'); }}" class="fa fa-list-alt customfontawesome" title='Payments List'></a>
		</span>
		<?php } ?>
          <h2><!--<span class="icon icon-profile">--></span>Fee Payment</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Fee Payment</h5>

             </div>

            <div class="panel-row">



{{ Form::open(array('url' => 'feepaymentprocess', 'files'=> true, 'id' => 'frm', 'name' => 'feepaymentprocess')) }}

 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

   <ul class="dash-form-lister">

        <li>
        <div class="label-control">
        {{ Form::label('r_no', 'School Name : ' ) }}
        </div>
        <div class="input-control">              
{{ Form::select('SchoolName', array(''=>'Select School')+$SchoolDetails,null, array('class'=> 'chosen-select', 'id'=> 'SchoolName' ))}}   
{{ $errors->first('SchoolName', '<div class="error">:message</div>') }}        
  <!--#here-->
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
	  
    }
	
	$('.chosen-select').on('change', function(event, params) {
     var choosedSchool = params.selected
	
	
	$.ajax({

                    type: "POST",

                    url : "getNewSchool",

                    data : {'school' : choosedSchool},

                    success : function(data){
					console.log('change');
					$("#replaceCompany").html(data);
					console.log(data);

                    }

                });
	
	
	
	
  });
  
  
  </script>

        </div>
        <div id="SchoolError" style="display:none;color:red">Please choose any School</div>
         {{ $errors->first('SchoolName', '<div class="error">:message</div>') }}
        </li>


        <li>
        <div class="label-control">
        {{ Form::label('r_no', 'Bus Company Name : ' ) }}
        </div>
        <div class="input-control">              
<div id="replaceCompany">
<!--{{ Form::select('BusCompanyName', array(''=>'Select Bus Company')+$BusCompanyName,null, array('class'=> 'chosen-select', 'id'=> 'BusCompanyName'))}}-->
<select class="chosen-select" id="BusCompanyName" name="BusCompanyName" disabled>
<option value="" >Select any School</option>
</select>
</div>
{{ $errors->first('BusCompanyName', '<div class="error">:message</div>') }}        
  <!--#here-->
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>

        </div>
        <div id="BusError" style="display:none;color:red">Please choose The Bus Company</div> 
         
        </li>


		  <li class="unwant">

        <div class="label-control">

        {{ Form::label('r_no', 'School' ) }}

        </div>

        <div class="input-control">              

	   <!--{{ Form::select('schoolid', $SchoolDetails,null, array('id'=> 'schoolid'))}}		-->

        </div>
{{ $errors->first('BusCompanyName', '<div class="error">:message</div>') }}
         {{ $errors->first('schoolid', '<div class="error">:message</div>') }}

        </li>



		  <li>
        <div class="label-control">
        </div>
        <div class="input-control">        
        </div>
        {{ $errors->first('studentname', '<div class="error">:message</div>') }}

        </li>
			 <!--
       <li>
        <div class="label-control">
        {{ Form::label('PaidDate', 'Paid Date' ) }}
        </div>
        <div class="input-control">
        {{ Form::text('PaidDate', null, ['class' => 'datetimepicker1 PaidDate']) }}        
        </div>
        {{ $errors->first('PaidDate', '<div class="error">:message</div>') }}
        </li>

-->

       

<!--
      <li>

          <div class="label-control">

          {{ Form::label('Amount', 'Amount' ) }}

          </div>

          <div class="input-control">

    {{ Form::text('Amount', null, ['class' => 'cls']) }}                 

          </div>
 
  {{ $errors->first('Amount', '<div class="error">:message</div>') }}
          </li>
        -->


<li>

          <div class="label-control">

          {{ Form::label('DateOfBirth', 'Payable For ' ) }}

          </div>


          <div class="input-control">
            <?php
            $curmonth = date("F");
            $month = date("m");
            
            ?>

<select style='width: 112px;' name='PayMonth' id='PayMonth'>
  <option name="PayMonth" value=''>Select Month</option>   
<?php
for($i = $month-3 ; $i <= $month; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
  <option value="<?php echo date("m",mktime(0,0,0,$i,1,date("Y"))); ?>" ><?php echo date("F",mktime(0,0,0,$i,1,date("Y")));?>
  </option>
    <?php
}?>

</select>    
<?php
$year = date('Y');
$nextyear = date('Y')-1;


$v = date("m"); 



$tmonth =  $v-3;
#echo $tmonth;
?>

<select name="PayYear" style='width: 112px;' id='PayYear'>
 <option name="PayYear" value=''>Select Year </option>   
<?php 
$year = date('Y');
$nextyear = date('Y')-1;


$v = date("m"); 



$tmonth =  $v-3;



if ($tmonth<=0) 
{
$from = date("Y")-1;
$to = date("Y");
} else 
{
$from = date("Y");
$to = date("Y");
}




for($i=$from; $i<=$to; $i++)
{

    echo "<option value=".$i.">".$i."</option>";
}
?> 
    
</select> 
<div id="MonthError" style="display:none;color:red">Please choose any Month</div>
    <div id="YearError" style="display:none;color:red">Please choose any Year</div>
    <?php
if ($errors->first('PayMonth') ||  $errors->first('PayYear'))
{
echo '<div class="error">The month and year is required.</div>';
}
    ?>
    

          </div>

          

          </li>
          

              </ul>

           

			  

			     <div class="btn-group form-list-btn-group">
          <!--<input class="submit-btn" type="submit" value="Save">    -->
          <input class="submit-btn" id="fire" type="submit" value="Go">    
    {{ Form::close() }}
        <!--        {{ Form::submit('Update', ['class' => 'submit-btn']) }}     -->

       

              </div>

            </div>

			<div class="result"></div>

			

          </div>
          



<!--

<script>
$(document).ready(function() {
$('#example').dataTable( {'aoColumnDefs': [{ 'bSortable': false, 
    'aTargets': [ '4']
     }] } );
} );
</script>
<div class='dash-content-head tabContaier'>
<h5>Student List</h5></div>
<table class='example tab' id='example'>
<tfoot class='tabl tab-abs'><tr>
<th style='display:none'></th>
<th style='display:none'></th>
<th style='display:none'></th>       
</th>
</tr></tfoot>   
<thead>    
<tr>
<th style='display:none'><input type='checkbox' id='selecctall'></th>
<th>Student Name</th>
<th>Number of Trip</th>
<th>Bus Type</th>
</tr>
</thead>
<tbody>
<tr>
<td  style='display:none'><input style='margin-left: 8px;' name='chkSelectRow[]' type='checkbox' class='deletelist' value='35'></td>
<td><span class='tab-check'></span>irfan</td>
<td><span class='tab-check'></span>30 </td>
<td>Yellow</td>
</tr>
<tr>
<td  style='display:none'><input style='margin-left: 8px;' name='chkSelectRow[]' type='checkbox' class='deletelist' value='36'></td>
<td><span class='tab-check'></span>Ibrabi</td>
<td><span class='tab-check'></span>40</td>
<td>Roger</td>
</tr>
</tbody>
</table>

<div class='panel-row list-row'>
<div class='dash-content-head tabContaier'>
<h5>Payment Summary</h5>
</div>

<div class='bottom-tab-row'>
<div class='col-left'>
<button class='btn-mti btn-mti-active'>Show Pick up list</button>
<button class='btn-mti'>Show Drop off list</button>
</div>
</div>
</div>
-->  


          <!-- dash content row end --> 

		

		  <script>

		  $("#AttendenceStatus").change(function(){

		  var value=$(this).val();

		  if(value=="")

		  {

		  

		  $("#AttendenceFrom").val("all");

		  } else {

		  

		  }

		  });

		   $("#Enddate").change(function(){

		    var end=$(this).val();

			

		   });

  $(function() {

    var availableTags = [

	<?php foreach($schoolname as $schoolname) { 

echo '"'.$schoolname.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

  	  <script>

  $(function() {

    var availableTags = [

	<?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';	

	?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

  	if(Auth::user()->usertype==1)

		{

		?>

		<script>

        $("document").ready(function(){

            $("#schoolid").change(function(e){

		

                e.preventDefault();

                var schoolid = $("#schoolid").val();                 

                var dataString = 'schoolid='+schoolid;  

                $.ajax({

                    type: "POST",

                    url : "sessionprocess",

                    data : dataString,

                    success : function(data){

					location.reload();

                    }

                });



        });

        });

		

		//end of document ready function

    </script>

	

		<?php	

		

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

  } else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}	 





		}  ?>

		<script>



        $("document").ready(function(){
            
        //     $(".submit-btns").click(function(e){
		      //    e.preventDefault();          
        //         var dataString = $("form").serialize();  
        //         $.ajax({
        //             type: "POST",
        //             url : "feepaymentprocess",
        //             data : dataString,
        //             success : function(data){
        //               console.log(data);
				    //       	$(".result").html(data);
        //             }
        //         });
        // });

$("#fire").click(function(e){
e.preventDefault();










//0000
if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").show();
$("#YearError").show();
return;
}
//0001

else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").show();
$("#YearError").show();
return;
}


else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").show();
$("#YearError").hide();
return;
}


else if($('#SchoolName').val() != '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").hide();
$("#BusError").hide();
$("#MonthError").hide();
$("#YearError").show();
return;
}

else if($('#SchoolName').val() != '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").hide();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").show();
return;
}


else if($('#SchoolName').val() != '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").hide();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").hide();
return;
}


else if($('#SchoolName').val() != '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").hide();
$("#BusError").hide();
$("#MonthError").show();
$("#YearError").show();
return;
}

else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").hide();
$("#BusError").hide();
$("#MonthError").hide();
$("#YearError").show();
return;
}


//0010
else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").show();
$("#YearError").hide();
return;
}
//0011
else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").show();
$("#YearError").hide();
return;
}
//0100
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").show();
return;
}
//0101
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").hide();
$("#YearError").show();
return;
}

//0110
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").hide();
return;
}
//0111
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").hide();
$("#YearError").hide();
return;
}
//1000
else if($('#SchoolName').val() != '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").hide();
$("#BusError").show();
$("#MonthError").show();
$("#YearError").show();
return;
}
//1001
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").hide();
return;
}

//////////////////
//1010
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").Show();
$("#MonthError").hide();
$("#YearError").hide();
return;
}
//1011
else if($('#SchoolName').val() == '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").hide();
$("#YearError").show();
return;
}
//1100
else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").show();
$("#YearError").hide();
return;
}
//1101
else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() == '')
{
$("#SchoolError").show();
$("#BusError").show();
$("#MonthError").show();
$("#YearError").hide();
return;
}

//1110
else if($('#SchoolName').val() == '' && $('#PayMonth').val() == '' &&  $('#PayYear').val() == '' &&  $('#BusCompanyName').val() != '')
{
$("#SchoolError").show();
$("#BusError").hide();
$("#MonthError").show();
$("#YearError").show();
return;
}


else if($('#SchoolName').val() != '' && $('#PayMonth').val() != '' &&  $('#PayYear').val() != '' &&  $('#BusCompanyName').val() != '')
{

$("#MonthError").hide();
$("#SchoolError").hide();
$("#YearError").hide();
$("#BusError").hide();



            e.preventDefault();          
             console.log('fire');

              var datastring = $("#frm").serialize();

              


                $.ajax({
                    type: "POST",
                    url : "studentfeedetails",
                    data : datastring,
                    success : function(data)
                    {
                    console.log(data);

                    $("#firsttable").html(data);

                    $('.datetimepicker1').datetimepicker({
                      timepicker:false,
                      format:'Y/m/d',
                      formatDate:'Y/m/d',
					  maxDate: new Date
                    });

                    }
                });

}
else
{
  console.log('sankarbai');
}




        });



        });

		

		

    </script>

        </div>

        <!--dash content row end --> 

    <div id="firsttable">

	</div>

      </div>
	</div><!--height-class ends-->

	  <!-- <div class='panel-tab-row'>
	  <table id='example' class='display' cellspacing='0' width='100%'>
	  <thead>
	  <tr>
	  <th> Bus Type</th>
	  <th> Rate </th>
	  <th> Number of Trips </th>
	  <th> Total </th>
	  </tr>
	  </thead>
	  
	  <tbody>
	  <tr>
	  <td> Yellow bus </td>
	  <td> 85 </td>
	  <td> 80 </td>
	  <td> 6800 </td>
	  </tr>
	  <tr>
	  <td> Bus A </td>
	  <td> 85 </td>
	  <td> 80 </td>
	  <td> 6800 </td>
	  </tr>
	  <tr>
	  <td> Bus B </td>
	  <td> 85 </td>
	  <td> 80 </td>
	  <td> 6800 </td>
	  </tr>
	  
	  </tbody>
	  </table>
	  </div> -->
    

@stop