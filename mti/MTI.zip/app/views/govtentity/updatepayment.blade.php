@extends('layouts.dashboardlayout')

@section('body')
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}


<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>
			<div class="height-class">
            <div class="form-panel">

        <div class="header-panel">
<?php if(Auth::user()->usertype ==3) { $URL = Session::get('urlpath'); ?>
		<?php $URL = Session::get('urlpath'); ?>
		<span style='float:right; '>
		<a href="{{ URL::to($URL.'/exportbusattendence'); }}" class="fa fa-book customfontawesome" title='Attendance Report'></a>
		<a href="{{ URL::to($URL.'/feepayment'); }}" class="fa fa-money customfontawesome" title='Payments'></a>
		<a href="{{ URL::to($URL.'/listfeepayment'); }}" class="fa fa-list-alt customfontawesome" title='Payments List'></a>
		</span>
		<?php } ?>
          <h2><!--<span class="icon icon-profile">--></span>Fee Payment Report</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5 class="heading-title">Edit Fee Payment</h5>

             </div>

            <div class="panel-row">
@if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

{{ Form::open(array('url' => 'paymentupdateprocess', 'files'=> true, 'id' => 'feepaymentprocess')) }}

   <ul class="dash-form-lister">

<li>

        <div class="label-control">
          {{ Form::label('Enddate', 'School Name' ) }}
      </div>
        <div class="input-control">
          <?php
            $SchoolNameVal = FeeModel::where('id', '=', $ScId)->pluck('SchoolName');  
            $SchoolNameVal = GeneralSettingModel::where('id', '=', $SchoolNameVal)->pluck('SchoolName');
          ?>
      
      {{ Form::text('SchoolNameval', $SchoolNameVal, array('readonly'=> 'readonly')) }}
      <input type="hidden" name="SchoolId" value ="<?php echo $DriverDetails[0]['SchoolName']; ?>">
      <input type="hidden" name="SchoolName" value ="<?php echo $ScId; ?>">
      
         {{ $errors->first('SchoolName', '<div class="error">:message</div>') }}

        </div>

      

        </li>

        </li>

		

		  <li>

        <div class="label-control">
<!--
        {{ Form::label('School Name', 'School Name' ) }}
-->
        </div>

        <div class="input-control">        

         <!-- {{ Form::text('studentname',null, array('id'=> 'Searchdata','placeholder' => 'Search School')) }}		 -->

        

        </div>

        {{ $errors->first('studentname', '<div class="error">:message</div>') }}

        </li>
			 <li>

        <div class="label-control">

        {{ Form::label('Start Date', 'Paid Date' ) }}

        </div>

        <div class="input-control">
        <?php 
       $dat =  date("m/d/Y", strtotime($DriverDetails[0]['PaidDate']) );
         ?>
        {{ Form::text('PaidDates', $dat, ['class' => 'datetimepicker1 DateOfBirth PaidDate', 'disabled'=>'disabled']) }} 
        {{ Form::hidden('PaidDate', $DriverDetails[0]['PaidDate'], ['class' => 'datetimepicker1 DateOfBirth PaidDate', 'readonly'=>'readonly']) }} 

        </div>

        {{ $errors->first('PaidDate', '<div class="errorsetting">:message</div>') }}

        </li>

		

        
<li>

        <div class="label-control">

        {{ Form::label('Amount', 'Amount' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Amount', $DriverDetails[0]['Amount'], ['class' => 'none']) }}        

        </div>

        {{ $errors->first('Amount', '<div class="errorsetting">:message</div>') }}

        </li>
        <li>

        <div class="label-control">

        {{ Form::label('Cheque', 'Cheque' ) }}

        </div>

        <div class="input-control">

        {{ Form::text('Cheque', $DriverDetails[0]['Cheque'], ['class' => 'none']) }}        

        </div>

        {{ $errors->first('Cheque', '<div class="errorsetting">:message</div>') }}

        </li>

 
<li>

          <div class="label-control">

          {{ Form::label('DateOfBirth', 'Payable For' ) }}

          </div>


          <div class="input-control">
            <?php
            $curmonth = date("F");
            $month = date("m");
            ?>

<input type="hidden" name="PayMonth" value="<?php echo $DriverDetails[0]['PayMonth']?>" >
<select style='width: 112px;' name='PayMonths' disabled>
<option name="PayMonth" value=''>Select Month</option>   
<option name="PayMonth" value='<?php echo $DriverDetails[0]['PayMonth']?>' selected><?php  echo date("F",mktime(0,0,0,$DriverDetails[0]['PayMonth'],1,date("Y")));?></option>   

</select>    
{{ $errors->first('PayMonth', '<div class="errorsetting">:message</div>') }}




<input type="hidden" name="PayYear" value="<?php echo $DriverDetails[0]['PayYear']?>" >
<select style='width: 112px;' name='PayYears' disabled>
<option name="PayYear" value=''>Select Year</option>   
<option name="PayYear" value='<?php echo $DriverDetails[0]['PayYear'];?>' selected><?php echo $DriverDetails[0]['PayYear'];?></option>   

</select>    
 
{{ $errors->first('PayYear', '<div class="errorsetting">:message</div>') }}
          </div>

          

          </li>
          

       <li>

        <div class="label-control">

        {{ Form::label('Status', 'Status' ) }}

        </div>

        <div class="input-control">        


          <?php
          if($DriverDetails[0]['Paid']=='2')
          {          
          ?>
          <input type='hidden' name='Paid' value='<?php echo $DriverDetails[0]['Paid']; ?>'>
          <select id="Paid" name="Paid" disabled><option value="" selected="selected">Select Status</option>
          <option value="1" <?php if ($DriverDetails[0]['Paid']=='1') { echo 'selected'; }?>>Paid</option>          
          <option value="2" <?php if ($DriverDetails[0]['Paid']=='0') { echo 'selected'; }?>>Rejected</option>
          <option value="2" <?php if ($DriverDetails[0]['Paid']=='2') { echo 'selected'; }?>>Accepted</option>
         </select>
          <?php

          }
          else
          {
          ?>

         <select id="Paid" name="Paid"><option value="" selected="selected">Select Status</option>
          <option value="1" <?php if ($DriverDetails[0]['Paid']=='1') { echo 'selected'; }?>>Paid</option>          
          <option value="0" <?php if ($DriverDetails[0]['Paid']=='0') { echo 'selected'; }?>>Rejected</option>
          
         </select>
         <?php
        }
         ?>
        

        </div>

        {{ $errors->first('Paid', '<div class="error">The status field is required</div>') }}

        </li>	


        


              </ul>

           

			  

			     <div class="btn-group form-list-btn-group">
          <input class="submit-btn" type="submit" value="Save">    
    {{ Form::close() }}
        <!--        {{ Form::submit('Update', ['class' => 'submit-btn']) }}     -->

       

              </div>

            </div>

			<div class="result"></div>

			

          </div>



          <!-- dash content row end --> 

		

        </div>

        <!--dash content row end --> 

    

      </div>
	  
	  </div><!--height-class ends-->

    

@stop