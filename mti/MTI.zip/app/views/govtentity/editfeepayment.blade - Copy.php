@extends('layouts.dashboardlayout')

@section('body')

<script>

$(document).ready(function(){

$("#AttendenceFrom").attr('disabled','disabled');

});

</script>

            <div class="form-panel">

        <div class="header-panel">

          <h2><!--<span class="icon icon-profile">--></span>Edit Fee Payment</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

          

          <div class="dash-content-row"> <!--- dash content row start -->

            <div class="dash-content-head">

              <h5>Edit Fee Payment</h5>

             </div>

            <div class="panel-row">

       @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        {{ Form::open(array('url' => 'exportattendenceprocesslist', 'files'=> true, 'id' => 'exportattendenceprocesslist')) }}

              <ul class="dash-form-lister">

       

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School' ) }}

        </div>

        <div class="input-control">              

     {{ Form::select('schoolid', array(''=>'Select School')+$SchoolDetails,null, array('id'=> 'schoolid'))}}    

        </div>

         {{ $errors->first('schoolid', '<div class="errorsetting">:message</div>') }}

        </li>

    

     


<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Select Month and Year' ) }}

        </div>

        <div class="input-control">  

    <select style='width: 112px;' name='PayMonth'>
  <option name="PayMonth" value=''>Select Month</option>   
<?php

for($i = 1 ; $i <= 12; $i++)
{
    $allmonth = date("F",mktime(0,0,0,$i,1,date("Y")))
    ?>
    <option value="<?php 
    echo $i; 
    
    ?>" 
    >
    <?php
    echo date("F",mktime(0,0,0,$i,1,date("Y")));
    //Close tag inside loop
    ?>
    </option>
    <?php
}?>

</select>    
<select name="PayYear" style='width: 112px;'>
 <option name="PayYear" value=''>Select Year </option>   
<?php 

for($i=2015; $i<=2020; $i++)
{

    echo "<option value=".$i.">".$i."</option>";
}
?> 
    
</select> 
        </div>

         {{ $errors->first('Triptype', '<div class="errorsetting">:message</div>') }}

        </li>   

              </ul>

           

        {{ Form::close() }}

           <div class="btn-group form-list-btn-group">

                {{ Form::submit('Search', ['class' => 'submit-btn']) }}    

       

              </div>

            </div>

      <div class="result"></div>

      

          </div>



          <!-- dash content row end --> 

    

      <script>

      

  $(function() {

    var availableTags = [

  <?php foreach($studentname as $studentnamevalue) { 

echo '"'.$studentnamevalue.'"'.','; 

  ?>

     

      <?php } ?>

    ];

    $( "#Searchdata" ).autocomplete({

      source: availableTags

    });

  });

  </script>

      <script>

  $(function() {

    var availableTags = [

  <?php foreach($parentname as $parentnamevalue) { 

echo '"'.$parentnamevalue.'"'.',';  

  ?>

     

      <?php } ?>

    ];

    $( "#ParentName" ).autocomplete({

      source: availableTags

    });

  });

  </script>

     <?php

    if(Auth::user()->usertype==1)

    {

    ?>

    <script>

        $("document").ready(function(){

            

        });

    

    //end of document ready function

    </script>

  

    <?php 

    

     if(Session::get('selectschool')=="")

{

?>

<script>

    $("document").ready(function(){

$("#Searchdata").attr('disabled','disabled');

$(".Startdate").attr('disabled','disabled');

$(".Enddate").attr('disabled','disabled');

$("#Gender").attr('disabled','disabled');

$("#Age").attr('disabled','disabled');

$("#Grade").attr('disabled','disabled');

$("#ParentName").attr('disabled','disabled');

$("#AttendenceStatus").attr('disabled','disabled');

});

</script>

<?php

} else {

?>

<script>

    $("document").ready(function(){

$("#schoolid").val(<?php echo Session::get('selectschool'); ?>);



});

</script>

<?php

}  





    }  ?>

    <script>

        $("document").ready(function(){

            $(".submit-btn").click(function(e){

    

                e.preventDefault();

              

                var dataString = $("form").serialize(); 


                $.ajax({

                    type: "POST",

                    url : "editpaymentlisting",

                    data : dataString,

                    success : function(data){
                      console.log(data);
          $(".result").html(data);

                    }

                });



        });

        });

    

    

    </script>

        </div>

        <!--dash content row end --> 

    

      </div>

    </div>

@stop