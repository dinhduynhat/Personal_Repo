@extends('layouts.dashboardlayout')

@section('body')

  
{{ HTML::script('assets/js/jquery.maskedinput.js') }}
<script>
$(document).ready(function() {
    $("#GovernmentEntityPhone").mask("999-999-9999");
	$("#GovernmentEntityMobile").mask("999-999-9999");
});
</script>
 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('GovernmentEntityAddress'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.k;
                var longitude = place.geometry.location.D;
                var mesg = "Address: " + address;
                mesg += "\nLatitude: " + latitude;
                mesg += "\nLongitude: " + longitude;
            //    alert(mesg);
			  //var longitude = place.geometry.location.D;
			  $('#latitude').val(latitude);
			  $('#longitude').val(longitude);
            });
        });
    </script>
	
	
	
	


        <div class="form-panel">

        <div class="header-panel">
		<span style='float:right;'>
		<?php $URL = Session::get('urlpath'); ?>
		<a href="{{ URL::to($URL.'/addgovtentity'); }}" class="fa fa-plus customfontawesome" title='Add School Department'></a>
		<a href="{{ URL::to($URL.'/listgovtentity'); }}" class="fa fa-list-ul customfontawesome" title='School Department List'></a>
		</span>

        <h2><!--<span class="icon icon-student"></span>-->Manage School Department</h2>

        </div>

        <div class="dash-content-panel"> <!-- dash panel start -->

        

        <div class="dash-content-row "> <!-- dash content row start -->

        <div class="dash-content-head tabContaier">

        <h5 class="heading-title">Add School Department</h5>

		 @if(Session::has('Message'))

        <p class="alert">{{ Session::get('Message') }}</p>

        @endif

        </div>    
	

        {{ Form::open(array('url' => 'addgovtentityprocess', 'files'=> true, 'id' => 'addgovtentityprocess')) }}



        <div class="panel-row panel-row-wborder">

        <div class="col-three-four">

        <ul class="dash-form-lister">

        <li>

        <div class="label-control">

        {{ Form::label('r_no', 'School Department' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityName',null, array('id'=> 'GovernmentEntityName')) }}

        </div>


<?php $errmsg=$errors->first('GovernmentEntityName'); $errmessage=str_replace("government entity name","School Department name",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>
		
        

        </li>
		
		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Allocated Schools' ) }}

        </div>

        <div class="input-control">       
		
{{ HTML::style('assets/css/chosen.css') }}

{{ HTML::style('assets/css/prism.css') }}

{{ HTML::script('assets/js/prism.js') }}
{{ HTML::script('assets/js/chosen.jquery.js') }}
{{ HTML::script('assets/js/prism.js') }}


<!--{{ Form::select('SchoolName', array(''=>'Select School Name')+$SchoolName,null, array('id'=> 'multiple-label-example', 'tabindex'=>18, 'multiple class' => 'chosen-select', 'style'=> 'width:96%' ))}}		                -->
<!--{{ Form::select('SchoolName',array(''=>'Select School Name')+$SchoolName,null, array('id'=> 'multiple-label-example', 'tabindex'=>18, 'multiple class' => 'chosen-select', 'style'=> 'width:96%' ))}}		                -->
{{ Form::select('SchoolName[]', $SchoolName,null, array('id'=> 'multiple-label-example', 'placeholder'=> 'te',  'multiple class' => 'chosen-select', 'style'=> 'width:96%' ))}}


        


  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
	


  </script>		
      
    
    


        </div>

        

        </li>

         <li>

        <div class="label-control">

        <label for="r_no">Entity Address <em>*</em></label>


        </div>

        <div class="input-control">       

       {{ Form::textarea('GovernmentEntityAddress', null,['class' => 'GovernmentEntityAddress','id' => 'GovernmentEntityAddress','size' => '100x100']) }}
	   
	   {{ Form::text('lat', null,['class' => 'unwant','id' => 'latitude','size' => '100x100']) }}
	   {{ Form::text('lon', null,['class' => 'unwant','id' => 'longitude','size' => '100x100']) }}
	   
        </div>

<?php $errmsg=$errors->first('GovernmentEntityAddress'); $errmessage=str_replace("government entity address","School Department Address",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>
		
        

        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Email ' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::email('GovernmentEntityEmail',null, array('id'=> 'GovernmentEntityEmail')) }}

        </div>

<?php $errmsg=$errors->first('GovernmentEntityEmail'); $errmessage=str_replace("government entity email","School Department Email",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>
		
         

        </li>			

		<li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Contact Person' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityContactPerson',null, array('id'=> 'GovernmentEntityContactPerson')) }}

        </div>

         {{ $errors->first('GovernmentEntityContactPerson', '<div class="errorsetting">:message</div>') }}

        </li>

         <li style="display:none;">

        <div class="label-control">

        {{ Form::label('r_no', 'User Name' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?>  <em>*</em> <?php } ?>

        </div>

		<?php

		if(!empty($schooluserDetailsbyid))

{ $user=$schooluserDetailsbyid[0]['UserName']; } else { $user=""; }

		?>

        <div class="input-control">       

       {{ Form::text('UserName',$user, array('id'=> 'Username')) }}

        </div>

         {{ $errors->first('UserName', '<div class="errorsetting">:message</div>') }}

        </li>

		<li id="Password"> 

        <div class="label-control">

        {{ Form::label('r_no', 'Password' ) }} <?php 

if(empty($schoolDetailsbyid))

{

?> <em>*</em> <?php } ?>

        </div>

        <div class="input-control">       

       {{ Form::password('Password',array('id'=> 'Password')) }}

	   

        </div>

         {{ $errors->first('Password', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

       <div class="col-three-two">

        <ul class="dash-form-lister">

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Phone' ) }}<em>*</em>

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityPhone',null, array('id'=> 'GovernmentEntityPhone')) }}

        </div>
<?php $errmsg=$errors->first('GovernmentEntityPhone'); $errmessage=str_replace("government entity phone","School Department Phone",$errmsg);
if($errmsg !="") { ?> <div class="errorsetting"><?php echo $errmessage ?></div> <?php } ?>
		


        </li>

		 <li>

        <div class="label-control">

        {{ Form::label('r_no', 'Government Entity Mobile' ) }}

        </div>

        <div class="input-control">       

       {{ Form::text('GovernmentEntityMobile',null, array('id'=> 'GovernmentEntityMobile')) }}

        </div>

         {{ $errors->first('GovernmentEntityMobile', '<div class="errorsetting">:message</div>') }}

        </li>

		

        </ul>

        </div>

        

        <div class="btn-group form-list-btn-group">

        <input class="submit-btn" type="submit" value="Save">    

        <input class="resetcancelbutton" type="reset" value="Cancel">

        </div>

        </div>

		  {{ Form::close() }}
		  <?php
		  if(!empty($schoolDetailsbyid) && $schoolDetailsbyid[0]['Schoolloginstatus']==0)

{

		  ?>
		    <div class="Sendmail dash-content-head tabContaier">
<a href="<?php echo url();?>/sendmail/<?php echo $schoolDetailsbyid[0]['id'];?>" class="btn-sb pass-btn">Send Login Details</a>
</div>
		  <?php 
}
		  if(!empty($deleteerror))

		{

		?>

			<script>

		function fnOpenNormalDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("This records used for student data.");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}

$(document).ready(function(){

fnOpenNormalDialogbox();

});



		</script>

		<?php

		}



if(!empty($schoolDetailsbyid))

{

?>

<script>

        $(document).ready(function(){		

		$("#SchoolName").val("<?php echo $schoolDetailsbyid[0]['SchoolName']?>");

		$(".SchoolAddress").val("<?php echo trim(preg_replace('/\s\s+/', ' ',$schoolDetailsbyid[0]['SchoolAddress']));?>");

		$("#SchoolEmail").val("<?php echo $schoolDetailsbyid[0]['SchoolEmail']?>");

		$("#SchoolPhone").val("<?php echo $schoolDetailsbyid[0]['SchoolPhone']?>");

		$("#SchoolMobile").val("<?php echo $schoolDetailsbyid[0]['SchoolMobile']?>");

		$("#SchoolFax").val("<?php echo $schoolDetailsbyid[0]['SchoolFax']?>");

		$("#AdminContactPerson").val("<?php echo $schoolDetailsbyid[0]['AdminContactPerson']?>");		

		$("#Country").val("<?php echo $schoolDetailsbyid[0]['Country']?>");	

		<?php if(!empty($schoolDetailsbyid[0]['Status']))

{ ?>

        $("#Status").val("<?php echo $schoolDetailsbyid[0]['Status']; ?>");	

	<?php } ?>

		});



</script>

<?php } 





if(Auth::user()->usertype !=2)

		{ ?>

		     
        

			<?php

		if(!empty($GeneralSettingDetails))

		{

		?>

	    

<?php } ?>

		

		<?php

		if(empty($GeneralSettingDetails))

		{

		?>

		

		<?php } else { ?>

		

		<?php } ?>

		

		


        <script>

$(document).ready(function(){



$('#student-listing-table').dataTable();

});

$(document).ready(function() {

    $('#example').DataTable( {

        initComplete: function () {

            var api = this.api();

 

            api.columns().indexes().flatten().each( function ( i ) {

                var column = api.column( i );

                var select = $('<select><option value="">Select Status</option></select>')

                    .appendTo( $(column.footer()).empty() )

                    .on( 'change', function () {

                        var val = $.fn.dataTable.util.escapeRegex(

                            $(this).val()

                        );

 

                        column

                            .search( val ? '^'+val+'$' : '', true, false )

                            .draw();

                    } );

 

                column.data().unique().sort().each( function ( d, j ) {

                    select.append( '<option value="'+d+'">'+d+'</option>' )

                } );

            } );

        }

    } );



   

    $('<span class="lab-abs">Status :</span>').appendTo('#acavails');

    

} );

</script>



        

        </div>

		<?php } ?>

	        </div>

        </div>
		
		<div class="panel-tab-row"> <!---------------- student listing table start ------>

				</div>
        <!-- dash content row end --> 

        

        
			 {{ Form::open(array('url' => 'schooldeleteprocess', 'files'=> true, 'id' => 'studentadmissionprocess','class'=>'unwant senddeleteform')) }}



<input type="hidden" name="schooldeletelist" value="" class="schooldeletelist"/>



</form>

	<script>

		function fnOpenschoolDialogbox() {

		var url =$(this).attr("id");

    $("#dialog-confirm").html("Are you sure want to delete selected items?");

var buttonsConfig = [

    {

        text: "Ok",

        "class": "ok",

        click: function() {

		$(".senddeleteform").submit();

		$(this).dialog('close');	

        }

    },

    {

        text: "Cancel",

        "class": "cancel",

        click: function() {

		$(this).dialog('close');

        }

    }

];

    // Define the Dialog and its properties.

    $("#dialog-confirm").dialog({

        resizable: false,

        modal: true,

        title: "MTI(Malden Taxi & Malden Trans Inc)",

        height: 250,

        width: 400,

        buttons: buttonsConfig,

    });

}





		</script>



<script>

$(".resetcancelbutton").click(function(){

var docnumbers = new Array();

$('input[name="chkSelectRow[]"]:checked').each(function() {

   var selectdoc=this.value;



   docnumbers.push(selectdoc);

});

$(".schooldeletelist").val(docnumbers);

if (typeof docnumbers !== 'undefined' && docnumbers.length > 0) {

fnOpenschoolDialogbox();

}

});

</script>

  @stop