
#Web Services for Parent App
Route::post('checkparentdevice', 'MTIService@CheckParentDevice');
Route::post('registerparentdevice', 'MTIService@RegisterParentDevice');
Route::post('authenticateparent', 'MTIService@AuthenticateParent');
Route::post('showparentprofile', 'MTIService@ShowParentProfile');
Route::post('updateparentprofile', 'MTIService@UpdateParentProfile');
Route::post('showparentnotification', 'MTIService@ShowParentNotification');
Route::post('updateparentnotification', 'MTIService@UpdateParentNotification');
Route::post('showkids', 'MTIService@ShowKids');
Route::post('showkid', 'MTIService@ShowKid');
Route::post('kidsdriveronmap', 'MTIService@KidsDriverOnMap');
Route::post('updateattendance', 'MTIService@UpdateAttendance');
Route::post('getdriverlocationparent', 'MTIService@GetDriverLocationParent');


#Route::post('updateattendance', 'MTIService@UpdateDailyAttendance');


#Web Services for Bus Operator App

Route::post('checkbusoperatordevice', 'MTIService@CheckBusOperatorDevice');
Route::post('authenticatebusoperator', 'MTIService@AuthenticateBusOperator');
Route::post('showbusoperatorprofile', 'MTIService@ShowBusOperatorProfile');
Route::post('showdrivernotification', 'MTIService@ShowDriverNotification');
Route::post('showdriverprofile', 'MTIService@ShowDriverProfile');
Route::post('updatedriverprofile', 'MTIService@UpdateDriverProfile');
Route::post('updatedrivernotification', 'MTIService@UpdateDriverNotification');
Route::post('showtotalpickup', 'MTIService@ShowTotalPickUp');
Route::post('kidsonmap', 'MTIService@KidsOnMap');
Route::post('driverlatlong', 'MTIService@DriverLatLong');
Route::post('getstudentdetail', 'MTIService@GetStudentDetail');
Route::post('updatebusoperatorprofile', 'MTIService@UpdateBusOperatorProfile');
Route::post('updatedriverlocation', 'MTIService@UpdateDriverLocation');
Route::post('getdriverlocation', 'MTIService@GetDriverLocation');
Route::post('markattendance', 'MTIService@MarkAttendance');
Route::post('alertparent', 'MTIService@AlertParent');


#Public Function


Route::post('clickam', 'MTIService@ClickAM');
Route::post('clickpm', 'MTIService@ClickPM');
Route::post('schoolreached', 'MTIService@SchoolReached');

